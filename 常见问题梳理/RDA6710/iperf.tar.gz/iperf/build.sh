tar zxf iperf-2.0.5.tar.gz
cd iperf-2.0.5
ac_cv_func_malloc_0_nonnull=yes ac_cv_func_realloc_0_nonnull=yes ./configure --host=mips-linux CC=mipsel-unknown-linux-uclibc-gcc CXX=mipsel-unknown-linux-uclibc-g++ --disable-ipv6 LDFLAGS=-static
make
mipsel-unknown-linux-uclibc-strip src/iperf
cd ..
ls iperf-2.0.5/src/iperf -al
cp iperf-2.0.5/src/iperf .
