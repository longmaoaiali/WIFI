#ifndef _IPERF_INCLUDE_IPERF_INT_H
#define _IPERF_INCLUDE_IPERF_INT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "iperf 2.0.5"
/* generated using gnu compiler mipsel-unknown-linux-uclibc-gcc (Buildroot 2012.05) 4.6.3 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
