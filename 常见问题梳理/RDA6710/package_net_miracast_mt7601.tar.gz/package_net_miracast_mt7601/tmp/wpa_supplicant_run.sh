HOSTAPD_ROOT_PATH=/bin
chmod 777 $HOSTAPD_ROOT_PATH/./*

$HOSTAPD_ROOT_PATH/./wpa_supplicant -iwlan0 -Dnl80211 -c ../etc/wpa_supplicant.conf -P ../etc/wpa_pidfile -d -B
$HOSTAPD_ROOT_PATH/./wpa_supplicant -ip2p0 -Dnl80211 -c ../etc/p2p_supplicant.conf -P ../etc/wpa_p2p_pidfile -d -B
