HOSTAPD_ROOT_PATH=/bin
chmod 777 $HOSTAPD_ROOT_PATH/./*

#echo 0 > /proc/sys/kernel/printk
rm wpa_ctrl_*
rm wfa.*
killall -9 udhcpd
killall -9 udhcpc
#killall -9 wpa_supplicant
killall -9 wpa_cli
sleep 1

#$HOSTAPD_ROOT_PATH/./wpa_supplicant -iwlan0 -Dnl80211 -c ../etc/wpa_supplicant.conf -B
#$HOSTAPD_ROOT_PATH/./wpa_supplicant -ip2p0 -Dnl80211 -c ../etc/p2p_supplicant.conf -B
$HOSTAPD_ROOT_PATH/./wpa_cli -ip2p0 -a ../tmp/p2p-action.sh &
