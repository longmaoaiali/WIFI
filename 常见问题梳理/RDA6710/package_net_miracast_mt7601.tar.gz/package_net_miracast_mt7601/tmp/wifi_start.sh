#!/bin/sh

insmod /tmp/mt7601Usta.ko
#rm /tmp/mt7601Usta.ko
sleep 1
ifconfig wlan0 up

