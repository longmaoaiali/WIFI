#include "TestRTSPClient.h"
#include "Utils.h"
#include "BasicUsageEnvironment.hh"
#include "DigestAuthentication.hh"
#include "MPEG4LATMAudioRTPSource.hh"
#include "GroupsockHelper.hh"
#include "WFDH264Sink.h"
#include "WFDAACSink.h"
#include "WFDMediaSink.h"
#include "ScopedMutex.h"
#include "myCfg.h"

namespace rtsp
{
#define CHECK_NULL_COND(condition, ret) \
    if (NULL == (condition)) \
    { \
        WFD_LOG_ERR("error!"); \
        return (ret); \
    }

static TaskScheduler* scheduler = NULL;
static UsageEnvironment * env = NULL;
static int iSetupCount = 0;
static unsigned int fileSinkBufferSize = 100000;
const unsigned int maxBufSize = 1024*1024;
extern bool bUseTcp;

void TestRTSPClient::SenderhandResponse(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    //TestRTSPClient *client = dynamic_cast<TestRTSPClient *>(rtspClient);
    TestRTSPClient *client = (TestRTSPClient *)rtspClient;
    if (NULL == client)
    {
        WFD_LOG_ERR("error!\n");
        return;
    }

    client->SenderhandResponse1(resultCode, resultString);
}

void TestRTSPClient::SenderhandResponse1(int resultCode, char* resultString)
{
    //ScopedMutex sm(locker);

    if (status == CLIENTSTATUS_DESTROY)
        return;

    bool bErr = false;

    do
    {
        if (NULL == pRtspReqSender)
        {
            WFD_LOG_ERR("error!\n");
            bErr = true;
            break;
        }

        bResponseErr = false;

        if (0 != resultCode)/*some error occur*/
        {
            WFD_LOG_ERR("response error! \nresultCode = %d\n", resultCode);
            bErr = true;
            bResponseErr = true;
            break;
        }
        SenderType type = pRtspReqSender->getSenderType();
        WFD_LOG_DEBUG("response send type = %d!\n", type);

        /*
         *TO DO: deal the result
         */
        if (SENDERTYPE_OPTINON == type)
        {
        }
        else if (SENDERTYPE_DESCRIPTION == type)
        {
            if (false == handDescription(resultString))
            {
                WFD_LOG_ERR("error\n");
                bErr = true;
                break;
            }
        }
        else if (SENDERTYPE_PLAY == type)
        {
        }
        else if (SENDERTYPE_PAUSE == type)
        {
        }
        else if (SENDERTYPE_TEARDOWN == type)
        {
        }
        else if (SENDERTYPE_SETUP== type)
        {
            if (false == handSetup(resultString))
            {
                WFD_LOG_ERR("error\n");
                bErr = true;
                break;
            }
        }
        else if (SENDERTYPE_SETPARAM== type)
        {
        }
        else if (SENDERTYPE_GETPARAM== type)
        {
        }
        else/*wrong type*/
        {
            bErr = true;
            break;
        }

    }while(0);

    if (NULL != resultString)
    {
        WFD_LOG_ERR("resultString=%s\n", resultString);
        delete[] resultString;
        resultString = NULL;
    }

    WFD_LOG_DEBUG("bErr = %d\n", bErr);

    if (false == bErr)
    {
        pRtspReqSender->callNext();
    }
    else
    {
        WFD_LOG_DEBUG("wake up waiters\n");
        /*wakeup all waiters */
        wakeupWaiters();
    }
}


void subsessionAfterPlaying(void* clientData)
{
    WFD_LOG_DEBUG("sub session play end!\n");
}

bool TestRTSPClient::handDescription(char* resultString)
{
    CHECK_NULL_COND(resultString, false);


    char* sdpDescription = resultString;
    //LOG_DEBUG("SDP description:%s", sdpDescription);

    // Create a media session object from this SDP description:
    session = MediaSession::createNew(*env, sdpDescription);
    if (session == NULL)
    {
            WFD_LOG_ERR("Failed to create a MediaSession object from the SDP description: %s\n", env->getResultMsg());
            return false;
    }
    if (!session->hasSubsessions())
    {
            WFD_LOG_ERR("This session has no media subsessions (i.e., \"m=\" lines)\n");
            Medium::close(session);
            session = NULL;
            return false;
    }

    /*
     *TO DO:GET THE TIME RANGE
     */
    fStartTime = session->playStartTime();
    if (fStartTime < 0)
    {
        fStartTime = 0.0f;
    }

    fEndTime= session->playEndTime();
    if (fEndTime < 0)
    {
        fEndTime = -1.0f;
    }

    {
        /*send setup requesst count*/
        iSetupCount = 0;
    }

    // Then, setup the "RTPSource"s for the session:
    MediaSubsessionIterator iter(*(session));
    MediaSubsession *subsession = NULL;
    RtspReqSender *senderSave = pRtspReqSender->getNext();
    if (senderSave == NULL)
    {
        WFD_LOG_ERR("error");
        return false;
    }
    CmdSenderDecorator *senderMove = pRtspReqSender;

    while ((subsession = iter.next()) != NULL)
    {
        if (!subsession->initiate(-1))
        {
            WFD_LOG_ERR("warning\n");
            continue;
        }

        if (subsession->rtpSource() != NULL)
        {
#if 0
            // Because we're saving the incoming data, rather than playing
            // it in real time, allow an especially large time threshold
            // (1 second) for reordering misordered incoming packets:
            unsigned const thresh = 1000000; // 1 second
            subsession->rtpSource()->setPacketReorderingThresholdTime(thresh);
#endif
#if 0
            // Set the RTP source's OS socket buffer size as appropriate - either if we were explicitly asked (using -B),
            // or if the desired FileSink buffer size happens to be larger than the current OS socket buffer size.
            // (The latter case is a heuristic, on the assumption that if the user asked for a large FileSink buffer size,
            // then the input data rate may be large enough to justify increasing the OS socket buffer size also.)
            int socketNum = subsession->rtpSource()->RTPgs()->socketNum();
            unsigned curBufferSize = getReceiveBufferSize(*env, socketNum);
            WFD_LOG_DEBUG("old receive buffer size:%d", curBufferSize);
            if (fileSinkBufferSize > curBufferSize)
            {
                unsigned newBufferSize = setReceiveBufferTo(*env, socketNum, fileSinkBufferSize);
                WFD_LOG_DEBUG("new receive buffer size:%d", newBufferSize);
            }
#else
            int socketNum = subsession->rtpSource()->RTPgs()->socketNum();
            unsigned newBufferSize = setReceiveBufferTo(*env, socketNum, maxBufSize);
            WFD_LOG_DEBUG("new receive buffer size:%d\n", newBufferSize);
#endif
        }

        if (subsession->readSource() == NULL)
        {
            WFD_LOG_ERR("warning");
            continue; // was not initiated
        }

        /*
         *TO DO:SET UP SUBSESSION
         */
        SetupSender *setupSender = new SetupSender(*senderSave);
        if (setupSender == NULL)
        {
            WFD_LOG_ERR("warning\n");
            continue;
        }

        sender->RecordSender(setupSender);
        senderMove->setNext(setupSender);
        senderMove = setupSender;
        setupSender->setRspHandler(respHandler);
        setupSender->setSubsession(subsession);

        if (bUseTcp == true)
        {
            if (subsession->clientPortNum() != 0)
            {
                WFD_LOG_DEBUG("sub session %p using tcp port :%d!\n", subsession, subsession->clientPortNum());
                setupSender->setParam(false, true, false);
            }
        }

        iSetupCount++;

        WFD_LOG_DEBUG("subsession, name:%s, codec:%s\n", subsession->mediumName(), subsession->codecName());
    }

    return true;
}

unsigned int TestRTSPClient::getBufType(MediaSubsession * subsession)
{
    if (subsession == NULL)
        return 0;
    if (subsession->rtpSource() == NULL)
        return 0;

    int pt = (int)subsession->rtpSource()->rtpPayloadFormat();

    WFD_LOG_DEBUG("pay load type:%d!\n", pt);

    /*
     *get media type by payload type
     */
    /*AUDIO*/
    if ((0 <= pt) && (pt <= 18))
    {
        return mediatype_audio;
    }

    /*AV*/
    if (pt == 33)
    {
        return mediatype_av;
    }

    /*VIDEO*/
    switch (pt)
    {
        case 25:
        case 26:
        case 31:
        case 32:
        case 34:
            return mediatype_video;
    }

    /*
     *get media type by medium name
     */
    if (NULL != subsession->mediumName())
    {
        if (strncasecmp(subsession->mediumName(), "audio", 5) == 0)
        {
            return mediatype_audio;
        }
        else if (strncasecmp(subsession->mediumName(), "video", 5) == 0)
        {
            return mediatype_video;
        }
    }

    /*
     *get media type by codec
     */
    /*h264*/
    if (strcmp(subsession->codecName(), "H264") == 0)
    {
        return mediatype_video;
    }
    else if (strcmp(subsession->codecName(), "MP4V-ES") == 0)
    {
        return mediatype_video;
    }
    else if (strcmp(subsession->codecName(), "MPEG4-GENERIC") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "AC3") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "AMR") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "AMR-WB") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "MPA-ROBUST") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "X-MP3-DRAFT-00") == 0)
    {
        return mediatype_audio;
    }
    else if (strcmp(subsession->codecName(), "MP4A-LATM") == 0)
    {
        return mediatype_audio;
    }

    return 0;
}
bool TestRTSPClient::handSetup(char* resultString)
{
    CHECK_NULL_COND(session, false);
    CHECK_NULL_COND(rtsp::env, false);

    bool bSuccess = false;

    // Then, setup the "RTPSource"s for the session:
    MediaSubsessionIterator iter(*(session));
    MediaSubsession *subsession = NULL;
    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() == NULL)
        {
            WFD_LOG_ERR("warning");
            continue; // was not initiated
        }

        if (subsession->sink != NULL)/*already be set*/
        {
            continue;
        }

        unsigned int type = getBufType(subsession);
        if (type == 0)
        {
            WFD_LOG_ERR("error type=%d\n", type);
            continue;
        }

        {
            iSetupCount--;
            /*set mediay info*/
            setMediaInfo(subsession, type);
        }

        WFDMediaSink *sink = NULL;
        if ((type != mediatype_audio) && (strcmp(subsession->codecName(), "H264") == 0))
        {
            sink = WFDH264Sink::createNew(*env, subsession->fmtp_spropparametersets(),
                                                type, fileSinkBufferSize);
        }
        else if ((type == mediatype_audio) &&
                    ((stMediaInfo.audioCodec == MEDIACODEC_AC3) ||
                     (stMediaInfo.audioCodec == MEDIACODEC_EAC3) ||
                     (stMediaInfo.audioCodec == MEDIACODEC_MPEG4_GENERIC) ||
                     (stMediaInfo.audioCodec == MEDIACODEC_MP4A_LATM)))
        {
            sink = WFDAACSink::createNew(*env, type, fileSinkBufferSize, subsession);
        }
        else
        {
            sink = WFDMediaSink::createNew(*env, type, fileSinkBufferSize);
        }
        subsession->sink = sink;
        if (subsession->sink == NULL)
        {
            WFD_LOG_ERR("error!\n");
        }
        else
        {
            if ((type != mediatype_audio) && (strcmp(subsession->codecName(), "MP4V-ES") == 0)
                && (subsession->fmtp_config() != NULL))
            {
                parseMpeg(sink,subsession);
            }
                rtspStartPlay(subsession);
               bSuccess = true;
        }

        break;

    }

    if (iSetupCount == 0)
    {
        mediaInfoReady();
    }

    return bSuccess ;
}




TestRTSPClient::TestRTSPClient(dealResultHandler *handler, char const* rtspURL,
               int verbosityLevel, char const* applicationName,
               portNumBits tunnelOverHTTPPortNum):
               RTSPClient(*env, rtspURL, verbosityLevel, applicationName, tunnelOverHTTPPortNum),
               pRtspReqSender(NULL), auth(NULL), session(NULL), sender(NULL),status(CLIENTSTATUS_UNINIT),
               cIsCmdSendEnd(0), fStartTime(0.0f), fEndTime(-1.0f),
               bMediaInfoReady(false), bResponseErr(false), respHandler(handler)
{
    memset(&stMediaInfo, 0, sizeof(stMediaInfo));
}

TestRTSPClient::~TestRTSPClient()
{
    pRtspReqSender = NULL;
    destroy();
}

TestRTSPClient* TestRTSPClient::createNew(char const* rtspURL, dealResultHandler *handler,
                                            char const* username, char const* pwd)
{
    if (scheduler != NULL)
    {
        delete scheduler;
        scheduler = NULL;
    }

    if (env != NULL)
    {
        env->reclaim();
        env = NULL;
    }

    if (scheduler == NULL)
    {
        scheduler = BasicTaskScheduler::createNew();
    }
    CHECK_NULL_COND(scheduler, NULL);
    if (env == NULL)
    {
        env = BasicUsageEnvironment::createNew(*scheduler);
    }
    CHECK_NULL_COND(env, NULL);

    TestRTSPClient* client =  new TestRTSPClient(handler, rtspURL, 0, "test.bin", 0);
    CHECK_NULL_COND(client, NULL);

    if ((username != NULL ) || (pwd != NULL))
    {
        Authenticator * _auth = new Authenticator(username,pwd);
        client->auth = _auth;
    }

    return client;
}

bool TestRTSPClient::play()
{
    //ScopedMutex sm(locker);

    if (status != CLIENTSTATUS_CONNECTED)
    {
        WFD_LOG_ERR("can't play, current status:%d!\n", (int)status);
        return false;
    }


    PlaySender * playSender = new PlaySender(*sender);
    CHECK_NULL_COND(playSender, false);
    sender->RecordSender(playSender);

    playSender->setRange(fStartTime, fEndTime);
    playSender->setRspHandler(respHandler);
    bool bRet = playSender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_PLAYED;
    iSetupCount = 0;

    return true;
}


bool TestRTSPClient::connect()
{
    //ScopedMutex sm(locker);

    if ((status != CLIENTSTATUS_UNINIT) &&
        (status != CLIENTSTATUS_STOPPED))
    {
        WFD_LOG_ERR("can't connect, current status:%d!\n", (int)status);
        return false;
    }

    sender = new SenderInit(this, auth);
    CHECK_NULL_COND(sender, false);

    DspSender *dspsender = new DspSender(*sender);
    CHECK_NULL_COND(dspsender, false);
    sender->RecordSender(dspsender);

    dspsender->setRspHandler(respHandler);

    OptionSender * optionsender = new OptionSender(*dspsender);
    CHECK_NULL_COND(optionsender, false);
    sender->RecordSender(optionsender);

    optionsender->setRspHandler(respHandler);
    bool bRet = optionsender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_CONNECTED;

    return true;
}

bool TestRTSPClient::pause()
{
    //ScopedMutex sm(locker);

    if (status != CLIENTSTATUS_PLAYED)
    {
        WFD_LOG_ERR("can't pause, current status:%d!\n", (int)status);
        return false;
    }

    CHECK_NULL_COND(sender, false);

    PauseSender * pauseSender = new PauseSender(*sender);
    CHECK_NULL_COND(pauseSender, false);
    sender->RecordSender(pauseSender);

    pauseSender->setRspHandler(respHandler);
    bool bRet = pauseSender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_PAUSED;

    return true;
}

bool TestRTSPClient::resume()
{
    //ScopedMutex sm(locker);

    if (status != CLIENTSTATUS_PAUSED)
    {
        WFD_LOG_ERR("can't resume, current status:%d!\n", (int)status);
        return false;
    }

    CHECK_NULL_COND(sender, false);
    CHECK_NULL_COND(session, false);

    PlaySender * playSender = new PlaySender(*sender);
    CHECK_NULL_COND(playSender, false);
    sender->RecordSender(playSender);

    playSender->setRange(-1.0f, fEndTime);

    playSender->setRspHandler(respHandler);
    bool bRet = playSender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_PLAYED;

    return true;
}

bool TestRTSPClient::stop()
{
    //ScopedMutex sm(locker);

    if ((status == CLIENTSTATUS_UNINIT) ||
        (status == CLIENTSTATUS_STOPPED))
    {
        WFD_LOG_ERR("can't stop, current status:%d!\n", (int)status);
        return false;
    }

    CHECK_NULL_COND(sender, false);

    TeardownSender * teardownSender = new TeardownSender(*sender);
    CHECK_NULL_COND(teardownSender, false);
    sender->RecordSender(teardownSender);

    teardownSender->setRspHandler(respHandler);
    bool bRet = teardownSender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_STOPPED;

    return true;
}

bool TestRTSPClient::timeseek(unsigned int uiTime)
{
    //ScopedMutex sm(locker);

    if ((status != CLIENTSTATUS_PLAYED) &&
        (status != CLIENTSTATUS_PAUSED))
    {
        WFD_LOG_ERR("can't play, current status:%d!\n", (int)status);
        return false;
    }

    CHECK_NULL_COND(sender, false);
    CHECK_NULL_COND(session, false);

    PlaySender * playSender = new PlaySender(*sender);
    CHECK_NULL_COND(playSender, false);
    sender->RecordSender(playSender);

    WFD_LOG_DEBUG("start time=%f, end time=%f, seek time=%d!\n", fStartTime, fEndTime, uiTime);

    if (fEndTime> 0)
    {
        if (uiTime > fEndTime)
        {
            return false;/*seek time error*/
        }
    }
    fStartTime = uiTime + 0.0f;
    playSender->setRange(fStartTime, fEndTime);

    playSender->setRspHandler(respHandler);
    bool bRet = playSender->sendRequest();
    if (false == bRet)
    {
        WFD_LOG_ERR("error!\n");
        return false;
    }

    status = CLIENTSTATUS_PLAYED;

    return true;
}

void TestRTSPClient::watcherBegin()
{
    cIsCmdSendEnd = 0;
    env->taskScheduler().doEventLoop(&cIsCmdSendEnd);
    //env->taskScheduler().doEventLoop();
}

void TestRTSPClient::watcherEnd()
{
    cIsCmdSendEnd = 1;
}

void TestRTSPClient::mediaInfoReady()
{
    mediaInfoWaiter.syncBegin();
    bMediaInfoReady = true;
    mediaInfoWaiter.notifyAll();
    mediaInfoWaiter.syncEnd();
}

void TestRTSPClient::wakeupWaiters()
{
    mediaInfoWaiter.syncBegin();
    WFD_LOG_DEBUG("wake up waiters notify all\n");
    mediaInfoWaiter.notifyAll();
    mediaInfoWaiter.syncEnd();
}

void TestRTSPClient::setMediaInfo(MediaSubsession *subsession, unsigned int type)
{
    MediaCodec codec;

#if 0
    if (strcmp(subsession->codecName(), "QCELP") == 0)
    {
        codec = MEDIACODEC_QCELP;
    }
    else
#endif
    if (strcmp(subsession->codecName(), "MPA") == 0)
    {
        codec = MEDIACODEC_MPA;
    }
    else if (strcmp(subsession->codecName(), "MPA-ROBUST") == 0)
    {
        codec = MEDIACODEC_MPA_ROBUST;
    }
    else if (strcmp(subsession->codecName(), "X-MP3-DRAFT-00") == 0)
    {
        codec = MEDIACODEC_X_MP3_DRAFT_00;
    }
    else if (strcmp(subsession->codecName(), "MP4A-LATM") == 0)
    {
        codec = MEDIACODEC_MP4A_LATM;
    }
    else if (strcmp(subsession->codecName(), "AC3") == 0)
    {
        codec = MEDIACODEC_AC3;
    }
    else if (strcmp(subsession->codecName(), "EAC3") == 0)
    {
        codec = MEDIACODEC_EAC3;
    }
    else if (strcmp(subsession->codecName(), "MP4V-ES") == 0)
    {
        codec = MEDIACODEC_MP4V_ES;
    }
    else if (strcmp(subsession->codecName(), "MPEG4-GENERIC") == 0)
    {
        codec = MEDIACODEC_MPEG4_GENERIC;
    }
    else if (strcmp(subsession->codecName(), "MPV") == 0)
    {
        codec = MEDIACODEC_MPV;
    }
    else if (strcmp(subsession->codecName(), "MP2T") == 0)
    {
        codec = MEDIACODEC_MP2T;
    }
#if 0
    else if (strcmp(subsession->codecName(), "H263-1998") == 0)
    {
        codec = MEDIACODEC_H263_1998;
    }
    else if (strcmp(subsession->codecName(), "H263-2000") == 0)
    {
        codec = MEDIACODEC_H263_2000;
    }
#endif
    else if (strcmp(subsession->codecName(), "H264") == 0)
    {
        codec = MEDIACODEC_H264;
    }
#if 1
    else if (strcmp(subsession->codecName(), "JPEG") == 0)
    {
        codec = MEDIACODEC_JPEG;
    }
#endif
    else if (strcmp(subsession->codecName(), "PCMU") == 0)
    {
        codec = MEDIACODEC_PCMU;
    }
    else if (strcmp(subsession->codecName(), "DVI4") == 0)
    {
        codec = MEDIACODEC_DVI4;
    }
    else if (strcmp(subsession->codecName(), "PCMA") == 0)
    {
        codec = MEDIACODEC_PCMA;
    }
    else if (strcmp(subsession->codecName(), "MP1S") == 0)
    {
        codec = MEDIACODEC_MP1S;
    }
    else if (strcmp(subsession->codecName(), "MP2P") == 0)
    {
        codec = MEDIACODEC_MP2P;
    }
    else
    {
        return ;
    }

    if (type == mediatype_audio)
    {
        stMediaInfo.type += mediatype_audio;
        stMediaInfo.audioCodec = codec;
    }
    else if (type == mediatype_video)
    {
        stMediaInfo.type += mediatype_video;
        stMediaInfo.videoCodec = codec;
    }
    else if (type == mediatype_av)
    {
        stMediaInfo.type += mediatype_av;
        stMediaInfo.avCodec = codec;
    }

}

bool TestRTSPClient::getMediaInfo(MediaInfo & media)
{
    mediaInfoWaiter.syncBegin();
    while (bMediaInfoReady == false)
    {
        if (bResponseErr == true)
        {
            mediaInfoWaiter.syncEnd();
            return false;
        }

        WFD_LOG_DEBUG("get media info wait\n");
        mediaInfoWaiter.timedWait(15000);
        WFD_LOG_DEBUG("get media info wake up:%d\n", bMediaInfoReady);
        if ((bMediaInfoReady == false) || (bResponseErr == true))
        {
            mediaInfoWaiter.syncEnd();
            return false;
        }
    }
    media = stMediaInfo;
    mediaInfoWaiter.syncEnd();
    return true;
}

void TestRTSPClient::destroy()
{
    stop();

    //ScopedMutex sm(locker);

    watcherEnd();

    if (session)
    {
        MediaSubsessionIterator iter(*(session));
        MediaSubsession* subsession;
        while ((subsession = iter.next()) != NULL)
        {
             Medium::close(subsession->sink);
             subsession->sink = NULL;
        }

        Medium::close(session);
        session = NULL;
    }

    if (sender != NULL)
    {
        delete sender;
        sender = NULL;
    }

    if (auth != NULL)
    {
        delete auth;
        auth = NULL;
    }

    status = CLIENTSTATUS_DESTROY;
    return ;
}

bool TestRTSPClient::IsPacketArrived()
{
    MediaSubsessionIterator iter(*session);
    MediaSubsession* subsession;
    while ((subsession = iter.next()) != NULL)
    {
        RTPSource* src = subsession->rtpSource();
        if (src == NULL)
            continue;

        if (src->receptionStatsDB().numActiveSourcesSinceLastReset() > 0)
        {
            return true;
        }
    }

    return false;
}

}


