#include "RtspPlayer.h"
#include "PushPlayer.h"
#include "Utils.h"
#include "myCfg.h"
#include "BasicUsageEnvironment.hh"
#include "WFDClient.h"
namespace rtsp
{

static char cWaitTcpTryEnd = 0;
void * doevent_thread(void *pv_data)
{
    if(NULL == pv_data)
    {
        WFD_LOG_ERR("error!");
        return NULL;
    }

    WFD_LOG_INFO( "do event loop thread start!\n");

    RtspPlayer *player = (RtspPlayer *)pv_data;

    while(1)
    {
        player->doeventWaiter.syncBegin();
        if (player->client == NULL)
        {
            player->doeventWaiter.wait();
            if ((player->bAlive == false) ||
                (player->client == NULL))
            {
                player->doeventWaiter.syncEnd();
                break;
            }
        }
        player->doeventWaiter.syncEnd();

        player->client->watcherBegin();
    }

    WFD_LOG_INFO( "do event loop thread exit!\n");

    return NULL;
}

static ThreadObject watcher(doevent_thread);

#define CHECK_FALSE_COND(condition, ret) \
    if (false == (condition)) \
    { \
        WFD_LOG_ERR( "error!\n"); \
        return (ret); \
    }

RtspPlayer::RtspPlayer():client(NULL), status(RTSPPLAYERSTATUS_STOPPED), bAlive(true),
                        scheduler(NULL), env(NULL), tcpRetryTimerTask(NULL), pCmpbEventNfy(NULL),
                            pEventArg(NULL)
{
    watcher.start(this);
}

RtspPlayer::~RtspPlayer()
{
    stop();
    doeventWaiter.syncBegin();
    bAlive = false;
    doeventWaiter.notifyAll();
    doeventWaiter.syncEnd();
    if (scheduler!= NULL)
    {
        delete scheduler;
        scheduler = NULL;
    }

    if (env!= NULL)
    {
        env->reclaim();
    }
}

RtspPlayer * RtspPlayer::createNew()
{
    RtspPlayer * player = new RtspPlayer();
    if (NULL == player)
    {
        WFD_LOG_ERR( "error!\n");
    }

    rtsp::setTcpFlag(false);

    return player;
}

void RtspPlayer::delRtspClient()
{
    doeventWaiter.syncBegin();
    if (client)
        delete client;
    client = NULL;
    doeventWaiter.notifyAll();
    doeventWaiter.syncEnd();
}

void ReConnectUseTcp(void * arg)
{
    WFD_LOG_INFO( "enter ReConnectUseTcp\n");
    cWaitTcpTryEnd = 1;

    //ScopedMutex sm(locker);

    if (!arg)
    {
        WFD_LOG_ERR( "ReConnectUseTcp arg error\n");
        return;
    }

    RtspPlayer * player = (RtspPlayer *)arg;

    player->tcpRetryTimerTask = NULL;/*doesn't need to delete*/

    if (player->client)
        if (player->client->IsPacketArrived())
        {
            WFD_LOG_INFO( "udp can received data\n");
            return;
        }

    if (player->status != RTSPPLAYERSTATUS_PLAYED)
    {
        WFD_LOG_ERR( "wrong status :%d\n", player->status);
        return ;
    }

    if (player->client != NULL)
    {
        player->client->stop();
    }

    player->delRtspClient();

    PushPlayer::instance().stop();

    player->status = RTSPPLAYERSTATUS_STOPPED;

    player->doeventWaiter.syncBegin();
    player->client = TestRTSPClient::createNew(player->rtspUrl.c_str());
    if (NULL == player->client)
    {
        WFD_LOG_ERR("error!");
        player->doeventWaiter.syncEnd();
        return ;
    }

    player->doeventWaiter.notifyAll();
    player->doeventWaiter.syncEnd();

    rtsp::setTcpFlag(true);

    if (false == player->client->connect())
    {
        WFD_LOG_ERR("error!");
        return;
    }

    MediaInfo media;
    if (false == player->client->getMediaInfo(media))
    {
        WFD_LOG_ERR("error!");
        return;
    }

    if (false == PushPlayer::instance().SetMediaInfo(media))
    {
        WFD_LOG_ERR("not support!");
        return;
    }

    if (false == PushPlayer::instance().open(player->pCmpbEventNfy, player->pEventArg))
    {
        WFD_LOG_ERR("error!");
        return;
    }

    if (false == PushPlayer::instance().play())
    {
        WFD_LOG_ERR("error!");
        return;
    }

    if (false == player->client->play())
    {
        WFD_LOG_ERR("error!");
        return;
    }

    WFD_LOG_DEBUG("player restarted!");
    player->status = RTSPPLAYERSTATUS_PLAYED;

    return ;
}

void RtspPlayer::setTcpRetry()
{
    //ScopedMutex sm(locker);

    if (scheduler == NULL)
    {
        scheduler = BasicTaskScheduler::createNew();
    }
    if (!scheduler)
    {
        WFD_LOG_ERR("error");
        return;
    }
    if (env == NULL)
    {
        env = BasicUsageEnvironment::createNew(*scheduler);
    }
    if (!env)
    {
        WFD_LOG_ERR("error");
        return;
    }


    if (!tcpRetryTimerTask)
    {
        tcpRetryTimerTask = env->taskScheduler().scheduleDelayedTask(10000000, (TaskFunc *)ReConnectUseTcp, this);
    }
    if (!tcpRetryTimerTask)
    {
        WFD_LOG_ERR("set scheduleDelayedTask failed");
    }
    else
    {
        WFD_LOG_DEBUG("set scheduleDelayedTask success");
    }

    cWaitTcpTryEnd = 0;
}


bool RtspPlayer::play(std::string & url, IMtkPb_Ctrl_Nfy_Fct fCmpbEventNfy, void* pvTag)
{
    //ScopedMutex sm(locker);

    pCmpbEventNfy = fCmpbEventNfy;
    pEventArg = pvTag;

    bool ret = true;

    /*the same url & current status is paused*/
    if ((rtspUrl.compare(url) == 0) && (rtspUrl.length() != 0))
    {
        if (status == RTSPPLAYERSTATUS_PAUSED)
        {
            ret = client->resume();
            //CHECK_FALSE_COND(ret, false);

            ret = PushPlayer::instance().resume();
            CHECK_FALSE_COND(ret, false);

            WFD_LOG_DEBUG("player resume!");
            status = RTSPPLAYERSTATUS_PLAYED;
            return true;
        }
        else if (status == RTSPPLAYERSTATUS_PLAYED)
        {
            return true;
        }
        else if (status == RTSPPLAYERSTATUS_STOPPED)
        {
            //do nothing, not return here
        }
        else
        {
            WFD_LOG_ERR("player current status:%d!", status);
            return false;
        }
    }

    /*different url or current type is stopped*/
    if (url.empty())
    {
        WFD_LOG_ERR("error!");
        return false;
    }

    if (client != NULL)
    {
        ret = client->stop();
        CHECK_FALSE_COND(ret, false);

        delRtspClient();

        ret = PushPlayer::instance().stop();
        CHECK_FALSE_COND(ret, false);

        status = RTSPPLAYERSTATUS_STOPPED;
    }

    doeventWaiter.syncBegin();
    client = TestRTSPClient::createNew(url.c_str());
    if (NULL == client)
    {
        WFD_LOG_ERR("error!");
        doeventWaiter.syncEnd();
        return false;
    }

    doeventWaiter.notifyAll();
    doeventWaiter.syncEnd();

    do
    {
        rtsp::setTcpFlag(false);

        if (false == client->connect())
        {
            WFD_LOG_ERR("error!");
            break;
        }

        MediaInfo media;
        if (false == client->getMediaInfo(media))
        {
            WFD_LOG_ERR("error!");
            break;
        }

        if (false == PushPlayer::instance().SetMediaInfo(media))
        {
            WFD_LOG_ERR("not support!");
            break;
        }

        if (false == PushPlayer::instance().open(fCmpbEventNfy, pvTag))
        {
            WFD_LOG_ERR("error!");
            break;
        }

        if (false == PushPlayer::instance().play())
        {
            WFD_LOG_ERR("error!");
            break;
        }

        if (false == client->play())
        {
            WFD_LOG_ERR("error!");
            break;
        }

        rtspUrl = url;
        WFD_LOG_DEBUG("player started!");
        status = RTSPPLAYERSTATUS_PLAYED;

        if (env)
        {
            WFD_LOG_DEBUG("begin wait env task exec");
            env->taskScheduler().doEventLoop(&cWaitTcpTryEnd);
            WFD_LOG_DEBUG("end wait env task exec");
        }

        return true;

    }while(0);

    PushPlayer::instance().stop();
    delRtspClient();
    return false;
}

bool RtspPlayer::pause(bool bBufferData)
{
    //ScopedMutex sm(locker);
    bool ret = true;

    if (status != RTSPPLAYERSTATUS_PLAYED)
    {
        WFD_LOG_ERR("player current status:%d!", status);
        return false;
    }

    if (false == bBufferData)
    {
        ret = client->pause();
        CHECK_FALSE_COND(ret, false);
    }

    ret = PushPlayer::instance().pause();
    CHECK_FALSE_COND(ret, false);

    status = RTSPPLAYERSTATUS_PAUSED;
    return true;
}

bool RtspPlayer::stop()
{
    //ScopedMutex sm(locker);

    if (tcpRetryTimerTask)
    {
        if (env)
        {
            WFD_LOG_DEBUG("remove taskScheduler reconnect use tcp");
            env->taskScheduler().unscheduleDelayedTask(tcpRetryTimerTask);
            tcpRetryTimerTask = NULL;
        }
    }
    bool ret = true;

    if ((status != RTSPPLAYERSTATUS_PLAYED) &&
        (status != RTSPPLAYERSTATUS_PAUSED))
    {
        WFD_LOG_ERR("player current status:%d!", status);
        return false;
    }
    WFD_LOG_DEBUG("rtsp player stop begin");

    ret = client->stop();
    CHECK_FALSE_COND(ret, false);
    WFD_LOG_DEBUG("rtsp push player stop begin");

    delRtspClient();

    ret = PushPlayer::instance().stop();
    CHECK_FALSE_COND(ret, false);

    status = RTSPPLAYERSTATUS_STOPPED;

    return true;
}

bool RtspPlayer::timeseek(unsigned int uiTime)
{
    //ScopedMutex sm(locker);
#if 0
    bool ret = client->pause();
    CHECK_FALSE_COND(ret, false);
#endif

    bool ret = true;

    if ((status != RTSPPLAYERSTATUS_PLAYED) &&
        (status != RTSPPLAYERSTATUS_PAUSED))
    {
        WFD_LOG_ERR("player current status:%d!", status);
        return false;
    }

    ret = client->timeseek(uiTime);
    CHECK_FALSE_COND(ret, false);

    status = RTSPPLAYERSTATUS_PLAYED;
    return true;
}

}
