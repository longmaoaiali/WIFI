#define WFD_LOG_TAG "MediaBufPool"

#include "MediaBufPool.h"
#include "assert.h"
#include "Utils.h"


namespace rtsp
{
static const unsigned int CMPB_PRIVATE_PS_BUF_SIZE = 4512 * 4;

#define ADVANCE_BUF_POS(pos) \
    do{\
        pos++;\
        if (pos == WFD_BUF_CHAIN_LEN)\
            pos = 0;\
    }while(0)

#define ADVANCE_BUF_POS_CNT(pos, cnt) \
    do{\
        pos+=cnt;\
        if (pos >= WFD_BUF_CHAIN_LEN)\
            pos = pos - WFD_BUF_CHAIN_LEN;\
    }while(0)

MediaBufPool::MediaBufPool()
{
    WFD_MUTEX_INIT(bufCtrlMutex);
    WFD_MUTEX_INIT(mediaPlayDataRdyMutex);
}

MediaBufPool::~MediaBufPool()
{
    WFD_MUTEX_DESTROY(bufCtrlMutex);
    WFD_MUTEX_UNLOCK(mediaPlayDataRdyMutex); //let pushPlayerThread could exit if it is in data wait state.
    WFD_MUTEX_DESTROY(mediaPlayDataRdyMutex);
}

int MediaBufPool::ReInitBufPool(void)
{
    int ii;
    unsigned char *ptr = NULL;

    mediaBufPool.w_idx = 0;
    mediaBufPool.r_idx = 0;
    mediaBufPool.w_start_pos = 0;
    mediaBufPool.bufferred_size = 0;
    mediaBufPool.total_size = WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE;
    memset(mediaBufPool.bufPool, 0, WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE);
    ptr = mediaBufPool.bufPool;
    /* arrange buf idx */
    for (ii=0; ii< WFD_BUF_CHAIN_LEN; ii++)
    {
        mediaBufPool.bufIdx[ii] = ptr;
        ptr += WFD_TS_BUF_UNIT_SIZE;
    }
    return 0;
}

int MediaBufPool::ClearBufPool(void)
{
    WFD_MUTEX_LOCK(bufCtrlMutex);
    mediaBufPool.w_idx = 0;
    mediaBufPool.r_idx = 0;
    mediaBufPool.w_start_pos = 0;
    mediaBufPool.bufferred_size = 0;
    mediaBufPool.total_size = WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE;
    WFD_MUTEX_UNLOCK(bufCtrlMutex);
    return 0;
}

int MediaBufPool::CreateBufPool(void)
{
    int ret = 0;

    memset(&mediaBufPool, 0, sizeof(BufferPool));
    /* allocate buffer */
    mediaBufPool.bufPool = new unsigned char[WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE];
    if (!mediaBufPool.bufPool)
    {
        WFD_LOG_ERR( "Failed to allocated mediaBufPool\n");
        return -1;
    }
    ret = ReInitBufPool();
    return ret;
}

int MediaBufPool::DestroyBufPool(void)
{
    if (mediaBufPool.bufPool)
         delete[] mediaBufPool.bufPool;

    memset(&mediaBufPool, 0, sizeof(BufferPool));
    return 0;
}


/*
*   @fillBufferPool: insert the buffer to the pool, untill pool is full, then insert the rest to the next pool
*   @param data/dataSize: the buffer need to be inserted to the pool
*   @param pool/poolSize : the pool
*   @param resetPool: to reset the pool
*   @return: 1: pool is full;  0: pool is not full; -1: error
*/
int MediaBufPool::fillBufferPool(unsigned char * data,unsigned int dataSize,
        unsigned char * pool,unsigned int poolSize, bool resetPool)
{
    int isPoolFull = 0;
    static unsigned int poolIndex = 0;
    static unsigned char* restData = new unsigned char[CMPB_PRIVATE_PS_BUF_SIZE];
    static unsigned int restSize = 0;
    assert(restData);
    if(resetPool)
    {
        WFD_LOG_ERR( "pool reset\n");
        isPoolFull = 0;
        poolIndex = 0;
        restSize = 0;
        return 0;
    }

    assert(data);
    assert(pool);
    if(poolSize == 0)
    {
        WFD_LOG_ERR("Error pool size is 0");
        return -1;
    }
    if(dataSize == 0)
    {
        WFD_LOG_ERR("Error data size is 0");
        return -1;
    }

    WFD_LOG_DEBUG("dataSize = %u, poolSize = %u, poolIndex = %u ", dataSize, poolSize, poolIndex);
    assert(dataSize + restSize < poolSize); // assume the restSize is small
    if(restSize > 0)
    {
        WFD_LOG_DEBUG("restSize = %u ", restSize);
        memcpy(pool, restData, restSize);
        poolIndex += restSize;
        restSize = 0;
    }

    if(poolIndex + dataSize < poolSize)
    {
        memcpy(pool + poolIndex, data, dataSize);
        poolIndex += dataSize;
        isPoolFull = 0;
    }
    else if(poolIndex + dataSize >= poolSize)
    {
        unsigned int copySize = poolSize - poolIndex;
        restSize = dataSize - copySize;
        memcpy(pool + poolIndex, data, copySize);
        poolIndex = 0;
        isPoolFull = 1;
        if(restSize > 0)
        {
            memcpy(restData, data + copySize, restSize);
        }
    }

    return isPoolFull;
}


/*
*   @mediaBufPoolPut: insert the buffer to the pool, untill pool is full, then insert the rest to the next pool
*   @param data/dataSize: the buffer need to be inserted to the pool
*   @return: 0: ok, otherwise: fail.
*/
int MediaBufPool::mediaBufPoolPut(unsigned char * data,unsigned int dataSize)
{
    BufferPool *pool;
    int remain_len = 0;
    unsigned char *curbufidx = NULL;
    int ret = 0;
    int data_size = (int)dataSize;
    int availablesize;
    int restsize;
    int next_idx = 0;

    pool = &mediaBufPool;
    /* calculate available buffer size */
    remain_len = pool->total_size - pool->bufferred_size;
    if (pool->w_idx == -1 || data_size > remain_len)
    {
        WFD_LOG_ERR( "%s: Out-Of-Buffer (req=%d, remain=%d, w_idx=%d, r_idx=%d)\n",
                __FUNCTION__, data_size, remain_len, pool->w_idx, pool->r_idx);
#ifdef WFD_RTP_STATS
        //wfd_pp_stats->oob_count ++;
#endif
        return -1;
    }
    /* start to copy data to buffer */
    if ((pool->w_start_pos + data_size) <= WFD_TS_BUF_UNIT_SIZE)
    {
        /* current bufIdx is large enough to put this data */
        curbufidx = pool->bufIdx[pool->w_idx];
        memcpy(curbufidx + pool->w_start_pos, data, data_size);
        WFD_MUTEX_LOCK(bufCtrlMutex);
        pool->w_start_pos += data_size;
        if (pool->w_start_pos == WFD_TS_BUF_UNIT_SIZE)
        {
            /* current bufIdx is full, advance w_idx */
            pool->w_start_pos = 0;
            ADVANCE_BUF_POS(pool->w_idx);
            if (pool->w_idx == pool->r_idx)
                pool->w_idx = -1; //full
            pool->bufferred_size += data_size;
            WFD_MUTEX_UNLOCK(bufCtrlMutex);
#ifdef PLAYBACK_MULTI_THREAD_ENABLE
            /* a new block is ready, notify consumer to read */
            if  (mediaPlayWaitFlag)
            {
                mediaPlayDataReadyNotify();
            }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */
        }
        else
        {
            pool->bufferred_size += data_size;
            WFD_MUTEX_UNLOCK(bufCtrlMutex);
        }
    }
    else
    {
        /* current bufIdx is not enough to put this data */
        availablesize = WFD_TS_BUF_UNIT_SIZE - pool->w_start_pos;
        restsize = data_size - availablesize;
        if (restsize > WFD_TS_BUF_UNIT_SIZE)
        {
            WFD_LOG_ERR( "!!!ERRPR!!! data is too large to put.!!!!\n");
            assert(0);
        }
        curbufidx = pool->bufIdx[pool->w_idx];
        memcpy(curbufidx + pool->w_start_pos, data, availablesize);
        next_idx = pool->w_idx;
        ADVANCE_BUF_POS(next_idx);
        if (next_idx == pool->r_idx)
        {
            WFD_LOG_ERR( "!!!ERROR!!!! buf idx is incorrect !!!!\n");
            assert(0);
        }
        curbufidx = pool->bufIdx[next_idx];
        memcpy(curbufidx, data+availablesize, restsize);
        WFD_MUTEX_LOCK(bufCtrlMutex);
        pool->w_start_pos = restsize;
        if (pool->w_start_pos == WFD_TS_BUF_UNIT_SIZE)
        {
            pool->w_start_pos = 0;
            ADVANCE_BUF_POS_CNT(pool->w_idx, 2);
        }
        else
        {
            ADVANCE_BUF_POS(pool->w_idx);
        }
        if (pool->w_idx == pool->r_idx)
            pool->w_idx = -1; //full
        pool->bufferred_size += data_size;
        WFD_MUTEX_UNLOCK(bufCtrlMutex);

#ifdef PLAYBACK_MULTI_THREAD_ENABLE
        /* a new block is ready, notify consumer to read */
        if  (mediaPlayWaitFlag)
        {
            mediaPlayDataReadyNotify();
        }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */
    }

    return ret;
}


int MediaBufPool::mediaBufPoolReadyToParse(void)
{
    /* To get ready to be parsed of a TS stream,
       the buf has to be at least 512k long */
    BufferPool *pool = &mediaBufPool;
    if (pool->bufferred_size >= WFD_TS_PARSE_MIN_SIZE)
        return 1;
    else
        return 0;
}

int MediaBufPool::mediaBufGetBufCount(void)
{
    int cnt = 0;

    BufferPool *pool = &mediaBufPool;
    WFD_MUTEX_LOCK(bufCtrlMutex);
    if (pool->w_idx == pool->r_idx) //buffer empty
        cnt = 0;
    else if (pool->w_idx == -1) //buffer full
        cnt = WFD_BUF_CHAIN_LEN;
    else if (pool->w_idx > pool->r_idx)
        cnt = (pool->w_idx - pool->r_idx);
    else //r_idx > w_idx
        cnt = ((WFD_BUF_CHAIN_LEN - pool->r_idx) + pool->w_idx);
    WFD_MUTEX_UNLOCK(bufCtrlMutex);

    return cnt;
}
int MediaBufPool::mediaBufConsumeDrop(int blocks)
{
    int bufCount = 0;
    BufferPool *pool = &mediaBufPool;
    int ori_r_idx = 0;

    bufCount = mediaBufGetBufCount();
    if (bufCount < blocks) //buffer not full enough
        return -1;
    /* drop buffers */
    WFD_MUTEX_LOCK(bufCtrlMutex);
    ori_r_idx = pool->r_idx;
    ADVANCE_BUF_POS_CNT(pool->r_idx, blocks);
    if (pool->w_idx == -1)
        pool->w_idx = ori_r_idx;
    assert((pool->bufferred_size -= (blocks*WFD_TS_BUF_UNIT_SIZE))>=0);
    WFD_MUTEX_UNLOCK(bufCtrlMutex);

    return 0;

}

int MediaBufPool::mediaBufStripHead(void)
{
    /* Strip bufferred to improve streaming latency */
    int bufCount = 0;

    bufCount = mediaBufGetBufCount();
    if (bufCount > 0)
    {
        mediaBufConsumeDrop(bufCount-1);
        return 0;
    }
    return -1;
}
int MediaBufPool::mediaBufGetHeaderParseLen(void)
{
    BufferPool *pool = &mediaBufPool;

    return pool->bufferred_size;
}

int MediaBufPool::mediaPlayDataReadyNotify(void)
{
    mediaPlayWaitFlag = 0;
    WFD_MUTEX_UNLOCK(mediaPlayDataRdyMutex);
    return 0;
}

int MediaBufPool::mediaPlayDataReadyWait(void)
{
    //int ret = 0;
#define DATA_READY_MAX_WAIT_MS      50 /* ms */

    WFD_MUTEX_INIT_LOCKED(mediaPlayDataRdyMutex);
    mediaPlayWaitFlag = 1;
    //WFD_MUTEX_TIMEDLOCK(mediaPlayDataRdyMutex, (DATA_READY_MAX_WAIT_MS*1000), ret);
    return 0;
}

int MediaBufPool::mediaPlayFirstDataReadyWait(void)
{
    //wait first data blocks to parse TS info
    WFD_MUTEX_INIT_LOCKED(mediaPlayDataRdyMutex);
    WFD_MUTEX_LOCK(mediaPlayDataRdyMutex);
    return 0;
}

}

