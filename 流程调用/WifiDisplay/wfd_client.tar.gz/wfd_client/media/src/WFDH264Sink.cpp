#define WFD_LOG_TAG "WFDH264Sink"

#include "WFDH264Sink.h"
#include "H264VideoRTPSource.hh"
#include "Utils.h"

namespace rtsp
{
static unsigned char start_code[4] = {0x00, 0x00, 0x00, 0x01};

WFDH264Sink::WFDH264Sink(UsageEnvironment& env, char const* sPropParameterSetsStr,
                            unsigned int type, unsigned bufferSize)
                                :WFDMediaSink(env, type, bufferSize, 4),
                                    fSPropParameterSetsStr(sPropParameterSetsStr),
                                        fHaveWrittenFirstFrame(false)
{
}

WFDH264Sink::~WFDH264Sink()
{
}

WFDH264Sink* WFDH264Sink::createNew(UsageEnvironment& env, char const* sPropParameterSetsStr,
                                        unsigned int type, unsigned bufferSize)
{
    return new WFDH264Sink(env, sPropParameterSetsStr, type, bufferSize);
}


void WFDH264Sink::afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime)
{

#if 1
    if (!fHaveWrittenFirstFrame)
    {
        // If we have PPS/SPS NAL units encoded in a "sprop parameter string", prepend these to the file:
        unsigned numSPropRecords;
        SPropRecord* sPropRecords = parseSPropParameterSets(fSPropParameterSetsStr, numSPropRecords);
        unsigned int iLen = 0;
        for (unsigned i = 0; i < numSPropRecords; ++i)
        {
            iLen += sPropRecords[i].sPropLength;
        }
        iLen += (numSPropRecords<<2) + 4 + frameSize;
        unsigned char *pTmp = (unsigned char *)malloc(iLen);
        if (pTmp)
        {
            unsigned int iTmpLen = 0;
            for (unsigned i = 0; i < numSPropRecords; ++i)
            {
                memcpy(pTmp+ iTmpLen, start_code, 4);
                iTmpLen += 4;
                memcpy(pTmp + iTmpLen , sPropRecords[i].sPropBytes, sPropRecords[i].sPropLength);
                iTmpLen += sPropRecords[i].sPropLength;
            }

            memcpy(pTmp + iTmpLen, start_code, 4);
            memcpy(pTmp + iTmpLen + 4, fBuffer + 4, frameSize);
            WFD_LOG_DEBUG("send data with prop  len:%d\n", iLen);
            sendData(pTmp, iLen, presentationTime);
            free(pTmp);
            delete[] sPropRecords;
            fHaveWrittenFirstFrame = True;
        }
        else
        {
            WFD_LOG_ERR("malloc size:%d failed\n", iLen);
            delete[] sPropRecords;
        }
    }
    else
    {
        WFD_LOG_DEBUG("send data with special header len:%d\n", 4 + frameSize);
        memcpy(fBuffer, start_code, 4);
        sendData(fBuffer, 4 + frameSize, presentationTime);
    }
 #endif
    continuePlaying();
}


}

