#define WFD_LOG_TAG "WFDAACSink"

#include "WFDAACSink.h"
#include "MPEG4GenericRTPSource.hh"
#include "Utils.h"


namespace rtsp
{

WFDAACSink::WFDAACSink(UsageEnvironment& env, unsigned int type,
                            unsigned bufferSize, MediaSubsession *subsession)
                                :WFDMediaSink(env, type, bufferSize, 7), fSubsession(subsession)
{
    memset(pucSpecialHead, 0, sizeof(pucSpecialHead));
    ucSampleRate = GetSampFreq(subsession);
    ucChannelID = 0x1;
    uFrameLen = 0;
}

WFDAACSink::~WFDAACSink()
{
}

WFDAACSink* WFDAACSink::createNew(UsageEnvironment& env, unsigned int type,
                                        unsigned bufferSize,
                                            MediaSubsession *subsession)
{
    return new WFDAACSink(env, type, bufferSize, subsession);
}


void WFDAACSink::afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime)
{
    /*
     *NOTE:cann't get frame len, so use the framesize instead, but this may cause problem
     */
    uFrameLen = frameSize;
    WFD_LOG_DEBUG("aac frame len = %d\n", uFrameLen);

    pucSpecialHead[0] = 0xFF;
    pucSpecialHead[1] = 0xF9;
    pucSpecialHead[2] = (unsigned char)((1<<6)|((ucSampleRate<<2)&0x3C)|((ucChannelID>>2)&0x1));
    pucSpecialHead[3] = (unsigned char)(((ucChannelID&0x3)<<6)|((uFrameLen>>11)&0x3));
    pucSpecialHead[4] = (unsigned char)((uFrameLen>>3)&0xFF);
    pucSpecialHead[5] = (unsigned char)(((uFrameLen<<5)&0xE0)|((0x7FF>>6)&0x1F));
    pucSpecialHead[6] = (unsigned char)((0x7FF<<2)&0xFC);
    memcpy(fBuffer, pucSpecialHead, 7);
    sendData(fBuffer, 7 + frameSize, presentationTime);

    continuePlaying();
}

unsigned char WFDAACSink::GetSampFreq(MediaSubsession *subsession)
{
    if (NULL == subsession)
        return 0xFF;

    unsigned rate = samplingFrequencyFromAudioSpecificConfig(subsession->fmtp_config());
    WFD_LOG_DEBUG("rtp sample rate = %d\n", rate);
    switch (rate)
    {
        case 96000:
            return 0x0;
        case 88200:
            return 0x1;
        case 64000:
            return 0x2;
        case 48000:
            return 0x3;
        case 44100:
            return 0x4;
        case 32000:
            return 0x5;
        case 24000:
            return 0x6;
        case 22050:
            return 0x7;
        case 16000:
            return 0x8;
        case 12000:
            return 0x9;
        case 11025:
            return 0xa;
        case 8000:
            return 0xb;
        case 7350:
            return 0xc;
        default:
            return 0xFF;
    }

    return 0xFF;
}
}


