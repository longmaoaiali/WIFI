#define WFD_LOG_TAG "WFDMediaSink"

#include "WFDMediaSink.h"
#include "Utils.h"
#include "UsageEnvironment.hh"
#include <sys/time.h>
#include <unistd.h>
#include "PushPlayer.h"
#include "wfd_client_internal.h"
#include "WFDClient.h"
#ifdef CC_S_PLATFORM
#include "SinkBuffer.h"
#endif

//#ifdef WFD_DEMO_SAVE_FILE
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <string.h>
    #include <stdlib.h>
    #include <stdio.h>
//#endif

#ifdef CC_S_PLATFORM
#ifndef SUPPORT_WFD_RECV_BUFF
#define SUPPORT_WFD_RECV_BUFF
#endif
#ifndef SUPPORT_WFD_PLAY_BUFF
#define SUPPORT_WFD_PLAY_BUFF
#endif
#ifndef SUPPORT_WFD_TCP_PRE_BUFF
#define SUPPORT_WFD_TCP_PRE_BUFF
#endif
#endif

extern bool fHavepacketlost;
struct timeval IDR_time_out = {0};

namespace rtsp
{
WFDMediaSink::WFDMediaSink(UsageEnvironment& env, unsigned int type,unsigned bufferSize,
                        unsigned attrHeadSize):MediaSink(env), uiType(type),
                            fBufferSize(bufferSize), uiAttrHeadSize(attrHeadSize)
{
#ifdef CC_S_PLATFORM
        /* Default use UDP protocol */
    useProtocol = 0;
#endif

    fBuffer = new unsigned char[bufferSize + attrHeadSize];

#ifndef CC_S_PLATFORM
    useProtocol = 0;
#endif

    if (NULL == fBuffer)
    {
        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
    }

#ifdef CC_S_PLATFORM
#ifdef SUPPORT_WFD_RECV_BUFF
    fRecvBuf = new ReceiverBuffer(0);
    if (NULL == fRecvBuf)
    {
        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
    }
#endif

#ifdef SUPPORT_WFD_PLAY_BUFF
    fPlayBuf = new PlayerBuffer(1024);
    if (NULL == fPlayBuf)
    {
        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
    }
#endif

#ifdef SUPPORT_WFD_TCP_PRE_BUFF
    fTCPPreBuf = new TCPPreBuffer(512 * 1024);
    if (NULL == fTCPPreBuf)
    {
        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
    }
#endif
#endif
    is_first_lost = true;
//#endif
}

WFDMediaSink::~WFDMediaSink()
{
    if (fBuffer != NULL)
    {
        delete[] fBuffer;
        fBuffer = NULL;
    }

#ifdef CC_S_PLATFORM
#ifdef SUPPORT_WFD_RECV_BUFF
    if (fRecvBuf != NULL)
    {
        delete fRecvBuf;
        fRecvBuf = NULL;
    }
#endif
#ifdef SUPPORT_WFD_PLAY_BUFF
    if (fPlayBuf != NULL)
    {
        delete fPlayBuf;
        fPlayBuf = NULL;
    }
#endif
#ifdef SUPPORT_WFD_TCP_PRE_BUFF
    if (fTCPPreBuf != NULL)
    {
        delete fTCPPreBuf;
        fTCPPreBuf = NULL;
    }
#endif
#endif
    useProtocol = 0;
//#endif
}

WFDMediaSink* WFDMediaSink::createNew(UsageEnvironment& env, unsigned int type, unsigned bufferSize)
{
    return  new WFDMediaSink(env, type, bufferSize, 0);
}

Boolean WFDMediaSink::continuePlaying()
{
    if (fSource == NULL)
    {
        return False;
    }

    fSource->getNextFrame(fBuffer + uiAttrHeadSize, fBufferSize, afterGettingFrame, this, onSourceClosure, this);

    return True;
}

void WFDMediaSink::switch_protocol(int e_protocol)
{
#ifdef CC_S_PLATFORM
#ifdef SUPPORT_WFD_TCP_PRE_BUFF
        /* Switch protocol from UDP to TCP */
        if (e_protocol == 1 && useProtocol != e_protocol)
        {
            fTCPPreBuf->setEnable(true);
        }
        else
        {
            fTCPPreBuf->setEnable(false);
        }
#endif
#endif

    useProtocol = e_protocol;
}


void WFDMediaSink::afterGettingFrame(void* clientData, unsigned frameSize, unsigned numTruncatedBytes,
                 struct timeval presentationTime, unsigned durationInMicroseconds)
{
//    printf("WFDMediaSink::afterGettingFrame frameSize = %d \n", frameSize);
    WFDMediaSink* sink = (WFDMediaSink*)clientData;
    if (NULL == sink)
    {
        WFD_LOG_ERR("error - invalid param!\n");
        return;
    }

#if 0
    WFD_LOG_DEBUG("size:%d, bytes:%d,time:[%d:%d],duration:%d!", frameSize, numTruncatedBytes,(int)presentationTime.tv_sec,
                        (int)presentationTime.tv_usec, durationInMicroseconds);
#endif
    sink->afterGettingFrame1(frameSize, presentationTime);
}

void WFDMediaSink::afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime)
{
#ifdef CC_S_PLATFORM
#ifdef SUPPORT_WFD_RECV_BUFF
        if (fRecvBuf->isEnable())
        {
            #ifdef SUPPORT_WFD_TCP_PRE_BUFF
            // use TCP pre-buffer
            if (fTCPPreBuf->isEnable())
            {
                // Save data to TCP pre-buffer
                fTCPPreBuf->assignBuffer(fBuffer + uiAttrHeadSize, frameSize);

                if (fTCPPreBuf->isFull())
                {
                    // Consume from TCP pre-buffer
                    #ifdef SUPPORT_WFD_PLAY_BUFF
                    // try to send player through play buffer
                    if (fPlayBuf->isEnable())
                    {
                        unsigned char *buf = NULL;
                        unsigned size = 0;

                        fPlayBuf->retrieveBuffer(buf, size);
                        //WFD_LOG_DEBUG("cmpb sink retrieve player buffer size :%d", size);
                        while (size > 0 && fTCPPreBuf->getRecvSize() >= size)
                        {
                            if (fTCPPreBuf->consumeBuffer(buf, size))
                            {
                                sendData(buf, size, presentationTime);
                                //WFD_LOG_DEBUG("cmpb sink received data length..send to pushplayer:%d", size);
                            }
                        }

                        if (fTCPPreBuf->getRecvSize() > 0)
                        {
                            size = fTCPPreBuf->getRecvSize();
                            if (fTCPPreBuf->consumeBuffer(buf, size))
                            {
                                sendData(buf, size, presentationTime);
                                //WFD_LOG_DEBUG("cmpb sink received data length..send to pushplayer:%d", size);
                            }
                        }
                    }
                    else
                    #endif /* #ifdef SUPPORT_WFD_PLAY_BUFF */
                    {
                        // Consume from TCP pre-buffer
                        unsigned size = fTCPPreBuf->getRecvSize();
                        unsigned char *buf = new unsigned char[size];
                        if (NULL == buf)
                        {
                            WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
                        }
                        else
                        {
                            if (fTCPPreBuf->consumeBuffer(buf, size))
                            {
                                sendData(buf, size, presentationTime);
                            }

                            delete[] buf;
                        }
                    }

                    fTCPPreBuf->setEnable(false);
                }
            }
            else
            #endif /* #ifdef SUPPORT_WFD_TCP_PRE_BUFF */
            {
                if (useProtocol)
                    fRecvBuf->assignBuffer(fBuffer + uiAttrHeadSize, frameSize);
                else
                    fRecvBuf->assignBuffer(fBuffer + uiAttrHeadSize + 12, frameSize);

                #ifdef SUPPORT_WFD_PLAY_BUFF
                // try to send player through play buffer
                if (fPlayBuf->isEnable())
                {
                    unsigned char *buf = NULL;
                    unsigned size = 0;

                    if (fRecvBuf->getRecvSize() >= fPlayBuf->getSize())
                    {
                        //Need consume data from recv buffer and start play buffer
                        fPlayBuf->retrieveBuffer(buf, size);
                        //WFD_LOG_DEBUG("cmpb sink retrieve player buffer size :%d", size);
                        while (size > 0 && fRecvBuf->getRecvSize() >= size)
                        {
                            if (fRecvBuf->consumeBuffer(buf, size))
                            {
                                fPlayBuf->afterSaveData(size);
                                sendData(buf, size, presentationTime);
                                fPlayBuf->afterPlayBuffer();
                                //WFD_LOG_DEBUG("cmpb sink received data length..send to pushplayer:%d", size);
                            }
                        }
                    }
                    else
                    {
                        fPlayBuf->retrieveCurBuffer(buf, size);
                        if (fRecvBuf->isFull() || fRecvBuf->getRecvSize() >= size)
                        {
                            //Need consume data from recv buffer
                            if (size > fRecvBuf->getRecvSize())
                            {
                                size = fRecvBuf->getRecvSize();
                            }

                            fRecvBuf->consumeBuffer(buf, size);
                            fPlayBuf->afterSaveData(size);

                            if (fPlayBuf->isFull())
                            {
                                fPlayBuf->retrieveBuffer(buf, size);
                                sendData(buf, size, presentationTime);
                                fPlayBuf->afterPlayBuffer();
                            }
                        }
                    }
                }
                else
                #endif /* #ifdef SUPPORT_WFD_PLAY_BUFF */
                {
                    unsigned size = fRecvBuf->getRecvSize();
                    unsigned char *buf = new unsigned char[size];
                    if (NULL == buf)
                    {
                        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
                    }
                    else
                    {
                        if (fRecvBuf->consumeBuffer(buf, size))
                        {
                            sendData(buf, size, presentationTime);
                        }

                        delete[] buf;
                    }
                }
            }
        }
        else
#endif /* #ifdef SUPPORT_WFD_RECV_BUFF */
        {
            #ifdef SUPPORT_WFD_RECV_BUFF
            // Consume last received buffer data
            if (fRecvBuf->getRecvSize() > 0)
            {
                unsigned size = fRecvBuf->getRecvSize();
                unsigned char *buf = new unsigned char[size];
                if (NULL == buf)
                {
                    WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
                }
                else
                {
                    if (fRecvBuf->consumeBuffer(buf, size))
                    {
                        sendData(buf, size, presentationTime);
                    }

                    delete[] buf;
                }
            }
            #endif /* #ifdef SUPPORT_WFD_RECV_BUFF */

            #ifdef SUPPORT_WFD_TCP_PRE_BUFF
            // use TCP pre-buffer
            if (fTCPPreBuf->isEnable())
            {
                // Save data to TCP pre-buffer
                fTCPPreBuf->assignBuffer(fBuffer + uiAttrHeadSize, frameSize);

                if (fTCPPreBuf->isFull())
                {
                    // Consume from TCP pre-buffer
                    unsigned size = fTCPPreBuf->getRecvSize();
                    unsigned char *buf = new unsigned char[size];
                    if (NULL == buf)
                    {
                        WFD_LOG_ERR("[WFDMediaSink] line:%d, new fail!\n", __LINE__);
                    }
                    else
                    {
                        if (fTCPPreBuf->consumeBuffer(buf, size))
                        {
                            sendData(buf, size, presentationTime);
                        }

                        delete[] buf;
                    }

                    fTCPPreBuf->setEnable(false);
                }
            }
            else
            #endif /* #ifdef SUPPORT_WFD_TCP_PRE_BUFF */
            {
                if (useProtocol)
                    sendData(fBuffer + uiAttrHeadSize, frameSize, presentationTime);
                else
                    sendData(fBuffer + uiAttrHeadSize + 12, frameSize, presentationTime);
            }
            //WFD_LOG_DEBUG("cmpb sink received data length..send to pushplayer:%d", frameSize);
        }
#else

    if (useProtocol)
        sendData(fBuffer + uiAttrHeadSize, frameSize, presentationTime);
    else
        sendData(fBuffer + uiAttrHeadSize + 12, frameSize, presentationTime);

#endif
    if (fHavepacketlost &&(useProtocol == 0))
    {
        if(is_first_lost)
        {
           // WFDClient::getInstance().sendIDRReq();//some devices do not support IDRReq
            fHavepacketlost = false;
            is_first_lost = false;
        }
        else
        {
             struct timeval timenow;
             gettimeofday(&timenow, NULL);

              //printf("timenow.tv_sec = %ld, timenow.tv_usec = %ld\n", timenow.tv_sec,
              //    timenow.tv_usec);

             //send M13 if timer expire, else wait for timer
             if (timenow.tv_sec > IDR_time_out.tv_sec ||
                (timenow.tv_sec == IDR_time_out.tv_sec && timenow.tv_usec > IDR_time_out.tv_usec))
             {
                 //WFDClient::getInstance().sendIDRReq();//some devices do not support IDRReq
                 fHavepacketlost = false;
             }
        }
    }

    continuePlaying();
}

void WFDMediaSink::sendData(unsigned char *pBuf, unsigned int iLen, struct timeval &duration)
{
    /*
     *TO DO:add data to cmpb
     */
    GetBufData tmp(pBuf, uiType, iLen, duration);
    PushPlayer::instance().SendData(tmp);
}

#ifdef CC_S_PLATFORM
void WFDMediaSink::setRecvBufferSize(unsigned bufferSize)
{
    if (fRecvBuf)
    {
        WFD_LOG_DEBUG("[WFD] set recv buffer size %u!\n", bufferSize);
        fRecvBuf->setSize(bufferSize);
    }
}

unsigned WFDMediaSink::getRecvBufferSize()
{
    if (fRecvBuf)
        return fRecvBuf->getSize();
    else
        return 0;
}

void WFDMediaSink::setPlayBufferSize(unsigned bufferSize)
{
    if (fPlayBuf)
    {
        WFD_LOG_DEBUG("[WFD] set play buffer size %u!\n", bufferSize);
        fPlayBuf->setSize(bufferSize);
    }
}

unsigned WFDMediaSink::getPlayBufferSize()
{
    if (fPlayBuf)
        return fPlayBuf->getSize();
    else
        return 0;
}

void WFDMediaSink::setTCPPreBufferSize(unsigned bufferSize)
{
    if (fTCPPreBuf)
    {
        WFD_LOG_DEBUG("[WFD] set TCP pre-buffer size %u!\n", bufferSize);
        fTCPPreBuf->setSize(bufferSize);
    }
}

unsigned WFDMediaSink::getTCPPreBufferSize()
{
    if (fTCPPreBuf)
        return fTCPPreBuf->getSize();
    else
        return 0;
}
#endif
}
