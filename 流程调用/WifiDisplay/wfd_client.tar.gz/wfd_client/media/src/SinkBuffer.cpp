/*
** RTP streaming data (UDP/TCP) -> Recv buffer -> (TCP pre-buferr) -> Play buffer -> CMPB
*/
#define WFD_LOG_TAG "SinkBuffer"

#include "SinkBuffer.h"
#include "Utils.h"
#include "UsageEnvironment.hh"
#include <sys/time.h>
#include <unistd.h>
#include "PushPlayer.h"
#include "wfd_client_internal.h"
#include "WFDClient.h"

//#ifdef WFD_DEMO_SAVE_FILE
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <string.h>
    #include <stdlib.h>
    #include <stdio.h>
//#endif

namespace rtsp
{

LinkedBuffer::LinkedBuffer(unsigned char *buf, unsigned size)
{
    fBuf = buf;
    fBufSize = size;
    fNextBuf = NULL;
}

LinkedBuffer::~LinkedBuffer()
{
    if (fBuf)
    {
        delete[] fBuf;
        fBuf = NULL;
        fBufSize = 0;
    }
}

ReceiverBuffer::ReceiverBuffer(unsigned bufSize)
{
    fBufSize = bufSize;
    fRecvSize = 0;
    fHeadBuf = NULL;
    fTailBuf = NULL;
    fIsBufFull = false;
}

ReceiverBuffer::~ReceiverBuffer()
{
    LinkedBuffer *fLinkedBuf = fHeadBuf;

    while (fLinkedBuf)
    {
        fHeadBuf = fHeadBuf->fNextBuf;
        delete fLinkedBuf;
        fLinkedBuf = fHeadBuf;
    }

    fHeadBuf = NULL;
    fTailBuf = NULL;
}

bool ReceiverBuffer::isEnable()
{
    if (fBufSize > 0)
        return true;
    else
        return false;
}

bool ReceiverBuffer::isFull()
{
    if (fRecvSize > 0 && fRecvSize >= fBufSize)
    {
        fIsBufFull = true;
        return true;
    }
    else
    {
        fIsBufFull = false;
        return false;
    }
}

void ReceiverBuffer::setSize(unsigned size)
{
    fBufSize = size;
}

unsigned ReceiverBuffer::getSize()
{
    return fBufSize;
}

unsigned ReceiverBuffer::getRecvSize()
{
    return fRecvSize;
}

bool ReceiverBuffer::assignBuffer(unsigned char *buf, unsigned size)
{
    unsigned assignSize = 0;
    unsigned char *fAssignBuf = NULL;
    LinkedBuffer *fLinkedBuf = NULL;

    if (fRecvSize >= fBufSize || fBufSize == 0)
    {
        WFD_LOG_ERR("[ReceiverBuffer] assign buffer fail, for receiver buffer is full (%u)!\n", fBufSize);
        return false;
    }

    assignSize = size;//(fRecvSize + size <= fBufSize)?size:(fBufSize - fRecvSize);
    fAssignBuf = new unsigned char[assignSize];
    if (NULL == fAssignBuf)
    {
        WFD_LOG_ERR("[ReceiverBuffer] alloc buffer fail!\n");
        return false;
    }

    memcpy(fAssignBuf, buf, assignSize);
    fLinkedBuf = new LinkedBuffer(fAssignBuf, assignSize);
    if (NULL == fLinkedBuf)
    {
        WFD_LOG_ERR("[ReceiverBuffer] alloc link buffer fail!\n");
        return false;
    }

    // insert to the tail of linked buffer list
    if (NULL == fHeadBuf || NULL == fTailBuf)
    {
        fHeadBuf = fLinkedBuf;
        fTailBuf = fLinkedBuf;
    }
    else
    {
        fTailBuf->fNextBuf = fLinkedBuf;
        fTailBuf = fLinkedBuf;
    }

    fRecvSize += assignSize;
    if (fRecvSize >= fBufSize)
        fIsBufFull = true;

#if 0
    WFD_LOG_DEBUG("[ReceiverBuffer] assign size %u, recv size %u, max size %u\n",
            assignSize, fRecvSize, fBufSize);
#endif

    return true;
}

bool ReceiverBuffer::consumeBuffer(unsigned char *buf, unsigned size)
{
    //WFD_LOG_DEBUG("[ReceiverBuffer] receive size (%u), consume size (%u)!\n", fRecvSize, size);
    if (fRecvSize < size && fBufSize > 0)
    {
        //WFD_LOG_DEBUG("[ReceiverBuffer] receive data (%u) is not enough for consume (%u)!\n", fRecvSize, size);
        return false;
    }

    LinkedBuffer *fLinkedBuf = fHeadBuf;
    unsigned consumeSize = 0;
    unsigned needSize = size;

    while (fLinkedBuf && (needSize > 0))
    {
        if (fLinkedBuf->fBufSize > needSize)
        {
            // The head buff is enough for consume
            memcpy(buf + consumeSize, fLinkedBuf->fBuf, needSize);
            memmove(fLinkedBuf->fBuf, fLinkedBuf->fBuf + needSize, fLinkedBuf->fBufSize - needSize);
            fLinkedBuf->fBufSize -= needSize;
            fRecvSize -= needSize;
            consumeSize += needSize;
            needSize = 0;
            return true;
        }
        else
        {
            memcpy(buf + consumeSize, fLinkedBuf->fBuf, fLinkedBuf->fBufSize);
            fRecvSize -= fLinkedBuf->fBufSize;
            needSize -= fLinkedBuf->fBufSize;
            consumeSize += fLinkedBuf->fBufSize;
        }

        // Curr linked buf have been consumed, so find next one
        fHeadBuf = fHeadBuf->fNextBuf;
        delete fLinkedBuf;
        fLinkedBuf = fHeadBuf;
    }

    if (NULL == fHeadBuf)
    {
        fTailBuf = NULL;
        return true;
    }

    if (needSize == 0 && consumeSize == size)
        return true;
    else
        return false;
}

TCPPreBuffer::TCPPreBuffer(unsigned bufSize)
        : ReceiverBuffer(bufSize)
{
    fIsEnable = false;
}

TCPPreBuffer::~TCPPreBuffer()
{
    fIsEnable = false;
}

void TCPPreBuffer::setEnable(bool enable)
{
    fIsEnable = enable;
    WFD_LOG_DEBUG("[TCPPreBuffer] set %s!\n", fIsEnable?"enable":"disable");
}

bool TCPPreBuffer::isEnable()
{
    return fIsEnable;
}

PlayerBuffer::PlayerBuffer(unsigned bufSize)
{
    fBufSize = bufSize;
    fNewSize = fBufSize;
    fCurSize = 0;
    if (fBufSize > 0)
    {
        fBuf = new unsigned char[fBufSize];
        if (NULL == fBuf)
        {
            WFD_LOG_ERR("[PlayerBuffer] new buff fail!\n");
        }
    }
    else
        fBuf = NULL;
}

PlayerBuffer::~PlayerBuffer()
{
    if (fBuf != NULL)
    {
        delete[] fBuf;
        fBuf = NULL;
    }
}

void PlayerBuffer::reset()
{
    if (fBuf != NULL)
    {
        memset(fBuf, 0, fBufSize);
        fCurSize = 0;
    }
}

bool PlayerBuffer::isEnable()
{
    if (fBufSize > 0 && fBuf != NULL)
        return true;
    else
        return false;
}

bool PlayerBuffer::isFull()
{
    if (fBufSize > 0 && fCurSize >= fBufSize)
    {
        return true;
    }
    else
    {
        return false;
    }
}

void PlayerBuffer::setSize(unsigned size)
{
    fNewSize = size;
}

unsigned PlayerBuffer::getSize()
{
    return fNewSize;
}

bool PlayerBuffer::retrieveBuffer(unsigned char*& buf, unsigned& size)
{
    unsigned char *fNewBuf = NULL;

    if (fBufSize != fNewSize)
    {
        fBufSize = fNewSize;

        // alloc new buff size
        if (fBufSize > 0)
        {
            fNewBuf = new unsigned char[fNewSize];
            if (NULL == fNewBuf)
            {
                WFD_LOG_ERR("[PlayerBuffer] new buff fail!\n");
            }

            if (fCurSize > 0 && fNewSize >= fCurSize)
            {
                memcpy(fNewBuf, fBuf, fCurSize);
            }
        }

        // delete last buff size
        if (fBuf != NULL)
        {
            delete[] fBuf;
            fBuf = NULL;
        }

        fBuf = fNewBuf;
    }

    buf = fBuf;
    size = fBufSize;

    return true;
}

bool PlayerBuffer::retrieveCurBuffer(unsigned char*& buf, unsigned& size)
{
    unsigned char *fNewBuf = NULL;

    if (fCurSize >= fBufSize)
        return false;

    if (fBufSize != fNewSize)
    {
        fBufSize = fNewSize;

        // alloc new buff size
        if (fBufSize > 0)
        {
            fNewBuf = new unsigned char[fNewSize];
            if (NULL == fNewBuf)
            {
                WFD_LOG_ERR("[PlayerBuffer] new buff fail!\n");
            }

            if (fCurSize > 0 && fNewSize >= fCurSize)
            {
                memcpy(fNewBuf, fBuf, fCurSize);
            }
        }

        // delete last buff size
        if (fBuf != NULL)
        {
            delete[] fBuf;
            fBuf = NULL;
        }

        fBuf = fNewBuf;
    }

    buf = fBuf + fCurSize;
    size = fBufSize - fCurSize;

    return true;
}

bool PlayerBuffer::afterSaveData(unsigned size)
{
    if (fCurSize >= fBufSize)
        return false;

    fCurSize += size;
    return true;
}

bool PlayerBuffer::afterPlayBuffer()
{
    reset();
    return true;
}

}
