#define WFD_LOG_TAG "CMPB-PushPlayer"

#include "PushPlayer.h"
#include "Utils.h"
#include <string.h>
#include "myCfg.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <errno.h>


#ifdef __ANDROID__
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/poll.h>
#include <sys/select.h>
#include <unistd.h>
#include <algorithm>
#include <string.h>
#endif

#ifdef ENABLE_HDCP2X_RX
#include <hdcp2x_ext.h>
#endif

extern struct wfd_rtsp_conf_s *wfd_rtsp_conf;
/*
#ifndef PLAYBACK_DROP_START_SECONDS
#define PLAYBACK_DROP_START_SECONDS 1
#endif
*/

#define SET_CMPB_PLAY_WAIT_S      20 /* second */
#define SET_MEDIAINFO_WAIT_S      20 /* second */

#ifdef __ANDROID__
extern int wfd_send_command(const char *comm);
#endif

namespace rtsp
{
void *pushPlayerThrdMain(void *arg);

static const unsigned int CMPB_PRIVATE_PS_BUF_SIZE = 4512 * 4;
static const unsigned int CMPB_PRIVATE_CONTAINER_HEADER_SIZE = 14;
static const unsigned int PUSH_PLAYER_LOCAL_BUFFER_SIZE = 1024*1024;
static unsigned long aTotalSize = 0;
static unsigned long vTotalSize = 0;
static IMtkPb_Ctrl_Nfy_Fct  gSelfCmpbNfy = NULL;
static void* gSelfTag;

PushPlayer PushPlayer::_instance;
extern bool bSaveLocalFile;
extern bool bSaveCmpb;
extern bool bOnlyCount;
extern bool bCmpbPlayAudio;
extern bool bCmpbPlayVideo;


static bool opened = false;
static bool played = false;
static bool playError = false;
static uint32_t pts = 0;

#ifdef PLAYBACK_MULTI_THREAD_ENABLE
static int pushPlayerThrdExit = 0;
static int pushPlayerThrdRunning = 0;
static int pushPlayerThrdRestart = 0;
pthread_mutex_t pushPlayerExitMutex;
#endif

char *PushPlayer::getRTPStats(void)
{
#ifdef WFD_RTP_STATS
    WFD_PUSH_PLAYER_STATS_T *stats = NULL;
    if (!wfd_pp_stats)
        return NULL;

    stats = (WFD_PUSH_PLAYER_STATS_T *)wfd_pp_stats;
    stats->total_size = mediaBufPool.total_size;
    stats->buf_w_idx = mediaBufPool.w_idx;
    stats->buf_r_idx = mediaBufPool.r_idx;
    stats->buf_w_start_pos = mediaBufPool.w_start_pos;
    stats->buffered_size = mediaBufPool.bufferred_size;
    stats->pushplayer_status = status;

    return (char *)wfd_pp_stats;
#else
    return NULL;
#endif
}


#ifdef WFD_DUMP_TS
void PushPlayer::dumpTsToFile(unsigned char *data, int len)
{
    if (!m_dumpFp)
    {
        return;
    }

    int ret = fwrite(data, 1, len, m_dumpFp);
    if (ret <= 0)
    {
        WFD_LOG_ERR( "Dump ts write fail! Error=%s\n", strerror(errno));
    }
}
#endif
#ifdef __ANDROID__
int pushplayer_send_command(const char *comm)
{
    return wfd_send_command(comm);
}
#endif
#ifdef __ANDROID__
void PushPlayer::GetCmpbWFDErrorInfo(void * getTypeInfo)
{
    //IMtkPb_Ctrl_Get(handle, IMTK_PB_CTRL_GET_TYPE_WFD_ERROR_INFO, (void *)getTypeInfo,sizeof(IMTK_PB_CTRL_DEC_WFD_ERR_INFO_T));
    return;
}
#endif

static IMTK_PB_CTRL_FRAME_RATE_T convertFPS(int fps)
{
    switch(fps)
    {
        case 24:
            return IMTK_PB_CTRL_FRAME_RATE_24;
        case 25:
            return IMTK_PB_CTRL_FRAME_RATE_25;
        case 30:
            return IMTK_PB_CTRL_FRAME_RATE_30;
        case 50:
            return IMTK_PB_CTRL_FRAME_RATE_50;
        case 60:
            return IMTK_PB_CTRL_FRAME_RATE_60;
        default:
            WFD_LOG_ERR("Error %s : unknown fps %d \n", __FUNCTION__,__LINE__);
            return IMTK_PB_CTRL_FRAME_RATE_UNKNOWN;
    }
}

static IMTK_PB_CB_ERROR_CODE_T pushPlayerCallback(IMTK_PB_CTRL_EVENT_T       eEventType,
                                                    void*                      pvTag,
                                                        uint32_t                   u4Data)
{
    //WFD_LOG_DEBUG("cmpb call back event(type:%d)!", (int)eEventType);

    if ( gSelfCmpbNfy )
    {
        return gSelfCmpbNfy( eEventType, gSelfTag, u4Data  );
    }

    switch (eEventType)
    {
        /*
        case IMTK_PB_CTRL_EVENT_PLAYED:
            //WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_PLAYED");
            played = true;
            break;
        */
        case IMTK_PB_CTRL_EVENT_CUR_TIME_UPDATE:
            //WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_CUR_TIME_UPDATE %d", u4Data);
            pts = u4Data;
            break;
        case IMTK_PB_CTRL_EVENT_BUFFER_UNDERFLOW:
            //WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_BUFFER_UNDERFLOW");
            break;
        case IMTK_PB_CTRL_EVENT_TOTAL_TIME_UPDATE:
            //WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_TOTAL_TIME_UPDATE %d", u4Data);
            break;
        case IMTK_PB_CTRL_EVENT_EOS:
            //WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_EOS");
            break;
        case IMTK_PB_CTRL_EVENT_PLAYBACK_ERROR:
        {

            WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_PLAYBACK_ERROR   in\n");
            playError = true;
            if(u4Data == IMTK_PB_CTRL_ERROR_VIDEO_STREAM_CTR_NOT_SUPPORT)
            {
                WFD_LOG_DEBUG("IMTK_PB_CTRL_ERROR_VIDEO_STREAM_CTR_NOT_SUPPORT in\n");
#ifdef __ANDROID__
                pushplayer_send_command(HDCP2X_ERR_VIDEO_STREAM_COUNTER_STR);
#endif
            }
            else if(u4Data == IMTK_PB_CTRL_ERROR_AUDIO_STREAM_CTR_NOT_SUPPORT)
            {
                WFD_LOG_DEBUG("IMTK_PB_CTRL_ERROR_AUDIO_STREAM_CTR_NOT_SUPPORT in\n");
#ifdef __ANDROID__
                pushplayer_send_command(HDCP2X_ERR_AUDIO_STREAM_COUNTER_STR);
#endif
            }
        }
        break;
#if 0
        case IMTK_PB_CTRL_EVENT_VIDEO_WFD_ERROR:
#ifdef __ANDROID__
            {
                WFD_LOG_DEBUG("IMTK_PB_CTRL_EVENT_VIDEO_WFD_ERROR  in\n");

                char str_send_cmd[256] = {0} ;
                char str_tmp[32] = {0};
                strcat(str_send_cmd,MSG_WITH_ARG_STR);
                strcat(str_send_cmd,IMTK_PB_CTRL_EVENT_VIDEO_WFD_ERROR_STR);
                strcat(str_send_cmd," 3");


                WFD_LOG_DEBUG("str_send_cmd 1:%s\n",str_send_cmd);

                IMTK_PB_CTRL_DEC_WFD_ERR_INFO_T getTypeInfo;
                memset(&getTypeInfo,0,sizeof(IMTK_PB_CTRL_DEC_WFD_ERR_INFO_T));
                PushPlayer::instance().GetCmpbWFDErrorInfo((void *)&getTypeInfo);

                memset(str_tmp,0,32);
                sprintf(str_tmp," %d",getTypeInfo.i4TimeoutCnt);
                strcat(str_send_cmd,str_tmp);
                WFD_LOG_DEBUG("str_send_cmd 2:%s\n",str_send_cmd);

                memset(str_tmp,0,32);
                sprintf(str_tmp," %d",getTypeInfo.i4LackSeqHeaderCnt);
                strcat(str_send_cmd,str_tmp);
                WFD_LOG_DEBUG("str_send_cmd 3:%s\n",str_send_cmd);

                memset(str_tmp,0,32);
                sprintf(str_tmp," %d",getTypeInfo.i4OutOfSpecCnt);
                strcat(str_send_cmd,str_tmp);
                WFD_LOG_DEBUG("str_send_cmd 4:%s\n",str_send_cmd);

                pushplayer_send_command(str_send_cmd,strlen(str_send_cmd));
            }
#endif
            break;
#endif
        default:
            break;
    }

    return IMTK_PB_CB_ERROR_CODE_OK;
}

int PushPlayer::ReInitBufPool(void)
{
    int ii;
    unsigned char *ptr = NULL;

    mediaBufPool.w_idx = 0;
    mediaBufPool.r_idx = 0;
    mediaBufPool.w_start_pos = 0;
    mediaBufPool.bufferred_size = 0;
    mediaBufPool.total_size = WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE;
    memset(mediaBufPool.bufPool, 0, WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE);
    ptr = mediaBufPool.bufPool;
    /* arrange buf idx */
    for (ii=0; ii< WFD_BUF_CHAIN_LEN; ii++)
    {
        mediaBufPool.bufIdx[ii] = ptr;
        ptr += WFD_TS_BUF_UNIT_SIZE;
    }
    return 0;
}

int PushPlayer::ClearBufPool(void)
{
    WFD_MUTEX_LOCK(bufCtrlMutex);
    mediaBufPool.w_idx = 0;
    mediaBufPool.r_idx = 0;
    mediaBufPool.w_start_pos = 0;
    mediaBufPool.bufferred_size = 0;
    mediaBufPool.total_size = WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE;
    WFD_MUTEX_UNLOCK(bufCtrlMutex);
    return 0;
}


int PushPlayer::CreateBufPool(void)
{
    int ret = 0;

    memset(&mediaBufPool, 0, sizeof(PushPlayerBuf));
    /* allocate buffer */
    mediaBufPool.bufPool = new unsigned char[WFD_BUF_CHAIN_LEN*WFD_TS_BUF_UNIT_SIZE];
    if (!mediaBufPool.bufPool)
    {
        WFD_LOG_ERR("Failed to allocated mediaBufPool\n");
        return -1;
    }
    ret = ReInitBufPool();
    return ret;
}

int PushPlayer::DestroyBufPool(void)
{
    if (mediaBufPool.bufPool)
         delete[] mediaBufPool.bufPool;

    memset(&mediaBufPool, 0, sizeof(PushPlayerBuf));

    return 0;
}

void PushPlayer::InitPushPlayerThread(void)
{
#if PLAYBACK_MULTI_THREAD_ENABLE
    pthread_attr_t ptAttr;
    struct sched_param ptSchedParam;
    int ptPolicy;

    pthread_attr_init(&ptAttr);

    ptSchedParam.sched_priority = 99;
    pthread_attr_setschedparam(&ptAttr, &ptSchedParam);
    pthread_attr_getschedpolicy(&ptAttr, &ptPolicy);
    pthread_attr_setschedpolicy(&ptAttr, SCHED_RR);
    pthread_attr_getschedpolicy(&ptAttr, &ptPolicy);
    if (pthread_create(&pushPlayerThrd, &ptAttr, pushPlayerThrdMain, NULL) != 0)
    {
        WFD_LOG_ERR("%s: failed to create thread\n", __FUNCTION__);
    }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */
}


PushPlayer::PushPlayer():handle(IMTK_NULL_HANDLE), status(PUSHPLAYERSTATUS_UNINIT),
                            pCmpbBufA(NULL), pCmpbBufV(NULL), uiAWriteLen(0), uiVWriteLen(0),
                                aFd(0), vFd(0)
{
    memset(&media_info, 0, sizeof(media_info));
    bDataFinished = true;
    isGetBufferReady = 1;
    bufferSuccessCnt = 0;
    bufferFailCnt = 0;
    isParseMediaInfoDone = true;
    isSetMediaInfoDone = false;
    mediaHeader = NULL;
    mediaHeaderSize = 0;
    WFD_MUTEX_INIT(bufCtrlMutex);

#ifdef PLAYBACK_MULTI_THREAD_ENABLE
    WFD_MUTEX_INIT(bufFullMutex);
    WFD_MUTEX_INIT(pushPlayerExitMutex);
    WFD_MUTEX_INIT(mediaPlayDataRdyMutex);
#endif

    bufFullFlag = 0;
    firstDataFlag = 1;
    mediaPlayWaitFlag = 0;
    pushPlayerThrdCmpbBuf = NULL;
    mediaBufPutFailCount = 0;
    CreateBufPool();
    InitPushPlayerThread();
    playbackStartDropTimeReset();
#ifdef WFD_RTP_STATS
    {
        wfd_pp_stats = (WFD_PUSH_PLAYER_STATS_T *)malloc(sizeof(WFD_PUSH_PLAYER_STATS_T));
        if (wfd_pp_stats)
        {
            memset(wfd_pp_stats, 0, sizeof(WFD_PUSH_PLAYER_STATS_T));
        }
        else
        {
            WFD_LOG_ERR("%s: Fail to malloc\n", __FUNCTION__);
        }
    }
#endif

}

PushPlayer::~PushPlayer()
{
    /*first set the continue flag to end and next notify all */
    if (status != PUSHPLAYERSTATUS_STOPPED)
    {
        stop();
    }
    DestroyBufPool();
    WFD_MUTEX_DESTROY(bufCtrlMutex);
#ifdef PLAYBACK_MULTI_THREAD_ENABLE
    WFD_MUTEX_INIT_LOCKED(pushPlayerExitMutex);
    pushPlayerThrdExit = 1;
    WFD_MUTEX_UNLOCK(mediaPlayDataRdyMutex); //let pushPlayerThread could exit if it is in data wait state.
    WFD_MUTEX_LOCK(pushPlayerExitMutex);
    WFD_MUTEX_DESTROY(pushPlayerExitMutex);
    WFD_MUTEX_DESTROY(bufFullMutex);
#endif
#ifdef WFD_RTP_STATS
    if (wfd_pp_stats)
        free(wfd_pp_stats);
    wfd_pp_stats = NULL;
#endif

    WFD_MUTEX_DESTROY(mediaPlayDataRdyMutex);


}

bool PushPlayer::open(IMtkPb_Ctrl_Nfy_Fct fCmpbEventNfy, void* pvTag)
{
    ScopedMutex sm(lock);

    gSelfCmpbNfy = fCmpbEventNfy;
    gSelfTag = pvTag;
    opened = false;
    uint8_t *profile = NULL;

    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;
    WFD_LOG_ERR("push player open begin\n");
    if ((status != PUSHPLAYERSTATUS_UNINIT) &&
        (status != PUSHPLAYERSTATUS_STOPPED))
    {
        WFD_LOG_ERR( "can't open, current status:%d!\n", (int)status);
        stop();
        return false;
    }

    #ifdef MTK_DTV
    #ifdef CC_S_PLATFORM
        if (avsync_freerun)
        profile = (uint8_t*)PROFILE_WFD_FREERUN;
        else
    #endif
        profile = (uint8_t*)PROFILE_WFD;
    #else /* !MTK_DTV */
        IMtkPb_Ctrl_Init();
        WFD_LOG_ERR( "IMtkPb_Ctrl_Init success\n");
        profile = (uint8_t*)NULL;
    #endif /* MTK_DTV */

    WFD_LOG_INFO( "IMtkPb_Ctrl_Open: profile = %s\n", profile==NULL?"NULL":(char *)profile);
    ret = IMtkPb_Ctrl_Open(&handle, IMTK_PB_CTRL_BUFFERING_MODEL_PUSH,
                            IMTK_PB_CTRL_APP_MASTER, profile);

    if (IMTK_PB_ERROR_CODE_OK != ret)
    {
        WFD_LOG_ERR( "cmpb open failed[ret=%d]!\n", ret);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_CONNECTION);
#endif
        return false;
    }
    WFD_LOG_INFO( "push player open success\n");

    if (bSaveLocalFile == true)
    {
        if (aFd <= 0)
        {
            aFd = ::open("./test_audio", O_RDWR | O_CREAT | O_TRUNC | O_APPEND,S_IRUSR|S_IWUSR|S_IXUSR);
        }

        if (vFd <= 0)
        {
            vFd = ::open("./test_video", O_RDWR | O_CREAT | O_TRUNC | O_APPEND,S_IRUSR|S_IWUSR|S_IXUSR);
        }
    }

    status = PUSHPLAYERSTATUS_OPENED;

    WFD_LOG_ERR( "mtk94104 pushplayer status change in open():%d!\n", (int)status);
    if (bOnlyCount == true)
    {
        aTotalSize = 0;
        vTotalSize = 0;
    }

    timeAPre.tv_sec = timeVPre.tv_sec = 0;
    timeAPre.tv_usec = timeVPre.tv_usec = 0;
    bDataFinished = false;
    opened = true;
    ClearBufPool();
#ifndef NEED_BUFFER_POOL
    do
    {
        ret = IMtkPb_Ctrl_RegCallback(handle, (void *)this, pushPlayerCallback);
        if (IMTK_PB_ERROR_CODE_OK != ret)
        {
            WFD_LOG_ERR("cmpb reg callback failed[ret=%d]!", ret);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_CONNECTION);
#endif
            break;
        }
        WFD_LOG_DEBUG("push player reg callback success");

        IMTK_PB_CTRL_ENGINE_PARAM_T     t_parm;

        memset(&t_parm, 0, sizeof(IMTK_PB_CTRL_ENGINE_PARAM_T));

        if (bCmpbPlayAudio)
            t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_AUDIO;

        if (bCmpbPlayVideo)
            t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_VIDEO;

        ret = IMtkPb_Ctrl_SetEngineParam(handle, &t_parm);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR("cmpb set engine failed[ret=%d]!", ret);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_CONNECTION);
#endif
            break;
        }
        WFD_LOG_DEBUG("push player set engine success");



    }while(0);

    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR("error:%d", ret);
        if (handle != IMTK_NULL_HANDLE)
        {
            IMtkPb_Ctrl_Close(handle);
            handle = IMTK_NULL_HANDLE;
        }
        return false;
    }
#endif//NEED_BUFFER_POOL

    status = PUSHPLAYERSTATUS_OPENED;
#ifdef WFD_DUMP_TS
    if (wfd_rtsp_conf && wfd_rtsp_conf->ts_dump_enable) {
        char *dumpPath = wfd_rtsp_conf->ts_dump_file;
        m_dumpFp = fopen(dumpPath, "w+");
        if(m_dumpFp == NULL)
        {
            WFD_LOG_ERR("failed to open/create dump file:%s, err:%s\n", dumpPath, strerror(errno));
        }
    }
#endif

    return true;
}

bool PushPlayer::play()
{
#ifdef NEED_BUFFER_POOL
    ScopedMutex sm(lock);
#endif

    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;
    WFD_LOG_INFO( "push player play begin\n");
    if ((status != PUSHPLAYERSTATUS_OPENED) && (status != PUSHPLAYERSTATUS_PAUSED) &&   \
        (status != PUSHPLAYERSTATUS_STOPPED) && (status != PUSHPLAYERSTATUS_SETMEDIAINFO))
    {
        WFD_LOG_ERR( "can't play, current status:%d!\n", (int)status);
        return false;
    }

    do
    {
#ifdef NEED_BUFFER_POOL

        ret = IMtkPb_Ctrl_RegCallback(handle, (void *)this, pushPlayerCallback);
        if (IMTK_PB_ERROR_CODE_OK != ret)
        {
            WFD_LOG_ERR( "cmpb reg callback failed[ret=%d]!\n", ret);
            break;
        }
        WFD_LOG_INFO( "push player reg callback success\n");

        IMTK_PB_CTRL_ENGINE_PARAM_T     t_parm;

        memset(&t_parm, 0, sizeof(IMTK_PB_CTRL_ENGINE_PARAM_T));

        if (bCmpbPlayAudio)
            t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_AUDIO;

        if (bCmpbPlayVideo)
            t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_VIDEO;

        ret = IMtkPb_Ctrl_SetEngineParam(handle, &t_parm);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "cmpb set engine failed[ret=%d]!\n", ret);
            break;
        }
        WFD_LOG_ERR( "push player set engine success\n");

        if (!bCmpbPlayVideo)
            media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_UNKNOWN;
        if (!bCmpbPlayAudio)
            media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_UNKNOWN;

#ifdef MTK_WFD_RTSP
        if(!isParseMediaInfoDone)
        {
                mediaInfoSema.syncBegin();
                if(!mediaInfoSema.timedWait(20000))
                {
                    WFD_LOG_ERR( "Error mediaInfo parse time out !\n");
#ifdef __ANDROID__
                    pushplayer_send_command(RTP_ERR_TIMEOUT);
#endif
                }
                mediaInfoSema.syncEnd();
        }

#endif

        ret = IMtkPb_Ctrl_SetMediaInfo(handle, &media_info);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "cmpb set media info failed[ret=%d]!\n", ret);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_FATAL);
#endif
            break;
        }
        WFD_LOG_INFO( "push player set media success\n");
#endif  //NEED BUFFER_POOL

#ifdef ENABLE_HDCP2X_RX
        /* Set HDCP2.0 keys after PID was set to DMX */
        // Another path to set key through CPMB -> SWDMX
        if (hdcp2x_rx_isAuthenticated())
        {
            IMTK_PB_CTRL_PARAM_SET_ENCRYPT_INFO HDCPSetKeyInfo;
            HDCPSetKeyInfo.eEncryptMode = IMTK_PB_CTRL_ENCRYPT_MODE_RESERVE;
            WFD_LOG_ERR( "HDCP is authenticated, setting key to driver...\n");
            hdcp2x_rx_getRiv((unsigned char *)&(HDCPSetKeyInfo.uEncryptInfo.u1Reserved));
            IMtkPb_Ctrl_SetEncryptInfo(handle, &HDCPSetKeyInfo);
        }
        else
        {
            WFD_LOG_ERR( "debug:HDCP is not authenticated...\n");

#ifdef __ANDROID__
            pushplayer_send_command(HDCP2X_TIMEOUT_HDCP_CREATE_SESSION_STR);
#endif
        }

#endif /* ENABLE_HDCP2X_RX */
        IMTK_PB_CTRL_RECT_T rect;
        rect.u4X=0;
        rect.u4Y=0;
        rect.u4W=10000;
        rect.u4H=10000;
        ret = IMtkPb_Ctrl_SetDisplayRectangleEx(handle,&rect,&rect);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR("cmpb set SetDisplayRectangle failed[ret=%d]!", ret);
            break;
        }

        ret = IMtkPb_Ctrl_Play(handle, 0);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "cmpb play failed[ret=%d]!\n", ret);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_FATAL);
#endif
            return false;
        }
        WFD_LOG_ERR( "push player play success\n");
        isSetMediaInfoDone = true;

    }while(0);


    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR("error:%d", ret);
            if (handle != 0)
            {
                 IMtkPb_Ctrl_Close(handle);
                 handle = 0;
            }
            return false;
        }
         status = PUSHPLAYERSTATUS_PLAYED;
         return true;
}

bool PushPlayer::pause()
{
#ifndef MTK_BDP_BOX
    WFD_LOG_ERR( "PushPlayer::pause\n");
    ScopedMutex sm(lock);
    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;

    if (status != PUSHPLAYERSTATUS_PLAYED)
    {
        WFD_LOG_ERR( "can't pause, current status:%d!\n", (int)status);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }
    #ifndef MTK_WFD_RTSP
        WFD_LOG_ERR( "CMPB Pause\n");
        ret = IMtkPb_Ctrl_Pause(handle);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "cmpb pause failed[ret=%d]!\n", ret);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_FATAL);
#endif
            return false;
        }

        status = PUSHPLAYERSTATUS_PAUSED;

    #else

        ret = IMtkPb_Ctrl_Stop(handle);

        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "cmpb stop failed[ret=%d]!\n", ret);
            sleep(1);
#ifdef __ANDROID__
            pushplayer_send_command(RTP_ERR_FATAL);
#endif
            return false;
        }
        status = PUSHPLAYERSTATUS_STOPPED;


        /*
        fprintf(stderr, "Executing IMtkPb_Ctrl_Close\n", __FUNCTION__);
        ret= IMtkPb_Ctrl_Close(handle);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR("cmpb close failed[ret=%d]!", ret);
        }
        fprintf(stderr, "IMtkPb_Ctrl_Close done\n", __FUNCTION__);
        status = PUSHPLAYERSTATUS_STOPPED;
        handle = IMTK_NULL_HANDLE;
        */
        reset();
        isParseMediaInfoDone = 1;
        isSetMediaInfoDone = true;
    #endif //ifndef MTK_WFD_RTSP
        return true;
#else
    bool re = stop();
    isParseMediaInfoDone = 1;
    return re;
#endif

}


bool PushPlayer::stop()
{
    ScopedMutex sm(lock);

    if ((status != PUSHPLAYERSTATUS_PAUSED) &&
        (status != PUSHPLAYERSTATUS_PLAYED) &&
        (status != PUSHPLAYERSTATUS_OPENED) &&
        (status != PUSHPLAYERSTATUS_SETMEDIAINFO))
    {
        WFD_LOG_ERR( "can't stop, current status:%d!\n", (int)status);
        return false;
    }

    setEOS();

    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;

    WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_Stop\n", __FUNCTION__);
    ret = IMtkPb_Ctrl_Stop(handle);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "cmpb stop failed[ret=%d]!\n", ret);
    }
#ifdef MTK_BDP_BOX
    if (pushPlayerThrdCmpbBuf)
    {
        WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_ReleaseBuffer\n", __FUNCTION__);
        IMtkPb_Ctrl_ReleaseBuffer(handle, pushPlayerThrdCmpbBuf);
        pushPlayerThrdCmpbBuf = NULL;
    }

    WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_SetMediaInfo\n", __FUNCTION__);
    ret = IMtkPb_Ctrl_SetMediaInfo(handle, NULL);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR("cmpb SetMediaInfo failed[ret=%d]!", ret);
    }
#endif
    WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_Close\n", __FUNCTION__);
    ret= IMtkPb_Ctrl_Close(handle);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "cmpb close failed[ret=%d]!\n", ret);
    }
    WFD_LOG_ERR( "%s IMtkPb_Ctrl_Close done\n", __FUNCTION__);
    status = PUSHPLAYERSTATUS_STOPPED;
    WFD_LOG_ERR( "mtk94104 pushplayer status change in 1 stop():%d!\n", (int)status);
    handle = IMTK_NULL_HANDLE;

#ifdef PLAYBACK_MULTI_THREAD_ENABLE
    pushPlayerThrdRestart = 1;
#endif
    reset();
#ifdef WFD_DUMP_TS
    if (m_dumpFp){
        fclose(m_dumpFp);
        m_dumpFp = NULL;
    }
#endif

    return true;
}

void PushPlayer::reset()
{


    if (aFd > 0)
    {
        ::close(aFd);
        aFd = 0;
    }
    if (vFd > 0)
    {
        ::close(vFd);
        vFd = 0;
    }

    if (bOnlyCount == true)
    {
        WFD_LOG_ERR( "******total audio size:%ld******\n", aTotalSize);
        WFD_LOG_ERR( "******total video size:%ld******\n", vTotalSize);

        aTotalSize = 0;
        vTotalSize = 0;
    }

    pCmpbBufA = NULL;
    pCmpbBufV = NULL;
    uiAWriteLen = 0;
    uiVWriteLen = 0;

    timeAPre.tv_sec = timeVPre.tv_sec = 0;
    timeAPre.tv_usec = timeVPre.tv_usec = 0;

    //fillBufferPool(NULL, 0, NULL, 0, true);
    isGetBufferReady = 1;
    bufferSuccessCnt = 0;
    bufferFailCnt = 0;
    firstDataFlag = 1;
#ifdef NEED_BUFFER_POOL
    isParseMediaInfoDone = false;
    isSetMediaInfoDone = false;
#else
    isParseMediaInfoDone = true;
    isSetMediaInfoDone = true;
#endif
    /*
    if(mediaHeader)
    {
        delete[] mediaHeader;
    }
    */
    mediaHeader = NULL;
    mediaHeaderSize = 0;
    mediaPlayWaitFlag = 0;
#if 0
    if (pushPlayerThrdCmpbBuf)
        {
           IMtkPb_Ctrl_ReleaseBuffer(handle, pushPlayerThrdCmpbBuf);
        }
#endif

    pushPlayerThrdCmpbBuf = NULL;
    mediaBufPutFailCount = 0;
    ClearBufPool();
    playbackStartDropTimeReset();
}
bool PushPlayer::resume()
{
    WFD_LOG_ERR( "PushPlayer::resume\n");
    ScopedMutex sm(lock);
#ifndef MTK_WFD_RTSP
    if (status != PUSHPLAYERSTATUS_PAUSED)
    {
        WFD_LOG_ERR( "can't resume, current status:%d!\n", (int)status);
        return false;
    }

    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;

    WFD_LOG_ERR( "CMPB Play\n");
    ret = IMtkPb_Ctrl_Play(handle, 0);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "cmpb resume failed[ret=%d]!\n", ret);
        return false;
    }
#else
    if (status != PUSHPLAYERSTATUS_STOPPED)
    {
        WFD_LOG_ERR( "can't resume, current status:%d!\n", (int)status);
        return false;
    }

    WFD_LOG_ERR( "play()\n");
    if(play() == false)
    {
        WFD_LOG_ERR( "can't try resume failed %d!\n", (int)status);
        return false;
    }
#endif

    status = PUSHPLAYERSTATUS_PLAYED;
    WFD_LOG_ERR( "mtk94104 pushplayer status change in  resume():%d!\n", (int)status);
    return true;
}

#ifndef NEED_BUFFER_POOL
bool PushPlayer::SetMediaInfo()
{
    IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;
#ifndef RTSP_LOCAL_TEST
    WFD_LOG_DEBUG("media type = %d \n", (int)media_info.eMediaType);
    WFD_LOG_DEBUG("media duration = %x \n", (int)media_info.u4TotalDuration);
    WFD_LOG_DEBUG("media size = %x \n", (int)media_info.u8Size);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = %d \n", media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = %d \n", media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eNumCh = %d \n", media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eNumCh);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eSampleRate = %d \n", media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eSampleRate);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eBitsPerSample = %d \n", media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eBitsPerSample);
    WFD_LOG_DEBUG("media_info.uFormatInfo.tTsInfo.eVidInfo.uVidCodecInfo.t_h264_info.eFrmRate = %d \n", media_info.uFormatInfo.tTsInfo.eVidInfo.uVidCodecInfo.t_h264_info.eFrmRate);
#endif
    if (!bCmpbPlayVideo)
        media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_UNKNOWN;
    if (!bCmpbPlayAudio)
        media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_UNKNOWN;

    ret = IMtkPb_Ctrl_SetMediaInfo(handle, &media_info);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR("cmpb set media info failed[ret=%d]!", ret);
        if (handle != IMTK_NULL_HANDLE)
        {
            IMtkPb_Ctrl_Close(handle);
            handle = IMTK_NULL_HANDLE;
        }
        return false;
    }
    WFD_LOG_DEBUG("push player set media success");
    isSetMediaInfoDone = true;
    status = PUSHPLAYERSTATUS_SETMEDIAINFO;
    return true;
}

#endif

#ifdef NEED_BUFFER_POOL
bool PushPlayer::SetMediaInfo(MediaInfo &info)
{
    memset(&media_info, 0, sizeof(media_info));

    WFD_LOG_ERR( "type:%d, audio codec:%d, video codec:%d, av codec = %d!\n",
        info.type, info.audioCodec, info.videoCodec, info.avCodec);
#ifndef RTSP_LOCAL_TEST
    /*
     *TO DO:set the media info
     */

    media_info.u4TotalDuration = 0xFFFFFFFF;
    media_info.u8Size = -1;


    if ((info.type & mediatype_video) == mediatype_video)
    {
        //media_info.uFormatInfo.tMtkP0Info.tVidInfo.tAspRatio.eAspectRatio = IMTK_PB_CTRL_SRC_ASPECT_RATIO_UNKNOWN;
        media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MTK_P0;

        switch (info.videoCodec)
        {
            case MEDIACODEC_H264:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                break;
            }
            case MEDIACODEC_MPV:/*MPEG-1 or 2 video*/
            case MEDIACODEC_MP1S:/*MPEG-1 System Stream*/
            case MEDIACODEC_MP2P:/*MPEG-2 Program Stream*/
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MPEG1_2;
                break;
            }
            case MEDIACODEC_MP4V_ES:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MPEG4;
                break;
            }
            case MEDIACODEC_JPEG:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MJPEG;
                break;
            }
            default:
            {
                /*not support, do nothing*/
                break;
            }
        }
    }


    if ((info.type & mediatype_audio) == mediatype_audio)
    {
        media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MTK_P0;

        switch (info.audioCodec)
        {
            case MEDIACODEC_MPA:/*MPEG-1 or 2 audio*/
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_MPEG;
                break;
            }
            case MEDIACODEC_MPA_ROBUST:
            case MEDIACODEC_X_MP3_DRAFT_00:
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_MP3;
                break;
            }
            case MEDIACODEC_AC3:/*AC3 audio*/
            case MEDIACODEC_EAC3:
            case MEDIACODEC_MP4A_LATM:
            case MEDIACODEC_MPEG4_GENERIC:
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_AAC;
                break;
            }
            case MEDIACODEC_PCMA:/*PCM a-law audio*/
            case MEDIACODEC_PCMU:/*PCM u-law audio*/
            case MEDIACODEC_DVI4:/*DVI4 (IMA ADPCM) audio*/
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_PCM;
                break;
            }
            default:
            {
                break;
            }
        }
    }

    if ((info.type & mediatype_av) == mediatype_av)/*currently only ts*/
    {
        switch(info.avCodec)
        {
            case MEDIACODEC_MP2T:
            {
                WFD_LOG_INFO( "for normal A/V codec setting\n");
                media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MPEG2_TS;
                media_info.uFormatInfo.tTsInfo.ePacketType = IMTK_PB_CTRL_MPEG2_TS_PACKET_TYPE_188BYTE;
                media_info.u4TotalDuration = 0xFFFFFFFF;
                media_info.u8Size = -1;

                media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 18;
                media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc= IMTK_PB_CTRL_AUD_ENC_DD;
                media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = 19;
                break;
            }
            case MEDIACODEC_WFDAV:
            {
                WFD_LOG_ERR( "for WFD A/V codec setting, acodec = %d, vcodec = %d \n", info.audioCodec, info.videoCodec);
                // 1. media type
                media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MPEG2_TS;
                media_info.uFormatInfo.tTsInfo.ePacketType = IMTK_PB_CTRL_MPEG2_TS_PACKET_TYPE_188BYTE;
                media_info.u4TotalDuration = 0xFFFFFFFF;
                media_info.u8Size = -1;

                // 2. audio codec & pid
                switch(info.audioCodec)
                {
                    case MEDIACODEC_WFDA_AAC:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_AAC;
                        break;
                    case MEDIACODEC_WFDA_AC3:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_DD;
                        break;
                    case MEDIACODEC_WFDA_DTS:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_DTS;  // for test, actually be DTS
                        break;
                    case MEDIACODEC_WFDA_LPCM:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_PCM;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.e_pcm_type = IMTK_PB_CTRL_AUD_PCM_TYPE_NORMAL;
                        WFD_LOG_ERR( "[WFD] SET PCM TYPE = IMTK_PB_CTRL_AUD_PCM_TYPE_NORMAL \n");
                        break;
                    default:
                        WFD_LOG_ERR( "Error PushPlayer::SetMediaInfo unknown audio codec \n");
                        assert(0);
                        break;
                }
                //media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = 19;

                // video codec & pid
                switch(info.videoCodec)
                {
                    case MEDIACODEC_WFDV_H264:
                        media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                        media_info.uFormatInfo.tTsInfo.eVidInfo.uVidCodecInfo.t_h264_info.eFrmRate = convertFPS(info.fPs);
                        break;
                    default:
                        WFD_LOG_ERR( "Error PushPlayer::SetMediaInfo unknown video codec \n");
                        /* Fixme: when aud-only */
                        //assert(0);
                        break;
                }
                //media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 18;

                break;
            }
            default:
            {
                break;
            }
        }

    }
#endif

    return true;
}

#else
bool PushPlayer::SetMediaInfo(MediaInfo &info)
{
    int audio_pid = -1, video_pid = -1;
    //WFD_MUTEX_LOCK(mediaInfoMutex);
#ifdef NEED_BUFFER_POOL
    if (isParseMediaInfoDone)
    {
        audio_pid = media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid;
        video_pid = media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid;
    }
#else
    if (isParseMediaInfoDone)
    {
        audio_pid = 4352;
        video_pid = 4113;
        WFD_LOG_ERR( "SET PID :audio_pid = 4352,video_pid = 4113");
    }
#endif
    memset(&media_info, 0, sizeof(media_info));
    //WFD_MUTEX_UNLOCK(mediaInfoMutex);

    WFD_LOG_DEBUG("type:%d, audio codec:%d, video codec:%d, av codec = %d!",
        info.type, info.audioCodec, info.videoCodec, info.avCodec);
#ifndef RTSP_LOCAL_TEST
    media_info.u4TotalDuration = 0xFFFFFFFF;
    media_info.u8Size = -1;


    if ((info.type & mediatype_video) == mediatype_video)
    {
        //media_info.uFormatInfo.tMtkP0Info.tVidInfo.tAspRatio.eAspectRatio = IMTK_PB_CTRL_SRC_ASPECT_RATIO_UNKNOWN;
        media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MTK_P0;

        switch (info.videoCodec)
        {
            case MEDIACODEC_H264:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                break;
            }
            case MEDIACODEC_MPV:/*MPEG-1 or 2 video*/
            case MEDIACODEC_MP1S:/*MPEG-1 System Stream*/
            case MEDIACODEC_MP2P:/*MPEG-2 Program Stream*/
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MPEG1_2;
                break;
            }
            case MEDIACODEC_MP4V_ES:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MPEG4;
                break;
            }
            case MEDIACODEC_JPEG:
            {
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_MJPEG;
                break;
            }
            default:
            {
                /*not support, do nothing*/
                break;
            }
        }
    }


    if ((info.type & mediatype_audio) == mediatype_audio)
    {
        media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MTK_P0;

        switch (info.audioCodec)
        {
            case MEDIACODEC_MPA:/*MPEG-1 or 2 audio*/
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_MPEG;
                break;
            }
            case MEDIACODEC_MPA_ROBUST:
            case MEDIACODEC_X_MP3_DRAFT_00:
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_MP3;
                break;
            }
            case MEDIACODEC_AC3:/*AC3 audio*/
            case MEDIACODEC_EAC3:
            case MEDIACODEC_MP4A_LATM:
            case MEDIACODEC_MPEG4_GENERIC:
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_AAC;
                break;
            }
            case MEDIACODEC_PCMA:/*PCM a-law audio*/
            case MEDIACODEC_PCMU:/*PCM u-law audio*/
            case MEDIACODEC_DVI4:/*DVI4 (IMA ADPCM) audio*/
            {
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_PCM;
                break;
            }
            default:
            {
                break;
            }
        }
    }

    if ((info.type & mediatype_av) == mediatype_av)/*currently only ts*/
    {
        switch(info.avCodec)
        {
            case MEDIACODEC_MP2T:
            {
                WFD_LOG_INFO( "for normal A/V codec setting\n");
                media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MPEG2_TS;
                media_info.uFormatInfo.tTsInfo.ePacketType = IMTK_PB_CTRL_MPEG2_TS_PACKET_TYPE_188BYTE;
                media_info.u4TotalDuration = 0xFFFFFFFF;
                media_info.u8Size = -1;

                media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 18;
                media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc= IMTK_PB_CTRL_AUD_ENC_DD;
                media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = 19;
                break;
            }
            case MEDIACODEC_WFDAV:
            {
                WFD_LOG_ERR( "for WFD A/V codec setting, acodec = %d, vcodec = %d \n", info.audioCodec, info.videoCodec);
                // 1. media type
                media_info.eMediaType = IMTK_PB_CTRL_MEDIA_TYPE_MPEG2_TS;
                media_info.uFormatInfo.tTsInfo.ePacketType = IMTK_PB_CTRL_MPEG2_TS_PACKET_TYPE_188BYTE;
                media_info.u4TotalDuration = 0xFFFFFFFF;
                media_info.u8Size = -1;

                // 2. audio codec & pid
                switch(info.audioCodec)
                {
                    case MEDIACODEC_WFDA_AAC:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_AAC;
                        break;
                    case MEDIACODEC_WFDA_AC3:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_DD;
                        break;
                    case MEDIACODEC_WFDA_DTS:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_DTS;  // for test, actually be DTS
                        break;
                    case MEDIACODEC_WFDA_LPCM:
                        media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_PCM;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.e_pcm_type = IMTK_PB_CTRL_AUD_PCM_TYPE_NORMAL;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eNumCh = IMTK_PB_CTRL_AUD_CH_STEREO;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eSampleRate = IMTK_PB_CTRL_AUD_SAMPLE_RATE_48K;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.u2BlockAlign = 4;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.eBitsPerSample = IMTK_PB_CTRL_AUD_PCM_BIT_DEPTH_16;
                        media_info.uFormatInfo.tTsInfo.eAudInfo.uAudCodecInfo.t_pcm_info.fgBigEndian = 0;
                        WFD_LOG_ERR( "[WFD] SET PCM TYPE = IMTK_PB_CTRL_AUD_PCM_TYPE_NORMAL \n");
                        break;
                    default:
                        WFD_LOG_ERR( "Error PushPlayer::SetMediaInfo unknown audio codec \n");
                        assert(0);
                        break;
                }
                //media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = 19;

                // video codec & pid
                switch(info.videoCodec)
                {
                    case MEDIACODEC_WFDV_H264:
                        media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H264;
                        media_info.uFormatInfo.tTsInfo.eVidInfo.uVidCodecInfo.t_h264_info.eFrmRate = convertFPS(info.fPs);
                        break;
                #ifdef MTK_WFD_4K_SUPPORT
                    case MEDIACODEC_WFDV_H265:
                        media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_H265;
                        media_info.uFormatInfo.tTsInfo.eVidInfo.uVidCodecInfo.t_h265_info.eFrmRate = convertFPS(info.fPs);
                        break;
                #endif
                    default:
                        WFD_LOG_ERR( "Error PushPlayer::SetMediaInfo unknown video codec \n");
                        /* Fixme: when aud-only */
                        //assert(0);
                        break;
                }
                //media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 18;
                if (isParseMediaInfoDone && (audio_pid > -1 || video_pid > -1))
                {
                    media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = video_pid;
                    media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = audio_pid;
                    WFD_LOG_ERR( "[DEBUG] SET PID default \n");
                }

                break;
            }
            default:
            {
                break;
            }
        }

    }
#endif

    return true;
}
#endif
void PushPlayer::setEOS()
{
    WFD_LOG_ERR( "PushPlayer::setEOS handle = %u \n", handle);
    if(bDataFinished == false)
    {
        if(handle != IMTK_NULL_HANDLE)
        {
            WFD_LOG_ERR( "PushPlayer::setEOS 1. set push eos \n");
            IMtkPb_Ctrl_SetPushModelEOS(handle);
            WFD_LOG_ERR( "PushPlayer::setEOS 2. set push eos \n");
        }
    }
    bDataFinished = true;
}

void PushPlayer::SendData(GetBufData & sender)
{

//Add for remove buffer poll


    if(sender.type == mediatype_av)
    {
#ifdef WFD_RTP_STATS
        wfd_pp_stats->total_received_size += sender.iLen;
#endif
        mediaBufConsumeAndSend(sender);
      //  WFD_LOG_ERR( "PushPlayer::SendData received_size = %d\n",sender.iLen);

        return;
    }
    else
    {
        WFD_LOG_ERR( "[qjdbg] pushplayer senddata type error : not av\n");
    }

}


void PushPlayer::getCurrentTime(PLAYBACK_TIME_T *tp)
{
    struct timeval ctv;

    gettimeofday(&ctv, NULL);
    tp->sec = ctv.tv_sec;
    tp->usec = ctv.tv_usec;
}

void PushPlayer::playbackStartDropTimeReset(void)
{
    memset(&playbackDropTime, 0, sizeof(PLAYBACK_TIME_T));
}

void PushPlayer::playbackStartDropTimeSet(unsigned int sec, unsigned int msec)
{
    getCurrentTime(&playbackDropTime);
    //fprintf(stderr,"%s-ctime:%u.%u\n", __FUNCTION__, playbackDropTime.sec, playbackDropTime.usec);
    playbackDropTime.sec += sec;
    playbackDropTime.usec += (msec*1000);

    //fprintf(stderr,"%s-stime:%u.%u\n", __FUNCTION__, playbackDropTime.sec, playbackDropTime.usec);
}


int PushPlayer::playbackStartDropTimeCheckDoDrop(void)
{
    /* On return 1, DO drop.
       On return 0, DO-NOT drop.
     */
    PLAYBACK_TIME_T *tp = &playbackDropTime, *ctp;
    PLAYBACK_TIME_T curtime;

    if (tp->sec==0 && tp->usec==0)
    {
        /* timer is not set, do not drop */
        return 0;
    }
    /* check against current time */
    getCurrentTime(&curtime);
    ctp = &curtime;
    if (ctp->sec < tp->sec)
    {
        /* timer is not hit, DO drop */
        return 1;
    }
    else if (ctp->sec >= tp->sec)
    {
        /* sec already fired, check usec */
        if (ctp->usec >= tp->usec)
        {
            /* timer hit! */
            playbackStartDropTimeReset();
            //fprintf(stderr, "%s:%u.%u\n", __FUNCTION__, ctp->sec, ctp->usec);
            WFD_LOG_ERR( "Stop dropping WFD data\n");
            return 0;
        }
        else
            return 1;
    }
    return 0;

}


/*
*   @fillBufferPool: insert the buffer to the pool, untill pool is full, then insert the rest to the next pool
*   @param data/dataSize: the buffer need to be inserted to the pool
*   @param pool/poolSize : the pool
*   @param resetPool: to reset the pool
*   @return: 1: pool is full;  0: pool is not full; -1: error
*/
int PushPlayer::fillBufferPool(unsigned char * data,unsigned int dataSize,unsigned char * pool,unsigned int poolSize, bool resetPool)
{
    int isPoolFull = 0;
    static unsigned int poolIndex = 0;
    static unsigned char* restData = new unsigned char[CMPB_PRIVATE_PS_BUF_SIZE];
    static unsigned int restSize = 0;
    assert(restData);
    if(resetPool)
    {
        WFD_LOG_ERR( "pool reset\n");
        isPoolFull = 0;
        poolIndex = 0;
        restSize = 0;
        return 0;
    }

    assert(data);
    assert(pool);
    if(poolSize == 0)
    {
        WFD_LOG_ERR("Error pool size is 0");
        return -1;
    }
    if(dataSize == 0)
    {
        WFD_LOG_ERR("Error data size is 0");
        return -1;
    }

    WFD_LOG_DEBUG("dataSize = %u, poolSize = %u, poolIndex = %u ", dataSize, poolSize, poolIndex);
    assert(dataSize + restSize < poolSize); // assume the restSize is small
    if(restSize > 0)
    {
        WFD_LOG_DEBUG("restSize = %u ", restSize);
        memcpy(pool, restData, restSize);
        poolIndex += restSize;
        restSize = 0;
    }

    if(poolIndex + dataSize < poolSize)
    {
        memcpy(pool + poolIndex, data, dataSize);
        poolIndex += dataSize;
        isPoolFull = 0;
    }
    else if(poolIndex + dataSize >= poolSize)
    {
        unsigned int copySize = poolSize - poolIndex;
        restSize = dataSize - copySize;
        memcpy(pool + poolIndex, data, copySize);
        poolIndex = 0;
        isPoolFull = 1;
        if(restSize > 0)
        {
            memcpy(restData, data + copySize, restSize);
        }
    }

    return isPoolFull;
}

/*
*   @mediaBufPoolPut: insert the buffer to the pool, untill pool is full, then insert the rest to the next pool
*   @param data/dataSize: the buffer need to be inserted to the pool
*   @return: 0: ok, otherwise: fail.
*/
int PushPlayer::mediaBufPoolPut(unsigned char * data,unsigned int dataSize)
{
    PushPlayerBuf *pool;
    int remain_len = 0;
    unsigned char *curbufidx = NULL;
    int ret = 0;
    int data_size = (int)dataSize;
    int availablesize;
    int restsize;
    int next_idx = 0;

    pool = &mediaBufPool;
    /* calculate available buffer size */
    remain_len = pool->total_size - pool->bufferred_size;
    if (pool->w_idx == -1 || data_size > remain_len)
    {
        WFD_LOG_ERR( "%s: Out-Of-Buffer (req=%d, remain=%d, w_idx=%d, r_idx=%d)\n",
                __FUNCTION__, data_size, remain_len, pool->w_idx, pool->r_idx);
#ifdef WFD_RTP_STATS
        wfd_pp_stats->oob_count ++;
#endif
        return -1;
    }
    /* start to copy data to buffer */
    if ((pool->w_start_pos + data_size) <= WFD_TS_BUF_UNIT_SIZE)
    {
        /* current bufIdx is large enough to put this data */
        curbufidx = pool->bufIdx[pool->w_idx];
        memcpy(curbufidx + pool->w_start_pos, data, data_size);
        WFD_MUTEX_LOCK(bufCtrlMutex);
        pool->w_start_pos += data_size;
        if (pool->w_start_pos == WFD_TS_BUF_UNIT_SIZE)
        {
            /* current bufIdx is full, advance w_idx */
            pool->w_start_pos = 0;
            ADVANCE_BUF_POS(pool->w_idx);
            if (pool->w_idx == pool->r_idx)
                pool->w_idx = -1; //full
            pool->bufferred_size += data_size;
            WFD_MUTEX_UNLOCK(bufCtrlMutex);
#ifdef PLAYBACK_MULTI_THREAD_ENABLE
            /* a new block is ready, notify consumer to read */
            if  (mediaPlayWaitFlag)
            {
                mediaPlayDataReadyNotify();
            }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */
        }
        else
        {
            pool->bufferred_size += data_size;
            WFD_MUTEX_UNLOCK(bufCtrlMutex);
        }
    }
    else
    {
        /* current bufIdx is not enough to put this data */
        availablesize = WFD_TS_BUF_UNIT_SIZE - pool->w_start_pos;
        restsize = data_size - availablesize;
        if (restsize > WFD_TS_BUF_UNIT_SIZE)
        {
            WFD_LOG_ERR( "!!!ERRPR!!! data is too large to put.!!!!\n");
            assert(0);
        }
        curbufidx = pool->bufIdx[pool->w_idx];
        memcpy(curbufidx + pool->w_start_pos, data, availablesize);
        next_idx = pool->w_idx;
        ADVANCE_BUF_POS(next_idx);
        if (next_idx == pool->r_idx)
        {
            WFD_LOG_ERR( "!!!ERROR!!!! buf idx is incorrect !!!!\n");
            assert(0);
        }
        curbufidx = pool->bufIdx[next_idx];
        memcpy(curbufidx, data+availablesize, restsize);
        WFD_MUTEX_LOCK(bufCtrlMutex);
        pool->w_start_pos = restsize;
        if (pool->w_start_pos == WFD_TS_BUF_UNIT_SIZE)
        {
            pool->w_start_pos = 0;
            ADVANCE_BUF_POS_CNT(pool->w_idx, 2);
        }
        else
        {
            ADVANCE_BUF_POS(pool->w_idx);
        }
        if (pool->w_idx == pool->r_idx)
            pool->w_idx = -1; //full
        pool->bufferred_size += data_size;
        WFD_MUTEX_UNLOCK(bufCtrlMutex);

#ifdef PLAYBACK_MULTI_THREAD_ENABLE
        /* a new block is ready, notify consumer to read */
        if  (mediaPlayWaitFlag)
        {
            mediaPlayDataReadyNotify();
        }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */
    }

    return ret;
}

int PushPlayer::mediaBufPoolReadyToParse(void)
{
    /* To get ready to be parsed of a TS stream,
       the buf has to be at least 512k long */
    PushPlayerBuf *pool = &mediaBufPool;
    if (pool->bufferred_size >= WFD_TS_PARSE_MIN_SIZE)
        return 1;
    else
        return 0;
}

int PushPlayer::mediaPlayDataReadyNotify(void)
{
    mediaPlayWaitFlag = 0;
    WFD_MUTEX_UNLOCK(mediaPlayDataRdyMutex);
    return 0;
}

int PushPlayer::mediaPLayFirstDataReadyWait(void)
{
    //wait first data blocks to parse TS info
    WFD_MUTEX_INIT_LOCKED(mediaPlayDataRdyMutex);
    WFD_MUTEX_LOCK(mediaPlayDataRdyMutex);
    return 0;
}

int PushPlayer::mediaPlayDataReadyWait(void)
{
    //int ret = 0;
#define DATA_READY_MAX_WAIT_MS      50 /* ms */

    WFD_MUTEX_INIT_LOCKED(mediaPlayDataRdyMutex);
    mediaPlayWaitFlag = 1;
    //WFD_MUTEX_TIMEDLOCK(mediaPlayDataRdyMutex, (DATA_READY_MAX_WAIT_MS*1000), ret);
    return 0;
}

int PushPlayer::mediaBufGetBufCount(void)
{
    int cnt = 0;

    PushPlayerBuf *pool = &mediaBufPool;
    WFD_MUTEX_LOCK(bufCtrlMutex);
    if (pool->w_idx == pool->r_idx) //buffer empty
        cnt = 0;
    else if (pool->w_idx == -1) //buffer full
        cnt = WFD_BUF_CHAIN_LEN;
    else if (pool->w_idx > pool->r_idx)
        cnt = (pool->w_idx - pool->r_idx);
    else //r_idx > w_idx
        cnt = ((WFD_BUF_CHAIN_LEN - pool->r_idx) + pool->w_idx);
    WFD_MUTEX_UNLOCK(bufCtrlMutex);

    return cnt;
}

#ifdef WFD_LATENCY_DEBUG
int PushPlayer::check_latency_tei_bit(unsigned char *buf, int buf_len)
{
#define TSP_SIZE            188
#define TS_TEI_BITMASK      0x80
    unsigned char *ptr, *ptr_end;
    struct timeval c_tv;
    int ret = 0;

    if (!buf || !buf_len)
        return ret;
    ptr = buf;
    ptr_end = buf+buf_len;

    while(ptr < ptr_end)
    {
        if (ptr[0] != 0x47)
            WFD_LOG_ERR( "Not TS Header!\n");
        else if (ptr[1] & TS_TEI_BITMASK)
        {
            /* show tsp */
            memset(&c_tv, 0, sizeof(struct timeval));
            if (gettimeofday(&c_tv, NULL) != 0)
                WFD_LOG_ERR( "Failed to get time!\n");
            else
            {
                ret = 1;
                WFD_LOG_ERR( "[%s@%u:%u]\n", "TS_TEI(wfd_app)", (unsigned int)c_tv.tv_sec, (unsigned int)c_tv.tv_usec);
                break;
            }

        }
        ptr += 188;
    }
    return ret;
}
#endif /* WFD_LATENCY_DEBUG */

int PushPlayer::mediaBufConsume(int blocks)
{

    return 0;
}

int PushPlayer::mediaBufConsumeAndSend(GetBufData & sender)
{
    int ret = 0;
    static unsigned int dataNo = 0 ;
    dataNo++;

    ScopedMutex sm(lock);
    if (status != PUSHPLAYERSTATUS_SETMEDIAINFO && status != PUSHPLAYERSTATUS_PLAYED)
    {
        return -1;
    }
    if (!pushPlayerThrdCmpbBuf)
    {
        ret = IMtkPb_Ctrl_GetBuffer(handle, sender.iLen, &pushPlayerThrdCmpbBuf);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "%s: GetBuffer Failed, ret=%d, reqsize=%d \n", __FUNCTION__, ret, sender.iLen);
#ifdef WFD_RTP_STATS
        wfd_pp_stats->cmpb_getbuffer_error_count++;
#endif
            return -1;
        }
    }
    memcpy(pushPlayerThrdCmpbBuf, sender.pBuf, sender.iLen);

    if (dataNo == 1 || (dataNo%1000) == 0)
    {
        WFD_LOG_TIME("PushPlayer....send data..No = %d\n", dataNo);
    }

#ifdef WFD_DUMP_TS
    dumpTsToFile(sender.pBuf, sender.iLen);
#endif

    ret = IMtkPb_Ctrl_SendData(handle, sender.iLen, pushPlayerThrdCmpbBuf);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "[WFD] %s: IMtkPb_Ctrl_SendData Failed\n", __FUNCTION__);
#ifdef WFD_RTP_STATS
        wfd_pp_stats->cmpb_senddata_error_count++;
#endif
        //IMtkPb_Ctrl_ReleaseBuffer(handle, pushPlayerThrdCmpbBuf);
        pushPlayerThrdCmpbBuf = NULL;
        return -1;
    }
    else
    {
      // WFD_LOG_ERR( "pushplayer  IMtkPb_Ctrl_SendData success\n");
#ifdef WFD_RTP_STATS
        wfd_pp_stats->total_consumed_size += sender.iLen;
#endif
        pushPlayerThrdCmpbBuf = NULL;
    }
    return 0;
}

int PushPlayer::mediaBufConsumeAndSend(int *firstFlag)
{
    int reqSize = 0;
    int ret = 0;
    int blockNeeded = 0;

    if (*firstFlag)
        reqSize = WFD_TS_PARSE_MIN_SIZE;
    else
        reqSize = WFD_TS_BUF_UNIT_SIZE;
    if (!isSetMediaInfoDone)
        {
            WFD_LOG_ERR( " %s error: isSetMediaInfoDone=0\n", __FUNCTION__);
            return -1;
        }

#ifdef __ANDROID__
    ScopedMutex sm(lock);

    if(handle == IMTK_NULL_HANDLE)
    return -1;
#endif

    if (!pushPlayerThrdCmpbBuf && reqSize == WFD_TS_BUF_UNIT_SIZE)
    {
        ret = IMtkPb_Ctrl_GetBuffer(handle, reqSize, &pushPlayerThrdCmpbBuf);
        if (ret != IMTK_PB_ERROR_CODE_OK)
        {
            WFD_LOG_ERR( "%s: GetBuffer Failed, ret=%d (reqsize=%d,w_idx=%d,r_idx=%d,bufferred=%d)\n",
                    __FUNCTION__, ret, reqSize, mediaBufPool.w_idx,mediaBufPool.r_idx, mediaBufPool.bufferred_size);
#ifdef WFD_RTP_STATS
        wfd_pp_stats->cmpb_getbuffer_error_count++;
    #ifdef MTK_DTV
        /* Note this is suggested by CMPB owner Junhai to add 100ms sleep if CMPB GetBuffer was failed. */
        usleep(50000);
    #endif

#endif
            return -1;
        }
    }
    blockNeeded = (reqSize/WFD_TS_BUF_UNIT_SIZE);
    if (blockNeeded > 0 && mediaBufConsume(blockNeeded) != 0)
    {
      /*  WFD_LOG_ERR( "%s: No buffer available (reqBlock=%d)...\n", __FUNCTION__, blockNeeded);*/
        return -1;
    }
    else
    {
#ifdef WFD_RTP_STATS
        wfd_pp_stats->total_consumed_size += reqSize;
#endif
    }
    pushPlayerThrdCmpbBuf = NULL;
    *firstFlag = 0;
#ifdef PLAYBACK_MULTI_THREAD_ENABLE
    if (bufFullFlag)
    {
        bufFullFlag = 0;
        WFD_MUTEX_UNLOCK(bufFullMutex);
    }
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */

    mediaPlayWaitFlag = 0;
    return 0;

}


int PushPlayer::mediaBufConsumeDrop(int blocks)
{
    int bufCount = 0;
    PushPlayerBuf *pool = &mediaBufPool;
    int ori_r_idx = 0;

    bufCount = mediaBufGetBufCount();
    if (bufCount < blocks) //buffer not full enough
        return -1;
    /* drop buffers */
    WFD_MUTEX_LOCK(bufCtrlMutex);
    ori_r_idx = pool->r_idx;
    ADVANCE_BUF_POS_CNT(pool->r_idx, blocks);
    if (pool->w_idx == -1)
        pool->w_idx = ori_r_idx;
    assert((pool->bufferred_size -= (blocks*WFD_TS_BUF_UNIT_SIZE))>=0);
    WFD_MUTEX_UNLOCK(bufCtrlMutex);

    return 0;

}

int PushPlayer::mediaBufStripHead(void)
{
    /* Strip bufferred to improve streaming latency */
    int bufCount = 0;

    bufCount = mediaBufGetBufCount();
    if (bufCount > 0)
    {
        mediaBufConsumeDrop(bufCount-1);
        return 0;
    }

    return -1;
}

int PushPlayer::mediaBufGetHeaderParseLen(void)
{
    PushPlayerBuf *pool = &mediaBufPool;

    return pool->bufferred_size;
}


#ifdef PLAYBACK_MULTI_THREAD_ENABLE
void *pushPlayerThrdMain(void *arg)
{
    WFD_LOG_ERR( "Entering %s \n", __FUNCTION__);
    int isFirstPlay;
    pushPlayerThrdRunning = 1;

restart:
    isFirstPlay = 1;
    WFD_LOG_ERR( "%s: Waiting for first data ready\n", __FUNCTION__);
    PushPlayer::instance().mediaPLayFirstDataReadyWait();
    WFD_LOG_ERR( "First data is ready, starting playback... \n");
    while(1)
    {
        if (pushPlayerThrdExit)
        {
            WFD_LOG_ERR( "Exiting pushPlayerThrdMain...\n");
            /* only after this thread exits, the pushPlayer instance could be destroyed.
               so we nned to notify destructor before exiting...*/
            WFD_MUTEX_UNLOCK(pushPlayerExitMutex);
            pushPlayerThrdExit = 0;
            return NULL;
        }
        if (pushPlayerThrdRestart)
        {
            pushPlayerThrdRestart = 0;
            goto restart;
        }
        if (PushPlayer::instance().mediaBufConsumeAndSend(&isFirstPlay) == -1)
        {
            /* block and wait for notification of data ready */
            PushPlayer::instance().mediaPlayDataReadyWait();
        }
    }

    pushPlayerThrdRunning = 0;
    return NULL;
}
#endif /* PLAYBACK_MULTI_THREAD_ENABLE */


#ifdef WFD_READ_TS_FROM_FILE
void PushPlayer::SendDataFromTsFile(unsigned char *data, int data_len)
{


    if (firstDataFlag)
    {
        IMTK_PB_ERROR_CODE_T ret = IMTK_PB_ERROR_CODE_OK;
        MediaInfo media;

    #ifdef CC_S_PLATFORM
            uint8_t *profile = NULL;

        if (avsync_freerun)
            profile = (uint8_t*)PROFILE_WFD_FREERUN;
        else
            profile = (uint8_t*)PROFILE_WFD;

        ret = IMtkPb_Ctrl_Open(&handle, IMTK_PB_CTRL_BUFFERING_MODEL_PUSH,
                                IMTK_PB_CTRL_APP_MASTER, profile);
    #else
        ret = IMtkPb_Ctrl_Open(&handle, IMTK_PB_CTRL_BUFFERING_MODEL_PUSH,
                                IMTK_PB_CTRL_APP_MASTER, (uint8_t*)PROFILE_WFD);
    #endif
        if (IMTK_PB_ERROR_CODE_OK != ret)
        {
            WFD_LOG_ERR( "cmpb open failed[ret=%d]!\n", ret);
            return;
        }
        WFD_LOG_ERR( "%s: CMPB Open OK\n", __FUNCTION__);
        /* set mediainfo & play */

        media.type = 4;
        media.avCodec = MEDIACODEC_WFDAV;
        media.audioCodec = MEDIACODEC_WFDA_LPCM;
        //media.audioCodec = MEDIACODEC_WFDA_AC3;
        //media.audioCodec = MEDIACODEC_WFDA_AAC;
        media.videoCodec = MEDIACODEC_WFDV_H264;
        SetMediaInfo(media);

        do
        {
            ret = IMtkPb_Ctrl_RegCallback(handle, (void *)this, pushPlayerCallback);
            if (IMTK_PB_ERROR_CODE_OK != ret)
            {
                WFD_LOG_ERR( "cmpb reg callback failed[ret=%d]!\n", ret);
                break;
            }
            WFD_LOG_ERR( "push player reg callback success\n");

            IMTK_PB_CTRL_ENGINE_PARAM_T     t_parm;

            memset(&t_parm, 0, sizeof(IMTK_PB_CTRL_ENGINE_PARAM_T));
            if (bCmpbPlayAudio)
                t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_AUDIO;
            if (bCmpbPlayVideo)
                t_parm.u4PlayFlag |= IMTK_PB_CTRL_PLAY_FLAG_VIDEO;
            ret = IMtkPb_Ctrl_SetEngineParam(handle, &t_parm);
            if (ret != IMTK_PB_ERROR_CODE_OK)
            {
                WFD_LOG_ERR( "cmpb set engine failed[ret=%d]!\n", ret);
                break;
            }
            /*
            if (!bCmpbPlayVideo)
                media_info.uFormatInfo.tMtkP0Info.tVidInfo.eVidEnc = IMTK_PB_CTRL_VID_ENC_UNKNOWN;
            if (!bCmpbPlayAudio)
                media_info.uFormatInfo.tMtkP0Info.tAudInfo.eAudEnc = IMTK_PB_CTRL_AUD_ENC_UNKNOWN;
            */

            media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 4113;
            media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid = 4352;

            if (audOnly)
            {
                WFD_LOG_ERR( "Playing Audio-Only file...\n");
                media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid = 0;
                media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc = (IMTK_PB_CTRL_VID_ENC_T)0;
            }

            WFD_LOG_ERR( "push player set engine success\n");
            WFD_LOG_ERR( "media type=%d\n", (int)media_info.eMediaType);
            WFD_LOG_ERR( "media duration=%x\n", (int)media_info.u4TotalDuration);
            WFD_LOG_ERR( "media size=%x\n", (int)media_info.u8Size);
            WFD_LOG_ERR( "media aud codec =%d\n", media_info.uFormatInfo.tTsInfo.eAudInfo.eAudEnc);
            WFD_LOG_ERR( "media aud pid =0x%x\n", media_info.uFormatInfo.tTsInfo.eAudInfo.u2Pid);
            WFD_LOG_ERR( "media vid codec =%d\n", media_info.uFormatInfo.tTsInfo.eVidInfo.eVidEnc);
            WFD_LOG_ERR( "media vid pid =0x%x\n", media_info.uFormatInfo.tTsInfo.eVidInfo.u2Pid);

            ret = IMtkPb_Ctrl_SetMediaInfo(handle, &media_info);
            if (ret != IMTK_PB_ERROR_CODE_OK)
            {
                WFD_LOG_ERR( "cmpb set media info failed[ret=%d]!\n", ret);
                break;
            }
            WFD_LOG_ERR( "push player set media success\n");

            ret = IMtkPb_Ctrl_Play(handle, 0);
            if (ret != IMTK_PB_ERROR_CODE_OK)
            {
                WFD_LOG_ERR( "cmpb play failed[ret=%d]!\n", ret);
                break;
            }
            WFD_LOG_ERR( "push player play success\n");
            isSetMediaInfoDone = true;
        }while(0);
        WFD_LOG_ERR( "%s: CMPB SetMediaInfo & Play OK\n", __FUNCTION__);

        /* setting hdcp keys for test */
#ifdef ENABLE_HDCP2X_RX
        hdcp2x_rx_setKeysforCryptoTest(4352, 4113);
#endif

        firstDataFlag = 0;
        WFD_LOG_ERR( "Starting sending data to CMPB\n");
    }

    if (mediaBufPoolPut(data, data_len) != 0)
    {
        /* decrease the debug frequency */
    //#define MEDIA_BUF_PUT_FAIL_DEBUG_BITMASK    0x000000FF
    //    if (((++mediaBufPutFailCount) & MEDIA_BUF_PUT_FAIL_DEBUG_BITMASK) == MEDIA_BUF_PUT_FAIL_DEBUG_BITMASK)
        int retrycnt = 0;
        while(retrycnt++ < 20)
        {
            WFD_LOG_ERR( "Put data to buf fail count=%d, retrycnt=%d\n", mediaBufPutFailCount, retrycnt);
            sleep(1);
            while (1)
            {
                if (mediaBufConsumeAndSend(&firstDataFlag) != 0)
                break;
            }
            if (mediaBufPoolPut(data, data_len) == 0)
                break;
            /* note, this means upper layer may send data too fast for MM driver to consume.
               we take a break here to digest the buffer */
        }
        if (retrycnt >= 20)
            WFD_LOG_ERR( "Data Drop @@@@\n");
    }

    if(1 /*sender.type == mediatype_av */)
    {
        while (1)
        {
            if (mediaBufConsumeAndSend(&firstDataFlag) != 0)
                break;
        }
        return;
    }

}


void PushPlayer::StopSendDataFromTsFile(void)
{
    int ret = 0;

    WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_Stop\n", __FUNCTION__);
    ret = IMtkPb_Ctrl_Stop(handle);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "cmpb stop failed[ret=%d]!\n", ret);
    }
    WFD_LOG_ERR( "%s Executing IMtkPb_Ctrl_Close\n", __FUNCTION__);
    ret= IMtkPb_Ctrl_Close(handle);
    if (ret != IMTK_PB_ERROR_CODE_OK)
    {
        WFD_LOG_ERR( "cmpb close failed[ret=%d]!\n", ret);
    }
    WFD_LOG_ERR( "%s IMtkPb_Ctrl_Close done\n", __FUNCTION__);

}

void PushPlayer::SendDataFromTsFile_SetAudOnly(int aud_only)
{
    audOnly = aud_only;
}



#endif /* WFD_READ_TS_FROM_FILE */



}

