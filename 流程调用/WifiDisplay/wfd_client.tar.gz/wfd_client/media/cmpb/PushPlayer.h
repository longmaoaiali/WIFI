#ifndef _PUSH_PLAYER_H_
#define _PUSH_PLAYER_H_
#include "ScopedMutex.h"
#include "Semaphore.h"
#include "NonCopyable.h"
#include "IMtkPb_Ctrl.h"
#include "IMtkPb_ErrorCode.h"
#ifdef MTK_DTV
#include "IMtkPb_Ctrl_DTV.h"
#endif
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>

#include "wfd_client_export.h"
#include "wfd_client_internal.h"

#define PROFILE_WFD "wifi_display"
#ifdef CC_S_PLATFORM
#define PROFILE_WFD_FREERUN "wifi_display_freerun"
#endif




namespace rtsp
{

struct GetBufData
{
    GetBufData(unsigned char *_pBuf, unsigned int _type, unsigned int _iLen, struct timeval &_time):
        pBuf(_pBuf), type(_type), iLen(_iLen), time(_time)
    {
    }
    GetBufData():pBuf(NULL), type(0), iLen(0)
    {
        time.tv_sec = 0;
        time.tv_usec = 0;
    }
    unsigned char *pBuf;
    unsigned int type;
    unsigned int iLen;
    struct timeval time;
};
typedef enum
{
    PUSHPLAYERSTATUS_UNINIT = 0,
    PUSHPLAYERSTATUS_OPENED,
    PUSHPLAYERSTATUS_SETMEDIAINFO,
    PUSHPLAYERSTATUS_PLAYED,
    PUSHPLAYERSTATUS_PAUSED,
    PUSHPLAYERSTATUS_STOPPED
}PushPlayerStatus;


const unsigned int mediatype_audio = 1;
const unsigned int mediatype_video = 2;
const unsigned int mediatype_av = 4;

typedef enum
{
    MEDIACODEC_QCELP,
    MEDIACODEC_AMR,
    MEDIACODEC_AMR_WB,
    MEDIACODEC_MPA,
    MEDIACODEC_MPA_ROBUST,
    MEDIACODEC_X_MP3_DRAFT_00,
    MEDIACODEC_MP4A_LATM,
    MEDIACODEC_AC3,
    MEDIACODEC_EAC3,
    MEDIACODEC_MP4V_ES,
    MEDIACODEC_MPEG4_GENERIC,       // 10
    MEDIACODEC_MPV,
    MEDIACODEC_MP2T,
    MEDIACODEC_H261,
    MEDIACODEC_H263_1998,
    MEDIACODEC_H263_2000,
    MEDIACODEC_H264,
    MEDIACODEC_DV,
    MEDIACODEC_JPEG,
    MEDIACODEC_X_QT,
    MEDIACODEC_PCMU,                // 20
    MEDIACODEC_GSM,
    MEDIACODEC_DVI4,
    MEDIACODEC_PCMA,
    MEDIACODEC_MP1S,
    MEDIACODEC_MP2P,
    MEDIACODEC_L8,
    MEDIACODEC_L16,
    MEDIACODEC_L20,
    MEDIACODEC_L24,
    MEDIACODEC_G726_16,             // 30
    MEDIACODEC_G726_24,
    MEDIACODEC_G726_32,
    MEDIACODEC_G726_40,
    MEDIACODEC_SPEEX,
    MEDIACODEC_T140,
    MEDIACODEC_DAT12,
    // for WFD codec
    MEDIACODEC_WFDAV,               // 37
    MEDIACODEC_WFDA_LPCM,
    MEDIACODEC_WFDA_AAC,
    MEDIACODEC_WFDA_AC3,            // 40
    MEDIACODEC_WFDA_DTS,
    MEDIACODEC_WFDV_H264,
#ifdef MTK_WFD_4K_SUPPORT
    MEDIACODEC_WFDV_H265
#endif
}MediaCodec;

typedef struct
{
    int type;
    int payload_type;
    MediaCodec audioCodec;
    MediaCodec videoCodec;
    MediaCodec avCodec;
    int fPs;
}MediaInfo;

/*
#define WFD_BUF_CHAIN_LEN           (256*4)
#define WFD_TS_BUF_UNIT_SIZE        (4512*4)
#define WFD_TS_PARSE_MIN_SIZE       (WFD_TS_BUF_UNIT_SIZE*5)
*/
//#define WFD_BUF_CHAIN_LEN           (256*4*4)
#define WFD_BUF_CHAIN_LEN           (256*2)
#define WFD_TS_BUF_UNIT_SIZE        (4512)
#define WFD_TS_PARSE_MIN_SIZE       (1024)


typedef void *(*pfn)(void*);

#define ADVANCE_BUF_POS(pos) \
    do{\
        pos++;\
        if (pos == WFD_BUF_CHAIN_LEN)\
            pos = 0;\
    }while(0)

#define ADVANCE_BUF_POS_CNT(pos, cnt) \
    do{\
        pos+=cnt;\
        if (pos >= WFD_BUF_CHAIN_LEN)\
            pos = pos - WFD_BUF_CHAIN_LEN;\
    }while(0)


typedef struct
{
    int w_idx; /* next write idx */
    int r_idx; /* next read idx */
    int w_start_pos; /* start write position of current bufIdx */
    int bufferred_size; /* length of data in the buffer */
    int total_size;

    unsigned char *bufPool;
    unsigned char *bufIdx[WFD_BUF_CHAIN_LEN];
} PushPlayerBuf;

typedef struct
{
    unsigned int sec;
    unsigned int usec;
} PLAYBACK_TIME_T;

class PushPlayer:private NonCopyable
{
    public:
        ~PushPlayer();

        bool open(IMtkPb_Ctrl_Nfy_Fct fCmpbEventNfy = NULL, void* pvTag = NULL);
        bool play();
        bool setBeforePlay();
        bool pause();
        bool stop();
        bool resume();
        bool SetMediaInfo();

        static PushPlayer & instance(void)
        {
            return _instance;
        }

        void SendData(GetBufData & sender);
        bool SetMediaInfo(MediaInfo &info);/*called by rtsp client after dsp response*/
        void setEOS();
        int ReInitBufPool();
        int DestroyBufPool();
        int CreateBufPool();
        int ClearBufPool();
        int mediaBufPoolPut(unsigned char * data,unsigned int dataSize);
        int mediaBufPoolReadyToParse(void);
        int mediaPlayDataReadyNotify(void);
        int mediaPlayDataReadyWait(void);
        int mediaPLayFirstDataReadyWait(void);
        void InitPushPlayerThread(void);
        int mediaBufConsumeAndSend(int *firstFlag);
        int mediaBufConsumeAndSend(GetBufData & sender);
        int mediaBufConsume(int blocks);
        int mediaBufConsumeDrop(int blocks);
        int mediaBufGetBufCount(void);
        int mediaBufStripHead(void);
        int mediaBufGetHeaderParseLen(void);
        int mediaPlayWaitFlag;
        int mediaBufPutFailCount;
        char *getRTPStats(void);
#ifdef WFD_LATENCY_DEBUG
        int check_latency_tei_bit(unsigned char *buf, int buf_len);
#endif

#ifdef __ANDROID__
        void GetCmpbWFDErrorInfo(void * getTypeInfo);
#endif
        void getCurrentTime(PLAYBACK_TIME_T *tp);
        void playbackStartDropTimeReset(void);
        void playbackStartDropTimeSet(unsigned int sec, unsigned int msec);
        int playbackStartDropTimeCheckDoDrop(void);
        PLAYBACK_TIME_T playbackDropTime;
        WFD_PUSH_PLAYER_STATS_T *wfd_pp_stats;
        int firstDataFlag;
#ifdef WFD_READ_TS_FROM_FILE
        void SendDataFromTsFile(unsigned char *data, int data_len);
        void StopSendDataFromTsFile(void);
        void SendDataFromTsFile_SetAudOnly(int aud_only);
        int audOnly;
#endif
    private:
        Mutex lock;
        static PushPlayer _instance;
        IMTK_PB_HANDLE_T handle;
        PushPlayerStatus status;
        IMTK_PB_CTRL_SET_MEDIA_INFO_T   media_info;
        bool    bDataFinished;
    private:
        void StartPlay();
        bool WaitPlay();
        void StopPlay();
        PushPlayer();
        int fillBufferPool(unsigned char* data, unsigned int dataSize, unsigned char* pool, unsigned int poolSize, bool resetPool);
#ifdef WFD_DUMP_TS
        void dumpTsToFile(unsigned char *data, int len);
#endif
    private:
        unsigned char *pCmpbBufA;
        unsigned char *pCmpbBufV;
        unsigned int uiAWriteLen;
        unsigned int uiVWriteLen;
        struct timeval timeAPre;
        struct timeval timeVPre;
        int aFd;
        int vFd;
        int isGetBufferReady;
        unsigned int bufferSuccessCnt;
        unsigned int bufferFailCnt;
        Semaphore   playSema;
        Semaphore   mediaInfoSema;
        bool        isParseMediaInfoDone;
        bool        isSetMediaInfoDone;
        unsigned char*  mediaHeader;            // for TS format
        PushPlayerBuf   mediaBufPool;
        pthread_mutex_t bufCtrlMutex;
        pthread_mutex_t bufFullMutex;
        pthread_mutex_t mediaPlayDataRdyMutex;
        pthread_t       pushPlayerThrd;
        unsigned char   *pushPlayerThrdCmpbBuf;
        int             bufFullFlag;
        int             mediaHeaderSize;
        void reset();
#ifdef WFD_DUMP_TS
        FILE* m_dumpFp;
#endif

};


}

#endif
