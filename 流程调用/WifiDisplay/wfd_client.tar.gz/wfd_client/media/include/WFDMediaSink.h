#ifndef _WFD_MEDIA_SINK_H_
#define _WFD_MEDIA_SINK_H_

#ifdef CC_S_PLATFORM
#include "SinkBuffer.h"
#endif
#include "MediaSink.hh"
#include <stdio.h>

namespace rtsp
{
class WFDMediaSink:public MediaSink
{
protected:
    WFDMediaSink(UsageEnvironment& env, unsigned int type, unsigned bufferSize, unsigned attrHeadSize); // abstract base class
    virtual ~WFDMediaSink(); // instances are deleted using close() only

protected:
    static void afterGettingFrame(void* clientData, unsigned frameSize, unsigned numTruncatedBytes,
                                    struct timeval presentationTime, unsigned durationInMicroseconds);
    virtual void afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime);

public:
    static WFDMediaSink* createNew(UsageEnvironment& env,  unsigned int type = 0, unsigned bufferSize = 100000);
    void sendData(unsigned char *pBuf, unsigned int iLen, struct timeval& duration);
    void switch_protocol(int e_protocol);
#ifdef CC_S_PLATFORM
    void setRecvBufferSize(unsigned bufferSize);
    unsigned getRecvBufferSize();
    void setPlayBufferSize(unsigned bufferSize);
    unsigned getPlayBufferSize();
    void setTCPPreBufferSize(unsigned bufferSize);
    unsigned getTCPPreBufferSize();
#endif

protected:
    virtual Boolean continuePlaying();

protected:
    unsigned int uiType;
    unsigned char* fBuffer;
    unsigned fBufferSize;
    unsigned uiAttrHeadSize;
    int useProtocol  ; //UDP-->0 ,TCP-->1
 #ifdef CC_S_PLATFORM
    ReceiverBuffer *fRecvBuf;
    PlayerBuffer *fPlayBuf;
    TCPPreBuffer *fTCPPreBuf;
 #endif
    bool is_first_lost;
};
}
#endif

