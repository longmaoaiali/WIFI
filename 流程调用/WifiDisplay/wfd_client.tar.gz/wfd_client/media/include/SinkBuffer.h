/*
** RTP streaming data (UDP/TCP) -> Recv buffer -> (TCP pre-buferr) -> Play buffer -> CMPB
*/
#ifndef _SINK_BUFFER_H_
#define _SINK_BUFFER_H_

#include "MediaSink.hh"
#include <stdio.h>

namespace rtsp
{

class LinkedBuffer {
public:
    LinkedBuffer(unsigned char *buf, unsigned size);
    virtual ~LinkedBuffer();

protected:
    unsigned char *fBuf;
    unsigned fBufSize;

private:
    friend class ReceiverBuffer;
    LinkedBuffer *fNextBuf;
};

class ReceiverBuffer {
public:
    ReceiverBuffer(unsigned bufSize);
    virtual ~ReceiverBuffer();

    // Save new data buff in the tail of linked buffer
    bool assignBuffer(unsigned char *buf, unsigned size);
    // Get data from linked buffer head for playback
    bool consumeBuffer(unsigned char *buf, unsigned size);
    bool isEnable();
    bool isFull();
    void setSize(unsigned size);
    unsigned getSize();
    unsigned getRecvSize();

protected:
    unsigned fBufSize;
    unsigned fRecvSize; // total received size store in the linked buffer
    LinkedBuffer *fHeadBuf;
    LinkedBuffer *fTailBuf;
    bool fIsBufFull;
};

class PlayerBuffer {
public:
    PlayerBuffer(unsigned bufSize);
    virtual ~PlayerBuffer();

    bool retrieveBuffer(unsigned char*& buf, unsigned& size);
    bool retrieveCurBuffer(unsigned char*& buf, unsigned& size);
    bool afterSaveData(unsigned size);
    bool afterPlayBuffer();
    void reset();
    bool isEnable();
    bool isFull();
    void setSize(unsigned size);
    unsigned getSize();

protected:
    unsigned char *fBuf;
    unsigned fBufSize;
    unsigned fNewSize;
    unsigned fCurSize;
};

class TCPPreBuffer: public ReceiverBuffer {
public:
    TCPPreBuffer(unsigned bufSize);
    virtual ~TCPPreBuffer();
    void setEnable(bool enable);
    bool isEnable();

private:
    bool fIsEnable;
};

}
#endif

