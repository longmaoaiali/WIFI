#ifndef _WFD_AAC_SINK_H_
#define _WFD_AAC_SINK_H_
#include "WFDMediaSink.h"
#include "MediaSession.hh"
namespace rtsp
{
class WFDAACSink:public WFDMediaSink
{
public:
    static WFDAACSink* createNew(UsageEnvironment& env, unsigned int type = 0,
                                    unsigned bufferSize = 100000,
                                        MediaSubsession *subsession = NULL);

protected:
    WFDAACSink(UsageEnvironment& env,unsigned int type,
                    unsigned bufferSize, MediaSubsession *subsession = NULL);
    virtual ~WFDAACSink();

protected:
    virtual void afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime);
private:
    unsigned char pucSpecialHead[8];
    MediaSubsession * fSubsession;
    unsigned char ucSampleRate;
    unsigned char ucChannelID;
    unsigned int uFrameLen;
private:
    unsigned char GetSampFreq(MediaSubsession *subsession);
};

}

#endif

