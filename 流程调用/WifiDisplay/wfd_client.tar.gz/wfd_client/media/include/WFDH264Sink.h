#ifndef _WFD_H264_SINK_H_
#define _WFD_H264_SINK_H_
#include "WFDMediaSink.h"

namespace rtsp
{
class WFDH264Sink:public WFDMediaSink
{
public:
    static WFDH264Sink* createNew(UsageEnvironment& env,
                      char const* sPropParameterSetsStr = NULL,
                      unsigned int type = 0, unsigned bufferSize = 100000);

protected:
    WFDH264Sink(UsageEnvironment& env, char const* sPropParameterSetsStr,
                    unsigned int type, unsigned bufferSize);
    virtual ~WFDH264Sink();

protected:
    virtual void afterGettingFrame1(unsigned frameSize, struct timeval &presentationTime);
private:
    char const* fSPropParameterSetsStr;
    bool fHaveWrittenFirstFrame;
};

}

#endif
