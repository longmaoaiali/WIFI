#ifndef _MEDIA_BUF_POOL_H_
#define _MEDIA_BUF_POOL_H_
#include <pthread.h>
#include "ScopedMutex.h"
#include "Semaphore.h"


namespace rtsp
{
#define WFD_BUF_CHAIN_LEN           (256*2)
#define WFD_TS_BUF_UNIT_SIZE        (4512)
#define WFD_TS_PARSE_MIN_SIZE       (1024)

typedef struct
{
    int w_idx; /* next write idx */
    int r_idx; /* next read idx */
    int w_start_pos; /* start write position of current bufIdx */
    int bufferred_size; /* length of data in the buffer */
    int total_size;

    unsigned char *bufPool;
    unsigned char *bufIdx[WFD_BUF_CHAIN_LEN];
} BufferPool;


class MediaBufPool
{
    public:
        MediaBufPool();
        ~MediaBufPool();
        int DestroyBufPool();
        int CreateBufPool();

        int mediaBufPoolPut(unsigned char * data,unsigned int dataSize);
    private:
        int ReInitBufPool();
        int ClearBufPool();
        int mediaBufPoolReadyToParse(void);
        int mediaPlayDataReadyNotify(void);
        int mediaPlayDataReadyWait(void);
        int mediaPlayFirstDataReadyWait(void);
        int mediaBufConsumeDrop(int blocks);
        int mediaBufGetBufCount(void);
        int mediaBufStripHead(void);
        int mediaBufGetHeaderParseLen(void);
        int fillBufferPool(unsigned char* data, unsigned int dataSize, unsigned char* pool, unsigned int poolSize, bool resetPool);
    private:
        int mediaPlayWaitFlag;
        int mediaBufPutFailCount;
        BufferPool  mediaBufPool;
        pthread_mutex_t bufCtrlMutex;
        pthread_mutex_t mediaPlayDataRdyMutex;


};
}
#endif
