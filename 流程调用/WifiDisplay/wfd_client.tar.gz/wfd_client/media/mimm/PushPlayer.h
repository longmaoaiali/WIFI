#ifndef _PUSH_PLAYER_H_
#define _PUSH_PLAYER_H_
#include "ScopedMutex.h"
//#include "Semaphore.h"
#include "NonCopyable.h"

#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>

#include "mi_common.h"
#include "MediaBufPool.h"

#include "wfd_client_internal.h"

namespace rtsp
{

struct GetBufData
{
    GetBufData(unsigned char *_pBuf, unsigned int _type, unsigned int _iLen, struct timeval &_time):
        pBuf(_pBuf), type(_type), iLen(_iLen), time(_time)
    {
    }

    GetBufData(unsigned char *_pBuf, unsigned int _type, unsigned int _iLen):
        pBuf(_pBuf), type(_type), iLen(_iLen)
    {
        time.tv_sec = 0;
        time.tv_usec = 0;
    }
    GetBufData():pBuf(NULL), type(0), iLen(0)
    {
        time.tv_sec = 0;
        time.tv_usec = 0;
    }
    unsigned char *pBuf;
    unsigned int type;
    unsigned int iLen;
    struct timeval time;
};

const unsigned int mediatype_audio = 1;
const unsigned int mediatype_video = 2;
const unsigned int mediatype_av = 4;

typedef enum
{
    E_PUSH_PLAYER_STATUS_UNINIT = 0,
    E_PUSH_PLAYER_STATUS_OPENED,
    E_PUSH_PLAYER_STATUS_SETMEDIAINFO,
    E_PUSH_PLAYER_STATUS_PLAYED,
    E_PUSH_PLAYER_STATUS_PAUSED,
    E_PUSH_PLAYER_STATUS_STOPPED
} Push_Player_Status_e;

typedef enum
{
    MEDIACODEC_QCELP,
    MEDIACODEC_AMR,
    MEDIACODEC_AMR_WB,
    MEDIACODEC_MPA,
    MEDIACODEC_MPA_ROBUST,
    MEDIACODEC_X_MP3_DRAFT_00,
    MEDIACODEC_MP4A_LATM,
    MEDIACODEC_AC3,
    MEDIACODEC_EAC3,
    MEDIACODEC_MP4V_ES,
    MEDIACODEC_MPEG4_GENERIC,       // 10
    MEDIACODEC_MPV,
    MEDIACODEC_MP2T,
    MEDIACODEC_H261,
    MEDIACODEC_H263_1998,
    MEDIACODEC_H263_2000,
    MEDIACODEC_H264,
    MEDIACODEC_DV,
    MEDIACODEC_JPEG,
    MEDIACODEC_X_QT,
    MEDIACODEC_PCMU,                // 20
    MEDIACODEC_GSM,
    MEDIACODEC_DVI4,
    MEDIACODEC_PCMA,
    MEDIACODEC_MP1S,
    MEDIACODEC_MP2P,
    MEDIACODEC_L8,
    MEDIACODEC_L16,
    MEDIACODEC_L20,
    MEDIACODEC_L24,
    MEDIACODEC_G726_16,             // 30
    MEDIACODEC_G726_24,
    MEDIACODEC_G726_32,
    MEDIACODEC_G726_40,
    MEDIACODEC_SPEEX,
    MEDIACODEC_T140,
    MEDIACODEC_DAT12,
    // for WFD codec
    MEDIACODEC_WFDAV,               // 37
    MEDIACODEC_WFDA_LPCM,
    MEDIACODEC_WFDA_AAC,
    MEDIACODEC_WFDA_AC3,            // 40
    MEDIACODEC_WFDA_DTS,
    MEDIACODEC_WFDV_H264,
#ifdef MTK_WFD_4K_SUPPORT
    MEDIACODEC_WFDV_H265
#endif
}MediaCodec_Type_e;

typedef struct
{
    int type;
    int payload_type;
    MediaCodec_Type_e audioCodec;
    MediaCodec_Type_e videoCodec;
    MediaCodec_Type_e avCodec;
    unsigned int fPs;
} MediaInfo;

class PushPlayer:private NonCopyable
{
    public:
        static PushPlayer & instance(void)
        {
            return _instance;
        }
        ~PushPlayer();

        bool init();
        bool deInit();

        bool open();
        bool play();
        bool pause();
        bool stop();
        bool resume();
        bool clearVideo();
        bool SetMediaInfo();
        bool SetMediaInfo(MediaInfo &info);

        bool GetIsPlayDone();
        void SetIsPlayDone(bool fgPlayDone);

        void SendData(GetBufData & sender);
        //bool SetMediaInfo(MediaInfo &info);/*called by rtsp client after dsp response*/
        void SetIsDataArrived(bool fgDataArrived);
        bool GetIsDataArrived();

        //char *getRTPStats(void);
        void setClearVideo(int enable);
        char *getRTPStats(void);

        int mediaBufConsumeAndSend(int *firstFlag);
        int mediaBufConsume(int blocks);

#ifdef WFD_READ_TS_FROM_FILE
        void SendDataFromTsFile(unsigned char *data, int data_len);
        void StopSendDataFromTsFile(void);
        void SendDataFromTsFile_SetAudOnly(int aud_only);
        int audOnly;
#endif
    int         firstDataFlag;

    private:
        PushPlayer();
        bool push_stream(GetBufData & sender);
        bool setFullScreen();
#ifdef WFD_DUMP_TS
        void dumpTsToFile(unsigned char *data, int len);
#endif
        Mutex lock;
        static PushPlayer _instance;

        MI_HANDLE m_hAout;
        MI_HANDLE m_hDisp;
        MI_HANDLE m_hMm;

        Push_Player_Status_e m_status;
        bool m_bInited;

        bool        isSetMediaInfoDone;
        bool        IsDataArrived;
        bool        isNeedClearVideo;
        bool        isPlayDone;
        MI_U64 m_callbackId;
#ifdef WFD_DUMP_TS
        FILE* m_dumpFp;;
#endif
        WFD_PUSH_PLAYER_STATS_T *wfd_pp_stats;
};
}
#endif
