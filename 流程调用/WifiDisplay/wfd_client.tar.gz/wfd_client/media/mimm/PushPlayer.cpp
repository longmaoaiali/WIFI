#define WFD_LOG_TAG "MIMM-PushPlayer"

#include "PushPlayer.h"
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <errno.h>

#include "mi_sys.h"
#include "mi_os.h"
#include "mi_disp.h"
#include "mi_aout.h"
#include "mi_mm.h"

#include "Utils.h"
#include <time.h>

#ifdef MTK_WFD_RTSP
#include "WfdRtspPlayer.h"
#include "WFDClient.h"
#endif

#ifdef __ANDROID__
extern int wfd_send_command(const char *comm);
#endif

extern struct wfd_rtsp_conf_s *wfd_rtsp_conf;

namespace rtsp
{

PushPlayer PushPlayer::_instance;
#define CHECK_INIT()\
{\
    if(m_bInit == FALSE)\
    {\
        WFD_LOG_DEBUG("Do INIT First");\
        return FALSE;\
    }\
}

#define CHECK_RET(RET, VALUE)  \
{   \
    if( RET != VALUE)  \
    {   \
        WFD_LOG_DEBUG("\033[33m%s %d [Check Ret Fail! Ret=%d]\033[m", __FUNCTION__, __LINE__, RET);  \
    }   \
}

#ifdef __ANDROID__
int pushplayer_send_command(const char *comm)
{
    return wfd_send_command(comm);
}
#endif

// register this function to MI MM
static MI_RESULT _PushPlayer_Event_Callback(MI_HANDLE hMm, MI_U32 u32Event, void *pNotifyParams, void *pUserParams)
{
    WFD_LOG_TIME("_PushPlayer_Event_Callback: received event=%d, pNotifyParams=%zu, user param=%p",
            (int)u32Event, (size_t)pNotifyParams, pUserParams);
    MI_MM_Event_e eEvent = (MI_MM_Event_e)u32Event;
    switch (eEvent)
    {
        case E_MI_MM_EVENT_EXIT_OK:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_EXIT_OK");
            PushPlayer::instance().SetIsPlayDone(TRUE);
            break;
        case E_MI_MM_EVENT_SUFFICIENT_DATA:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_SUFFICIENT_DATA.");
            break;
        case E_MI_MM_EVENT_INSUFFICIENT_DATA:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_INSUFFICIENT_DATA.");
#ifdef MTK_WFD_RTSP
#ifndef __ANDROID__
            WFDClient::getInstance().notifyToBufferLow();
#endif
#endif
            break;
        case E_MI_MM_EVENT_EXIT_ERROR_FILE:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_EXIT_ERROR_FILE.");
#ifdef MTK_WFD_RTSP
#ifndef __ANDROID__

            WFDClient::getInstance().notifyToPlayBackError();
            WFDClient::getInstance().notifyToPlayBackError();
#else
//          pushplayer_send_command();
#endif
#endif
            break;
        case E_MI_MM_EVENT_PLAYING_INIT_OK:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_PLAYING_INIT_OK");
            break;
        case E_MI_MM_EVENT_FRAME_READY:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_FRAME_READY");
            break;
        case E_MI_MM_EVENT_START_PLAY:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_START_PLAY");
            break;
        case E_MI_MM_EVENT_PLAYING_OK:
            WFD_LOG_INFO("CALLBACK FUNC...E_MI_MM_EVENT_PLAYING_OK");
            break;
        default :
            break;
    }
    return MI_OK;
}

PushPlayer::PushPlayer():
    firstDataFlag(1),
    m_hAout(MI_HANDLE_NULL), m_hDisp(MI_HANDLE_NULL), m_hMm(MI_HANDLE_NULL),
    m_status(E_PUSH_PLAYER_STATUS_UNINIT)
{
    isSetMediaInfoDone = true;

#ifdef WFD_RTP_STATS
    {
        wfd_pp_stats = (WFD_PUSH_PLAYER_STATS_T *)malloc(sizeof(WFD_PUSH_PLAYER_STATS_T));
        if (wfd_pp_stats)
        {
            memset(wfd_pp_stats, 0, sizeof(WFD_PUSH_PLAYER_STATS_T));
        }
        else
        {
            WFD_LOG_ERR("%s: Fail to malloc", __FUNCTION__);
        }
    }
#endif
}

PushPlayer::~PushPlayer()
{
    /*first set the continue flag to end and next notify all */
    if (m_status != E_PUSH_PLAYER_STATUS_STOPPED  && m_status != E_PUSH_PLAYER_STATUS_UNINIT)
    {
        stop();
    }
    m_bInited = false;

#ifdef WFD_RTP_STATS
    if (wfd_pp_stats)
        free(wfd_pp_stats);
    wfd_pp_stats = NULL;
#endif
}

bool PushPlayer:: setFullScreen()
{
    MI_DISP_VidWinRect_t dst_rect;
    WFD_LOG_ENTER();

    if (MI_HANDLE_NULL == m_hDisp)
    {
        WFD_LOG_ERR("MI_MM_Handle == NULL");
        return false;
    }

    WFD_LOG_INFO("====MI_DISP_GetDispRect start====\n");
    MI_RESULT e4ret = MI_DISP_GetDispRect(m_hDisp, &dst_rect);
    if (e4ret >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_DISP_GetDispRect error,error code = %d", e4ret);
        return false;
    }
    WFD_LOG_INFO("====MI_DISP_GetDispRect[%d,%d,%d,%d] end====\n", dst_rect.u16X, dst_rect.u16Y, dst_rect.u16Width, dst_rect.u16Height);

    WFD_LOG_INFO("====MI_DISP_SetOutputRect start====\n");
    e4ret = MI_DISP_SetOutputRect(m_hDisp, &dst_rect);
    if (e4ret >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_DISP_SetOutputRect error,error code = %d", e4ret);
        return false;
    }

    WFD_LOG_INFO("====MI_DISP_ApplySetting start====\n");
    e4ret = MI_DISP_ApplySetting(m_hDisp);
    if (e4ret >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_DISP_ApplySetting error,error code = %d", e4ret);
        return false;
    }
    WFD_LOG_INFO("====MI_DISP_ApplySetting end====\n");
    return true;
}

bool PushPlayer::init()
{
    ScopedMutex sm(lock);
    WFD_LOG_ENTER();
    if (m_bInited)
    {
        WFD_LOG_ERR("Has been inited!!!");
        return true;
    }

    MI_RESULT eRet;

    WFD_LOG_INFO("Calling MI_SYS_Init...");
    eRet = MI_SYS_Init(NULL);
    if(eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_SYS_Init ERROR:%d", eRet);
        return false;
    }

    //MI DISP will be activated in MI_DISP_GetCaps function.
    WFD_LOG_INFO("Calling MI_DISP_GetCaps... ");
    MI_DISP_Caps_t stCaps_t;
    memset(&stCaps_t, 0, sizeof(stCaps_t));
    eRet = MI_DISP_GetCaps(&stCaps_t);
    if (eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_DISP_GetCaps ERROR:%d", eRet);
        return false;
    }

    WFD_LOG_INFO("Calling MI_AOUT_Init...");
    MI_AOUT_InitParams_t stAoutInitParams = {0};
    eRet = MI_AOUT_Init(&stAoutInitParams);
    if (eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_AOUT_Init ERROR:%d", eRet);
        return false;
    }

    WFD_LOG_TIME("Calling MI_MM_Init...");
    eRet = MI_MM_Init(NULL);
    if (eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Init ERROR:%d", eRet);
        return false;
    }

    if (wfd_rtsp_conf && wfd_rtsp_conf->wfd_mimm_dbg_level > MI_DBG_NONE) {
        MI_MM_SetDebugLevel(wfd_rtsp_conf->wfd_mimm_dbg_level);
    }

    m_bInited = true;
    return true;
}

bool PushPlayer::deInit()
{
    if (m_bInited == false)
        return true;

    MI_RESULT eRet;

    WFD_LOG_TIME("Calling MI_MM_DeInit...");
    eRet = MI_MM_DeInit();
    if(eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_DEBUG("MI_MM_DeInit ERROR:%d", eRet);
        return false;
    }
    m_bInited= false;
    return true;
}

bool PushPlayer::open()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);
    if ((m_status != E_PUSH_PLAYER_STATUS_UNINIT) &&
        (m_status != E_PUSH_PLAYER_STATUS_STOPPED))
    {
        WFD_LOG_ERR("Can't open, current status:%d", (int)m_status);
        return false;
    }

    if (FALSE == init())
    {
        WFD_LOG_ERR("init() failed...");
        return false;
    }

    MI_RESULT eRet;
    MI_MM_OpenParams_t stOpenParams;

    WFD_LOG_TIME("Calling MI_MM_Open");
    memset(&stOpenParams, 0, sizeof(stOpenParams));
    stOpenParams.pszName = (MI_U8 *)"WFD";
    stOpenParams.eMediaType = E_MI_MM_MEDIA_MOVIE;
    eRet = MI_MM_Open(&stOpenParams, &m_hMm);
    if (eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("The MM path is already used, eRet = %d", eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif

        return false;
    }

    bool hasErr = false;
    do
    {
        //Set callback function to MM handle
        MI_MM_CallbackInputParams_t stCallbackInputParams;
        memset(&stCallbackInputParams, 0, sizeof(stCallbackInputParams));
        stCallbackInputParams.pfEventCallback = _PushPlayer_Event_Callback;
        stCallbackInputParams.u32EventFlags = E_MI_MM_EVENT_ALL;
        stCallbackInputParams.pUserParams = this;
        MI_MM_CallbackOutputParams_t stCallbackOutputParams;
        memset(&stCallbackOutputParams, 0, sizeof(stCallbackOutputParams));

        WFD_LOG_TIME("Calling MI_MM_RegisterCallback");
        eRet = MI_MM_RegisterCallback(m_hMm, &stCallbackInputParams, &stCallbackOutputParams);
        if((eRet == MI_OK) && (stCallbackOutputParams.u64CallbackId != 0))
        {
            WFD_LOG_DEBUG("Set Callback function Success!!");
            m_callbackId = stCallbackOutputParams.u64CallbackId;
        }
        else
        {
            WFD_LOG_ERR("Set Callback function failure!!");
            hasErr = true;
            break;
        }

        //Open Disp Handle if media type is video or photo
        WFD_LOG_INFO("Calling MI_DISP_Open");
        //bDispVidWinSelfOpen = false;
        MI_DISP_QueryHandleParams_t stQueryHandle;
        memset(&stQueryHandle, 0, sizeof(stQueryHandle));
        stQueryHandle.pszName = (MI_U8*)"MI_DISP_HD0"; //Always get/open main window now due to MI DISP restrict
        if(MI_DISP_GetHandle(&stQueryHandle, &m_hDisp) != MI_OK)
        {
            MI_DISP_OpenParams_t stDispOpenParams;
            memset(&stDispOpenParams, 0, sizeof(stDispOpenParams));
            stDispOpenParams.eVidWinType = E_MI_DISP_VIDWIN_HD;
            stDispOpenParams.pszName = (MI_U8 *)"MI_DISP_HD0";  //Always get/open main window now due to MI DISP restrict
            eRet = MI_DISP_Open(&stDispOpenParams, &m_hDisp);
            if((eRet == MI_OK) && (m_hDisp != MI_HANDLE_NULL))
            {
                WFD_LOG_DEBUG("MI_DISP_Open function Success!!");
            }
            else
            {
                WFD_LOG_ERR("MI_DISP_Open function failure!!");
                hasErr = true;

                break;
            }
            //bDispVidWinSelfOpen = true;
        }
        setFullScreen();

        //Get Aout Handle if media type is video or audio
        WFD_LOG_DEBUG("Calling MI_AOUT_GetHandle");
        MI_AOUT_QueryHandleParams_t stAoutQueryParams;
        memset(&stAoutQueryParams, 0, sizeof(stAoutQueryParams));
        stAoutQueryParams.ePath = E_MI_AOUT_PATH_ALL;
        eRet = MI_AOUT_GetHandle(&stAoutQueryParams, &m_hAout);
        if (m_hAout == MI_HANDLE_NULL)
        {
            WFD_LOG_DEBUG("Calling MI_AOUT_Open");
            MI_AOUT_OpenParams_t stAoutOpenParams;
            memset(&stAoutOpenParams, 0, sizeof(stAoutOpenParams));
            stAoutOpenParams.ePath = E_MI_AOUT_PATH_ALL;
            stAoutOpenParams.stVolCfg.bUseCusVolTbl = FALSE;
            eRet = MI_AOUT_Open(&stAoutOpenParams,&m_hAout);
            if (eRet != MI_OK)
            {
               WFD_LOG_ERR("MI_AOUT_Open function failure!!");
               hasErr = true;
               break;
            }
            else
            {
               WFD_LOG_DEBUG("MI_AOUT_Open function Success!!");
            }
        }

    }while(0);

    if (hasErr)
    {
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        if (m_hMm != MI_HANDLE_NULL)
            CHECK_RET(MI_MM_Close(m_hMm), MI_OK);
        if (m_hDisp != MI_HANDLE_NULL)
            //CHECK_RET(MI_DISP_Close(m_hDisp), MI_OK);
        if (m_hAout != MI_HANDLE_NULL)
            //CHECK_RET(MI_AOUT_CLOSE(m_hAout), MI_OK);
        m_callbackId = 0;
        return false;
    }
    m_status = E_PUSH_PLAYER_STATUS_OPENED;

#ifdef WFD_DUMP_TS
    if (wfd_rtsp_conf && wfd_rtsp_conf->ts_dump_enable) {
        char *dumpPath = wfd_rtsp_conf->ts_dump_file;
        m_dumpFp = fopen(dumpPath, "w+");
        if(m_dumpFp == NULL)
        {
            WFD_LOG_ERR("failed to open/create dump file:%s, err:%s\n", dumpPath, strerror(errno));
        }
    }
#endif

    return true;
}
bool PushPlayer::play()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);

    if ( m_status != E_PUSH_PLAYER_STATUS_OPENED
            && m_status != E_PUSH_PLAYER_STATUS_PAUSED
            && m_status != E_PUSH_PLAYER_STATUS_STOPPED
            && m_status != E_PUSH_PLAYER_STATUS_SETMEDIAINFO )
    {
        WFD_LOG_ERR("Can't play, current status:%d", (int)m_status);
        return false;
    }

    MI_RESULT eRet;

    MI_MM_ApTypeParams_t stApParams;
    memset(&stApParams, 0, sizeof(stApParams));
    stApParams.eApType = E_MI_MM_AP_TYPE_STRING;
    stApParams.pszApName = (MI_U8*)"WFD";  //E_MI_MM_AP_TYPE_NORMAL;

    eRet = MI_MM_SetAttr(m_hMm, E_MI_MM_ATTR_TYPE_SET_AP_TYPE, (void *)&stApParams);
    if(eRet==MI_OK)
    {
        WFD_LOG_DEBUG("Set-AP-mode-WFD Success!!\n");
    }
    else
    {
        WFD_LOG_DEBUG("Set-AP-mode-WFD Failure!!\n");
        return false;
    }

    MI_MM_StartParams_t stStartParams;
    memset(&stStartParams, 0, sizeof(stStartParams));
    stStartParams.bInitOnly = 0;
    stStartParams.bPreviewEnable = 0;
    stStartParams.pu8DirMemInputBuf = NULL;
    stStartParams.u32DirMemInputBufLen  = 0;
    stStartParams.stPreviewSetting.eMode  = E_MI_MM_PREVIEW_NORMAL_MODE;
    stStartParams.stPreviewSetting.u32VideoPauseTime = 0;
    stStartParams.hDisplay = m_hDisp; //set disp handle to MI MM
    stStartParams.hAout = m_hAout; //set aout handle to MI MM
    //set media file type, such as push or pull mode, to MI MM
    stStartParams.eFileOption = E_MI_MM_TS_INJECT_MODE;//E_MI_MM_ES_INJECT_MODE;
    stStartParams.pszFileName = NULL;
    stStartParams.bMuteAudio = false;

    //
    stStartParams.bIsLowLatencyMode  = TRUE;
    stStartParams.bSecureModeEnable = false;
    stStartParams.eDrmType = E_MI_MM_DRM_TYPE_NONE;
    if (WfdRtspClient::wfd_is_hdcp_authed())
    {
        stStartParams.bSecureModeEnable = true;
        stStartParams.eDrmType = E_MI_MM_DRM_TYPE_HDCP;
    }

    WFD_LOG_DEBUG("Calling MI_MM_Start: bIsLowLatencyMode:%d, bSecureModeEnable:%d, eDrmType:%d",
        stStartParams.bIsLowLatencyMode, stStartParams.bSecureModeEnable, stStartParams.eDrmType);

    eRet = MI_MM_Start(m_hMm, &stStartParams);
    if (eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Start ERROR:%d", eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }
    isSetMediaInfoDone = true;
    m_status = E_PUSH_PLAYER_STATUS_PLAYED;
    return true;
}

bool PushPlayer::pause()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);

    if (m_status != E_PUSH_PLAYER_STATUS_PLAYED)
    {
        WFD_LOG_ERR("Can't pause, current status:%d!", (int)m_status);
        return false;
    }

    MI_RESULT eRet;
    WFD_LOG_TIME("calling MI_MM_Pause...");
    eRet = MI_MM_Pause(m_hMm);
    if(eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Pause ERROR:%d", eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }

    m_status = E_PUSH_PLAYER_STATUS_PAUSED;
    return true;
}

bool PushPlayer::stop()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);
    if (m_status== E_PUSH_PLAYER_STATUS_STOPPED
            || m_status ==E_PUSH_PLAYER_STATUS_UNINIT )
    {
        WFD_LOG_ERR("can't stop, current status:%d", (int)m_status);
        return true;
    }

    MI_RESULT eRet;
    if (m_status == E_PUSH_PLAYER_STATUS_PLAYED
            || m_status == E_PUSH_PLAYER_STATUS_PAUSED
            || m_status == E_PUSH_PLAYER_STATUS_SETMEDIAINFO)
    {
         WFD_LOG_TIME("Calling MI_MM_Stop...");
         eRet = MI_MM_Stop(m_hMm);
         if (eRet>=MI_ERR_FAILED)
         {
             WFD_LOG_ERR("MI_MM_Stop ERROR:%d", eRet);
         }
    }

    WFD_LOG_TIME("Calling MI_MM_Close...");
    eRet= MI_MM_Close(m_hMm);
    if (eRet>=MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Close ERROR:%d", eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
    }
    m_status = E_PUSH_PLAYER_STATUS_STOPPED;
    m_hMm = MI_HANDLE_NULL;
    firstDataFlag = 1;
    deInit();
#ifdef WFD_DUMP_TS
    if (m_dumpFp)
    {
        fclose(m_dumpFp);
        m_dumpFp = NULL;
    }
#endif

    return true;
}

bool PushPlayer::resume()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);
    if (m_status != E_PUSH_PLAYER_STATUS_PAUSED)
    {
        WFD_LOG_ERR("Can't resume, current status:%d", (int)m_status);
        return false;
    }

    MI_RESULT eRet;
    WFD_LOG_TIME("Calling MI_MM_Resume...");
    eRet = MI_MM_Resume(m_hMm);
    if(eRet>=MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Resume ERROR:%d", eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }

    m_status = E_PUSH_PLAYER_STATUS_PLAYED;
    return true;
}
bool PushPlayer::clearVideo()
{
    WFD_LOG_ENTER();
    ScopedMutex sm(lock);

    if (m_status != E_PUSH_PLAYER_STATUS_PLAYED)
    {
        WFD_LOG_ERR("Can't clearVideo, current status:%d!", (int)m_status);
        return false;
    }
    MI_RESULT eRet;
    MI_U32 u32ClearData = 0;

    WFD_LOG_TIME("Calling MI_MM_Stop...");
    eRet = MI_MM_Stop(m_hMm);
    if(eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Stop Failed");
#ifdef __ANDROID__
                pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }
    m_status = E_PUSH_PLAYER_STATUS_STOPPED;

    WFD_LOG_TIME("Calling MI_MM_Clear...");
    u32ClearData = E_MI_MM_CLEAR_DATA_VIDEO;
    eRet = MI_MM_Clear(m_hMm, u32ClearData);
    if(eRet >= MI_ERR_FAILED)
    {
        WFD_LOG_ERR("MI_MM_Clear ERROR:%d",eRet );
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
        return false;
    }
    return true;
}

void PushPlayer::setClearVideo(int enable)
{
    isNeedClearVideo = (enable ? true : false);
}

bool PushPlayer::GetIsDataArrived()
{
    return IsDataArrived;
}

void PushPlayer::SetIsDataArrived(bool fgDataArrived)
{
    IsDataArrived = fgDataArrived;
}

bool PushPlayer::GetIsPlayDone()
{
    return isPlayDone;
}

void PushPlayer::SetIsPlayDone(bool fgPlayDone)
{
    isPlayDone = fgPlayDone;
}
bool PushPlayer::SetMediaInfo()
{
    WFD_LOG_ENTER();
    m_status = E_PUSH_PLAYER_STATUS_SETMEDIAINFO;
    return true;
}

bool PushPlayer::SetMediaInfo(MediaInfo &info)
{
    WFD_LOG_ENTER();
    m_status = E_PUSH_PLAYER_STATUS_SETMEDIAINFO;
    return true;
}

void PushPlayer::SendData(GetBufData & sender)
{
    if (sender.type == mediatype_av)
    {
    #ifdef WFD_RTP_STATS
        wfd_pp_stats->total_received_size += sender.iLen;
    #endif
        push_stream(sender);
    }
    return;
}

bool PushPlayer::push_stream(GetBufData & sender)
{
    //WFD_LOG_ENTER();
    static unsigned int dataNo = 0 ;
    dataNo++;
    ScopedMutex sm(lock);
    if (m_status != E_PUSH_PLAYER_STATUS_SETMEDIAINFO
            && m_status != E_PUSH_PLAYER_STATUS_PLAYED)
    {
        WFD_LOG_ERR("Status error, current is = %d", m_status);
        return false;
    }

    MI_MM_StreamData_t stData;
    MI_RESULT eRet;

    memset(&stData, 0, sizeof(stData));
    stData.pu8BufAddr = sender.pBuf;
    stData.u32BufSize = sender.iLen;
    stData.eDataType = E_MI_MM_DATA_TYPE_TS;
#ifdef WFD_DUMP_TS
    dumpTsToFile(sender.pBuf, sender.iLen);
#endif

    if (firstDataFlag == 1)
    {
        WFD_LOG_TIME("PushPlayer....send First data..No = %d\n", dataNo);
        WFD_LOG_TIME("Calling MI_MM_PushStream+++... Data length:%d", sender.iLen);
        firstDataFlag = 0;
    }
    if ((dataNo%1000) == 0)
    {
        WFD_LOG_TIME("PushPlayer....send data..No = %d\n", dataNo);
        WFD_LOG_TIME("Calling MI_MM_PushStream+++... Data length:%d", sender.iLen);
    }

    eRet = MI_MM_PushStream(m_hMm, &stData);
    if (eRet!= MI_OK)
    {
        WFD_LOG_ERR("MI_MM_PushStream ERROR:%d",eRet);
#ifdef __ANDROID__
        pushplayer_send_command(RTP_ERR_FATAL);
#endif
#ifdef WFD_RTP_STATS
        wfd_pp_stats->cmpb_senddata_error_count++;
#endif
        return false;
    }
#ifdef WFD_RTP_STATS
        wfd_pp_stats->total_consumed_size += sender.iLen;
#endif
    //set Dataarrived flag:
    IsDataArrived = true;
    return true;
}

char *PushPlayer::getRTPStats(void)
{
#ifdef WFD_RTP_STATS
        WFD_PUSH_PLAYER_STATS_T *stats = NULL;
        if (!wfd_pp_stats)
            return NULL;

        stats = (WFD_PUSH_PLAYER_STATS_T *)wfd_pp_stats;
        #if 0
        stats->total_size = m_bufPool.total_size;
        stats->buf_w_idx = m_bufPool.w_idx;
        stats->buf_r_idx = m_bufPool.r_idx;
        stats->buf_w_start_pos = m_bufPool.w_start_pos;
        stats->buffered_size = m_bufPool.bufferred_size;
        #endif
        stats->pushplayer_status = m_status;
        return (char *)wfd_pp_stats;
#else
        return NULL;
#endif
}


int PushPlayer::mediaBufConsume(int blocks)
{
    return 0;
}


int PushPlayer::mediaBufConsumeAndSend(int *firstFlag)
{
    return 0;
}

#ifdef WFD_READ_TS_FROM_FILE
void PushPlayer::SendDataFromTsFile(unsigned char *data, int data_len)
{
}

void PushPlayer::StopSendDataFromTsFile(void)
{
}

void PushPlayer::SendDataFromTsFile_SetAudOnly(int aud_only)
{
    audOnly = aud_only;
}
#endif /* WFD_READ_TS_FROM_FILE */

#ifdef WFD_DUMP_TS
void PushPlayer::dumpTsToFile(unsigned char *data, int len)
{
    if (!m_dumpFp)
    {
        return;
    }

    int ret = fwrite(data, 1, len, m_dumpFp);
    if (ret <= 0)
    {
        WFD_LOG_ERR( "Dump ts write fail! Error=%s\n", strerror(errno));
    }
}
#endif

}

