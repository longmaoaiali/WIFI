#ifndef _WFD_CLIENT_INTERNAL_H_
#define _WFD_CLIENT_INTERNAL_H_
#include "WFD_common.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C"
{
#endif

    typedef struct _WFD_VIDEO_FORMAT
    {
        char cea[10];
        char vesa[10];
        char hh [10];
    }WFD_VIDEO_FORMAT_T;

    typedef struct Wfd_Video_Format
    {
        unsigned int length;
        unsigned int width;
        unsigned int frame_rate;
    }e_wfdVideoFormat;

    typedef enum _WFD_AUDIO_FORMAT{
        WFD_AUDIO_ALL= 0,
        WFD_AUDIO_LPCM,
        WFD_AUDIO_AAC,
        WFD_AUDIO_AC3
    }WFD_AUDIO_FORMAT;

    extern WFD_RESULT wfd_client_start_rtsp();
    extern WFD_RESULT wfd_client_media_play();
    extern WFD_RESULT wfd_client_media_pause();
    extern WFD_RESULT wfd_client_media_teardown();
    extern const char * wfd_client_get_rtpSessionId();
    extern WFD_RESULT wfd_client_send_IDRReq();
    extern WFD_RESULT wfd_client_enter_standby_mode();
    extern WFD_RESULT wfd_client_get_rtp_stats(char *buf, int len);
    extern WFD_RESULT wfd_client_uibc_gen_event(int isMultiTouch);
    extern WFD_RESULT wfd_client_uibc_cap_update(char *type);
    extern WFD_RESULT wfd_client_rtsp_sigma_cmd(int cmdtype, char *data, int datalen);
    extern int wfd_client_rtsp_conf_set(int conf_type, void *data, int data_len);
    extern int wfd_client_rtsp_conf_reset(void);
#ifdef CC_S_PLATFORM
    extern int wfd_client_avsync_set_freerun(int enable);
    extern int wfd_client_avsync_get_freerun(void);
    extern void wfd_client_set_recv_buffer_size(unsigned size);
    extern unsigned wfd_client_get_recv_buffer_size();
    extern void wfd_client_set_play_buffer_size(unsigned size);
    extern unsigned wfd_client_get_play_buffer_size();
    extern void wfd_client_set_tcp_pre_buffer_size(unsigned size);
    extern unsigned wfd_client_get_tcp_pre_buffer_size();
#endif
    extern int wfd_client_rtsp_conf_set(int conf_type, void *data, int data_len);
    typedef struct WFD_PUSH_PLAYER_STATS_S
    {
        unsigned int total_received_size;
        unsigned int total_consumed_size;
        int buf_w_idx;
        int buf_r_idx;
        int buf_w_start_pos;
        int buffered_size;
        int total_size;
        unsigned int oob_count; /* out-of-buffer */
        unsigned int cmpb_getbuffer_error_count;
        unsigned int cmpb_senddata_error_count;
        unsigned int header_parse_fail_count;
        int audio_pid;
        int video_pid;
        int audio_codec;
        int video_codec;
        int pushplayer_status;
    } WFD_PUSH_PLAYER_STATS_T;

#define WFD_DUMP_TS_MAX_PATH_SIZE   512
#ifdef __ANDROID__
#define WFD_DUMP_TS_DEFAULT_PATH    "/data/wfd_dump.ts"
#else
#define WFD_DUMP_TS_DEFAULT_PATH    "/3rd_rw/wfd_dump.ts"
#endif

#define WFD_DUMP_TS_FILE_NAME       "wfd_dump.ts"
#define WFD_OVERSCAN_RESET_TIMER_MS 7000 /* msec */

    typedef struct WFD_DUMP_TS_CONF_S
    {
        int enable;
        FILE *d_fp;
        char d_path[WFD_DUMP_TS_MAX_PATH_SIZE];
    } WFD_DUMP_TS_CONF_T;


    enum {
        WFD_RTSP_SIGMA_CMD_AUDIO_ONLY = 0,
        WFD_RTSP_SIGMA_CMD_HIDC_EVT_KEYBOARD,
        WFD_RTSP_SIGMA_CMD_HIDC_EVT_MOUSE,
        WFD_RTSP_SIGMA_CMD_GEN_EVT_KEYBOARD,
        WFD_RTSP_SIGMA_CMD_END
    };

    enum {
        WFD_RTSP_CONF_TYPE_AUDIO_ONLY = 0,
        WFD_RTSP_CONF_TYPE_UIBC_CAP_TYPE,
        WFD_RTSP_CONF_TYPE_HDCP2X_ENABLE,
        WFD_RTSP_CONF_TYPE_LOG_LEVEL,
        WFD_RTSP_CONF_TYPE_VIDEO_FORMAT,
        WFD_RTSP_CONF_TYPE_SIGMA_DISABLE_ALL,
        WFD_RTSP_CONF_TYPE_TS_READ_NAME,
        WFD_RTSP_CONF_TYPE_STANDBY_ENABLE,
        WFD_RTSP_CONF_TYPE_I2C_ENABLE,
        WFD_RTSP_CONF_TYPE_EDID_ENABLE,
        WFD_RTSP_CONF_TYPE_MAX
    };

    enum {
        WFD_UIBC_CAP_ALL = 0,
        WFD_UIBC_CAP_GENERIC,
        WFD_UIBC_CAP_HIDC
    };

    struct wfd_rtsp_conf_s
    {
        int enable_aud_only;
        int uibc_cap_type;
        int disable_hdcp2x;
        int rtsp_debug;
        int video_format_set;
        int video_format_list_size;
        int sigma_disable_all;
        unsigned char video_format_list[64];
        char ts_read_name[128];
        int enable_standby;
        int enable_i2c;
        int enable_edid;
        int ts_dump_enable;
        char ts_dump_file[128];
        int log_level;
        int wfd_mimm_dbg_level;
        int player_start_not_initonly;
    };

typedef enum wfa_VideoFormats
{
    eCEA = 1,
    e640x480p60,
    e720x480p60,
    e20x480i60,
    e720x576p50,
    e720x576i50,
    e1280x720p30,
    e1280x720p60,
    e1920x1080p30,
    e1920x1080p60,
    e1920x1080i60,
    e1280x720p25,
    e1280x720p50,
    e1920x1080p25,
    e1920x1080p50,
    e1920x1080i50,
    e1280x720p24,
    e1920x1080p24,

    eVesa,
    e800x600p30,
    e800x600p60,
    e1024x768p30,
    e1024x768p60,
    e1152x864p30,
    e1152x864p60,
    e1280x768p30,
    e1280x768p60,
    e1280x800p30,
    e1280x800p60,
    e1360x768p30,
    e1360x768p60,
    e1366x768p30,
    e1366x768p60,
    e1280x1024p30,
    e1280x1024p60,
    e1400x1050p30,
    e1400x1050p60,
    e1440x900p30,
    e1440x900p60,
    e1600x900p30,
    e1600x900p60,
    e1600x1200p30,
    e1600x1200p60,
    e1680x1024p30,
    e1680x1024p60,
    e1680x1050p30,
    e1680x1050p60,
    e1920x1200p30,
    e1920x1200p60,

    eHH,
    e800x480p30,
    e800x480p60,
    e854x480p30,
    e854x480p60,
    e864x480p30,
    e864x480p60,
    e640x360p30,
    e640x360p60,
    e960x540p30,
    e960x540p60,
    e848x480p30,
    e848x480p60,
} wfavideoFormats;

#ifdef CC_S_PLATFORM
extern int avsync_freerun;
#endif

#ifdef __cplusplus
}
#endif

#endif /* _WFD_CLIENT_EXPORT_H_ */
