#ifndef _WFDCLIENT_H_
#define _WFDCLIENT_H_

#ifdef __ANDROID__
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/poll.h>
#include <sys/select.h>
#include <unistd.h>

#include "WFD_common.h"
#include "WfdRtspPlayer.h"

#define MONITOR_SOCK_PATH "/mnt/vendor/tmp/smonitorsock"
#define REQUEST_SOCK_PATH "/mnt/vendor/tmp/srequestsock"

extern int monitor_sock;
extern int ctrl_sock;

int wfd_socket_create();
int wfd_socket_destory();
int wfd_send_command(const char *comm);
int wfd_ctrl_recv(int s,char *reply,size_t* replylen);
int wfd_wait_for_thread_exit();
int get_grm_callback_flag();

#endif /* __ANDROID__ */

class WFDClient
{
public:
    WFDClient();
    static WFDClient & getInstance();
    WFD_RESULT start(const char* ip, int port, bool fast_connection = false);
    WFD_RESULT mediaPlay();
    WFD_RESULT mediaPause();
    WFD_RESULT mediaTearDown();
    WFD_RESULT mediaTearDown_GrmCallback();
    std::string & getRtpSessionId();
    WFD_RESULT sendIDRReq();
    WFD_RESULT enterStandbyMode();
    WFD_RESULT uibcGenEvent(int isMultiTouch);
    WFD_RESULT uibcCapUpdate(char *type);
    WFD_RESULT rtspSigmaCmd(int cmdtype, char *data, int datalen);
    WFD_RESULT getRtpStats(char *buf, int len);
    WFD_RESULT cancelNegTimeout();    

#ifdef PROTOCOL_API
    void setProtocol(int prot);
    int getProtocol();
#endif

#ifdef CC_S_PLATFORM
    void setRecvBufferSize(unsigned bufferSize);
    unsigned getRecvBufferSize(void);
    void setPlayBufferSize(unsigned bufferSize);
    unsigned getPlayBufferSize(void);
    void setTCPPreBufferSize(unsigned bufferSize);
    unsigned getTCPPreBufferSize(void);
#endif

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    WFD_RESULT sendM121(int max_value,int current_value,int mute_setting, int reserve);
    WFD_RESULT sendVolumnChange(bool increase);
#endif

private:
    static WFDClient _INS_;
    rtsp::WfdRtspPlayer* mPlayer;
    Mutex mLock;
    std::string rtpId;
#ifdef PROTOCOL_API
    int protocol ; // UDP: 0 , TCP :1
#endif
};
#endif /* _WFDCLIENT_H_ */
