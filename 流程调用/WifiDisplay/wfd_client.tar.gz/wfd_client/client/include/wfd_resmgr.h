#ifndef _WFD_RESMGR_H_
#define _WFD_RESMGR_H_

#ifdef __cplusplus
extern "C" {
#endif


#ifdef GLOBAL_RESOURCE_MANAGER
int wfd_resmgr_request_resource();
int wfd_resmgr_release_resource();
int wfd_resmgr_destory_component();

#endif

#ifdef __cplusplus
    }
#endif

#endif //_WFD_RESMGR_H_
