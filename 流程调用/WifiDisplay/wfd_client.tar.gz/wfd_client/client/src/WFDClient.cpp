#define WFD_LOG_TAG "WFDClient"
#include "WFDClient.h"
#include "Utils.h"
#include "WfdRtspPlayer.h"

#include <algorithm>
#include <string.h>
#include <sys/socket.h>
#include "wfd_resmgr.h"

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
#include <stdlib.h>
#endif

//add for set withoutlayer property
#include <cutils/properties.h>
static const char kWifidispCap[] = "vendor.mstar.video.withoutlayer";
//static char vWifidispCap[] = "1";

using namespace rtsp;
using namespace std;

#ifdef __ANDROID__
int monitor_sock = -1;
int ctrl_sock = -1;
int release_flag = 0;
int lock_flag = 0;
int grm_callback_flag = 0;
static bool has_teardown = false;
// struct sockaddr_un addr_monitor,addr_ctrl;
int wfd_socket_create()
{
    WFD_LOG_ENTER();

    struct sockaddr_un addr_monitor;
    monitor_sock = socket(PF_UNIX, SOCK_DGRAM, 0);
    if (monitor_sock < 0)
    {
        WFD_LOG_ERR( "monitor_sock create fail!\n");
        return -1;
    }
    unlink(MONITOR_SOCK_PATH);

    memset(&addr_monitor,0,sizeof(addr_monitor));

    addr_monitor.sun_family = AF_UNIX;
    strcpy(addr_monitor.sun_path,MONITOR_SOCK_PATH);
    int len = sizeof(addr_monitor.sun_family)+strlen(addr_monitor.sun_path);

    if (::bind(monitor_sock, (struct sockaddr *) &addr_monitor, len) < 0)
    {
        WFD_LOG_ERR( "monitor_sock bind fail!\n");
        close(monitor_sock);
        monitor_sock = -1;
        unlink(MONITOR_SOCK_PATH);
        return -1;
    }

    ctrl_sock = socket(PF_UNIX, SOCK_DGRAM, 0);

    if (ctrl_sock < 0)
    {
        WFD_LOG_ERR( "ctrl_sock create fail!\n");
        close(monitor_sock);
        monitor_sock = -1;
        unlink(MONITOR_SOCK_PATH);
        return -1;
    }
    WFD_LOG_INFO( "socket create success!\n");
    return 0;

}

int wfd_socket_destory()
{
    close(monitor_sock);
    close(ctrl_sock);
    monitor_sock = -1;
    ctrl_sock = -1;
    unlink(MONITOR_SOCK_PATH);
    unlink(REQUEST_SOCK_PATH);
    WFD_LOG_INFO( "wfd_socket_destory !\n");
    return 0;
}

int wfd_send_command(const char *comm)
{
    if(-1==ctrl_sock)
    {
        WFD_LOG_ERR( "socket create fail!\n");
        return -1;
    }
    int commlen = strlen(comm);
    struct sockaddr_un addr_monitor;
    memset(&addr_monitor,0,sizeof(addr_monitor));
    addr_monitor.sun_family = AF_UNIX;
    strcpy(addr_monitor.sun_path,MONITOR_SOCK_PATH);
    int len = sizeof(addr_monitor.sun_family)+strlen(addr_monitor.sun_path);

    if(sendto(ctrl_sock,comm,commlen,0,(struct sockaddr *)&addr_monitor,len) < 0)
    {
        WFD_LOG_ERR( "send command fail!\n");
        return -1;
    }
    WFD_LOG_INFO( "wfd_send_command: result = 0 len=%d string=\"%s\"\n", commlen, comm);
    return 0;
}

int wfd_ctrl_recv(int s,char *reply,size_t* replylen)
{
    int res;

    struct pollfd rfds;
    rfds.fd = s;
    rfds.events = POLLIN|POLLPRI;
    res = poll(&rfds, 1, -1);
    if(res<0)
    {
        WFD_LOG_ERR( "Error poll = %d", res);
        return -1;
    }
    // printf("poll return %d!\n",rfds.revents);
    if (rfds.revents & (POLLIN|POLLPRI))
    {
        res = recvfrom(s, reply, *replylen,0,NULL,NULL);
        if (res < 0)
        return res;
        *replylen = res;
        return 0;

    }
    else
    {
        WFD_LOG_ERR( "Received on exit socket, terminate\n");
        return -1;
    }
    return 0;
}
int wfd_wait_for_thread_exit()
{
    fd_set fds;
    struct timeval tv;
    int err;
    FD_ZERO(&fds);
    FD_SET(monitor_sock,&fds);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    int time = 0;
    while(time++ < 30)
    {
        err = select(monitor_sock+1,&fds,NULL,NULL,&tv);
        if(FD_ISSET(monitor_sock,&fds)) //readable
        {
            WFD_LOG_ERR( "wfd_wait_for_thread_exit LINE[%d] err[%d]\n",__LINE__,err);
            usleep(1000);
        }
        else
        {
            WFD_LOG_ERR( "wfd_wait_for_thread_exit LINE[%d] err[%d]\n",__LINE__,err);
            break;
        }
    }
    return 0;
}

#endif /* __ANDROID__ */

WFDClient WFDClient::_INS_;
WFDClient::WFDClient()
{
    mPlayer = NULL;
#ifdef PROTOCOL_API
     protocol = false; // UDP: false , TCP :true
#endif
}

WFD_RESULT WFDClient::start(const char* ip, int port, bool fast_connection)
{
    mLock.lock();
    WFD_LOG_INFO( "start ip:%s port:%d fast_connection:%d \n",ip, port, fast_connection);
    if (ip == NULL)
    {
        mLock.unlock();
        return WFD_ERR_FAILED;
    }
    //WFD GRM
    #ifdef GLOBAL_RESOURCE_MANAGER
    wfd_resmgr_request_resource();
    #endif

    // property_set 1 for screenshot
    WFD_LOG_INFO("property_set kWifidispCap 1\n");
    if (property_set(kWifidispCap, "1")){
      WFD_LOG_ERR("property_set kWifidispCap 1 fail! \n");
    }
    has_teardown = false;
    if(mPlayer)
    {
        WFD_LOG_ERR( "Warning start already start \n");
        delete mPlayer;
        mPlayer = NULL;
    }
    int ret = 0;
    mPlayer = new WfdRtspPlayer();

    if (port == 0)
        port = 7236;
    char c_port[12] = { 0 };
    snprintf(c_port, sizeof(c_port), "%d", port);
    string url = string("rtsp://") + string(ip) + string(":") + string(c_port);
    ret = mPlayer->open(url, fast_connection);
    if(ret)
    {
        WFD_LOG_ERR( "start connection failed, ret=(%d) \n", ret);
        mLock.unlock();
        mediaTearDown();
        return WFD_ERR_FAILED;
    }
    mLock.unlock();
    return WFD_OK;
}

WFDClient & WFDClient::getInstance()
{
    return _INS_;
}

WFD_RESULT WFDClient::mediaPlay()
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }

    if(mPlayer->play() != WFD_OK)
    {
        WFD_LOG_ERR("mediaPlay play failed \n");
        return WFD_ERR_FAILED;
    }
    return WFD_OK;
}

WFD_RESULT WFDClient::mediaPause()
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!");
        return WFD_ERR_FAILED;
    }

    if(mPlayer->pause() != WFD_OK)
    {
        WFD_LOG_ERR("mediaPause pause failed \n");
        return WFD_ERR_FAILED;
    }
    return WFD_OK;
}

WFD_RESULT WFDClient::mediaTearDown()
{
    mLock.lock();
    WFD_LOG_ENTER();
    if(has_teardown)
    {
        mLock.unlock();
        return WFD_OK;
    }
    lock_flag = 1;
    if(!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL\n");
#ifdef GLOBAL_RESOURCE_MANAGER
        lock_flag = 0;
        mLock.unlock();
        wfd_resmgr_destory_component();
#endif
        if(lock_flag){
            lock_flag = 0;
            mLock.unlock();
        }
        return WFD_OK;
    }
    has_teardown = true;
    release_flag = 1;
    if(mPlayer->stop() != WFD_OK)
    {
        WFD_LOG_ERR("mediaTearDown stop failed \n");
        mLock.unlock();
        return WFD_ERR_FAILED;
    }

    if(mPlayer->close() != WFD_OK)
    {
        WFD_LOG_ERR("mediaTearDown close failed \n");
        mLock.unlock();
        return WFD_ERR_FAILED;
    }

    delete mPlayer;
    mPlayer = NULL;

   // property_set 0 for screenshot
    WFD_LOG_INFO("property_set kWifidispCap 0\n");
    if (property_set(kWifidispCap, "0")){
      WFD_LOG_ERR("property_set kWifidispCap 0 fail! \n");
    }

#ifdef GLOBAL_RESOURCE_MANAGER
    wfd_resmgr_release_resource();
    lock_flag = 0;
    mLock.unlock();
    wfd_resmgr_destory_component();
#endif
    release_flag = 0;
    if(lock_flag){
        lock_flag = 0;
        mLock.unlock();
    }
    return WFD_OK;
}

WFD_RESULT WFDClient::mediaTearDown_GrmCallback()
{
    mLock.lock();
    WFD_LOG_ENTER();
    grm_callback_flag = 1;
    if(!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL\n");
        mLock.unlock();
        return WFD_OK;
    }

    if(mPlayer->stop() != WFD_OK)
    {
        WFD_LOG_ERR("mediaTearDown stop failed \n");
        mLock.unlock();
        return WFD_ERR_FAILED;
    }

    if(mPlayer->close() != WFD_OK)
    {
        WFD_LOG_ERR("mediaTearDown close failed \n");
        mLock.unlock();
        return WFD_ERR_FAILED;
    }

    delete mPlayer;
    mPlayer = NULL;
    wfd_resmgr_release_resource();

    grm_callback_flag = 0;
    mLock.unlock();
    return WFD_OK;
}

std::string & WFDClient::getRtpSessionId()
{
    WFD_LOG_ENTER();
    rtpId = "";
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL\n");
        return rtpId;
    }
    assert(mPlayer);

    char sid[128];
    memset(sid, 0, sizeof(sid));
    int ret = mPlayer->getRtpSessionId(sid);
    if (ret != WFD_OK)
        rtpId = "";
    rtpId = sid;
    WFD_LOG_DEBUG("getRtpSessionId ret:%d, rtpId:%s\n", ret, rtpId.c_str());
    return rtpId;

}

WFD_RESULT  WFDClient::sendIDRReq()
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->sendIDRRequest();
}

WFD_RESULT WFDClient::enterStandbyMode()
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->enterStandbyMode();
}

WFD_RESULT WFDClient::uibcGenEvent(int isMultiTouch)
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->uibcGenEvent(isMultiTouch);
}

WFD_RESULT WFDClient::uibcCapUpdate(char *type)
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->uibcCapUpdate(type);

}

WFD_RESULT WFDClient::rtspSigmaCmd(int cmdtype, char *data, int datalen)
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->rtspSigmaCmd(cmdtype, data, datalen);
}

WFD_RESULT WFDClient::getRtpStats(char *buf, int len)
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->getRtpStats(buf, len);

}

WFD_RESULT WFDClient::cancelNegTimeout()
{
    WFD_LOG_ENTER();
    if (!mPlayer)
    {
        WFD_LOG_ERR("mPlayer NULL!\n");
        return WFD_ERR_FAILED;
    }
    return mPlayer->cancelNegTimeout();
}

#ifdef PROTOCOL_API
void WFDClient::setProtocol(int prot)
{
    protocol = prot;
    WFD_LOG_INFO("WFDClient set protocol : %d\n", protocol);
}

int WFDClient::getProtocol()
{
    WFD_LOG_INFO("WFDClient get protocol : %d\n", protocol);
    return protocol;
}
#endif

#ifdef CC_S_PLATFORM
void WFDClient::setRecvBufferSize(unsigned bufferSize)
{
    WFD_LOG_ERR( "setRecvBufferSize %u\n", bufferSize);
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return ;
    }
    mPlayer->setRecvBufferSize(bufferSize);
}

unsigned WFDClient::getRecvBufferSize(void)
{
    unsigned bufferSize = 0;

    WFD_LOG_ERR( "getRecvBufferSize \n");
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return 0;
    }
    bufferSize = mPlayer->getRecvBufferSize();
    return bufferSize;
}

void WFDClient::setPlayBufferSize(unsigned bufferSize)
{
    WFD_LOG_ERR( "setPlayBufferSize %u\n", bufferSize);
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return ;
    }
    mPlayer->setPlayBufferSize(bufferSize);
}

unsigned WFDClient::getPlayBufferSize(void)
{
    unsigned bufferSize = 0;
    WFD_LOG_ERR( "getPlayBufferSize \n");
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return 0;
    }

    bufferSize = mPlayer->getPlayBufferSize();
    return bufferSize;
}

void WFDClient::setTCPPreBufferSize(unsigned bufferSize)
{
    WFD_LOG_ERR( "setTCPPreBufferSize %u\n", bufferSize);
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return ;
    }
    mPlayer->setTCPPreBufferSize(bufferSize);
}

unsigned WFDClient::getTCPPreBufferSize(void)
{
    unsigned bufferSize = 0;

    WFD_LOG_ERR( "getTCPPreBufferSize \n");
    if (!mPlayer)
    {
        WFD_LOG_ERR( "%s: invlid pointer!\n", __FUNCTION__);
        return 0;
    }
    bufferSize = mPlayer->getTCPPreBufferSize();
    return bufferSize;
}
#endif

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
WFD_RESULT WFDClient::sendM121(int max_value,int current_value,int mute_setting, int reserve)
{
    const char *para_name = "sony_ext_10";
    const char *para_fmt = "%x %x %x %x";
    char para_value[256] = {0};
    WFD_LOG_INFO("WfdRtspClient::sendVolumeControl \n");

    sprintf(para_value,para_fmt,max_value,current_value,mute_setting,reserve);

    WFD_LOG_INFO("===== Sending M121 Request =====\n");

    if (mPlayer)
    {
        mPlayer->sendSetParameterCmd(para_value);
        WFD_LOG_INFO("sendVolumeControl request's data done\n");
        return 0;
    }

    WFD_LOG_INFO("sendVolumeControl ssMentor is NULL\n");
    return -1;
}

WFD_RESULT WFDClient::sendVolumnChange(bool increase)
{
    WFD_LOG_INFO("WFDClient::sendVolumnChange \n");
    //step 1: get current volume
    int current_index = -1;
    int update_index = -1;

    //android::AudioSystem::getStreamVolumeIndex(AUDIO_STREAM_MUSIC,&current_index,AUDIO_DEVICE_OUT_DEFAULT);
    WFD_LOG_INFO("current_index: %x \n",current_index);

    //step 2: increase of decrese
    update_index = current_index+(increase*2 -1);

    //step 3:judge the range
    if(update_index<0)   update_index=0;
    if(update_index>100) update_index=100;

    WFD_LOG_INFO("update_index: %x \n",current_index);
    //android::AudioSystem::setStreamVolumeIndex(AUDIO_STREAM_MUSIC,update_index,AUDIO_DEVICE_OUT_DEFAULT);

    //step 4:send M121
    sendM121(0x64,update_index,0,0);
    return update_index;
}
#endif


