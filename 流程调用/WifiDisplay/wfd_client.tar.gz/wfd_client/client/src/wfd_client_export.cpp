#define WFD_LOG_TAG "wfd_client_export"
/*-------------------------------------------------------------------------

-------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include "WFDClient.h"
#include "wfd_client_export.h"
#include "wfd_client_internal.h"
#include "Utils.h"
#include "WFDConfig.h"
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
#include "WfdRtspClient.h"
#endif

#ifdef CC_S_PLATFORM
int avsync_freerun = 0;
#endif

unsigned int wfd_idr_interval = 1000;
static bool b_client_started = false;
e_wfdVideoFormat wfdVideoFormat;
struct wfd_rtsp_conf_s *wfd_rtsp_conf = NULL;
int _wfd_dbg_level = WFD_DBG_INFO;

/** Start extern C code **/
#ifdef __cplusplus
extern "C"
{
#endif

extern int wfd_sigma_start(void);

#ifdef __cplusplus
}
#endif
/** End extern C code **/

WFD_RESULT  wfd_client_start(WFD_Client_callback pf_callback)
{
    WFD_LOG_ENTER();
    rtsp::WFDConfig ini(WFD_CFG_INI_PATH);
    if (ini.isValid())
    {
        wfd_client_rtsp_conf_reset();
        wfd_rtsp_conf->disable_hdcp2x = ini.getBoolean("wfd:disable_hdcp2x", 0);
        wfd_rtsp_conf->ts_dump_enable = ini.getBoolean("wfd:ts_dump_enable", 0);
        const char *ts_dump_file  = ini.getString("wfd:ts_dump_file");
        strncpy(wfd_rtsp_conf->ts_dump_file, ts_dump_file, sizeof(wfd_rtsp_conf->ts_dump_file)-1);
        wfd_rtsp_conf->log_level = ini.getInt("wfd:log_level", 0);
        wfd_rtsp_conf->wfd_mimm_dbg_level = ini.getInt("wfd:wfd_mimm_dbg_level", 0);
        wfd_rtsp_conf->player_start_not_initonly = ini.getBoolean("wfd:player_start_not_initonly", 0);

        WFD_LOG_ERR("wfd_rtsp_conf disable_hdcp2x=%d, ts_dump_enable:%d, ts_dump_file:%s, log_level:%d, wfd_mimm_dbg_level:%d, player_start_not_initonly:%d\n",
                wfd_rtsp_conf->disable_hdcp2x, wfd_rtsp_conf->ts_dump_enable,
                wfd_rtsp_conf->ts_dump_file,  wfd_rtsp_conf->log_level, wfd_rtsp_conf->wfd_mimm_dbg_level, wfd_rtsp_conf->player_start_not_initonly);

        _wfd_dbg_level = wfd_rtsp_conf->log_level;
    }

    if(b_client_started)
    {
        WFD_LOG_INFO("WFD Client has been started!\n");
        return 1;   //cowork with haixia to control the monitor thread
    }

#ifdef __ANDROID__
    //create monitor socket
    if(-1 == monitor_sock)
    {
        if(0 != wfd_socket_create())
        {
            WFD_LOG_ERR( "Sockect create error!");
            return -1;
        }
    }
    /* Start sigma thread to enable sigma & wfd_cli functions */
#ifdef ENABLE_WFD_SIGMA
    wfd_sigma_start();
#endif
#endif

    b_client_started = true;
    return 0;
}

WFD_RESULT wfd_client_rtsp_start(const char* ip, int port, int fast_connection)
{
    WFD_LOG_INFO( "Enter WFD ip=%s port=%d\n", ip, port);
    int ret = 0;
    ret = WFDClient::getInstance().start(ip, port, fast_connection);
    if (ret != WFD_OK)
    {
        WFD_LOG_ERR( "Fail to start RTSP\n");
        return WFD_ERR_FAILED;
    }
    WFD_LOG_ERR( "RTSP started successfully, going to play...\n");
    return WFD_OK;
}

WFD_RESULT wfd_client_rtsp_play()
{
    return WFDClient::getInstance().mediaPlay();
}

WFD_RESULT wfd_client_rtsp_pause()
{
    return WFDClient::getInstance().mediaPause();
}

WFD_RESULT wfd_client_rtsp_stop()
{
    WFD_LOG_ENTER();
    WFDClient::getInstance().cancelNegTimeout();
    return WFDClient::getInstance().mediaTearDown();
}

const char * wfd_client_get_rtpSessionId()
{
    return WFDClient::getInstance().getRtpSessionId().c_str();
}

WFD_RESULT wfd_client_stop()
{
    if(false == b_client_started)
    {
        WFD_LOG_INFO("WFD Client has been stopped!");
        return 0;
    }
#ifdef __ANDROID__
    wfd_send_command(RTSP_EVENT_TERMINATE);
    wfd_wait_for_thread_exit();
    wfd_socket_destory();
    WFD_LOG_INFO("Socket destroy\n");
#endif /* __ANDROID__ */
    b_client_started = false;
    return 0;
}

WFD_RESULT  wfd_client_send_IDRReq()
{
    return WFDClient::getInstance().sendIDRReq();
}

WFD_RESULT wfd_client_enter_standby_mode()
{
    return WFDClient::getInstance().enterStandbyMode();
}

WFD_RESULT wfd_client_uibc_gen_event(int isMultiTouch)
{
    return WFDClient::getInstance().uibcGenEvent(isMultiTouch);
}

WFD_RESULT wfd_client_uibc_cap_update(char *type)
{
    return WFDClient::getInstance().uibcCapUpdate(type);
}

WFD_RESULT wfd_client_rtsp_sigma_cmd(int cmdtype, char *data, int datalen)
{
    return WFDClient::getInstance().rtspSigmaCmd(cmdtype, data, datalen);
}

WFD_RESULT wfd_client_get_rtp_stats(char *buf, int len)
{
    return WFDClient::getInstance().getRtpStats(buf, len);
}

//@increase:  int
//  true  : increase index by 1
//  false : decrease index by 1
WFD_RESULT wfd_client_volume_control_M121(int increase)
{
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    bool increase_flag = false;
    if(increase != 0) increase_flag =true;
    return WFDClient::getInstance().sendVolumnChange(increase_flag);
#else
    return -1;
#endif
}

//////////////////////////////////////////////////
//////////////////////////////////////////////////
int wfd_client_rtsp_conf_reset(void)
{
    if (!wfd_rtsp_conf)
    {
        wfd_rtsp_conf = (struct wfd_rtsp_conf_s *)malloc(sizeof(struct wfd_rtsp_conf_s));
        if (!wfd_rtsp_conf)
        {
            WFD_LOG_ERR("failed to malloc\n");
            return WFD_ERR_FAILED;
        }
    }
    memset(wfd_rtsp_conf, 0, sizeof(struct wfd_rtsp_conf_s));
    return WFD_OK;
}

int wfd_client_rtsp_conf_set(int conf_type, void *data, int data_len)
{
    int param_int32 = 0;
    //wfd_client_rtsp_conf_reset();
    if (!wfd_rtsp_conf)
    {
        WFD_LOG_ERR("Error wfd_rtsp_conf not allocated!\n");
        return WFD_ERR_FAILED;
    }

    switch (conf_type)
    {
        case WFD_RTSP_CONF_TYPE_AUDIO_ONLY:
        {
            param_int32 = *((int *)data);
            WFD_LOG_INFO("%s Audio-Only mode\n", param_int32?"Enabling":"Disabling");
            wfd_rtsp_conf->enable_aud_only = param_int32;

            break;
        }
        case WFD_RTSP_CONF_TYPE_UIBC_CAP_TYPE:
        {
            param_int32 = *((int *)data);
            WFD_LOG_INFO("Enable Cap Type = %s\n", (param_int32==WFD_UIBC_CAP_GENERIC)?"Generic":"HIDC");
            wfd_rtsp_conf->uibc_cap_type = param_int32;
            break;
        }
        case WFD_RTSP_CONF_TYPE_HDCP2X_ENABLE:
        {
            param_int32 = *((int *)data);
            WFD_LOG_INFO("%s HDCP2.x\n", param_int32?"Enabling":"Disabling");

            if (param_int32)
            {
                wfd_rtsp_conf->disable_hdcp2x = 0;
            }
            else
            {
                wfd_rtsp_conf->disable_hdcp2x = 1;
            }
            //mtk94097
            break;
        }
        case (WFD_RTSP_CONF_TYPE_LOG_LEVEL):
        {
            param_int32 = *((int *)data);
            WFD_LOG_INFO("log LEVEL:%d\n", param_int32);
            wfd_rtsp_conf->log_level = param_int32;
            break;
        }
        case (WFD_RTSP_CONF_TYPE_VIDEO_FORMAT):
        {
            memset(wfd_rtsp_conf->video_format_list, 0, sizeof(wfd_rtsp_conf->video_format_list));
            wfd_rtsp_conf->video_format_list_size = data_len;
            memcpy(wfd_rtsp_conf->video_format_list, (unsigned char *)data, data_len);
            WFD_LOG_INFO("Setting video format list size:%d\n", wfd_rtsp_conf->video_format_list_size);
            wfd_rtsp_conf->video_format_set = 1;
            break;
        }
        case (WFD_RTSP_CONF_TYPE_SIGMA_DISABLE_ALL):
        {
            wfd_rtsp_conf->sigma_disable_all = 1;
            WFD_LOG_INFO("WFD disable all optional features\n");
            break;
        }
        case (WFD_RTSP_CONF_TYPE_TS_READ_NAME):
        {
            char *name = (char *)data;
            memset(wfd_rtsp_conf->ts_read_name, 0, sizeof(wfd_rtsp_conf->ts_read_name));
            strncpy(wfd_rtsp_conf->ts_read_name, name, sizeof(wfd_rtsp_conf->ts_read_name)-1);
            WFD_LOG_INFO("Set TS filename to [%s]\n", wfd_rtsp_conf->ts_read_name);
            break;
        }
        default:
        {
            WFD_LOG_ERR( "Error Unknown WFD RTSP CONF TYPE %d\n", conf_type);
            break;
        }
    }
    return WFD_OK;
}

#ifdef PROTOCOL_API
int wfd_client_get_protocol()
{
    return WFDClient::getInstance().getProtocol();
}
#endif

#ifdef CC_S_PLATFORM
int wfd_client_avsync_set_freerun(int enable)
{
    avsync_freerun = enable;
    return 0;
}

int wfd_client_avsync_get_freerun(void)
{
    return avsync_freerun;
}

void wfd_client_set_recv_buffer_size(unsigned size)
{
    WFDClient::getInstance().setRecvBufferSize(size);
}

unsigned wfd_client_get_recv_buffer_size()
{
    return WFDClient::getInstance().getRecvBufferSize();
}

void wfd_client_set_play_buffer_size(unsigned size)
{
    WFDClient::getInstance().setPlayBufferSize(size);
}

unsigned wfd_client_get_play_buffer_size()
{
    return WFDClient::getInstance().getPlayBufferSize();
}

void wfd_client_set_tcp_pre_buffer_size(unsigned size)
{
    WFDClient::getInstance().setTCPPreBufferSize(size);
}

unsigned wfd_client_get_tcp_pre_buffer_size()
{
    return WFDClient::getInstance().getTCPPreBufferSize();
}

#endif

void wfd_client_dec_error_reset()
{
}

/* The following are APIs created for Android platform */
#ifdef __ANDROID__
WFD_RESULT wfd_client_wait_for_event(char *buf, size_t buflen)
{
    size_t nread = buflen - 1;
    int result;

    if (monitor_sock == -1) {
        return -1;
    }

    result = wfd_ctrl_recv(monitor_sock, buf, &nread);
    if (result < 0) {
        return -2;
    }
    buf[nread] = '\0';
    WFD_LOG_INFO( "wait_for_event: result=%d nread=%d string=\"%s\"\n", result, nread, buf);
    /* Check for EOF on the socket */
    if (result == 0 && nread == 0) {

        return -3;
    }
    /*
     * Events strings are in the format
     *
     *     RTSP-EVENT-XXX
     *
     */

    return nread;
}

void wfd_client_get_video_format(e_wfdVideoFormat* format_ptr)
{
    format_ptr->length = wfdVideoFormat.length;
    format_ptr->width = wfdVideoFormat.width;
    format_ptr->frame_rate = wfdVideoFormat.frame_rate;
}
#endif /* __ANDROID__ */

