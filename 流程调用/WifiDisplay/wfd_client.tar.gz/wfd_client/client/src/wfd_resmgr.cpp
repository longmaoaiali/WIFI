#ifndef _WFD_RESMGR_C_
#define _WFD_RESMGR_C_

#define WFD_LOG_TAG "WFDClient"
#include "WFDClient.h"

#include "Utils.h"

#include "wfd_resmgr.h"


#ifdef GLOBAL_RESOURCE_MANAGER
#include "hwbinder/MtkRmHwAPI.h"

static ClientID mClientId;
#define RMClientMIF "WFD_GRM"

Resource resctx = {0};


static BOOL WFD_RESMGR_EventReleaseCallback(void* ctx, void* pv_data)
{
    int ret = WFDClient::getInstance().mediaTearDown_GrmCallback();
    if(ret == WFD_OK)
    {
        WFD_LOG_INFO("GRM WFD_Resmgr_Release_Function_Wrap Done !!!\n");
        return TRUE;
    }
    return FALSE;

}


int WFD_RESMGR_releaseHwResource()
{
    if (mClientId == 0)
    {
        WFD_LOG_INFO("GRM %s: mClientId is 0!", __FUNCTION__);
        return FALSE;
    }
    ReleaseAllResource(mClientId);
    WFD_LOG_INFO("GRM %s", __FUNCTION__);
    return TRUE;
}

int WFD_RESMGR_destroyHwResource()
{
    if (mClientId == 0)
    {
        WFD_LOG_INFO("GRM %s: mClientId is 0!", __FUNCTION__);
        return FALSE;
    }
    if(!CallbackDone(mClientId))
    {
        WFD_LOG_INFO("GRM %s: Wait %p callbackDone failed", __FUNCTION__, &resctx);
    }
    RMDestoryComponent(mClientId);
    WFD_LOG_INFO("GRM %s", __FUNCTION__);

    mClientId = 0;
    return TRUE;
}

int WFD_RESMGR_acquireHwResource()
{
    int ret = 0;

    if (mClientId == 0)
    {
        ret = RMCreateComponent((char *)RMClientMIF, WFD_RESMGR_EventReleaseCallback, &resctx, &mClientId);
        if (0 != ret)
        {
            WFD_LOG_INFO("GRM %s: RMCreateComponent failed!", __FUNCTION__);
            return FALSE;
        }
    }

    SetComponentPriority(mClientId, RMClientPriority_OMXVideoEncoder);
    SetComponentPreemptEqual(mClientId, TRUE);

    // check resource either regist. if resource not regist, return error.
    if (RMCheckResource((char *)VIDEODECODER))
    {
        //allocate the vdec resource to make sure video and photo can be mutex.

        resctx.e_Type                  = RESOURCE_TYPE_NUMBERNIC;
        resctx.resourceName            = (char *)VIDEODECODER;
        resctx.u.NumbernicType.value   = 0;

        if (!(AddResourceEx(mClientId, &resctx)))
        {
            WFD_LOG_INFO("GRM AddResourceEx VIDEODECODER fail.\n");
            WFD_RESMGR_releaseHwResource();
            return FALSE;
        }

        resctx.e_Type                  = RESOURCE_TYPE_NUMBERNIC;
        resctx.resourceName            = (char *)DISPLAYBUFFER;
        resctx.u.NumbernicType.value   = 0;

        if (!(AddResourceEx(mClientId, &resctx)))
        {
            WFD_LOG_INFO("GRM AddResourceEx VIDEOPATH fail.\n");
            WFD_RESMGR_releaseHwResource();
            return FALSE;
        }

        resctx.e_Type                  = RESOURCE_TYPE_NUMBERNIC;
        resctx.resourceName            = (char *)AUDIODECODER;
        resctx.u.NumbernicType.value   = 0;
        if (AddResourceEx(mClientId, &resctx))
        {
            if (AllocResourceWithPriority(mClientId, RMClientPriority_Default))
            {
                WFD_LOG_INFO("GRM Source Open OK.\n");
                return TRUE;
            }
            else
            {
                WFD_LOG_INFO("GRM Source Open fail.\n");
            }
        }
        else
        {
            WFD_RESMGR_releaseHwResource();
            WFD_LOG_INFO( "GRM AddResource AUDIODECODER fail.\n");
            WFD_LOG_INFO( "GRM Source Open fail.\n");
            return FALSE;
        }
    }
    return TRUE;
}

int wfd_resmgr_request_resource()
{
    WFD_LOG_INFO( "GRM WFD Request Resource\n");
    WFD_RESMGR_acquireHwResource();

    return TRUE;
}

int wfd_resmgr_release_resource()
{
    WFD_LOG_INFO( "GRM WFD Release Resource\n");
    WFD_RESMGR_releaseHwResource();
    return TRUE;
}
int wfd_resmgr_destory_component()
{
    WFD_LOG_INFO( "GRM WFD destory component\n");
    WFD_RESMGR_destroyHwResource();
    return TRUE;
}


#endif

#endif // _WFD_RESMGR_C_
