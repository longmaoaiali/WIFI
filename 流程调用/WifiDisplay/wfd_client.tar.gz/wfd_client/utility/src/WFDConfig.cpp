#define WFD_LOG_TAG "WFDConfig"
#include "WFDConfig.h"
#include "iniparser.h"
#include "dictionary.h"

#include "Utils.h"

namespace rtsp
{

static int _wfd_iniparser_error_callback(const char *format, ...)
{
  va_list argptr;
  va_start(argptr, format);
  __android_log_vprint(ANDROID_LOG_ERROR, _WFD_LOG_TAG, format, argptr);
  va_end(argptr);
  return 1;
}

WFDConfig::WFDConfig(std::string iniPath)
{
    iniparser_set_error_callback(_wfd_iniparser_error_callback);
    WFD_LOG_DEBUG("WFDConfig: %s\n", iniPath.c_str());
    ini = iniparser_load(iniPath.c_str());
    if (ini==NULL) {
        WFD_LOG_ERR("cannot parse file: %s\n", iniPath.c_str());
    }
}

WFDConfig::~WFDConfig()
{
    iniparser_freedict(ini);
}
bool WFDConfig::isValid()
{
    if (ini == NULL)
        return false;
    return true;
}
const char* WFDConfig::getString(const char* key)
{
    return iniparser_getstring(ini, key, NULL);
}

int WFDConfig::getInt(const char* key, int def)
{
    return iniparser_getint(ini, key, def);
}

int WFDConfig::getBoolean(const char* key, int def)
{
    return iniparser_getboolean(ini, key, def);
}
}