#include "Utils.h"
namespace rtsp
{

//bool b_debug_log = true;
bool b_debug_log = true;
int wfd_rtsp_dbg_lvl = WFD_DBG_MAX;


}

