#ifndef _UTILS_H_
#define _UTILS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef __ANDROID__
#include <android/log.h>
#endif

//#define WFD_HDCP_LIB_PATH            "/vendor/lib/libhdcp.so"
#ifdef WFD_BUILD_AN64
#define WFD_HDCP_LIB_PATH            "/vendor/lib64/libhdcp.so"
#else
#define WFD_HDCP_LIB_PATH            "/vendor/lib/libhdcp.so"
#endif

#define WFD_CFG_INI_PATH             "/data/WFD/wfd_cfg.ini"

#define _WFD_LOG_TAG "[WFD-" WFD_LOG_TAG "]"

extern int _wfd_dbg_level;
#define WFD_DBG_LEVEL   _wfd_dbg_level

#define WFD_DBG_ERR    0
#define WFD_DBG_DEBUG   1
#define WFD_DBG_INFO     2

#ifndef __ANDROID__

#define WFD_LOG_INFO(fmt, args...)      ({do{if(WFD_DBG_LEVEL>=WFD_DBG_INFO){   printf("[WFD-"WFD_LOG_TAG"] I : ");printf(fmt, ##args);printf("\n");}}while(0);})
#define WFD_LOG_DEBUG(fmt, args...)     ({do{if(WFD_DBG_LEVEL>=WFD_DBG_DEBUG){  printf("[WFD-"WFD_LOG_TAG"] D : ");printf(fmt, ##args);printf("\n");}}while(0);})
#define WFD_LOG_ERR(fmt, args...)       ({do{   printf("[WFD-"WFD_LOG_TAG"] E : [%s:%d] " ,__FUNCTION__,__LINE__);printf(fmt, ##args);printf("\n");}while(0);})

#define WFD_LOG_ENTER()                 ({do{if(WFD_DBG_LEVEL>=WFD_DBG_DEBUG){  printf("[WFD-"WFD_LOG_TAG"] D : Enter [%s:%d]\n",__FUNCTION__,__LINE__);}}while(0);})

#define WFD_LOG_TIME(fmt, args...)      \
    do {\
        if(WFD_DBG_LEVEL>=WFD_DBG_INFO){\
            timespec now; \
            clock_gettime(CLOCK_MONOTONIC, &now); \
            printf("[WFD-"WFD_LOG_TAG"] T :Time[%lld ms]:", (long long)(now.tv_sec*1000 + now.tv_nsec/1000000));\
            printf(fmt, ##args); \
            printf("\n"); \
        }\
    } while(0)

#else /*__ANDROID__*/

#define WFD_LOG_INFO(...)      \
    ({do{ \
        if(WFD_DBG_LEVEL>=WFD_DBG_INFO){    \
            __android_log_print(ANDROID_LOG_INFO, _WFD_LOG_TAG, __VA_ARGS__);\
        }\
    }while(0);})

#define WFD_LOG_DEBUG(...)  \
    ({do{ \
        if(WFD_DBG_LEVEL>=WFD_DBG_DEBUG){   \
            __android_log_print(ANDROID_LOG_DEBUG, _WFD_LOG_TAG, __VA_ARGS__);\
        }\
    }while(0);})

#define WFD_LOG_ERR(fmt,args...)      \
    ({do{ \
        __android_log_print(ANDROID_LOG_ERROR, _WFD_LOG_TAG, "[%s:%d]" fmt, __FUNCTION__, __LINE__, ##args);\
    }while(0);})

#define WFD_LOG_ENTER()    \
    ({do{ \
        if(WFD_DBG_LEVEL>=WFD_DBG_INFO){   \
            __android_log_print(ANDROID_LOG_INFO, _WFD_LOG_TAG, "Enter[%s:%d]", __FUNCTION__, __LINE__);\
        } \
    }while(0);})

#define WFD_LOG_TIME(fmt,args...)       \
    {do {\
        if(WFD_DBG_LEVEL>=WFD_DBG_INFO){\
            timespec now; \
            clock_gettime(CLOCK_MONOTONIC, &now); \
            __android_log_print(ANDROID_LOG_INFO, _WFD_LOG_TAG, "Time[%lld ms]" fmt, (long long)(now.tv_sec*1000 + now.tv_nsec/1000000), ##args);\
        }\
    } while(0);}
#endif
#define UNUSED(x)   (void)(x)

#endif
