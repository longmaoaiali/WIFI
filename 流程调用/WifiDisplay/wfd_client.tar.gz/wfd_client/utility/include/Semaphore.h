#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_
#include <pthread.h>

//#define RECURSIVE_LOCK_SUPPORT

#ifdef RECURSIVE_LOCK_SUPPORT
#include <sys/types.h>
#endif

namespace rtsp {
/* init a mutex to unlocked state */
#define WFD_MUTEX_INIT(x) do{pthread_mutex_init(&x, NULL);}while(0)

/* init a mutex to locked state */
#define WFD_MUTEX_INIT_LOCKED(x) do{pthread_mutex_trylock(&x);}while(0)

#define WFD_MUTEX_DESTROY(x) do{pthread_mutex_destroy(&x);}while(0)
#define WFD_MUTEX_LOCK(x)  do{pthread_mutex_lock(&x);}while(0)
#define WFD_MUTEX_UNLOCK(x)  do{pthread_mutex_unlock(&x);}while(0)
#define WFD_MUTEX_TIMEDLOCK(x,usec,r) do{r=wfd_mutexLTimedLock(&x,usec);}while(0)

extern int wfd_mutexLTimedLock(pthread_mutex_t *mut, int usec);
extern int getCurrentAbsTime(void *ts);


class Semaphore{
public:
    /**
     * Creates a new semaphore. Optionally specify an initial count,
     * default is 0.
     */
    Semaphore();     // cond number: the Semaphore can maintain more than one cond(s).

    /**
     * Destroys this semaphore.
     */
    ~Semaphore();

    void syncBegin();
    void syncEnd();

    void wait(int condInex = 0);
    bool timedWait(unsigned int relTimeOutMs);
    void notify(int condInex = 0);
    void notifyAll(int condInex = 0);
    bool bTimeWait();
private:
    pthread_mutex_t mutex_;
    pthread_cond_t  cond;
    bool bwait;
#ifdef RECURSIVE_LOCK_SUPPORT
    pid_t t_owner;
    int lock_count;
    pthread_mutex_t ext_protector;
#define EXT_BEGIN()                             \
    pthread_mutex_lock(&ext_protector)

#define EXT_END()                               \
    pthread_mutex_unlock(&ext_protector)

#endif
};
}

#endif /* _SEMAPHORE_H_ */
