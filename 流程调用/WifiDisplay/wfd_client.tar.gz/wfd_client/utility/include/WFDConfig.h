#ifndef _WFD_CONFIG_H_
#define _WFD_CONFIG_H_
#include "dictionary.h"
#include <string>
namespace rtsp
{

class WFDConfig
{
public:
    WFDConfig(std::string iniPath);
    ~WFDConfig();

    const char* getString(const char* key);
    int getInt(const char* key, int def);
    int getBoolean(const char* key, int def);
    bool isValid();
private:
    dictionary *ini;
};
}
#endif