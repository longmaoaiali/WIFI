#ifndef _MY_CFG_H_
#define _MY_CFG_H_

namespace rtsp
{

void saveLocalFile(bool flag);
void saveCmpbPlay(bool flag);
void setLog(bool flag);
void setTcpFlag(bool flag);
void setOnlyCount(bool flag);
void setCmpbPlayAudio(bool flag);
void setCmpbPlayVideo(bool flag);
}
#endif
