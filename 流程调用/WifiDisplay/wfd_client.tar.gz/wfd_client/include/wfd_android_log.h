#ifndef _WFD_ANDROID_LOG_H_
#define _WFD_ANDROID_LOG_H_

#ifdef __ANDROID__
#include <android/log.h>

static int my_fprintf(FILE *stream,const char *format,...)
{
    va_list ap;
    va_start(ap,format);
    __android_log_vprint(ANDROID_LOG_DEBUG,"WFD",format,ap);
    va_end(ap);
    return 0;
}

static int my_printf(const char *format,...)
{
    va_list ap;
    va_start(ap,format);
    __android_log_vprint(ANDROID_LOG_DEBUG,"WFD",format,ap);
    va_end(ap);
    return 0;
}

#ifdef fprintf
#undef fprintf
#endif

#ifdef printf
#undef printf
#endif

#define fprintf(fp,...) my_fprintf(fp,__VA_ARGS__)
#define printf(...) my_printf(__VA_ARGS__)

#endif

#endif

