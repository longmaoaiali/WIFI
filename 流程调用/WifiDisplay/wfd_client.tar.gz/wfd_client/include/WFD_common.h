#ifndef _WFD_COMMON_H_
#define _WFD_COMMON_H_

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#ifndef true
#define true 1
#endif
#ifndef false
#define false 0
#endif

typedef char                CHAR ;
typedef unsigned char       UINT8;
typedef short               INT16;
typedef unsigned short      UINT16;
typedef signed int          INT32;
typedef unsigned int        UINT32;
typedef void                VOID;

#define WFD_RESULT                                  UINT32
#define WFD_OK                                      ((UINT32) 0)
#define WFD_ERR_FAILED                              ((UINT32)-1)    ///< general failed
#define WFD_ERR_INV_ARG                             ((UINT32)-2)
#define WFD_ERR_STATUS_NOT_MATCH                    ((UINT32)-3)
#define WFD_ERR_TCP_ESTABLISH_FAILED                ((UINT32)-4)
#define WFD_ERR_NEGONIATE_TIMEOUT                   ((UINT32)-5)
#define WFD_ERR_PLAYBACK_FAILED                     ((UINT32)-6)
#define WFD_ERR_CANCEL_START_RTSP                   ((UINT32)-7)

typedef enum
{
    WFD_DEVICE_FOUND,
    WFD_DEVICE_LOST,
    WFD_DEVICE_GROUP_START,
    WFD_DEVICE_GROUP_REMOVED,
    WFD_DEVICE_IP_GET ,
    WFD_DEVICE_START_OK ,
    WFD_DEVICE_START_FAILED ,
    WFD_DEVICE_EVENT_ENTER_PIN ,
    WFD_DEVICE_EVENT_SHOW_PIN,
    WFD_DEVICE_EVENT_NEG_REQ,

    WFD_DEVICE_EVENT_ENTER_PIN_REQ,
    WFD_DEVICE_EVENT_SHOW_PIN_REQ,
    WFD_DEVICE_DIRECT_ON
} WFDClient_Event_e;

#ifdef __ANDROID__
/*****************************************
                WFD_EVENT
*****************************************/

#define RTSP_EVENT_START_OK                 "WFD-START-OK"
#define RTSP_EVENT_START_FAIL               "WFD-START-FAIL"
#define RTSP_EVENT_PLAY_SUCCESS             "WFD-RTSP-PLAY-SUCCESS"
#define RTSP_EVENT_PLAY_FAIL                "WFD-RTSP-PLAY-FAIL"
#define RTSP_EVENT_PAUSE_SUCCESS            "WFD-RTSP-PAUSE-SUCCESS"
#define RTSP_EVENT_PAUSE_FAIL               "WFD-RTSP-PAUSE-FAIL"
#define RTSP_EVENT_STOP_SUCCESS             "WFD-RTSP-TEARDOWN-SUCCESS"
#define RTSP_EVENT_STOP_FAIL                "WFD-RTSP-TEARDOWN-FAIL"
#define RTSP_EVENT_TERMINATE                "WFD-RTSP-TERMINATE"

#define RTSP_REASON_FATAL_ERROR             "RTSP_REASON_FATAL_ERROR"
#define RTSP_REASON_REQUESTED_BY_USER       "RTSP_REASON_REQUESTED_BY_USER"
#define RTSP_REASON_REQUESTED_BY_PEER       "RTSP_REASON_REQUESTED_BY_PEER"
#define RTSP_REASON_UNABLE_TO_CONNECT       "RTSP_REASON_UNABLE_TO_CONNECT"
#define RTSP_REASON_RTSP_TIMEOUT            "RTSP_REASON_RTSP_TIMEOUT"
#define RTSP_REASON_RTSP_DISCONNECTED       "RTSP_REASON_RTSP_DISCONNECTED"
#define RTSP_REASON_KEEP_ALIVE_LOST         "RTSP_REASON_KEEP_ALIVE_LOST"
#define RTSP_REASON_NEGOTIATION_FAILED      "RTSP_REASON_NEGOTIATION_FAILED"

#define RTP_ERR_CONNECTION                  "RTP_ERR_CONNECTION"
#define RTP_ERR_PORT_ALREADY_USED           "RTP_ERR_PORT_ALREADY_USED"
#define RTP_ERR_TIMEOUT                     "RTP_ERR_TIMEOUT"
#define RTP_ERR_FATAL                       "RTP_ERR_FATAL"

#define HDCP2X_ERR_VIDEO_STREAM_COUNTER_STR     "HDCP2X_ERR_VIDEO_STREAM_COUNTER"
#define HDCP2X_ERR_AUDIO_STREAM_COUNTER_STR     "HDCP2X_ERR_AUDIO_STREAM_COUNTER"
#define HDCP2X_TIMEOUT_HDCP_CREATE_SESSION_STR  "HDCP2X_TIMEOUT_HDCP_CREATE_SESSION"

#define MSG_WITH_ARG_STR    "ARGC_ARGV_"
#define IMTK_PB_CTRL_EVENT_VIDEO_WFD_ERROR_STR  "IMTK_PB_CTRL_EVENT_VIDEO_WFD_ERROR"

#define RTSP_STATUS_UPDATE_SET_VOLUME_DONE "VOLUME_CONTROL_DONE_"
#define RTSP_STATUS_UPDATE_SET_VOLUME_FAIL "VOLUME_CONTROL_FAIL_"


#endif
typedef void (*WFD_Client_callback)(WFDClient_Event_e e);

#endif /* _WFD_COMMON_H_ */
