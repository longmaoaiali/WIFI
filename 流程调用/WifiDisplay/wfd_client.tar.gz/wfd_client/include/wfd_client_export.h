#ifndef _WFD_CLIENT_EXPORT_H_
#define _WFD_CLIENT_EXPORT_H_
#include "WFD_common.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C"
{
#endif

    extern WFD_RESULT wfd_client_start(WFD_Client_callback pf_callback);
    extern WFD_RESULT wfd_client_stop();
    extern WFD_RESULT wfd_client_rtsp_start(const char* ip, int port, int fast_connection);
    extern WFD_RESULT wfd_client_rtsp_stop();
    extern WFD_RESULT wfd_client_rtsp_play();
    extern WFD_RESULT wfd_client_rtsp_pause();
    extern WFD_RESULT wfd_client_wait_for_event(char *buf, size_t buflen);
    extern int wfd_sigma_start(void);
    extern WFD_RESULT wfd_client_volume_control_M121(int increase);
    extern void wfd_client_dec_error_reset();
#ifdef __cplusplus
}
#endif

#endif /* _WFD_CLIENT_EXPORT_H_ */
