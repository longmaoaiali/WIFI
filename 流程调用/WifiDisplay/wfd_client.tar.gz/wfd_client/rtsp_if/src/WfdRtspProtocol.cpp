#define WFD_LOG_TAG "WfdRtspProtocol"

#include "WfdRtspProtocol.h"
#include <stdio.h>
#include <string>
#include <vector>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <assert.h>
#include "ScopedMutex.h"
#include "Mutex.h"
#include "Utils.h"
#include "ThreadObject.h"
#include "WfdRtspUibcPacket.h"
#include <errno.h>

//using namespace android;

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
#include <stdlib.h>
//#include "media/AudioSystem.h"
//#include "system/audio.h"
#endif

#define PREF_DSP_MODE_SUPPT             1
#define FAKE_UIBC_MOUSE_MOVE            1
#define UIBC_EVENT_SLEEP_INTERVAL_SEC   2
#ifndef MAX
#define MAX(x, y)   ((x) >= (y) ? (x) : (y))
#endif
#ifndef TCP_NODELAY
#define TCP_NODELAY     0x01
#endif

int UibcThreadEnabled = false;
int I2CThreadEnabled = false;
pthread_mutex_t i2cMutex;

extern struct wfd_rtsp_conf_s *wfd_rtsp_conf;



#define WFD_USE_FAKE_EDID
#ifdef WFD_USE_FAKE_EDID
static const unsigned char fake_edid[] = /* 256 bytes edid */
{
    0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00,  /* row-1 */
    0x36, 0x8B, 0x01, 0x00, 0x01, 0x01, 0x01, 0x01,
    0x01, 0x0F, 0x01, 0x03, 0x80, 0x3C, 0x22, 0x78,
    0x0A, 0x0D, 0xC9, 0xA0, 0x57, 0x47, 0x98, 0x27,
    0x12, 0x48, 0x4C, 0xBF, 0xEF, 0x00, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
    0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x1D,
    0x00, 0x72, 0x51, 0xD0, 0x1E, 0x20, 0x6E, 0x28,
    0x55, 0x00, 0xC4, 0x8E, 0x21, 0x00, 0x00, 0x1E,
    0x01, 0x1D, 0x80, 0x18, 0x71, 0x1C, 0x16, 0x20,  /* row-10 */
    0x58, 0x2C, 0x25, 0x00, 0xC4, 0x8E, 0x21, 0x00,
    0x00, 0x9E, 0x00, 0x00, 0x00, 0xFC, 0x00, 0x4D,
    0x54, 0x4B, 0x20, 0x4C, 0x43, 0x44, 0x54, 0x56,
    0x0A, 0x20, 0x20, 0x20, 0x00, 0x00, 0x00, 0xFD,
    0x00, 0x31, 0x4C, 0x0F, 0x50, 0x0E, 0x00, 0x0A,
    0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x01, 0x56,
    0x02, 0x03, 0x23, 0x74, 0x4B, 0x84, 0x10, 0x1F,
    0x05, 0x13, 0x14, 0x01, 0x02, 0x11, 0x06, 0x15,
    0x26, 0x09, 0x7F, 0x03, 0x11, 0x7F, 0x18, 0x83,
    0x01, 0x00, 0x00, 0x67, 0x03, 0x0C, 0x00, 0x10,  /* row-20 */
    0x00, 0xB8, 0x2D, 0x01, 0x1D, 0x00, 0xBC, 0x52,
    0xD0, 0x1E, 0x20, 0xB8, 0x28, 0x55, 0x40, 0xC4,
    0x8E, 0x21, 0x00, 0x00, 0x1E, 0x01, 0x1D, 0x80,
    0xD0, 0x72, 0x1C, 0x16, 0x20, 0x10, 0x2C, 0x25,
    0x80, 0xC4, 0x8E, 0x21, 0x00, 0x00, 0x9E, 0x8C,
    0x0A, 0xD0, 0x8A, 0x20, 0xE0, 0x2D, 0x10, 0x10,
    0x3E, 0x96, 0x00, 0x13, 0x8E, 0x21, 0x00, 0x00,
    0x18, 0x8C, 0x0A, 0xD0, 0x90, 0x20, 0x40, 0x31,
    0x20, 0x0C, 0x40, 0x55, 0x00, 0x13, 0x8E, 0x21,
    0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00,  /* row-30 */
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x52
};
#endif /* WFD_USE_FAKE_EDIDv */
//mtk94097

e_wfdVideoFormat CEAVideoFormat[] =
{
    {640, 480, 60},
    {720, 480, 60},
    {720, 480, 60},
    {720, 576, 50},
    {720, 576, 50},
    {1280, 720, 30},
    {1280, 720, 60},
    {1920, 1080, 30},
    {1920, 1080, 60},
    {1920, 1080, 60},
    {1280, 720, 25},
    {1280, 720, 50},
    {1920, 1080, 25},
    {1920, 1080, 50},
    {1920, 1080, 50},
    {1280, 720, 24},
    {1920, 1080, 24},
#ifdef MTK_WFD_4K_SUPPORT
    {3840, 2160, 24},
    {3840, 2160, 25},
    {3840, 2160, 30},
    {3840, 2160, 50},
    {3840, 2160, 60},//21
    {4096, 2160, 24},
    {4096, 2160, 25},
    {4096, 2160, 30},
    {4096, 2160, 50},
    {4096, 2160, 60},//26
#endif
};

e_wfdVideoFormat VESAVideoFormat[] =
{
    {800, 600, 30},
    {800, 600, 60},
    {1024, 768, 30},
    {1024, 768, 60},
    {1152, 864, 30},
    {1152, 864, 60},
    {1280, 768, 30},
    {1280, 768, 60},
    {1280, 800, 30},
    {1280, 800, 60},
    {1360, 768, 30},
    {1360, 768, 60},
    {1366, 768, 30},
    {1366, 768, 60},
    {1280, 1024, 30},
    {1280, 1024, 60},
    {1400, 1050, 30},
    {1400, 1050, 60},
    {1440, 900, 30},
    {1440, 900, 60},
    {1600, 900, 30},
    {1600, 900, 60},
    {1600, 1200, 30},
    {1600, 1200, 60},
    {1680, 1024, 30},
    {1680, 1024, 60},
    {1680, 1050, 30},
    {1680, 1050, 60},
    {1920, 1200, 30},
    {1920, 1200, 60},
#ifdef MTK_WFD_4K_SUPPORT
    {2560, 1440, 30},
    {2560, 1440, 60},
    {2560, 1600, 30},
    {2560, 1600, 60},//33
#endif
};

e_wfdVideoFormat HHVideoFormat[] =
{
    {800, 480, 30},
    {800, 480, 60},
    {854, 480, 30},
    {854, 480, 60},
    {864, 480, 30},
    {864, 480, 60},
    {640, 360, 30},
    {640, 360, 60},
    {960, 540, 30},
    {960, 540, 60},
    {848, 480, 30},
    {848, 480, 60},
};

extern e_wfdVideoFormat wfdVideoFormat;

using namespace std;
namespace rtsp
{
void* I2CListenerThread(void* data);
static ThreadObject I2CListener(I2CListenerThread);
static WfdRtspProtocol wfdprotocol;


void* UibcCommThread(void* data);
static ThreadObject UibcComm(UibcCommThread);
std::deque<WfdRtspUibcPacket* > UibcQueue;
Mutex  UibcMutex;

Mutex  singletonLock;
const char* WfdRtspProtocol::keys[WFD_SEGMENT_MAX] =
{
    /*[WFD_AUDIO_CODECS]              =*/ "wfd_audio_codecs",
    /*[WFD_VIDEO_FORMATS]             =*/ "wfd_video_formats",
#ifdef MTK_WFD_4K_SUPPORT
    /*[WFD2_VIDEO_FORMATS]             */ "wfd2_video_formats",
#endif
    /*[WFD_3D_FORMATS]                =*/ "wfd_3d_video_formats",
    /*[WFD_CONTENT_PROTECTION]        =*/ "wfd_content_protection",
    /*[WFD_DISPLAY_EDID]              =*/ "wfd_display_edid",
    /*[WFD_COUPLED_SINK]              =*/ "wfd_coupled_sink",
    /*[WFD_CLIENT_RTP_PORTS]          =*/ "wfd_client_rtp_ports",
    /*[WFD_PRESENTATION_URL]          =*/ "wfd_presentation_URL",
    /*[WFD_TRIGGER_METHOD]            =*/ "wfd_trigger_method",
    /*[WFD_UIBC_CAPABILITY]           =*/ "wfd_uibc_capability",
    /*[WFD_PREFERRED_DISPLAY_MODE]    =*/ "wfd_preferred_display_mode",
    /*[WFD_I2C]                       =*/ "wfd_I2C",
    /*[WFD_STANDBY_RESUME_CAPABILITY] =*/ "wfd_standby_resume_capability",
    /*[WFD_CONNECTOR_TYPE]            =*/ "wfd_connector_type",
    /*[RDS_SINK_VERSION]              =*/ "rds_sink_version" /* for intel */,
    /*[WFD_AV_FORMAT_CHANGE_TIMING]   =*/ "wfd_av_format_change_timing",
    /*[WFD_UIBC_SETTING]              =*/ "wfd_uibc_setting",
    /*[SONY_EXT_TCPSTREAM]         =*/   "sony_ext_01"  ,   /* for sony request :tcp stream*/
    /*[SONY_EXT_02_AVC]         =*/     "sony_ext_02"  ,   /* for sony request :4K AVC*/
    /*[SONY_EXT_03_HEVC]         =*/   "sony_ext_03"    ,/* for sony request :4K HEVC*/
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    /*[SONY_EXT_10_VOLUMN]       =*/   "sony_ext_10"    /* for sony request :volumn control*/
#endif
};

WfdRtspProtocol& WfdRtspProtocol::instance()
{
    ScopedMutex sm(singletonLock);
    return wfdprotocol;
}

WfdRtspProtocol::WfdRtspProtocol()
{
    mState = UNKNOWN;
    mMediaInfo = new MediaInfo;
    memset(mMediaInfo, 0, sizeof(*mMediaInfo));
    mMediaInfo->type = mediatype_av;
    mMediaInfo->avCodec = MEDIACODEC_WFDAV;
    mMediaInfo->audioCodec = MEDIACODEC_WFDA_LPCM;
    mMediaInfo->videoCodec = MEDIACODEC_WFDV_H264;
    mMediaInfo->fPs = 30;//IMTK_PB_CTRL_FRAME_RATE_30;
    mI2CPort = 30000;       // Default I2C communication port
    mI2CAckLen = 0;
    bzero(mI2CAckBuf, sizeof(mI2CAckBuf));
    loadEdid();
    mUibcPort = 40000;
    mIsUibcEnabled = false;
    mUibcEventCategory = 0;
    mUibcEventType = 0;
    mUibcGenOneEvent = 0;
    mClient = NULL;
}

WfdRtspProtocol::~WfdRtspProtocol()
{
    I2CThreadEnabled = false;
    UibcThreadEnabled = false;
/*added by qingjiang.xu*/
    delete mMediaInfo;
    mMediaInfo = NULL;
/*added by qingjiang.xu*/
}

int WfdRtspProtocol::parseToMeta(const string& str,const string & token, vector<string>& result)
{
    string segStr;
    string lastToken = "\0";
    size_t startPos = 0;
    size_t endPos = 0;

    while(startPos < str.size())
    {
        endPos = str.find_first_of(token, startPos);
        if(endPos == string::npos)    // special treatment for the last segment
        {
            endPos = str.find_first_of(lastToken, startPos);
            segStr = str.substr(startPos, endPos - startPos);
            if(segStr.size())       // prevent last segStr is null
            {
                result.push_back(segStr);
            }
            break;
        }
        segStr = str.substr(startPos, endPos - startPos);
        startPos = endPos + token.size();

        result.push_back(segStr);
    }

    return 0;
}


int WfdRtspProtocol::parse(const std::string& prtclStr)
{
#if 0
    string token = "\r\n";
    string segStr;
    int startPos = 0;
    int endPos = 0;

    while(startPos < prtclStr.size())
    {
        endPos = prtclStr.find_first_of(token, startPos);
        segStr = prtclStr.substr(startPos, endPos - startPos);
        startPos = endPos + token.size();

        WFD_LOG_INFO( "endPos = %d, startPos = %d, size = %d, segStr = %s \n",
                endPos, startPos, prtclStr.size(), segStr.c_str());
        for(int i = 0; i < WFD_SEGMENT_MAX; i++)
        {
            if(segStr.find(keys[i]) != string::npos)      // found key word
            {
                switch(i)
                {
                    case WFD_AUDIO_CODECS:
                        handleWfdAudioCodecs(segStr);
                        break;
                    case WFD_VIDEO_FORMATS:
                        handleWfdVideoFormats(segStr);
                        break;
                    case WFD_3D_FORMATS:
                        handle3DFormats(segStr);
                        break;
                    case WFD_CONTENT_PROTECTION:
                        handleContentProtection(segStr);
                        break;
                    case WFD_DISPLAY_EDID:
                        handleDisplayEdid(segStr);
                        break;
                    case WFD_COUPLED_SINK:
                        handleCoupledSink(segStr);
                        break;
                    case WFD_CLIENT_RTP_PORTS:
                        handleClientRtpPorts(segStr);
                        break;
                    case WFD_PRESENTATION_URL:
                        handlePresentationUrl(segStr);
                        break;
                    case WFD_TRIGGER_METHOD:
                        handleTriggerMethod(segStr);
                        break;
                }
                break;
            }
        }
    }
#endif

    vector<string> wfdSegs;
    parseToMeta(prtclStr, "\r\n", wfdSegs);

    for(vector<string>::iterator it = wfdSegs.begin(); it != wfdSegs.end(); it++)
    {
        for(int i = 0; i < WFD_SEGMENT_MAX; i++)
        {
            if((*it).find(keys[i]) != string::npos)      // found key word
            {
                switch(i)
                {
                    case WFD_AUDIO_CODECS:
                        handleWfdAudioCodecs(*it);
                        break;
                    case WFD_VIDEO_FORMATS:
                        handleWfdVideoFormats(*it);
                        break;
             #ifdef MTK_WFD_4K_SUPPORT
                    case WFD2_VIDEO_FORMATS:
                        handleWfd2VideoFormats(*it);
                        break;
             #endif
                    case WFD_3D_FORMATS:
                        handle3DFormats(*it);
                        break;
                    case WFD_CONTENT_PROTECTION:
                        handleContentProtection(*it);
                        break;
                    case WFD_DISPLAY_EDID:
                        handleDisplayEdid(*it);
                        break;
                    case WFD_COUPLED_SINK:
                        handleCoupledSink(*it);
                        break;
                    case WFD_CLIENT_RTP_PORTS:
                        handleClientRtpPorts(*it);
                        break;
                    case WFD_PRESENTATION_URL:
                        handlePresentationUrl(*it);
                        break;
                    case WFD_TRIGGER_METHOD:
                        handleTriggerMethod(*it);
                        break;
                    case WFD_UIBC_CAPABILITY:
                        handleUibcCapability(*it);
                        break;
                    case WFD_PREFERRED_DISPLAY_MODE:
                        handlePreferredDisplayMode(*it);
                        break;
                    case WFD_I2C:
                        handleI2C(*it);
                        break;
                    case WFD_STANDBY_RESUME_CAPABILITY:
                        handleStandbyResumeCapability(*it);
                        break;
                    case WFD_CONNECTOR_TYPE:
                        handleConnectorType(*it);
                        break;
                    case RDS_SINK_VERSION:
                        handleRdsSinkVersion(*it);
                        break;
                    case WFD_AV_FORMAT_CHANGE_TIMING:
                        handleAVFormatChangeTiming(*it);
                        break;
                    case WFD_UIBC_SETTING:
                        handleUibcSetting(*it);
                        break;
                    case SONY_EXT_TCPSTREAM:
                        handleSONYTcpStream(*it);
                        break;
                    case SONY_EXT_02_AVC:
                        handleSONY4KAVC(*it);
                        break;
                    case SONY_EXT_03_HEVC:
                        handleSONY4KHEVC(*it);
                        break;
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
                    case SONY_EXT_10_VOLUMN:
                        handleSONYVolumnControl(*it);
                        break;
#endif

                    default:
                        WFD_LOG_ERR( "Unsupported WFD RTSP method: %s\n", (*it).c_str());
                        break;
                }
                break;
            }
        }
    }

    return 0;
}

int WfdRtspProtocol::parse(WfdRtspClient* client, const  string & prtclStr)
{
    mClient = client;
    parse(prtclStr);
    return 0;
}

int WfdRtspProtocol::parseI2C(const unsigned char* buffer, int length)
{
    WFD_LOG_ENTER();
    const unsigned char VALID_DEVICE_ID = 0x50;
    int pos = 0;
    unsigned char reqID = buffer[pos++];
    if(reqID == 0x00)    // Read request
    {
        WFD_LOG_INFO( "I2C_Read_Request received\n");
        unsigned char writeTranNum = buffer[pos++];
        for(int i = 0;i < writeTranNum; i++)
        {
            unsigned char writeDevID = buffer[pos++];
            unsigned char writeLen = buffer[pos++];
            for(int j = 0;j < writeLen; j++)
            {
                unsigned char writeData = buffer[pos++];
                UNUSED(writeData);
                if(writeDevID != VALID_DEVICE_ID)
                {
                    WFD_LOG_ERR("Note Invalid device ID!");
                    goto Read_Reply_Nak;
                }
                // Todo: write data to the device (data address ?)
                // ... ...
            }
            unsigned char noStopBit = buffer[pos++];
            unsigned char tranDelay = buffer[pos++];
            UNUSED(noStopBit);
            UNUSED(tranDelay);
        }
        unsigned char readDevID = buffer[pos++];
        if(readDevID != VALID_DEVICE_ID)
        {
            WFD_LOG_ERR("Note Invalid device ID!");
            goto Read_Reply_Nak;
        }
        unsigned char readLen = buffer[pos++];
        bzero(mI2CAckBuf, sizeof(mI2CAckBuf));
        mI2CAckLen = 0;

        mI2CAckBuf[0] = 0x00;       // Read ack
        mI2CAckBuf[1] = readLen;
        memcpy(mI2CAckBuf + 2, mFakeEDID, readLen);
        mI2CAckLen = readLen + 2;
    }
    else if(reqID == 0x01)  // Write request
    {
        WFD_LOG_INFO( "I2C_Write_Request received\n");
        unsigned char writeDevID = buffer[pos++];
        unsigned char writeLen = buffer[pos++];
        for(int i = 0;i < writeLen;i++)
        {
            unsigned char writeData = buffer[pos++];
            UNUSED(writeData);
            UNUSED(writeDevID);
            if(writeDevID != VALID_DEVICE_ID)
            {
                WFD_LOG_ERR("Note Invalid device ID!");
                goto Write_Reply_Nak;
            }
            // Todo: write data to the device (data address ?)
            // ... ...
        }
        bzero(mI2CAckBuf, sizeof(mI2CAckBuf));
        mI2CAckLen = 0;

        mI2CAckBuf[0] = 0x01;       // Write ack
        mI2CAckLen = 1;
    }

OUT:
    return 0;

Read_Reply_Nak:
    mI2CAckBuf[0] = 0x80;           // Remote_I2C_Read_Reply_Nak
    mI2CAckLen = 1;
    goto OUT;

Write_Reply_Nak:
    mI2CAckBuf[0] = 0x81;           // Remote_I2C_Write_Reply_Nak
    mI2CAckLen = 1;
    goto OUT;

}

int WfdRtspProtocol::getResult(string & result)
{
    WFD_LOG_ENTER();
    //ScopedMutex sm(mLocker);

    //string msgEnd = "\r\n";
    mResult = mAudioResult + mVideoResult + mCntPrtResult + mDisplayResult
                + mCoupledSinkResult + m3DResult + mUibcResult + mPrfDisplayModeResult
    #ifdef MTK_WFD_4K_SUPPORT
                + mVideo2Result
    #endif
                + mI2CResult + mStandbyResumeResult + mConnectorTypeResult + mRdsSinkVersion
                + mClientRtpPortsResult + mSONYExt01Result+ mSONYExt02Result+ mSONYExt03Result
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    + mSONYExt10Result
#endif
        ; //+ msgEnd;
    result = mResult;

    mAudioResult.clear();
    mVideoResult.clear();
    #ifdef MTK_WFD_4K_SUPPORT
    mVideo2Result.clear();
    #endif
    mCntPrtResult.clear();
    mDisplayResult.clear();
    mCoupledSinkResult.clear();
    m3DResult.clear();
    mUibcResult.clear();
    mPrfDisplayModeResult.clear();
    mI2CResult.clear();
    mStandbyResumeResult.clear();
    mConnectorTypeResult.clear();
    mRdsSinkVersion.clear();
    mClientRtpPortsResult.clear();
    mSONYExt01Result.clear();
    mSONYExt02Result.clear();
    mSONYExt03Result.clear();
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    mSONYExt10Result.clear();
#endif

    return 0;
}

int WfdRtspProtocol::getI2CResult(unsigned char* buffer, int bufSize)
{
    WFD_LOG_ENTER();
    if(bufSize < mI2CAckLen)
    {
        WFD_LOG_ERR("Error Buffer size is not enough! %d %d", bufSize, mI2CAckLen);
        return -1;
    }
    memcpy(buffer, mI2CAckBuf, mI2CAckLen);
    return mI2CAckLen;
}

int WfdRtspProtocol::getMediaInfo(MediaInfo & mediaInfo)
{
    WFD_LOG_ENTER();
    //ScopedMutex sm(mLocker);
    if(!mMediaInfo)
    {
        WFD_LOG_ERR("Error WfdRtspProtocol::getMediaInfo is not ready \n");
        return -1;
    }
    mediaInfo = *mMediaInfo;

    return 0;
}

int WfdRtspProtocol::getI2CPort(unsigned int& port)
{
    port = mI2CPort;
    return 0;
}

bool WfdRtspProtocol::isUibcEnabled() const
{
    return mIsUibcEnabled;
}

int WfdRtspProtocol::getUibcPort(unsigned int& port)
{
    port = mUibcPort;
    return 0;
}

int WfdRtspProtocol::getSourceIp(string & ip)
{
    if(!mClient)
    {
        WFD_LOG_ERR("Error client isn't be set\n");
        return -1;
    }
    mClient->getSourceIp(ip);
    return 0;
}

int WfdRtspProtocol::inputUibcPacket(WfdRtspUibcPacket* packet)
{
    //ScopedMutex sm(mLocker);
    UibcMutex.lock();
    if(mIsUibcEnabled)
    {
        UibcQueue.push_back(packet);
    }
    UibcMutex.unlock();
    return 0;
}

/* ===================== Private Function ===================== */

int WfdRtspProtocol::handleWfdAudioCodecs(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
        vector<string> audSegs;
        parseToMeta(str, " ", audSegs);
#if 1
        for(vector<string>::iterator iter = audSegs.begin(); iter != audSegs.end(); iter++)
        {
            WFD_LOG_INFO("WfdRtspProtocol::handleWfdAudioCodecs seg = %s \n", (*iter).c_str());
        }
#endif
        // audio format/mode/latency parse
        const int audFmtIdx = 1;
        const int audModeIdx = 2;
        const int audLatencyIdx = 3;
        UNUSED(audModeIdx);
        UNUSED(audLatencyIdx);
        if(audSegs.at(audFmtIdx) == "LPCM")
        {
            mMediaInfo->audioCodec = MEDIACODEC_WFDA_LPCM;
            //mMediaInfo->audioCodec = MEDIACODEC_WFDA_AC3;
            //mMediaInfo->audioCodec = MEDIACODEC_WFDA_AAC;
        }
        else if(audSegs.at(audFmtIdx) == "AAC")
        {
            mMediaInfo->audioCodec = MEDIACODEC_WFDA_AAC;
        }
        else if(audSegs.at(audFmtIdx) == "AC3" || audSegs.at(audFmtIdx) == "AC")
        {
            mMediaInfo->audioCodec = MEDIACODEC_WFDA_AC3;
        }
        else if(audSegs.at(audFmtIdx) == "DTS")
        {
            mMediaInfo->audioCodec = MEDIACODEC_WFDA_DTS;
        }
        else
        {
            WFD_LOG_DEBUG("Unknown codec, setting to default\n");
            mMediaInfo->audioCodec = MEDIACODEC_WFDA_AC3;
        }

    }
    else                                    // get parameter
    {
        //string reply = "wfd_audio_codecs: LPCM 00000003 00, AC 00000001 00\r\n"; // hardcode for test
        //string reply = "wfd_audio_codecs: LPCM 00000003 00\r\n"; // hardcode for testbed
        //string reply = "wfd_audio_codecs: AAC 00000007 00\r\n";
        string reply = "wfd_audio_codecs: LPCM 00000003 00, AAC 00000007 00\r\n";
        mAudioResult = reply;
    }

    return 0;
}

int WfdRtspProtocol::handleWfdVideoFormats(const string & str)
{
    WFD_LOG_ENTER();
    /* WFD should by default use H.264 */
    mMediaInfo->videoCodec = MEDIACODEC_WFDV_H264;

    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
        vector<string> vedioSegs;
        parseToMeta(str, " ", vedioSegs);
#if 1
        for(vector<string>::iterator iter = vedioSegs.begin(); iter != vedioSegs.end(); iter++)
        {
            WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats seg = %s \n", (*iter).c_str());
        }
#endif
        mMediaInfo->videoCodec = MEDIACODEC_WFDV_H264;
/*#ifdef _WFD_FOR_MSB_*/
#if 1

        WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats vedioSegs.at(5).c_str = %s \n", vedioSegs.at(5).c_str());
        int index = -1;
        //CEA
        if (strncmp(vedioSegs.at(5).c_str(), "00000000", 8) != 0)
        {
            WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats vedioSegs.at(5).c_str = %s \n", vedioSegs.at(5).c_str());
            index = getIndex(vedioSegs.at(5).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = CEAVideoFormat[index];
                if (wfdVideoFormat.frame_rate != 24
                        && wfdVideoFormat.frame_rate != 25
                        && wfdVideoFormat.frame_rate != 30
                        && wfdVideoFormat.frame_rate != 50
                        && wfdVideoFormat.frame_rate != 60)
                {
                    WFD_LOG_ERR("Error : unknown frame rate %d \n", wfdVideoFormat.frame_rate);
                    assert(0);
                }
                mMediaInfo->fPs = wfdVideoFormat.frame_rate;
                WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats CEA length = %d, widht = %d, framrate = %d fPs= %d\n", wfdVideoFormat.length,
                    wfdVideoFormat.width, wfdVideoFormat.frame_rate, mMediaInfo->fPs);
            }
        }

        //VESA
        if (strncmp(vedioSegs.at(6).c_str(), "00000000", 8) != 0)
        {
            index = getIndex(vedioSegs.at(6).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = VESAVideoFormat[index];
                if (wfdVideoFormat.frame_rate != 30
                        && wfdVideoFormat.frame_rate != 60)
                {
                    WFD_LOG_ERR("Error : unknown frame rate %d \n", wfdVideoFormat.frame_rate);
                    assert(0);
                }
                mMediaInfo->fPs = wfdVideoFormat.frame_rate;
                WFD_LOG_ERR( "WfdRtspProtocol::handleWfdVideoFormats VESA length = %d, widht = %d, framrate = %d, fPs= %d\n", wfdVideoFormat.length,
                    wfdVideoFormat.width, wfdVideoFormat.frame_rate, mMediaInfo->fPs);
            }
        }

        //HH
        if (strncmp(vedioSegs.at(7).c_str(), "00000000", 8) != 0)
        {
            index = getIndex(vedioSegs.at(7).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = HHVideoFormat[index];
                if (wfdVideoFormat.frame_rate != 30
                        && wfdVideoFormat.frame_rate != 60)
                {
                    WFD_LOG_ERR("Error : unknown frame rate %d \n", wfdVideoFormat.frame_rate);
                    assert(0);
                }
                mMediaInfo->fPs = wfdVideoFormat.frame_rate;
               WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats HH length = %d, widht = %d, framrate = %d, fPs= %d\n", wfdVideoFormat.length,
                    wfdVideoFormat.width, wfdVideoFormat.frame_rate, mMediaInfo->fPs);
            }
        }

/* mark here, for not exist notifyToVideoFormat() interface
        if (index >= 0)
        {
            WFDClient::getInstance().notifyToVideoFormat();
        }
*/
#endif
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string sp                   = " ";
        string comma                = ",";
        string native               = "00";     // Index to CEA resolution/refresh rates
        string prfr_dsp_mod_supt;
#ifdef PREF_DSP_MODE_SUPPT
        if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
            prfr_dsp_mod_supt = "00";
        else
            prfr_dsp_mod_supt = "01";
#else
        prfr_dsp_mod_supt    = "00";     // Not supported
#endif

        string fst_profile              = "01";         // CBP(Constrained Baseline Profile)
        string fst_level                = "08";         // H.264 Level 4.1
        string fst_cea_support;
        string fst_vesa_support;
        string fst_hh_support;
        if (wfd_rtsp_conf && wfd_rtsp_conf->video_format_set)
        {
            /* Use the settings from SIGMA UCC cmd */
            int idx = 0, shift = 0;
            unsigned int cea_bitmask = 0x0;
            unsigned int vesa_bitmask = 0x0;
            unsigned int hh_bitmask = 0x0;
            unsigned char val = 0;
            char strbuf[12];
            WFD_LOG_DEBUG("Setting video_format to specified value\n");
            for (idx=0; idx < wfd_rtsp_conf->video_format_list_size; idx ++)
            {
                val = wfd_rtsp_conf->video_format_list[idx];
                if (val > eHH)
                {
                    shift = (val - (eHH+1));
                    hh_bitmask |= (0x1 << shift);
                }
                else if (val > eVesa)
                {
                    shift = (val - (eVesa+1));
                    vesa_bitmask |= (0x1 << shift);
                }
                else
                {
                    shift = (val - (eCEA+1));
                    cea_bitmask |= (0x1 << shift);
                }
            }
            WFD_LOG_DEBUG("%s: hh=0x%08x,vesa=0x%08x,cea=0x%08x\n", __FUNCTION__, hh_bitmask, vesa_bitmask, cea_bitmask);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", cea_bitmask);
            fst_cea_support = string(strbuf);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", vesa_bitmask);
            fst_vesa_support = string(strbuf);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", hh_bitmask);
            fst_hh_support = string(strbuf);
        }
        else if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            /* If UCC asks us to disableAll, we should set only CEA-0 on */
            /* Use default settings */
            fst_cea_support          = "00000001";
            fst_vesa_support         = "00000000";
            fst_hh_support           = "00000000";
        }
        else
        {
            /* Use default settings */
            fst_cea_support          = "0001FFFF";   /* support all */
            fst_vesa_support         = "0F3FFFFF"; /* support all except for 1600x1200p30/p60 & 1920x1200p30/p60 */
            fst_hh_support           = "00000FFF"; /* support all */

            char strbuf[12];
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", getCEAVideoFormat(0,1199,0));
            fst_cea_support = string(strbuf);

            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", getVESAVideoFormat(0,1199,0));
            fst_vesa_support = string(strbuf);

            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", getHHVideoFormat(0,1199,0));
            fst_hh_support = string(strbuf);
        }

        string fst_latency              = "00";
        string fst_min_slice_size       = "0000";
        string fst_slice_enc_params     = "0000";
        /* as per to the WFD testplan, the frame skipping interval should be set to 500 ms */
        string fst_frm_rate_ctl_supt    = "13";
#ifdef PREF_DSP_MODE_SUPPT
        string fst_max_hres;
        string fst_max_vres;
        if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            /* When SIGMA UCC asks to disableAll, we need to disable preferred-display-mode */
            fst_max_hres                = "none";
            fst_max_vres                = "none";
        }
        else
        {
            #if 0
            fst_max_hres                = "0280";       // Max-Width: 640
            fst_max_vres                = "01E0";       // Max-Hight: 480
            #endif
#if 0
            fst_max_hres                = "none";       // Max-Width: 1280
            fst_max_vres                = "none";       // Max-Hight: 720
#else /* !__ANDROID__ */
            fst_max_hres                = "0500";       // Max-Width: 1280
            fst_max_vres                = "02D0";       // Max-Hight: 720
#endif
        }
#else
        string fst_max_hres             = "none";
        string fst_max_vres             = "none";
#endif

        string reply;

        if (wfd_rtsp_conf && wfd_rtsp_conf->enable_aud_only)
        {
            reply = "wfd_video_formats: none\r\n";
        }
        else
        {
            string fst_format_list =                    \
                        fst_profile + sp +              \
                        fst_level + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        fst_max_hres + sp +             \
                        fst_max_vres;
            /* hard-coded
            string reply = "wfd_video_formats: 00 00 01 01 00000001 00000000 00000000 00"
                             "0000 0000 00 none none\r\n"; // hardcode for test
            */
            reply = "wfd_video_formats:" + sp +  \
                           native + sp +                \
                           prfr_dsp_mod_supt + sp +     \
                           fst_format_list +            \
                           "\r\n";
        }

        mVideoResult = reply;
    }

    return 0;
}

#ifdef MTK_WFD_4K_SUPPORT
int WfdRtspProtocol::handleWfd2VideoFormats(const string & str)
{
    WFD_LOG_INFO( "%s :%d\n", __FUNCTION__,__LINE__);
    /* WFD should by default use H.264 */
    mMediaInfo->videoCodec = MEDIACODEC_WFDV_H265;

    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
        vector<string> vedioSegs;
        parseToMeta(str, " ", vedioSegs);
#if 1
        for(vector<string>::iterator iter = vedioSegs.begin(); iter != vedioSegs.end(); iter++)
        {
            WFD_LOG_INFO("WfdRtspProtocol::handleWfd2VideoFormats seg = %s \n", (*iter).c_str());
        }
#endif
        mMediaInfo->videoCodec = MEDIACODEC_WFDV_H265;
/*#ifdef _WFD_FOR_MSB_*/
#if 1

        WFD_LOG_INFO("WfdRtspProtocol::handleWfd2VideoFormats vedioSegs.at(5).c_str = %s \n", vedioSegs.at(5).c_str());
        int index = -1;
        //CEA
        if (strncmp(vedioSegs.at(5).c_str(), "000000000000", 12) != 0)
        {
            WFD_LOG_INFO("WfdRtspProtocol::handleWfd2VideoFormats vedioSegs.at(5).c_str = %s \n", vedioSegs.at(5).c_str());
            index = getIndex_4k(vedioSegs.at(5).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = CEAVideoFormat[index];
                if (wfdVideoFormat.frame_rate != 24
                        && wfdVideoFormat.frame_rate != 25
                        && wfdVideoFormat.frame_rate != 30
                        && wfdVideoFormat.frame_rate != 50
                        && wfdVideoFormat.frame_rate != 60)
                {
                    WFD_LOG_ERR("Error : unknown frame rate %d \n", wfdVideoFormat.frame_rate);
                    assert(0);
                }

                mMediaInfo->fPs = wfdVideoFormat.frame_rate;
                WFD_LOG_INFO("WfdRtspProtocol::handleWfdVideoFormats CEA length = %d, widht = %d, framrate = %d fPs= %d\n", wfdVideoFormat.length,
                    wfdVideoFormat.width, wfdVideoFormat.frame_rate, mMediaInfo->fPs);
            }
        }

        //VESA
        if (strncmp(vedioSegs.at(6).c_str(), "000000000000", 12) != 0)
        {
            index = getIndex_4k(vedioSegs.at(6).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = VESAVideoFormat[index];
            }
        }

        //HH
        if (strncmp(vedioSegs.at(7).c_str(), "000000000000", 12) != 0)
        {
            index = getIndex_4k(vedioSegs.at(7).c_str());
            if (index >= 0)
            {
                wfdVideoFormat = HHVideoFormat[index];
                if (wfdVideoFormat.frame_rate != 30
                        && wfdVideoFormat.frame_rate != 60)
                {
                    WFD_LOG_ERR("Error : unknown frame rate %d \n", wfdVideoFormat.frame_rate);
                    assert(0);
                }
                mMediaInfo->fPs = wfdVideoFormat.frame_rate;
                WFD_LOG_INFO("WfdRtspProtocol::handleWfd2VideoFormats HH length = %d, widht = %d, framrate = %d, fPs= %d\n", wfdVideoFormat.length,
                    wfdVideoFormat.width, wfdVideoFormat.frame_rate, mMediaInfo->fPs);
            }
        }
/*mark here, for not exist notifyToVideoFormat() interface
        if (index >= 0)
        {
            WFDClient::getInstance().notifyToVideoFormat();
        }
*/
#endif
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string sp                   = " ";
        string comma                = ",";
        string native               = "00";     // Index to CEA resolution/refresh rates
        string codec                = "02";     //h.265
#if 0 //none in wfd2-vedio_formats
        string prfr_dsp_mod_supt;
#ifdef PREF_DSP_MODE_SUPPT
        if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
            prfr_dsp_mod_supt = "00";
        else
            prfr_dsp_mod_supt = "01";
#else
        prfr_dsp_mod_supt    = "00";     // Not supported
#endif
#endif

        string fst_profile              = "02";         // CHP(Constrained High Profile)
        string fst_level                = "10";         // H.265 Level 4.2
        //string fst_cea_support          = "00000061";   // 640x480p60, 1280x720p60, 1280x720p30
        //string fst_vesa_support         = "0001040";
        //string fst_hh_support           = "00000000";
        string fst_cea_support;
        string fst_vesa_support;
        string fst_hh_support;
        if (wfd_rtsp_conf && wfd_rtsp_conf->video_format_set)
        {
            /* Use the settings from SIGMA UCC cmd */
            int idx = 0, shift = 0;
            unsigned int cea_bitmask = 0x0;
            unsigned int vesa_bitmask = 0x0;
            unsigned int hh_bitmask = 0x0;
            unsigned char val = 0;
            char strbuf[12];
            WFD_LOG_ERR( "Setting video_format to specified value\n");
            for (idx=0; idx < wfd_rtsp_conf->video_format_list_size; idx ++)
            {
                val = wfd_rtsp_conf->video_format_list[idx];
                if (val > eHH)
                {
                    shift = (val - (eHH+1));
                    hh_bitmask |= (0x1 << shift);
                }
                else if (val > eVesa)
                {
                    shift = (val - (eVesa+1));
                    vesa_bitmask |= (0x1 << shift);
                }
                else
                {
                    shift = (val - (eCEA+1));
                    cea_bitmask |= (0x1 << shift);
                }
            }
            WFD_LOG_ERR( "%s: hh=0x%08x,vesa=0x%08x,cea=0x%08x\n", __FUNCTION__, hh_bitmask, vesa_bitmask, cea_bitmask);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", cea_bitmask);
            fst_cea_support = string(strbuf);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", vesa_bitmask);
            fst_vesa_support = string(strbuf);
            memset(strbuf, 0, sizeof(strbuf));
            snprintf(strbuf, sizeof(strbuf), "%08x", hh_bitmask);
            fst_hh_support = string(strbuf);
        }
        else if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            /* If UCC asks us to disableAll, we should set only CEA-0 on */
            /* Use default settings */
            fst_cea_support          = "000000000001";
            fst_vesa_support         = "000000000000";
            fst_hh_support           = "000000000000";
        }
        else
        {
            /* Use default settings */
            #ifdef __ANDROID__
                fst_cea_support          = "000007FFFFFF";   /* support all 30fps*/
                fst_vesa_support         = "0003FFFFFFFF"; /* support all 30fps except for 1600x1200p30/p60 & 1920x1200p30/p60 */
                fst_hh_support           = "000000000FFF"; /* support all 30fps*/
            #elif defined _WFD_FOR_MSB_/* !__ANDROID__ */
                native              = "40";     // Index to CEA resolution/refresh rates
                fst_cea_support          = "00019CEB";
                fst_vesa_support         = "00000000";
                fst_hh_support           = "00000000";
            #else /* !_WFD_FOR_MSB_ */
                if (wfd_video_format_conf == NULL)
                {
                    fst_cea_support          = "000007FFFFFF";   /* support all */
                    fst_vesa_support         = "0003FFFFFFFF"; /* support all */
                    fst_hh_support           = "000000000FFF"; /* support all */
                }
                else
                {
                    fst_cea_support = wfd_video_format_conf->cea;
                    fst_vesa_support = wfd_video_format_conf->vesa;
                    fst_hh_support = wfd_video_format_conf->hh;
                }
            #endif
        }
        //mtk94097
        string fst_latency              = "00";
        string fst_min_slice_size       = "0000";
        string fst_slice_enc_params     = "0000";
        /* as per to the WFD testplan, the frame skipping interval should be set to 500 ms */
        string fst_frm_rate_ctl_supt    = "13";
#ifdef PREF_DSP_MODE_SUPPT
        string fst_max_hres;
        string fst_max_vres;
        if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            /* When SIGMA UCC asks to disableAll, we need to disable preferred-display-mode */
            fst_max_hres                = "none";
            fst_max_vres                = "none";
        }
        else
        {
            #if 0
            fst_max_hres                = "0280";       // Max-Width: 640
            fst_max_vres                = "01E0";       // Max-Hight: 480
            #endif
                #ifdef __WFD_BDP__
                    fst_max_hres             = "0780";       // Max-Width: 1920
                    fst_max_vres             = "0640";       // Max-Hight: 1600
                #else
                    #ifdef __ANDROID__
                            fst_max_hres                = "none";       // Max-Width: 1280
                            fst_max_vres                = "none";       // Max-Hight: 720
                    #else /* !__ANDROID__ */
                            fst_max_hres                = "0500";       // Max-Width: 1280
                            fst_max_vres                = "02D0";       // Max-Hight: 720
                    #endif
                #endif
        }
#else
        string fst_max_hres             = "none";
        string fst_max_vres             = "none";
#endif

        string reply;

        if (wfd_rtsp_conf && wfd_rtsp_conf->enable_aud_only)
        {
            reply = "wfd_video_formats: none\r\n";
        }
        else
        {
#ifdef _WFD_FOR_MSB_
            string fst_format_list =                    \
                        "01" + sp +              \
                        "04" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        fst_max_hres + sp +             \
                        fst_max_vres +                  \
                        "," + sp +                      \
                        "02" + sp +              \
                          "04" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        fst_max_hres + sp +             \
                        fst_max_vres;

#else
            string fst_format_list =                    \
                        "01" + sp +                     \
                        "0001" + sp +                     \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "01" + sp +              \
                        "0002" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "01" + sp +              \
                        "0004" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "01" + sp +              \
                        "0008" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "01" + sp +              \
                        "0010" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "02" + sp +              \
                        "0001" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "02" + sp +              \
                        "0002" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "02" + sp +              \
                        "0004" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "02" + sp +              \
                        "0008" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "02" + sp +              \
                        "0010" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "08" + sp +              \
                        "0001" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "08" + sp +              \
                        "0002" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "08" + sp +              \
                        "0004" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "08" + sp +              \
                        "0008" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00"                            \
                        "," + sp +                      \
                        "02" + sp +              \
                        "08" + sp +              \
                        "0010" + sp +                \
                        fst_cea_support + sp +          \
                        fst_vesa_support + sp +         \
                        fst_hh_support + sp +           \
                        fst_latency + sp +              \
                        fst_min_slice_size + sp +       \
                        fst_slice_enc_params + sp +     \
                        fst_frm_rate_ctl_supt + sp +    \
                        "00";
            /* hard-coded
            string reply = "wfd_video_formats: 00 00 01 01 00000001 00000000 00000000 00"
                             "0000 0000 00 none none\r\n"; // hardcode for test
            */
            /* hard-coded
            string reply = "wfd_video_formats: 00 00 01 01 00000001 00000000 00000000 00"
                             "0000 0000 00 none none\r\n"; // hardcode for test
            */
#endif
            reply = "wfd2_video_formats:" + sp +  \
                           native + sp +                \
                           codec + sp +     \
                           fst_format_list +            \
                           "\r\n";
        }

        mVideo2Result = reply;
    }

    return 0;
}
#endif

int WfdRtspProtocol::handle3DFormats(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        /* the "wfd_3d_video_formats" below is a template from WFA, needs to be revised then. */
        //string reply = "wfd_3d_video_formats: 00 00 00 00 0000000000000000 00 0000 0000 00 none none\r\n"; // hardcode for test
        string reply = "wfd_3d_video_formats: none\r\n"; // hardcode for test
        m3DResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleContentProtection(const string & str)
{
    string reply;
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
#ifdef ENABLE_HDCP2X_RX
        #define WFD_SUPPORT_HDCP20  "HDCP2.0"
        #define WFD_SUPPORT_HDCP21  "HDCP2.1"
        #define WFD_SUPPORT_HDCP22  "HDCP2.2"
        #define WFD_HDCP2X_PORT 4990

        string sp = " ";
        string crlf = "\r\n";
        string port = "port=" + num2str(WFD_HDCP2X_PORT);
        string hdcp2_spec = WFD_SUPPORT_HDCP21 + sp + port;

        /* Modified in WFD TBRE-1.
           As being a DUT, the UCC will not ask you to enable HDCP,
           so you'll have to enbale it by default */
        if (wfd_rtsp_conf &&
            (wfd_rtsp_conf->sigma_disable_all || wfd_rtsp_conf->disable_hdcp2x))
        {
            reply = "wfd_content_protection: none\r\n";
        }
        else
        {
            reply = "wfd_content_protection:" + sp + hdcp2_spec + crlf;
            mClient->startHDCP();
        }
#else /* !ENABLE_HDCP2X_RX */

        reply = "wfd_content_protection: none\r\n";

#endif /* ENABLE_HDCP2X_RX */
        mCntPrtResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleDisplayEdid(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {

        mState = WFD_GET_PARAMETER;
        string sp               = " ";
        string end              = "\r\n";
        string reply;
#ifdef WFD_USE_FAKE_EDID
        if (wfd_rtsp_conf && wfd_rtsp_conf->enable_edid)
        {
            string edid_block_count = "0002";   // 1 of 128-byte EDID block
            string edid_playload    = array2str(mFakeEDID, sizeof(mFakeEDID));
            reply = "wfd_display_edid:" + sp + \
                       edid_block_count + sp + \
                       edid_playload + end;
        }
        else if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            reply = "wfd_display_edid:" + sp + "none" + end;
        }
        else
        {
            string edid_block_count = "0002";   // 1 of 128-byte EDID block
            string edid_playload    = array2str(mFakeEDID, sizeof(mFakeEDID));
            reply = "wfd_display_edid:" + sp + \
                       edid_block_count + sp + \
                       edid_playload + end;
        }
        //string edid_playload    = array2str(fake_edid, sizeof(fake_edid));
#else
        reply = "wfd_display_edid:" + sp + "none" + end;
#endif

        reply = "wfd_display_edid: none\r\n"; // hardcode for test
        mDisplayResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleCoupledSink(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply = "wfd_coupled_sink: none\r\n"; // hardcode for test
        mCoupledSinkResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleClientRtpPorts(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        string reply;

        mState = WFD_GET_PARAMETER;
        if (wfd_rtsp_conf && wfd_rtsp_conf->enable_aud_only)
            reply = "wfd_client_rtp_ports: RTP/AVP/UDP;unicast 0 19900 mode=play\r\n";
        else
            reply = "wfd_client_rtp_ports: RTP/AVP/UDP;unicast 19900 0 mode=play\r\n";

        mClientRtpPortsResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::setAudioOnly(int audOnly)
{
    /* Obsolete function */
    /*
    audOnlyFlag = audOnly;
    */
    return 0;
}

int WfdRtspProtocol::handlePresentationUrl(const string & str)
{
    WFD_LOG_ENTER();
    return 0;
}

int WfdRtspProtocol::handleTriggerMethod(const string & str)
{
    WFD_LOG_ENTER();
    return 0;
}

int WfdRtspProtocol::handleUibcCapability(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
        int startPos = str.find("port=") + strlen("port=");
        int endPos = str.find("\r\n");
        string uibcPort = str.substr(startPos, endPos - startPos);
        mUibcPort = (unsigned int)atoi(uibcPort.c_str());
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply;
#if (1)
        /* According to SIMGA UCC's request */
        if (wfd_rtsp_conf && wfd_rtsp_conf->uibc_cap_type == WFD_UIBC_CAP_GENERIC)
        {
            string reply = "wfd_uibc_capability: input_category_list=GENERIC;"
                           "generic_cap_list=Mouse, Keyboard;"
                           "hidc_cap_list=none;port=none\r\n";
            mUibcResult = reply;
        }
        else if (wfd_rtsp_conf && wfd_rtsp_conf->uibc_cap_type == WFD_UIBC_CAP_HIDC)
        {
            string reply = "wfd_uibc_capability: input_category_list=HIDC;"
                           "generic_cap_list=none;hidc_cap_list=Mouse/USB, Keyboard/USB;port=none\r\n";
            mUibcResult = reply;
        }
        else if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
        {
            /* DisableAll */
            string reply = "wfd_uibc_capability: input_category_list=none;generic_cap_list=none;"
                       "hidc_cap_list=none;port=none\r\n";
            mUibcResult = reply;
        }
        else
        {
            /* default to carry all caps */
            string reply = "wfd_uibc_capability: input_category_list=GENERIC, HIDC;"
                           "generic_cap_list=Mouse, Keyboard;"
                           "hidc_cap_list=Mouse/USB, Keyboard/USB;port=none\r\n";
            mUibcResult = reply;
        }
#elif (0)
        /* Support both GENERIC-SingleTouch/MultiTouch & HIDC-Keyboard/USB */
        string reply = "wfd_uibc_capability: input_category_list=GENERIC, HIDC;"
                       "generic_cap_list=Mouse, SingleTouch, MultiTouch;"
                       "hidc_cap_list=Keyboard/USB;port=none\r\n";
#elif (0)
        /* Support GENERIC only */
        string reply = "wfd_uibc_capability: input_category_list=GENERIC;"
                       "generic_cap_list=Mouse, SingleTouch, MultiTouch;"
                       "hidc_cap_list=none;port=none\r\n";
#elif (0)
        /* Support HIDC only */
        string reply = "wfd_uibc_capability: input_category_list=HIDC;"
                       "generic_cap_list=none;hidc_cap_list=Keyboard/USB;port=none\r\n";
#else
        /* Not supported */
        string reply = "wfd_uibc_capability: input_category_list=none;generic_cap_list=none;"
                       "hidc_cap_list=none;port=none\r\n";
#endif

    }
    return 0;
}

int WfdRtspProtocol::handleUibcSetting(const  string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
        if(str.find("enable") != string::npos)  // enable
        {
            mIsUibcEnabled = true;
            if(UibcThreadEnabled == false)
            {
                UibcThreadEnabled = true;
                UibcComm.start((void*)this);
            }
        }
        else                                    // dissable
        {
            UibcThreadEnabled = false;
            mIsUibcEnabled = false;
        }
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
    }
    return 0;
}

int WfdRtspProtocol::handleSONYTcpStream(const  string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
       // mState = WFD_SET_PARAMETER;
       WFD_LOG_DEBUG("WfdRtspProtocol::handleSONYTcpStream SET \n");
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply = "sony_ext_01: 19000 0 0 0\r\n"; // hardcode for test
        mSONYExt01Result = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleSONY4KAVC(const  string & str)
{
    WFD_LOG_ERR( "WfdRtspProtocol::handleSONY4KAVC \n");
    if(str.find(":") != string::npos)       // set parameter
    {
       // mState = WFD_SET_PARAMETER;
       WFD_LOG_ERR( "WfdRtspProtocol::handleSONY4KAVC SET \n");
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply = "sony_ext_02: none\r\n"; // hardcode for test
        mSONYExt02Result = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleSONY4KHEVC(const  string & str)
{
    WFD_LOG_ERR( "WfdRtspProtocol::handleSONY4KHEVC \n");
    if(str.find(":") != string::npos)       // set parameter
    {
       // mState = WFD_SET_PARAMETER;
       WFD_LOG_ERR( "WfdRtspProtocol::handleSONY4KHEVC SET \n");
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;

        string reply = "sony_ext_03: 00 00 01 08 0007ffff 03ffffff 00000fff 00 0000 0000 13 none none\r\n"; // hardcode for test

        mSONYExt03Result = reply;
    }
    return 0;
}

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
int WfdRtspProtocol::handleSONYVolumnControl(const  string & str)
{
    WFD_LOG_ERR( "WfdRtspProtocol::handleSONYVolumnControl \n");
    if(str.find(":") != string::npos)       // set parameter
    {
       WFD_LOG_ERR( "WfdRtspProtocol::handleSONYVolumnControl SET \n");
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;

        //get max volumn : max index is 0x64
        string max_str=" 64";                       // 1*2HEXDIG

        //get current volumn
        int current_index= -1;
        string value_str;                           // 1*2HEXDIG
        char tmp_char_index[4]={0};

        //android::AudioSystem::getStreamVolumeIndex(AUDIO_STREAM_MUSIC,&current_index,AUDIO_DEVICE_OUT_DEFAULT);

        sprintf(tmp_char_index," %x",current_index);
        value_str = (string)tmp_char_index;

        string mute_str=" 0";                       //0:off    1:on

        string setting_str="0";                 //reserved

        string reply = "sony_ext_10: "+ max_str + value_str + mute_str + setting_str;
        mSONYExt10Result = reply;
    }

    return 0;
}
#endif

int WfdRtspProtocol::uibcGenerateEvent(int category, int eventType)
{

    mUibcEventCategory = category;
    mUibcEventType = eventType;
    mUibcGenOneEvent = 1;

    return 0;
}


void* UibcCommThread(void* data)
{
    int sendLen = 0;
#define UIBC_BUFFER_SIZE    1024
    unsigned char buffer[UIBC_BUFFER_SIZE] = {0};
    int round_count = 0;
    int idx = 0, tmpcode = 0, total_counts = 0;
    int currEventType = 0;
    int keycode_array_hid[] = {0x10, 0x08, 0x07, 0x0C, 0x04, 0x17, 0x08, 0x0E, /* Mediatek */
                               0x2D, 0x16, 0x0C, 0x11, 0x0E, /* -sink */
                               0x2D, 0x0B, 0x0C, 0x07, 0x28}; /* -hid <Enter> */

    int keycode_array_generic[] = {0x4D, 0x65, 0x64, 0x69, 0x61, 0x74, 0x65, 0x6B, /* Mediatek */
                                   0x2D, 0x53, 0x69, 0x6E, 0x6B, /* -Sink */
                                   0x2D, 0x47, 0x65, 0x6E, 0x65, 0x72, 0x69, 0x63, /* -Generic */
                                   0x2D, 0x48, 0x65, 0x6C, 0x6C, 0x6F, 0x20, 0x0A, 0x0D}; /* -Hello <return> */

#define DEFAULT_ROUNDS_KEYBOARD         2
#define DEFAULT_ROUNDS_MOUSE            30
#define DELAY_BETWEEN_EACH_EVENT_MS     500 /* ms */

    WFD_LOG_ENTER();
    UNUSED(data);

    int uibcSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(uibcSocket < 0)
    {
        WFD_LOG_ERR("Error socket create failed !");
        return NULL;
    }

    string serverIp;
    WfdRtspProtocol::instance().getSourceIp(serverIp);
    unsigned int port = 0;
    WfdRtspProtocol::instance().getUibcPort(port);

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(serverIp.c_str());
    serverAddr.sin_port = htons(port);

    WFD_LOG_DEBUG("server address = %s, port = %u", serverIp.c_str(), port);
    WFD_LOG_DEBUG("sin_addr.s_addr = 0x%x, sin_port = 0x%x", serverAddr.sin_addr.s_addr, serverAddr.sin_port);
    if(connect(uibcSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) < 0)
    {
        if(errno == EINPROGRESS)
        {
            WFD_LOG_ERR("Error connect timeout!");
        }
        else
        {
            WFD_LOG_ERR("Error UIBC connect failed");
        }
        return NULL;
    }

    while(UibcThreadEnabled)
    {
        /* Modified for WFD PF#4, we do send UIBC event only when requested */
        if (WfdRtspProtocol::instance().mUibcGenOneEvent == 0)
        {
            sleep(UIBC_EVENT_SLEEP_INTERVAL_SEC);
            continue;
        }

        WfdRtspProtocol::instance().mUibcGenOneEvent = 0;
        /*
        if(WfdRtspProtocol::instance().isUibcEnabled() == false)
        {
            usleep(500 * 1000);     // sleep 500ms
            continue;
        }
        */

#ifdef FAKE_UIBC_MOUSE_MOVE
        /* ============================ GENERIC ===============================*/
        if (WfdRtspProtocol::instance().mUibcEventCategory == UIBC_CATEGORY_GENERIC)
        {
            if (WfdRtspProtocol::instance().mUibcEventType == GENERIC_EVT_TYPE_KEYBOARD)
            {
                /* --------------------------------------------------------------------
                                        Generic Keyboard
                   -------------------------------------------------------------------*/
                WFD_LOG_ERR( "Trying to generate UIBC Generic Keyboard event\n");
                int data[2] = {0x00, 0x10}; /* [0] -> keydown or keyup, [1] -> keycode */
                WfdRtspUibcPacket* newPacket = new WfdRtspUibcPacket();
                currEventType = WfdRtspProtocol::instance().mUibcEventType;
                newPacket->setCategory(WfdRtspUibcPacket::UIBC_GENERIC);
                newPacket->setGenType(WfdRtspUibcPacket::GEN_TYPE_KEYBOARD);
                WFD_LOG_ERR( "Trying to generate UIBC Generic Keyboard event\n");

                UibcQueue.push_back(newPacket);
                UibcMutex.lock();
                if(UibcQueue.empty())
                {
                    usleep(2000 * 1000);     // sleep n-msec
                    UibcMutex.unlock();
                    continue;
                }
                WfdRtspUibcPacket* uibcPacket = UibcQueue.front();
                UibcQueue.pop_front();

                /* Send several Keyboard events in a row */
                for (round_count = 0; round_count < DEFAULT_ROUNDS_KEYBOARD; round_count ++)
                {
                    /**** Note here we sent fake keycode: "mtk-dtv" out ****/
                    for (idx = 0; idx < (int)(sizeof(keycode_array_generic)/sizeof(int)); idx++)
                    {
                        tmpcode = keycode_array_generic[idx];
                        data[0] = 0; /* keydown */
                        data[1] = tmpcode;
                        /* send keycode */
                        WFD_LOG_INFO( "Sending Generic keyboard KEY=[%c]\n", (char)(keycode_array_generic[idx]));
                        sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, (void *)data);
                        //WFD_LOG_DEBUG( "Dumping UIBC Generic Keyboard body...\n");
                        //WfdRtspProtocol::instance().dumpHex(buffer, sendLen);
                        if(send(uibcSocket, buffer, sendLen, 0) < 0)
                        {
                            WFD_LOG_ERR( "Error! send UIBC Keyboard data error !");
                            break;
                        }
                        data[0] = 1; /* keyup */
                        data[1] = tmpcode;
                        sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, (void *)data);
                        WFD_LOG_DEBUG( "Dumping UIBC Generic Keyboard body...\n");
                        WfdRtspProtocol::instance().dumpHex(buffer, sendLen);
                        if(send(uibcSocket, buffer, sendLen, 0) < 0)
                        {
                            WFD_LOG_ERR( "Error! send UIBC Keyboard data error !");
                            break;
                        }
                        if (!UibcThreadEnabled || WfdRtspProtocol::instance().mUibcEventType != currEventType)
                            break;
                    }
                }
                delete uibcPacket;
                UibcMutex.unlock();

            }
            else
            {
                /* --------------------------------------------------------------------
                                        Generic Mouse
                   -------------------------------------------------------------------*/
                WFD_LOG_INFO( "Trying to generate UIBC Generic Mouse/SingleTouch/Multitouch event\n");
                int incr1 = 10, incr2 = 10, delta = 10;
                currEventType = WfdRtspProtocol::instance().mUibcEventType;
                WfdRtspUibcPacket* newPacket = new WfdRtspUibcPacket();
                newPacket->setCategory(WfdRtspUibcPacket::UIBC_GENERIC);
                newPacket->setGenericId(WfdRtspUibcPacket::MOUSE_MOVE);
                UibcQueue.push_back(newPacket);
                UibcMutex.lock();
                if(UibcQueue.empty())
                {
                    usleep(2000 * 1000);     // sleep n-msec
                    UibcMutex.unlock();
                    continue;
                }
                WfdRtspUibcPacket* uibcPacket = UibcQueue.front();
                UibcQueue.pop_front();

                /* Send several Mouse events in a row */
                for (round_count = 0; round_count < DEFAULT_ROUNDS_MOUSE; round_count ++)
                {
                    if (WfdRtspProtocol::instance().mUibcEventType == GENERIC_EVT_TYPE_MULTI_TOUCH)
                        newPacket->setCoordinates(incr1, incr1, incr2, incr2);
                    else
                        newPacket->setCoordinate(incr1, incr1);

                    if(incr1 > 65535 || incr1 < 0)
                    {
                        incr1 = 0;
                    }
                    if(incr2 > 65535 || incr2 < 0)
                    {
                        incr2 = 0;
                    }
#endif
                    sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, NULL);
                    if (WfdRtspProtocol::instance().mUibcEventType == GENERIC_EVT_TYPE_MULTI_TOUCH)
                    {   /* multi-touch */
               WFD_LOG_DEBUG("sending UIBC MultiTouch Data:coordinate=(%d/%d:%d/%d)\n",
                                incr1, incr1, incr2, incr2);
                        incr1 += delta;
                        incr2 += delta;
                    }
                    else
                    {
                        /* single touch */
                WFD_LOG_DEBUG("sending UIBC SingleTouch Data:coordinate=(%d/%d)\n",
                                incr1, incr1);
                        incr1 += delta;
                    }

                    if(send(uibcSocket, buffer, sendLen, 0) < 0)
                    {
                        WFD_LOG_ERR("Error send UIBC Generic data error !");
                        UibcMutex.unlock();
                        break;
                    }
                    if (!UibcThreadEnabled || (WfdRtspProtocol::instance().mUibcEventType != currEventType))
                        break;
                    usleep(DELAY_BETWEEN_EACH_EVENT_MS * 1000);
                }
                UibcMutex.unlock();
                delete uibcPacket;
            }
        }

        /* ============================ HIDC ===============================*/
        else if (WfdRtspProtocol::instance().mUibcEventCategory == UIBC_CATEGORY_HIDC)
        {
            WfdRtspUibcPacket* newPacket = new WfdRtspUibcPacket();
            currEventType = WfdRtspProtocol::instance().mUibcEventType;
            newPacket->setCategory(WfdRtspUibcPacket::UIBC_HIDC);
            if (WfdRtspProtocol::instance().mUibcEventType == HIDC_EVT_TYPE_MOUSE)
                newPacket->setHidType(WfdRtspUibcPacket::HID_TYPE_MOUSE);
            else
                newPacket->setHidType(WfdRtspUibcPacket::HID_TYPE_KEYBOARD);

            UibcQueue.push_back(newPacket);
            UibcMutex.lock();
            if(UibcQueue.empty())
            {
                usleep(2000 * 1000);     // sleep n-msec
                UibcMutex.unlock();
                continue;
            }
            WfdRtspUibcPacket* uibcPacket = UibcQueue.front();
            UibcQueue.pop_front();

            if (WfdRtspProtocol::instance().mUibcEventType == HIDC_EVT_TYPE_MOUSE)
            {
                /* --------------------------------------------------------------------
                                        HID Mouse/USB
                   -------------------------------------------------------------------*/
                WFD_LOG_DEBUG("Sending UIBC HIDC (Mouse/USB) events\n");
                int disps[2] = {5, 5}; /* x-displacement, y-displacement */
                for (round_count = 0; round_count < DEFAULT_ROUNDS_MOUSE; round_count ++)
                {
                    sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, (void *)disps);
                    WFD_LOG_INFO( "Sending HID Mouse Coordinate (%d/%d)\n", disps[0], disps[1]);
                    //WFD_LOG_DEBUG( "Dumping UIBC Mouse body...\n");
                    //WfdRtspProtocol::instance().dumpHex(buffer, sendLen);
                    if(send(uibcSocket, buffer, sendLen, 0) < 0)
                    {
                        WFD_LOG_ERR("Error! send UIBC Mouse data1 error !");
                        break;
                    }
                    total_counts ++;
                    disps[0] += 5;
                    disps[1] += 5;
                    usleep(DELAY_BETWEEN_EACH_EVENT_MS * 1000);
                    if (!UibcThreadEnabled || (WfdRtspProtocol::instance().mUibcEventType != currEventType))
                        break;
                }
                WFD_LOG_DEBUG( "Sent UIBC HIDC (Mouse/USB) finished (total events = %d)\n", total_counts);
                UibcMutex.unlock();
            }
            else
            {
                /* --------------------------------------------------------------------
                                        HID Keyboard/USB
                   -------------------------------------------------------------------*/
                WFD_LOG_DEBUG( "Sending UIBC HIDC (Keyboard/USB) events\n");

                /* Note: As per WFD test spec, the Sink will need to send out 100 keyboard events at least */
                for (round_count = 0; round_count < DEFAULT_ROUNDS_KEYBOARD; round_count ++)
                {
                    /**** Note here we sent fake keycode: "mtk-dtv" out ****/
                    for (idx = 0; idx < (int)(sizeof(keycode_array_hid)/sizeof(int)); idx++)
                    {
                        /* send keycode */
                        WFD_LOG_INFO( "Sending HIDC keyboard Keycode=[0x%x]\n", (keycode_array_hid[idx]));
                        tmpcode = keycode_array_hid[idx];
                        sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, (void *)&tmpcode);
                        WFD_LOG_DEBUG( "Dumping UIBC keyboard body...\n");
                        WfdRtspProtocol::instance().dumpHex(buffer, sendLen);
                        if(send(uibcSocket, buffer, sendLen, 0) < 0)
                        {
                            WFD_LOG_ERR("Error! send UIBC HIDC data1 error (err=%s)!", strerror(errno));
                            break;
                        }
                        total_counts ++;
                        /* send key release */
                        tmpcode = 0;
                        sendLen = uibcPacket->getTranData(buffer, UIBC_BUFFER_SIZE, (void *)&tmpcode);
                        WFD_LOG_DEBUG( "Dumping UIBC keyboard body...\n");
                        WfdRtspProtocol::instance().dumpHex(buffer, sendLen);
                        if(send(uibcSocket, buffer, sendLen, 0) < 0)
                        {
                            WFD_LOG_ERR("Error! send UIBC HIDC data2 error (err=%s)!", strerror(errno));
                            break;
                        }
                        total_counts ++;
                        //usleep(DELAY_BETWEEN_EACH_EVENT_MS * 1000);
                        if (!UibcThreadEnabled || (WfdRtspProtocol::instance().mUibcEventType != currEventType))
                            break;
                    }
                }
                WFD_LOG_DEBUG( "Sent UIBC HIDC (Keyboard/USB) finished (total events = %d)\n", total_counts);
                UibcMutex.unlock();
            }
            delete uibcPacket;
        }

        else
        {
            WFD_LOG_ERR( "Error unknown event category=%d\n\n", WfdRtspProtocol::instance().mUibcEventCategory);
            continue;
        }


    }

    close(uibcSocket);
    WFD_LOG_DEBUG("UIBCListenerThread exit...");
    return NULL;
}

int WfdRtspProtocol::handlePreferredDisplayMode(const string & str)
{
    WFD_LOG_ENTER();
    string sp = " ";
    string end = "\r\n";

    string p_clock      = "000ACC";     // 1280x720p30
    string H            = "0500";       // 1280
    string HB           = "0000";       // no blank period
    string HSPOL_HSOFF  = "0000";       // negative, no offset
    string HSW          = "0500";       // 1280 sync width
    string V            = "02D0";       // 720
    string VB           = "0000";       // no blank period
    string VSPOL_VSOFF  = "0000";       // negative, no offset
    string VSW          = "02D0";       // 720 sync width
    string VBS3D        = "00";         // no vertical blanking interval lines
    string R            = "001E";       // 30HZ
    string D_modes      = "FF";         // All supported
    string P_depth      = "01";         // 24 bit per pixel

    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
#ifdef PREF_DSP_MODE_SUPPT
        string reply = "wfd_preferred_display_mode:" + sp + \
                        p_clock + sp +      \
                        H + sp +            \
                        HB + sp +           \
                        HSPOL_HSOFF + sp +  \
                        HSW + sp +          \
                        V + sp +            \
                        VB + sp +           \
                        VSPOL_VSOFF + sp +  \
                        VSW + sp +          \
                        VBS3D + sp +        \
                        R + sp +            \
                        D_modes + sp +      \
                        P_depth + end;
#else
        string reply = "wfd_preferred_display_mode: none\r\n"; // hardcode for test
#endif
        mPrfDisplayModeResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleI2C(const string & str)
{
    WFD_LOG_ENTER();
    int ret = 0;
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply;
        /* We need to make sure the socket is ready before we responding M3 Response.
           So we add a mutex here to wait until i2c thread is ready, then we step further.
         */
#define WFD_I2C_THREAD_MAX_WAIT_SEC     1
        WFD_MUTEX_INIT(i2cMutex);
        WFD_MUTEX_INIT_LOCKED(i2cMutex);

        if (mI2CPort > 0 && wfd_rtsp_conf && wfd_rtsp_conf->enable_i2c)
        {
            reply = "wfd_I2C: " + num2str(mI2CPort) + "\r\n";
            I2CThreadEnabled = true;
            I2CListener.start((void*)this);
            WFD_MUTEX_TIMEDLOCK(i2cMutex, (WFD_I2C_THREAD_MAX_WAIT_SEC*1000000), ret);
        }
        else if(mI2CPort <= 0 || (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all))
        {
            reply = "wfd_I2C: none\r\n";
        }
        else
        {
            reply = "wfd_I2C: " + num2str(mI2CPort) + "\r\n";
            I2CThreadEnabled = true;
            I2CListener.start((void*)this);
            WFD_MUTEX_TIMEDLOCK(i2cMutex, (WFD_I2C_THREAD_MAX_WAIT_SEC*1000000), ret);
        }
        mI2CResult = reply;
    }
    return 0;
}


/* This function sets the time value of 'secs' and 'usecs' to the timeval structure
   pointed by 'tv', and return it as return value */
struct timeval *WfdSetTimeval(int secs, int usecs, struct timeval *tv)
{
    struct timeval *mytv;

    tv->tv_sec = secs ;             /* timeout (secs.) */
    tv->tv_usec = usecs;            /* 0 microseconds */

    if(tv->tv_sec == 0 && tv->tv_usec == 0)
        mytv = NULL;
    else
        mytv = tv;

    return mytv;
}


void* I2CListenerThread(void* data)
{
    WFD_LOG_ENTER();
    UNUSED(data);

    unsigned int listenPort = 0;
    WfdRtspProtocol::instance().getI2CPort(listenPort);
    int listenSocket;             // For listen
    int commSocket = -1;          // Uninitialized
    fd_set fdset;
    int maxfdn = -1;
    int nfds = -1;
    int on = 1;
    struct timeval toutvalp, *tovalp; /* Timeout for select() */

    if((listenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    {
        WFD_LOG_ERR("Error listenSocket create failed !");
        WFD_MUTEX_UNLOCK(i2cMutex);
        return NULL;
    }
    /* To avoid TCP TIME_WAIT issue that restricts from binding to a previously closed
       socket for 2~4 minutes, we need to set this socket option */
    if(setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0)
    {
        WFD_LOG_ERR( "%s:setsockopt failed\n", __FUNCTION__);
        WFD_MUTEX_UNLOCK(i2cMutex);
        return NULL;
    }

    sockaddr_in serverAddr, clientAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serverAddr.sin_port = htons(listenPort);
    if(::bind(listenSocket, (sockaddr*)&serverAddr, sizeof(serverAddr)) < 0)
    {
        WFD_LOG_ERR("Error bind error !");
        WFD_MUTEX_UNLOCK(i2cMutex);
        return NULL;
    }
    else
        WFD_LOG_ERR( "%s: bind to port:%d OK\n", __FUNCTION__, listenPort);

    if(listen(listenSocket, 10) < 0)
    {
        WFD_LOG_ERR( "Error listen error !");
        WFD_MUTEX_UNLOCK(i2cMutex);
        return NULL;
    }

    WFD_MUTEX_UNLOCK(i2cMutex);
    socklen_t clientAddrLen = sizeof(clientAddr);
    const int BUFFER_SIZE = 1024;
    unsigned char buffer[BUFFER_SIZE] = {0};
    while(I2CThreadEnabled)
    {
        FD_ZERO(&fdset);
        /* sets fd_set to be used in 'select' call */
        FD_SET(listenSocket, &fdset);
        maxfdn = MAX(maxfdn-1, listenSocket) + 1;
        if (commSocket > 0)
        {
            FD_SET(commSocket, &fdset);
            maxfdn = MAX(maxfdn-1, commSocket) + 1;
        }
        tovalp = WfdSetTimeval(2,
                               0,
                               &toutvalp);

        /* select on fdset */
        if ((nfds = select(maxfdn, &fdset, NULL, NULL, tovalp)) < 0)
        {
            WFD_LOG_ERR( "%s: select error!\n", __FUNCTION__);
            sleep(5); continue;
        }
        if (nfds == 0)
        {
            /* no data */
            continue;
        }
        if(FD_ISSET(listenSocket, &fdset))
        {
            int flag = 1;
            commSocket = accept(listenSocket, (sockaddr*)&clientAddr, &clientAddrLen);
            if(commSocket < 0)      // For non-block socket
            {
                WFD_LOG_ERR("accept failed\n");
                continue;
            }
            WFD_LOG_INFO("%s: Client IP: %s connected", __FUNCTION__, inet_ntoa(clientAddr.sin_addr));

            if(setsockopt(commSocket, IPPROTO_TCP, TCP_NODELAY, (char *)&flag, sizeof(int)) < 0)
            {
                WFD_LOG_ERR("Set TCP_NODELAY Failed\n");
            }
            else
            {
                WFD_LOG_INFO("%s:Set TCP_NODELAY Successful\n", __FUNCTION__);
            }
        }

        if (commSocket>0 && FD_ISSET(commSocket, &fdset))
        {
            bzero(buffer, sizeof(buffer));
            int recvLen = recv(commSocket, buffer, sizeof(buffer), 0);
            if(recvLen < 0)
            {
                WFD_LOG_ERR( "Error receive error !");
                continue;
            }
            else if(recvLen == 0)
            {
            WFD_LOG_INFO("TCP comm finish this time");
                commSocket = -1;
                continue;
            }
            WFD_LOG_INFO( "Recevied I2C data (len=%d)", recvLen);
            WfdRtspProtocol::instance().dumpHex(buffer, recvLen);
            if(WfdRtspProtocol::instance().parseI2C(buffer, recvLen) < 0)
            {
                WFD_LOG_ERR( "Error parse I2C data failed !");
            }
            unsigned char ackBuf[1024] = {0};
            int ackLen = 0;
            if((ackLen = WfdRtspProtocol::instance().getI2CResult(ackBuf, sizeof(ackBuf))) <= 0)
            {
                // Dont't need to acknowledge
                WFD_LOG_ERR( "Dont't need to acknowledge");
                continue;
            }
            WFD_LOG_ERR( "Response I2C data:");
            WfdRtspProtocol::instance().dumpHex(ackBuf, ackLen);

            int sendLen = 0;
            sendLen = send(commSocket, ackBuf, ackLen, 0);
            if(sendLen < 0)
            {
                WFD_LOG_ERR( "Error send I2C data error !");
                break;
            }
            else if(sendLen < ackLen)
            {
                WFD_LOG_ERR( "Error sent less than actual size");
            }
            else
            {
                WFD_LOG_ERR( "Response I2C finished !");
            }
        }
    }

    if (listenSocket > 0)
        close(listenSocket);
    if (commSocket > 0)
        close(commSocket);
    WFD_LOG_ERR( "I2CListenerThread Exit...");
    return NULL;
}


int WfdRtspProtocol::handleStandbyResumeCapability(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply;
        if (wfd_rtsp_conf && wfd_rtsp_conf->enable_standby)
            reply = "wfd_standby_resume_capability: supported\r\n";
        else if (wfd_rtsp_conf && wfd_rtsp_conf->sigma_disable_all)
            reply = "wfd_standby_resume_capability: none\r\n";
        else
            reply = "wfd_standby_resume_capability: supported\r\n";

        mStandbyResumeResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleConnectorType(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        string reply;
        mState = WFD_GET_PARAMETER;
        //if (wfd_rtsp_conf->enable_hdcp2x)
        if (1)
            /* for Intel's request, need to respond with HDMI type when enabling HDCP2.0 */
            reply = "wfd_connector_type: " + string(WFD_CONNECTOR_TYPE_WIFI_DISPLAY) + "\r\n";
        else
            reply = "wfd_connector_type: none\r\n";

        mConnectorTypeResult = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleRdsSinkVersion(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
        string reply = "rds_sink_version: none\r\n";
        mRdsSinkVersion = reply;
    }
    return 0;
}

int WfdRtspProtocol::handleAVFormatChangeTiming(const string & str)
{
    WFD_LOG_ENTER();
    if(str.find(":") != string::npos)       // set parameter
    {
        mState = WFD_SET_PARAMETER;
    }
    else                                    // get parameter
    {
        mState = WFD_GET_PARAMETER;
    }
    return 0;
}

string WfdRtspProtocol::num2str(const unsigned int & num)
{
    char tmp[10] = {0};
#if 0
    sprintf(tmp, "%d", num);
#else /*modified by qingjiang.xu*/
    snprintf(tmp, sizeof(tmp), "%d", num);
#endif

    return string(tmp);
}

void WfdRtspProtocol::dumpHex(const unsigned char * hexBuffer,int length)
{
    for(int i = 0;i < length; i++)
    {
        if(i && (i%16==0))
        {
            WFD_LOG_INFO("\n");
        }
        WFD_LOG_INFO("0x%02x ", hexBuffer[i]);
    }
    WFD_LOG_INFO("\n");
}

string WfdRtspProtocol::array2str(unsigned char* array, int size)
{
    const int tmpSize = 10240;
    if((size << 1) > tmpSize)
    {
        WFD_LOG_ERR("Error Array size is too large \n");
        return "";
    }
    char tmp[tmpSize] = {0};

    for(int i = 0; i < size; i++)
    {
#if 0
        sprintf(tmp + (i << 1), "%02x", array[i]);
#else /*modified by qingjiang.xu*/
       snprintf(tmp + (i << 1),sizeof(tmp), "%02x", array[i]);
#endif
    }

    return string(tmp);
}

int WfdRtspProtocol::getIndex(const char* str)
{
    if (strlen(str) != 8)
    {
        WFD_LOG_ERR("Video format error!\n");
        return -1;
    }

    int ret = 0;
    for(int bit = 7; bit > 0; --bit)
    {
        if (str[bit] == '0')
            ret += 4;
        else
        {
            if (str[bit] == '1')
                ret += 1;
            else if (str[bit] == '2')
                ret += 2;
            else if (str[bit] == '4')
                ret += 3;
            else if (str[bit] == '8')
                ret += 4;

            break;
        }
    }

    return (ret - 1);
}

UINT32 WfdRtspProtocol::getCEAVideoFormat(UINT32 maxH, UINT32 maxW, UINT32 maxFps)
{
    int length = sizeof(CEAVideoFormat) / sizeof (CEAVideoFormat[0]);
    unsigned int bitmark = 0x0;
    for(int i=0; i < length; i++)
    {
        if ((maxH == 0 || CEAVideoFormat[i].length <= maxH)
            && (maxW == 0 || CEAVideoFormat[i].width <= maxW)
            && (maxFps == 0 || CEAVideoFormat[i].frame_rate <= maxFps))
        {
            bitmark |= (0x1<<i);
        }
    }
    return bitmark;
}

UINT32 WfdRtspProtocol::getVESAVideoFormat(UINT32 maxH, UINT32 maxW, UINT32 maxFps)
{
    int length = sizeof(VESAVideoFormat) / sizeof (VESAVideoFormat[0]);

    unsigned int bitmark = 0x0;
    for(int i=0; i < length; i++)
    {
        if ((maxH == 0 || VESAVideoFormat[i].length <= maxH)
            && (maxW == 0 || VESAVideoFormat[i].width <= maxW)
            && (maxFps == 0 || VESAVideoFormat[i].frame_rate <= maxFps))
        {
            bitmark |= (0x1<<i);
        }
    }
    return bitmark;
}

UINT32 WfdRtspProtocol::getHHVideoFormat( UINT32 maxH, UINT32 maxW, UINT32 maxFps)
{
    int length = sizeof(HHVideoFormat) / sizeof (HHVideoFormat[0]);

    unsigned int bitmark = 0x0;
    for(int i=0; i < length; i++)
    {
        if ((maxH == 0 || HHVideoFormat[i].length <= maxH)
            && (maxW == 0 || HHVideoFormat[i].width <= maxW)
            && (maxFps == 0 || HHVideoFormat[i].frame_rate <= maxFps))
        {
            bitmark |= (0x1<<i);
        }
    }
    return bitmark;
}

int WfdRtspProtocol::loadEdid()
{
    bzero(mFakeEDID, sizeof(mFakeEDID));


#ifdef WFD_USE_FAKE_EDID
    memcpy(mFakeEDID, fake_edid, sizeof(mFakeEDID));
#endif

#if 0
    int pos = 0;
    // header
    mFakeEDID[pos++] = 0x00;        // position 0
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0xFF;
    mFakeEDID[pos++] = 0x00;

    // menufacture ID
    mFakeEDID[pos++] = 0x00;        // position 8
    mFakeEDID[pos++] = 0x00;

    // product ID
    mFakeEDID[pos++] = 0x00;        // position 10
    mFakeEDID[pos++] = 0x00;

    // serial number
    mFakeEDID[pos++] = 0x00;        // position 12
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;

    // menufacture info
    mFakeEDID[pos++] = 0x00;        // position 16
    mFakeEDID[pos++] = 0x00;

    // EDID version
    mFakeEDID[pos++] = 0x00;        // position 18
    mFakeEDID[pos++] = 0x00;

    // monitor info
    mFakeEDID[pos++] = 0x00;        // position 20
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;

    // monitor color feature
    mFakeEDID[pos++] = 0x00;        // position 25
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;

    // monitor basic timing, timer, resolution
    mFakeEDID[pos++] = 0x00;        // position 35
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;

    // monitor standard timing & timer
    mFakeEDID[pos++] = 0x00;        // position 38
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;

    // monitor detailed timing & timer (72 bytes)
    mFakeEDID[pos++] = 0x00;        // position 54
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    mFakeEDID[pos++] = 0x00;
    // ... ...

    // extra flags
    mFakeEDID[pos++] = 0x00;        // position 126

    // checksum
    mFakeEDID[pos++] = 0x00;        // position 127
#endif

    return 0;
}
#ifdef MTK_WFD_4K_SUPPORT
int WfdRtspProtocol::getIndex_4k(const char* str)
{
    if (strlen(str) != 12)
    {
        WFD_LOG_ERR("Video format error!\n");
        return -1;
    }

    int ret = 0;
    for(int bit = 11; bit > 0; --bit)
    {
        if (str[bit] == '0')
            ret += 4;
        else
        {
            if (str[bit] == '1')
                ret += 1;
            else if (str[bit] == '2')
                ret += 2;
            else if (str[bit] == '4')
                ret += 3;
            else if (str[bit] == '8')
                ret += 4;

            break;
        }
    }

    return (ret - 1);
}
#endif
}
