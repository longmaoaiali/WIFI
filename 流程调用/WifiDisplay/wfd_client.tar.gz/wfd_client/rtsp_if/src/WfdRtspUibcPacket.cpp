#define WFD_LOG_TAG "WfdRtspUibcPacket"

#include "WfdRtspUibcPacket.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "Utils.h"
#include <arpa/inet.h>


namespace rtsp
{

WfdRtspUibcPacket::WfdRtspUibcPacket()
{
    reset();
}

int WfdRtspUibcPacket::setCategory(UIBC_CATEGORY category)
{
    WFD_LOG_INFO("UIBC category = %d", category);
    mCategory = category;
    return 0;
}

int WfdRtspUibcPacket::setGenericId(GENERIC_ID genericId)
{
    WFD_LOG_INFO("UIBC genericId = %d", genericId);
    if(mCategory == UIBC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Category should be set!");
        assert(0);
        return -1;
    }
    mGenericId = genericId;
    return 0;
}

int WfdRtspUibcPacket::setGenType(GENERIC_TYPE genType)
{
    mGenType = genType;
    return 0;
}

int WfdRtspUibcPacket::setHidType(HID_TYPE hidType)
{
    mHidType = hidType;
    return 0;
}


int WfdRtspUibcPacket::setCoordinate(int x,int y)
{
    //WFD_LOG_DEBUG("UIBC x = %d, y = %d", x, y);
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mPointNum = 1;
    mX1 = x;
    mY1 = y;
    return 0;
}

int WfdRtspUibcPacket::setCoordinates(int x1,int y1,int x2,int y2)
{
    //WFD_LOG_DEBUG("UIBC x1 = %d, y1 = %d, x2 = %d, y2 = %d", x1, y1, x2, y2);
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mPointNum = 2;
    mX1 = x1;    mY1 = y1;
    mX2 = x2;    mY2 = y2;
    return 0;
}

int WfdRtspUibcPacket::setKeyCodes(int key1,int key2)
{
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mKey1 = key1;
    mKey2 = key2;
    return 0;
}

int WfdRtspUibcPacket::setZoom(int x,int y,int intTime,int fracTime)
{
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mZoomX = x;
    mZoomY = y;
    mZoomIntTime = intTime;
    mZoomFracTime = fracTime;
    return 0;
}

int WfdRtspUibcPacket::setScrolls(int vertAmount,int horizAmount)
{
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mVScrollAmount = vertAmount;
    mHScrollAmount = horizAmount;
    return 0;
}

int WfdRtspUibcPacket::setRotate(int intPortion,int fracPortion)
{
    if(mGenericId == GENERIC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Generid ID should be set!");
        assert(0);
        return -1;
    }
    mRotateInt = intPortion;
    mRotateFrac = fracPortion;
    return 0;
}

int WfdRtspUibcPacket::getTranData(unsigned char * buffer,int len, void *data)
{
    unsigned char prtData[1024] = {0};
    int prtLen = 0;
    int retLen = 0;
    static const int VERSION_OFFSET = 5;
    static const int TIMESTAMP_OFFSET = 4;
    static const int CATEGORY_OFFSET = 0;
    unsigned char tmpChar1, tmpChar2, tmpChar3, tmpChar4;

    if(len < 20)
    {
        WFD_LOG_ERR("Error buffer length should larger than 20!");
        return -1;
    }
    if(mCategory == UIBC_UNKNOWN)
    {
        WFD_LOG_ERR("Error Category should be set!");
        assert(0);
        return -1;
    }

    /***** GENERIC *****/
    if(mCategory == UIBC_GENERIC)
    {
        if (mGenType == GEN_TYPE_KEYBOARD)
        {
            #define GEN_KEYBOARD_LEN    0x0c
            int keyupdown = *((int *)data);
            int keycode = *(((int *)data)+1);
            /* Fixme: hardcoded first */
            buffer[0] = 0;
            buffer[1]= 0;
            buffer[2] = 0x00;
            buffer[3] = GEN_KEYBOARD_LEN;
            buffer[4] = (keyupdown==0)?KEY_DOWN:KEY_UP;
            buffer[5] = 0x00;
            buffer[6] = 0x05;
            buffer[7] = 0;
            buffer[8] = 0;
            buffer[9] = (unsigned char)keycode;
            buffer[10] = 0;
            buffer[11] = 0;
            retLen = GEN_KEYBOARD_LEN;
        }
        else
        {
            if(mGenericId == GENERIC_UNKNOWN)
            {
                WFD_LOG_ERR("Error Generid ID should be set!");
                assert(0);
                return -1;
            }

            int pos = 0;
            prtData[pos] = (mVersion & 0b111) << VERSION_OFFSET;        // Version
            prtData[pos++] += mIsTimestampEnabled << TIMESTAMP_OFFSET;  // Timestamp
            prtData[pos++] += mCategory << CATEGORY_OFFSET;             // Category
            prtLen = 4;
            if(mIsTimestampEnabled)                  // Not supported yet!
            {
                assert(0);
                prtLen += 2;
            }
            prtLen += calBodyLen();
            /* note: we need to pad to make sure the length is 2-byte aligned */
            if (prtLen%2 != 0)
                prtLen += 1;
            int2uchar(prtLen, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
            prtData[pos++] = tmpChar3;
            prtData[pos++] = tmpChar4;
            if(mIsTimestampEnabled)
            {
                int2uchar(mTimestamp, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;
                prtData[pos++] = tmpChar4;
            }

            int fieldLen = calBodyLen() - 3;
            prtData[pos++] = mGenericId;            // ID
            int2uchar(fieldLen, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
            prtData[pos++] = tmpChar3;              // Field length
            prtData[pos++] = tmpChar4;

            if(mGenericId == LEFT_MOUSE_DOWN || mGenericId == TOUCH_DOWN
                || mGenericId == LEFT_MOUSE_UP || mGenericId == TOUCH_UP
                || mGenericId == MOUSE_MOVE || mGenericId == TOUCH_MOVE)
            {
                prtData[pos++] = mPointNum;         // Number of pointers

                // (x1, y1) coordinate
                prtData[pos++] = 0;                 // Pointer ID
                int2uchar(mX1, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // X-coordinate
                prtData[pos++] = tmpChar4;

                int2uchar(mY1, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Y-coordinate
                prtData[pos++] = tmpChar4;

                if(mPointNum == 2)
                {
                    // (x2, y2) coordinate
                    prtData[pos++] = 1;              // Pointer ID
                    int2uchar(mX2, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                    prtData[pos++] = tmpChar3;       // X-coordinate
                    prtData[pos++] = tmpChar4;

                    int2uchar(mY2, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                    prtData[pos++] = tmpChar3;       // Y-coordinate
                    prtData[pos++] = tmpChar4;
                }
            }
            else if(mGenericId == KEY_DOWN || mGenericId == KEY_UP)
            {
                prtData[pos++] = 0;                 // Reserved
                int2uchar(mKey1, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Key Code 1
                prtData[pos++] = tmpChar4;

                int2uchar(mKey2, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Key Code 2
                prtData[pos++] = tmpChar4;
            }
            else if(mGenericId == ZOOM)
            {
                int2uchar(mZoomX, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Zoom X-coordinate
                prtData[pos++] = tmpChar4;

                int2uchar(mZoomY, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Zoom Y-coordinate
                prtData[pos++] = tmpChar4;

                prtData[pos++] = mZoomIntTime;      // Zoom interger times
                prtData[pos++] = mZoomFracTime;     // Zoom fraction times
            }
            else if(mGenericId == VERTICAL_SCROLL)
            {
                int2uchar(mVScrollAmount, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Vertical scroll amount
                prtData[pos++] = tmpChar4;
            }
            else if(mGenericId == HORIZONTAL_SCROLL)
            {
                int2uchar(mHScrollAmount, tmpChar1, tmpChar2, tmpChar3, tmpChar4);
                prtData[pos++] = tmpChar3;          // Horizontal scroll amount
                prtData[pos++] = tmpChar4;
            }
            else if(mGenericId == ROTATE)
            {
                prtData[pos++] = mRotateInt;        // Rotate integer portion
                prtData[pos++] = mRotateFrac;       // Rotate fraction portion
            }
            else
            {
                WFD_LOG_ERR("Error Unknown generic ID");
                assert(0);
            }

            memcpy(buffer, prtData, prtLen);
            retLen = prtLen;
        }
    }

    /***** HIDC (USB) *****/
    else if (mCategory == UIBC_HIDC)
    {
        struct uibc_packet_s upkt;
        unsigned short *usptr;
        unsigned char *buf_ptr = NULL, *buf_head_ptr = NULL;

        WFD_LOG_DEBUG("Generating UIBC_HIDC event, mHidType=%d\n", mHidType);
        memset(buffer, 0, len);
        memset(&upkt, 0, sizeof(struct uibc_packet_s));

        upkt.hdr.version = mVersion;
        upkt.hdr.T = 0;
        upkt.hdr.rsvd = 0;
        upkt.hdr.input_category = mCategory;
        /* need to convert first ushort bytes to network order */
        usptr = (unsigned short *)&upkt.hdr;
        *usptr = htons(*usptr);

        if (mHidType == HID_TYPE_MOUSE)
        {
            struct hid_mouse_input_report_s *mouse = NULL;
            int *disps = (int *)data;
            upkt.u_body.uibc_hidc.input_path = HID_INPUT_PATH_USB;
            upkt.u_body.uibc_hidc.hid_type = HID_TYPE_MOUSE;
            upkt.u_body.uibc_hidc.usage = 0; /* not Report Descriptor */
            upkt.u_body.uibc_hidc.length = htons(HIDC_USB_MOUSE_VALUE_LEN);
            mouse = (struct hid_mouse_input_report_s *)&upkt.u_body.uibc_hidc.hidc_value[0];
            mouse->x_disp = (unsigned char)disps[0];
            mouse->y_disp = (unsigned char)disps[1];
            /* copy result to buffer */
            /* Note that because alignment issue that after HIDC "usage filed" will have one additional
               byte, so we manage the buffer by copying.
               It is better to use pragma though.
            */
            buf_ptr = buffer;
            buf_head_ptr = buf_ptr;
            buf_ptr += sizeof(struct uibc_packet_hdr_s);
            *buf_ptr++ = upkt.u_body.uibc_hidc.input_path;
            *buf_ptr++ = upkt.u_body.uibc_hidc.hid_type;
            *buf_ptr++ = upkt.u_body.uibc_hidc.usage;
            memcpy(buf_ptr, (unsigned char *)&upkt.u_body.uibc_hidc.length, sizeof(upkt.u_body.uibc_hidc.length));
            buf_ptr += sizeof(upkt.u_body.uibc_hidc.length);
            memcpy(buf_ptr, mouse, sizeof(struct hid_mouse_input_report_s));
            buf_ptr += sizeof(struct hid_mouse_input_report_s);
            retLen = UIBC_HDR_LEN + UIBC_HIDC_BODY_LEN_MOUSE;
            upkt.hdr.length = htons((unsigned short)retLen);
            memcpy(buf_head_ptr, (unsigned char *)&upkt.hdr, sizeof(struct uibc_packet_hdr_s));


        }
        else if (mHidType == HID_TYPE_KEYBOARD)
        {
            struct hid_keyboard_input_report_s *keyboard = NULL;
            int keycode = *((int *)data);
            upkt.u_body.uibc_hidc.input_path = HID_INPUT_PATH_USB;
            upkt.u_body.uibc_hidc.hid_type = HID_TYPE_KEYBOARD;
            upkt.u_body.uibc_hidc.usage = 0; /* not Report Descriptor */
            upkt.u_body.uibc_hidc.length = htons(HIDC_USB_KEYBOARD_VALUE_LEN);
            keyboard = (struct hid_keyboard_input_report_s *)&upkt.u_body.uibc_hidc.hidc_value[0];
            keyboard->keycode1 = (unsigned char) keycode;
            /* copy result to buffer */
            /* Note that because alignment issue that after HIDC "usage filed" will have one additional
               byte, so we manage the buffer by copying.
               It is better to use pragma though.
            */
            buf_ptr = buffer;
            buf_head_ptr = buf_ptr;
            buf_ptr += sizeof(struct uibc_packet_hdr_s);
            *buf_ptr++ = upkt.u_body.uibc_hidc.input_path;
            *buf_ptr++ = upkt.u_body.uibc_hidc.hid_type;
            *buf_ptr++ = upkt.u_body.uibc_hidc.usage;
            memcpy(buf_ptr, (unsigned char *)&upkt.u_body.uibc_hidc.length, sizeof(upkt.u_body.uibc_hidc.length));
            buf_ptr += sizeof(upkt.u_body.uibc_hidc.length);
            memcpy(buf_ptr, keyboard, sizeof(struct hid_keyboard_input_report_s));
            buf_ptr += sizeof(struct hid_keyboard_input_report_s);
            retLen = UIBC_HDR_LEN + UIBC_HIDC_BODY_LEN_KEYBOARD;
            upkt.hdr.length = htons((unsigned short)retLen);
            memcpy(buf_head_ptr, (unsigned char *)&upkt.hdr, sizeof(struct uibc_packet_hdr_s));
            //sarick test
            //WFD_LOG_ERR( "(sadbg)buf[0-3]=0x%02x,0x%02x,0x%02x,0x%02x\n", buffer[0],buffer[1],buffer[2],buffer[3]);
            /*
            buffer[0]=0x00;buffer[1]=0x01;buffer[2]=0x00;buffer[3]=0x11;
            buffer[4]=0x01;buffer[5]=0x00;buffer[6]=0x00;buffer[7]=0x00;
            buffer[8]=0x08;buffer[9]=0x00;buffer[10]=0x00;buffer[11]=(unsigned char)keycode;
            buffer[12]=0x00;buffer[13]=0x00;buffer[14]=0x00;buffer[15]=0x00;
            buffer[16]=0x00;
            */
        }
    }

    return retLen;
}


WfdRtspUibcPacket::~WfdRtspUibcPacket()
{
}


/* ====================== Private Functions ======================= */

int WfdRtspUibcPacket::setVersion(int version)
{
    WFD_LOG_ERR("Error Not supported!");
    return 0;
}

int WfdRtspUibcPacket::enableTimestamp(bool enabled)
{
    WFD_LOG_ERR("Error Not supported!");
    return 0;
}

int WfdRtspUibcPacket::reset()
{
    mCategory = UIBC_UNKNOWN;
    mGenericId = GENERIC_UNKNOWN;
    mHidType = HID_TYPE_KEYBOARD;
    mGenType = GEN_TYPE_SINGLETOUCH;
    mVersion = 0;
    mIsTimestampEnabled = false;
    mTimestamp = 0;
    mPointNum = 0;
    mKey1 = mKey2 = 0;

    return 0;
}

void WfdRtspUibcPacket::int2uchar(const int & integer,unsigned char & char1,unsigned char & char2,unsigned char & char3,unsigned char & char4)
{
    char1 = (integer & 0xFF000000) >> 24;
    char2 = (integer & 0x00FF0000) >> 16;
    char3 = (integer & 0x0000FF00) >> 8;
    char4 = (integer & 0x000000FF);
}

int WfdRtspUibcPacket::calBodyLen()
{
    int idLen = 1;
    int lenLen = 2;
    int descLen = 0;
    if(mGenericId == LEFT_MOUSE_DOWN || mGenericId == LEFT_MOUSE_UP
        || mGenericId == TOUCH_DOWN || mGenericId == TOUCH_UP || mGenericId == MOUSE_MOVE)
    {
        if(mPointNum == 1)
        {
            descLen = 6;
        }
        else if(mPointNum == 2)
        {
            descLen = 11;
        }
    }
    else if(mGenericId == KEY_DOWN || mGenericId == KEY_UP)
    {
        descLen = 5;
    }
    else if(mGenericId == ZOOM)
    {
        descLen = 6;
    }
    else if(mGenericId == VERTICAL_SCROLL || mGenericId == HORIZONTAL_SCROLL)
    {
        descLen = 2;
    }
    else if(mGenericId == ROTATE)
    {
        descLen = 2;
    }
    else
    {
        WFD_LOG_ERR("Error not supported ID!");
        assert(0);
    }

    return (idLen + lenLen + descLen);
}

}
