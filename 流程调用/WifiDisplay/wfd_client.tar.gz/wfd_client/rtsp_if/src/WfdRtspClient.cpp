#define WFD_LOG_TAG "WfdRtspClient"

#include "WfdRtspClient.h"
#include <assert.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <algorithm>
#include <sys/time.h>
#include "BasicUsageEnvironment.hh"
#include "GroupsockHelper.hh"
#include "MPEG2TransportStreamFramer.hh"
#include "ThreadObject.h"
#include "Semaphore.h"
#include "ScopedMutex.h"
#include "WfdRtspCmdSender.h"
#include "WfdRtspProtocol.h"
#include "WFDMediaSink.h"
#include "WFDAACSink.h"
#include "WFDH264Sink.h"
#include "WFDClient.h"
#include "PushPlayer.h"
#include "Utils.h"
#include "wfd_client_internal.h"
#include "WFD_common.h"

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
#include <stdlib.h>
//#include "media/AudioSystem.h"
//#include "system/audio.h"
#endif

#ifdef ENABLE_HDCP2X_RX
#define WFD_HDCP2X_PORT     4990
#ifndef HDCP_ON_UTOPIA
#include <hdcp2x_ext.h>
#endif
#include <dlfcn.h>
#endif


#define ENABLE_WFD_CLIENT

#define RTSP_PARAM_STRING_MAX   512
#define RTSP_TCP_CONN_MAX_TRY   5
#define ENABLE_WFD_CLIENT
#define EVENTLOOP_SEMA_TIMEOUT_S    1 /*sec*/
#define RTSP_SETUP_SEMA_TIMEOUT_S       30 /*sec*/
#define RTSP_TEARDOWN_SEMA_TIMEOUT_S    10 /*sec*/
#define RTSP_OPTION_SEMA_TIMEOUT_S      10 /*sec */
#define RTSP_PARAMETER_SEMA_TIMEOUT_S   10/*sec*/

//#define TCP_STREAM_PORT 19000

#ifdef WFD_READ_TS_FROM_FILE
#define READ_TS_FILE_PATH           "/mnt/usb/sda1"
#define READ_TS_FILE_NAME_DEFAULT   "wfd.ts"
int enableReadTsFlag = 0;
#endif
extern int UibcThreadEnabled;
extern int I2CThreadEnabled;
extern struct wfd_rtsp_conf_s *wfd_rtsp_conf;

extern unsigned int wfd_idr_interval;
extern struct timeval IDR_time_out;
extern bool fHavepacketlost;


using namespace std;
namespace rtsp
{
static TaskScheduler* scheduler = NULL;
static UsageEnvironment* env = NULL;
static char exitEventLoop = 1;
static char exitTransportLoop = 1;
static int newSocket = -1;
static int TransportTCP = 0;

static Semaphore eventLoopSema;
static int transportTCPPort = -1;
static int tmp_transportTCPPort = -1;
static int PotocolTCPPort = 0;
static bool has_teardown_ = false;

static unsigned int fileSinkBufferSize = 100000;
const unsigned int maxBufSize = 1024*1024;

bool WfdRtspClient::is_need_hdcp = false;
bool WfdRtspClient::is_hdcp_end = false;
bool WfdRtspClient::is_hdcp_authed = false;

void wfdDumpRtsp(const char *msgname, const char *data)
{
    if (!data)
    {
        WFD_LOG_ERR("No data to dump!\n");
        return;
    }
    WFD_LOG_INFO("Dumping RTSP message (%s)\n", msgname);
    WFD_LOG_INFO("------------------------------\n");
    WFD_LOG_INFO("%s", data);
    WFD_LOG_INFO("------------------------------\n");
}

void* eventLoopThread(void* data)
{
    WFD_LOG_INFO("eventLoopThread start...\n");
    assert(data);

    WfdRtspClient* client = static_cast<WfdRtspClient*>(data);
    UNUSED(client);
    while(!exitEventLoop)
    {
        if (!env)
        {
            WFD_LOG_ERR("Error, env=NULL!!!\n");
            return NULL;
        }
        env->taskScheduler().doEventLoop(&exitEventLoop);
    }

    eventLoopSema.notifyAll();
    if (!has_teardown_) {
        WFDClient::getInstance().mediaTearDown();
    }
    WFD_LOG_INFO("eventLoopThread exit...\n");
    return NULL;
}
void* transportThread(void* data)
{
    WFD_LOG_INFO("transportThread start...");
    assert(data);

    WfdRtspClient* client = static_cast<WfdRtspClient*>(data);
    //UNUSED(client);

    int reuseFlag = 1;
    int counter = 0;
    newSocket = socket(AF_INET, SOCK_STREAM, 0);
    if(newSocket < 0)
    {
        WFD_LOG_ERR("socket() failed\n");
        return NULL;
    }

    if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuseFlag, sizeof reuseFlag) < 0)
    {
        WFD_LOG_ERR("setsockopt(SO_REUSEADDR) error\n");
        close(newSocket);
        return NULL;
    }

/*
    struct linger so_linger;
    so_linger.l_onoff = 1;
    so_linger.l_linger = 0;

    if (setsockopt(newSocket, SOL_SOCKET, SO_LINGER,
                &so_linger, sizeof so_linger) < 0) {
        WFD_LOG_ERR("setsockopt(SO_LINGER) error\n");
        close(newSocket);
        return NULL;
    }
*/
    struct sockaddr_in sockaddr;
    sockaddr.sin_family = AF_INET;
    sockaddr.sin_addr.s_addr = INADDR_ANY;
    sockaddr.sin_port = htons(19000);
    bzero(&(sockaddr.sin_zero), 8);
    if (::bind(newSocket, (struct sockaddr*)&sockaddr, sizeof sockaddr) != 0)
    {
        WFD_LOG_ERR("bind socket error\n");
        close(newSocket);
        return NULL;
    }
    if (listen(newSocket, 10) != 0)
    {
        WFD_LOG_ERR("listen socket error\n");
        close(newSocket);
        return NULL;
    }
    WFD_LOG_DEBUG("before TCP accept\n");

    struct sockaddr_in clientAddr;
    socklen_t clientAddrLen = sizeof clientAddr;
    unsigned int requestedSize;
    socklen_t sizeSize = sizeof(requestedSize);
    while(!exitTransportLoop)
    {
        WFD_LOG_DEBUG("waiting TCP accept\n");
        transportTCPPort = accept(newSocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
        WFD_LOG_DEBUG("accept return %d \n", transportTCPPort);

        if((tmp_transportTCPPort != transportTCPPort) && (counter != 0)) {
            if(tmp_transportTCPPort > 0)
            {
                WFD_LOG_ERR("socket:%d,close socket.\n", tmp_transportTCPPort);
                ::close(tmp_transportTCPPort);
            }
            tmp_transportTCPPort = -1;
        }

        if (transportTCPPort > 0)
        {
            counter++;
            tmp_transportTCPPort = transportTCPPort;
            requestedSize = 77824 * 12.5;
            if(setsockopt(transportTCPPort, SOL_SOCKET, SO_RCVBUF, (char*)&requestedSize, sizeSize) < 0)
            {
                WFD_LOG_ERR("setsockopt socket error\n");
                close(newSocket);
                break;
            }
            if(getsockopt(transportTCPPort, SOL_SOCKET, SO_RCVBUF, (char*)&requestedSize, &sizeSize) < 0)
            {
                WFD_LOG_ERR("getsockopt socket error\n");
                close(newSocket);
                break;
            }
            WFD_LOG_DEBUG("Set TCP socket buffer size = %u\n", requestedSize);
            client->changeTransport();

        }
    }
    WFD_LOG_DEBUG("transportThread exit...");
    return NULL;
}

static ThreadObject watcher(eventLoopThread);
static ThreadObject transportWatcher(transportThread);

//request handler
void WfdRtspClient::wfdRtspResponseHandler(RTSPClient * rtspClient,int resultCode,char * resultString)
{
    assert(rtspClient);
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WfdState state = client->mState;
    WFD_LOG_DEBUG("wfdRtspResponseHandler state = %d, resultCode = %d\n", state, resultCode);
    WFD_LOG_DEBUG("result string=[%s]\n", resultString?resultString:"NULL");

    /*****************************************
         When resultCode > 0 --> RTSP Request.
         When resultCode ==0 --> RTSP Response.
    *****************************************/
    if (resultCode < 0)
    {
        /*handle the error*/
        WFD_LOG_ERR( "wifi-display source reply error:resultString=[%s]\n", resultString?resultString:"NULL");
        return;
    }

    if( resultCode == 0 && resultString == NULL )
    {
        /*handle some uncommon scene,like source just return response header*/
        WFD_LOG_ERR("wifi-display source reply NULL.\n");
        return;
    }

    string request(resultString);
    if(request.find("OPTIONS") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M1 Request =====\n");
        client->mIsOptionsFinished = true;
        client->mOptionsSema.notifyAll();                  // connection Success
        client->replyOPTIONS(resultCode, resultString);
        client->sendOPTIONS();
    }
    else if(request.find("GET_PARAMETER") != string::npos)
    {
        WFD_LOG_INFO( "sink receive source's get_parameter request\n");
    #ifdef CC_S_PLATFORM
        if(request.find("Content-Type:") != string::npos)
    #else
        if(request.find("Session:") != string::npos)
    #endif
        {
            WFD_LOG_INFO("===== Received M16 Request =====\n");
            if (client->isInStandByMode)
            {
                WFD_LOG_INFO("===== Sending M16 Response (406) =====\n");
                client->replyReq(406, resultCode);
            }
            else
            {
                WFD_LOG_INFO("===== Sending M16 Response (200 OK) =====\n");
                client->replyGET_PARAMETER(resultCode, resultString);
            }
        }
        else
        {
            WFD_LOG_INFO("===== Received M3 Request =====\n");
            client->updateState(SRC2SNK_GET_PARAMETER);
            client->replyGET_PARAMETER(resultCode, resultString);
            WFD_LOG_INFO( "sink reply source's get_parameter request ok\n");
        }
    }
    else if(request.find("SET_PARAMETER") != string::npos)
    {
        WFD_LOG_INFO( "sink receive source's SET_PARAMETER request\n");

        if(state != SRC2SNK_SET_PARAMETER_STANDBY
            && state != SNK2SRC_SET_PARAMETER_STANDBY)
        {
            client->updateState(SRC2SNK_SET_PARAMETER);
        }
        client->replySET_PARAMETER(resultCode, resultString);
        WFD_LOG_INFO("wfdRtspResponseHandler source SET_PARAMETER reply \n");
    }
    else
    {
        WFD_LOG_INFO("not support:%s\n", resultString?resultString:"NULL");
    }
}

void WfdRtspClient::wfdAfterOPTIONS(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received M2 Response =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's options request ok\n");
    }
    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }
}

void WfdRtspClient::wfdAfterSetUp(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO( "===== Received M6 Response =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's setup request ok\n");
        client->replySETUP(resultCode, resultString);
        client->mIsSetupFinished = true;
        client->mSetupSema.notifyAll();     // notify waitForSETUPFinished
    }
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }
}

void WfdRtspClient::wfdAfterPlay(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received M7 Response =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_DEBUG("source reply sink's play request ok\n");
        client->mIsM7PlayFinished = true;
        client->mPlaySema.notifyAll();     // notify waitForSETUPFinished
    }
    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }

}

void WfdRtspClient::wfdAfterPause(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received M9 Response =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's pause request ok\n");
    }
    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }

}

void WfdRtspClient::wfdAfterTearDown(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received M8 Response =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's teardown request ok\n");
        client->mIsTearDownFinished = true;
    }
    client->mTearDownSema.notifyAll();  // for waitForTearDownFinished();
    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }

}

void WfdRtspClient::wfdAfterIDR(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received SET_PARAMETER Response (IDR) =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's IDR request ok\n");
    }
    else
    {
        WFD_LOG_ERR("source reply sink's IDR request %s\n", resultString);
    }

    struct timeval timenow;
    gettimeofday(&timenow, NULL);

    IDR_time_out.tv_usec = timenow.tv_usec + (wfd_idr_interval * 1000) % 1000000;
    IDR_time_out.tv_sec = timenow.tv_sec + wfd_idr_interval / 1000;
    if (IDR_time_out.tv_usec >= 1000000)
    {
        IDR_time_out.tv_usec -= 1000000;
        IDR_time_out.tv_sec += 1;
    }
    //printf("IDR_time_out.tv_sec = %ld, IDR_time_out.tv_usec = %ld\n", IDR_time_out.tv_sec,
    //  IDR_time_out.tv_usec);

    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }

}

void WfdRtspClient::wfdAfterStandBy(RTSPClient* rtspClient, int resultCode, char* resultString)
{
    WfdRtspClient* client = (WfdRtspClient*)rtspClient;
    WFD_LOG_INFO("===== Received SNK2SRC_SET_PARAMETER Response (Standby) =====\n");
    WFD_LOG_INFO("%s --> %d, resultCode = %d, resultString = %s\n",
                __FUNCTION__, __LINE__, resultCode, resultString);
    if (resultCode == 0)
    {
        WFD_LOG_INFO("source reply sink's standby request ok\n");
    }
    client->updateState();
    if (resultString != NULL)
    {
        delete[] resultString;
        resultString = NULL;
    }
}

void WfdRtspClient::subsessionAfterPlaying(void * clientData)
{
    WFD_LOG_ENTER();
    // closing this media subsession's stream:
    MediaSubsession* subsession = (MediaSubsession*)clientData;
    Medium::close(subsession->sink);
    subsession->sink = NULL;
}

WfdRtspClient* WfdRtspClient::createNew(char const* rtspURL, responseHandler *handler,
                                    char const* username, char const* pwd)
{
    WFD_LOG_ENTER();
    if(scheduler == NULL)
    {
        scheduler = BasicTaskScheduler::createNew();
    }
    assert(scheduler != NULL);
    if(env == NULL)
    {
        env = BasicUsageEnvironment::createNew(*scheduler);
    }
    assert(env != NULL);
    WfdRtspClient* client = new WfdRtspClient(handler, rtspURL, 0, NULL, 0);
    assert(client != NULL);

    if((username != NULL ) || (pwd != NULL))
    {
        Authenticator * auth = new Authenticator(username, pwd);
        client->mAuth= auth;
    }

    return client;
}

WfdRtspClient::WfdRtspClient(responseHandler * handler, char const * rtspURL,
        int verbosityLevel,char const * applicationName,
        portNumBits tunnelOverHTTPPortNum):
#ifdef __ANDROID__
        RTSPClient(*env, rtspURL, verbosityLevel, applicationName, tunnelOverHTTPPortNum, true),
#else
        RTSPClient(*env, rtspURL, verbosityLevel, applicationName, tunnelOverHTTPPortNum),
#endif
        mWfdRtspResponseHandler(handler)
{
    mUrl = string(rtspURL);
    mIp = mUrl.substr(strlen("rtsp://"));
    mState = UNKNOWN;
    mSession = NULL;
    mAuth = NULL;
    mMediaInfo = NULL;
    mIsOptionsFinished = false;
    mIsParameterFinished = false;
    mIsSetupFinished = false;
    mIsM7PlayFinished = false;
    mIsTearDownFinished = false;
    isInStandByMode = 0;
    mCancelNeg = false;
#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
    memset(&mHDCP_miracast_data, 0, sizeof(ST_HDCP_MIRACAST_DATA));
    mHDCPHandle = NULL;
#endif
#endif
}

WfdRtspClient::~WfdRtspClient()
{
    WFD_LOG_ENTER();
    disconnect();
    closeMediaSession();
    stopHDCP();
    wfd_reset_hdcp_flag();
}

int WfdRtspClient::connect(bool fast_connection)
{
    WFD_LOG_ENTER();
    int ret = 0;
    int retries = 0;
    int errNo= 0;
    has_teardown_ = false;
#define MAX_RTSP_TCP_CONN_RETRY     30

    if(startEventLoop())
    {
        WFD_LOG_ERR( "Error connect startEventLoop failed, ret = %d \n", ret);
        return -1;
    }

    isInStandByMode = 0;
    registerWfdCallback(wfdRtspResponseHandler);
    while (retries < MAX_RTSP_TCP_CONN_RETRY)
    {
        retries ++;
        ret = buildTcpConnection();
        if (ret && (retries < MAX_RTSP_TCP_CONN_RETRY))
        {
            if (mCancelNeg)
            {
                break;
            }
            if (retries < 10)
            {
                WFD_LOG_ERR("buildTcpConnection failed, retrying after 200ms ... %d times\n", retries);
                usleep(200 * 1000);
            }
            else
            {
                WFD_LOG_ERR("buildTcpConnection failed, retrying after 1 sencond ... %d times\n", retries);
                sleep(1);
            }
        }
        else
            break;
    }
    if(ret)
    {
        #ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_UNABLE_TO_CONNECT);
        #endif
        WFD_LOG_ERR("xxxx TCP connection Failed! xxxx\n");
        return -1;
    }
    WFD_LOG_INFO("oooo TCP connection Succeeded oooo retry=%d\n", retries);

    WFD_LOG_INFO("%s: Waiting for M1 message...", __FUNCTION__);
    updateState(SRC2SNK_OPTIONS);

    if (false == PushPlayer::instance().open())
    {
        WFD_LOG_ERR("Error open PushPlayer open failed \n");
        return -3;
    }

    if(waitForParameterFinished()) // waiting for M5 request
    {
        WFD_LOG_ERR("Error WfdRtspClient::connect PARAMETER failed, ret = %d \n", ret);
        return -4;
    }
    WFD_LOG_DEBUG("WfdRtspClient::connect PARAMETER successfully \n");

    MediaInfo media;
    ret = this->getMediaInfo(media);
    if(ret)
    {
        WFD_LOG_ERR("Error WfdRtspClient get media info failed, ret = %d \n", ret);
        return -5;
    }

    if (false == PushPlayer::instance().SetMediaInfo(media))
    {
        WFD_LOG_ERR("Error WfdRtspClient SetMediaInfo(media) failed \n");
        return -6;
    }
    
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error ::connect() CancelNeg true!\n");
        return -3;
    }

    if (false == PushPlayer::instance().SetMediaInfo())
    {
        WFD_LOG_ERR("Error WfdRtspClient SetMediaInfo() failed \n");
        return -6;
    }
    WFD_LOG_INFO( "Waiting for SETUP (M6) to be done...\n");
    if(waitForSETUPFinished())
    {
        WFD_LOG_ERR( "Error WfdRtspClient::connect SETUP failed, ret = %d \n", ret);
        return -3;
    }
    WFD_LOG_INFO( "WfdRtspClient::connect SETUP successfully \n");

    waitForHDCPFinish();
    
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error ::connect() CancelNeg true!\n");
        return -3;
    }

    if(play())
    {
        WFD_LOG_ERR( "Error WfdRtspClient::play  failed, ret = %d \n", ret);

        return -10;
    }
    
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error ::connect() CancelNeg true!\n");
        return -3;
    }

    if (false == PushPlayer::instance().play())
    {
        WFD_LOG_ERR("Error WfdRtspPlayerImpl::open PushPlayer play failed \n");
        #ifdef __ANDROID__
        wfd_send_command(RTSP_EVENT_PLAY_FAIL);
        #endif
        return -8;
    }
#ifdef __ANDROID__
    wfd_send_command(RTSP_EVENT_PLAY_SUCCESS);
#endif

    WFD_LOG_DEBUG("Waiting for PLAY (M7) to be done...\n");
    if(waitForM7PlayFinished())
    {
         WFD_LOG_ERR("Error WfdRtspClient::connect PLAY failed, ret = %d \n", ret);
         return -9;
    }
    WFD_LOG_DEBUG("WfdRtspClient::connect PLAY successfully \n");
    return WFD_OK;
}

int WfdRtspClient::play()
{
    WFD_LOG_ENTER();
    isInStandByMode = 0;
    //ScopedMutex sm(mLocker);
    if ((mState == SNK2SRC_PLAY) || (mState == SRC2SNK_REPLY_PLAY) || (mState == UNKNOWN))
    {
        WFD_LOG_ERR("current stat is %d", (int)mState);
        return 0;
    }

    int ret = 0;

    isInStandByMode = 0;
    ret = sendPLAY();
    if(ret)
    {
        WFD_LOG_ERR("send PLAY error\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_NEGOTIATION_FAILED);
#endif
        return -3;
    }
    WFD_LOG_DEBUG("send PLAY successful\n");

    return 0;
}

int WfdRtspClient::pause()
{
    WFD_LOG_ENTER();
    //ScopedMutex sm(mLocker);
    if ((mState == SNK2SRC_PAUSE) || (mState == SRC2SNK_REPLY_PAUSE) || (mState == UNKNOWN))
    {
        WFD_LOG_ERR("current stat is %d", (int)mState);
        return 0;
    }

    int ret = sendPAUSE();
    if(ret)
    {
        WFD_LOG_ERR("send pause failed, ret = %d \n", ret);
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_NEGOTIATION_FAILED);
#endif
        return -1;
    }
    return 0;
}

int WfdRtspClient::unPause()
{
    WFD_LOG_ENTER();
    //ScopedMutex sm(mLocker);
    if ((mState == SNK2SRC_PLAY) || (mState == SRC2SNK_REPLY_PLAY) || (mState == UNKNOWN))
    {
        WFD_LOG_ERR("current stat is %d", (int)mState);
        return 0;
    }

    WFD_LOG_INFO("begin send play request's data...");
    int ret = sendPLAY();
    WFD_LOG_INFO("send play request's data done");
    if(ret)
    {
        WFD_LOG_ERR("unpause failed, ret = %d \n", ret);
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_NEGOTIATION_FAILED);
#endif
        return -1;
    }

    return 0;
}

int WfdRtspClient::disconnect()
{
    //ScopedMutex sm(mLocker);
    WFD_LOG_ENTER();
    if (has_teardown_) {
      return 0;
    }
    has_teardown_ = true;
#ifdef __ANDROID__
    wfd_send_command(RTSP_REASON_REQUESTED_BY_USER);
#endif

    UibcThreadEnabled = false;
    I2CThreadEnabled = false;

    if(!exitEventLoop)
    {
        int ret = sendTEARDOWN();
        if(ret)
        {
            WFD_LOG_ERR( "send teardown failed, ret = %d \n", ret);
    #ifdef __ANDROID__
            wfd_send_command(RTSP_REASON_NEGOTIATION_FAILED);
    #endif
            return -1;
        }
    }

    if(!exitEventLoop)
    {
        exitEventLoop = 1;
        if(!eventLoopSema.timedWait(1000))
        {
            WFD_LOG_ERR( "Error wait for eventLoop to exit time out\n");
        }
    }

    if (!exitTransportLoop)
    {
        exitTransportLoop = 1;
        TransportTCP = 0;
        tmp_transportTCPPort = -1;
        shutdown(newSocket, SHUT_RDWR);
        ::close(newSocket);
        newSocket = -1;
    }

    if ((mState == SNK2SRC_TEARDOWN) || (mState == SRC2SNK_REPLY_TEARDOWN) || (mState == UNKNOWN))
    {
        WFD_LOG_ERR( "current stat is %d\n", (int)mState);
        return 0;
    }

    isInStandByMode = 0;

    int ret = closeMediaSession();
    if(ret)
    {
        WFD_LOG_ERR( "close media session failed, ret = %d \n", ret);
        return -1;
    }

    stopHDCP();
    wfd_reset_hdcp_flag();

    mIsOptionsFinished = false;
    mIsParameterFinished = false;
    mIsM7PlayFinished = false;

    mIsSetupFinished = false;
    mIsTearDownFinished = false;
    mCancelNeg = false;
    return 0;
}

int WfdRtspClient::getMediaInfo(MediaInfo & media)
{
    WFD_LOG_ENTER();
    int ret = 0;
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error getMediaInfo CancelNeg true!\n");
        return -1;
    }
    ret = WfdRtspProtocol::instance().getMediaInfo(media);
    if(ret)
    {
        WFD_LOG_ERR("get media info failed\n ");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_FATAL_ERROR);
#endif
    }

    return 0;
}

int WfdRtspClient::getRtpSessionId(char * sid)
{
    WFD_LOG_ENTER();
    if(!mSession)
    {
        WFD_LOG_ERR( "session is null\n");
        return -1;
    }

    int sessionNum = 0;
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    while ((subsession = iter.next()) != NULL)
    {
        sessionNum++;
        memcpy(sid, subsession->sessionId, strlen(subsession->sessionId));
    }

    if(sessionNum != 1)
    {
        WFD_LOG_ERR("session number is %d", sessionNum);
        return -2;
    }

    return 0;
}

int WfdRtspClient::sendIDRRequest()
{
    WFD_LOG_ENTER();
    if (mState == SNK2SRC_SET_PARAMETER)
    {
        WFD_LOG_ERR("Wait for prvious IDR response!\n");
        return -1;
    }
    WFD_LOG_INFO("%s Before\n",__FUNCTION__);

    // Mean 1 (bad): shortcoming: can't receive source's reply
/*
    string header   = "SET_PARAMETER " + mUrl + "/wfd1.0 RTSP/1.0";
    string cseq     = string("CSeq: ") + num2str(++fCSeq);
    string content  = "wfd_idr_request";
    string cntType  = "Content-Type: text/parameters";
    string cntLength = string("Content-Length: ") + num2str(content.size()+2);//[chia-chi] add "\r\n" length = 2
    string sep      = string("\r\n");

    string request = header + sep +     \
                    cseq + sep +        \
                    cntType + sep +     \
                    cntLength + sep +   \
                    sep +               \
                    content + sep;

    WFD_LOG_ERR( "===== Sending IDR Request =====\n");
    wfdDumpRtsp("IDR Request", request.c_str());
    send(fOutputSocketNum, request.c_str(), request.size(), 0);
*/

    string content = "wfd_idr_request\r\n";
    sendRequest(new RequestRecord(++fCSeq, "SET_PARAMETER", wfdAfterIDR, mSession, NULL, False, 0.0, 0.0, 0.0, content.c_str()));

    updateState(SNK2SRC_SET_PARAMETER);
    return 0;
}

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
bool WfdRtspClient::sendSetParameterCmd(char * para_value)
{
    WFD_LOG_INFO("sendSetParameterCmd(%s)\n",para_value);

    string content = para_value;

    sendRequest(new RequestRecord(++fCSeq, "SET_PARAMETER", wfdRtspResponseHandler, mSession, NULL, False, 0.0, 0.0, 0.0, content.c_str()));
    return true;
}
#endif

int WfdRtspClient::enterStandbyMode()
{
    WFD_LOG_ENTER();

    // Mean 1 (bad): shortcoming: can't receive source's reply
/*
    string header   = "SET_PARAMETER " + mUrl + "/wfd1.0 RTSP/1.0";
    string cseq     = string("CSeq: ") + num2str(++fCSeq);
    string content  = "wfd_standby";
    string cntType  = "Content-Type: text/parameters";
    string cntLength = string("Content-Length: ") + num2str(content.size()+2);//[chia-chi] add "\r\n" length = 2
    string sep      = string("\r\n");

    string request = header + sep +     \
                    cseq + sep +        \
                    cntType + sep +     \
                    cntLength + sep +   \
                    sep +               \
                    content + sep;

    WFD_LOG_ERR( "===== Sending Standby Request =====\n");
    wfdDumpRtsp("Standby Request", request.c_str());
    send(fOutputSocketNum, request.c_str(), request.size(), 0);
*/

    // Mean 2 (bad): shortcoming: the sent string is "wfd_standby:" (unnecessary colon)
//    sendSetParameterCommand(*mSession, wfdRtspResponseHandler, "wfd_standby", "", mAuth);

    // Mean 3 (Good)
    string content = "wfd_standby\r\n";
    sendRequest(new RequestRecord(++fCSeq, "SET_PARAMETER", wfdAfterStandBy, mSession, NULL, False, 0.0, 0.0, 0.0, content.c_str()));

    isInStandByMode = 1;
    updateState(SNK2SRC_SET_PARAMETER_STANDBY);

    return 0;
}

int WfdRtspClient::uibcGenEvent(int isMultiTouch)
{
    WFD_LOG_ENTER();
    int evtType = GENERIC_EVT_TYPE_SINGLE_TOUCH;
    WfdRtspProtocol& protocol = WfdRtspProtocol::instance();

    if (isMultiTouch)
        evtType = GENERIC_EVT_TYPE_MULTI_TOUCH;
    WFD_LOG_INFO("entering %s\n", __FUNCTION__);
    if (protocol.uibcGenerateEvent(UIBC_CATEGORY_GENERIC, evtType))
    {
        WFD_LOG_ERR( "Failed to generate uibc-generic event\n");
        return -1;
    }
    return 0;
}

int WfdRtspClient::uibcCapUpdate(char *type)
{
    WFD_LOG_ENTER();
    string captype;
    if (!type)
    {
        WFD_LOG_ERR( "Error UIBC Cap type!\n");
        return -1;
    }

    if (strcasecmp(type, "Mouse") == 0)
        captype = "Mouse";
    else if (strcasecmp(type, "SingleTouch") == 0)
        captype = "SingleTouch";
    else if (strcasecmp(type, "Keyboard") == 0)
        captype = "Keyboard";
    else
        captype = "Keyboard";

    string content = "wfd_uibc_capability: input_category_list=GENERIC;generic_cap_list=" + captype +
                     ";hidc_cap_list=none;port=none\r\n";

    WFD_LOG_INFO("======Sending M14 Request (SET_PARAMETER, UIBC Cap update to %s)======\n",
            captype.c_str());

    sendRequest(new RequestRecord(++fCSeq, "SET_PARAMETER", wfdRtspResponseHandler, mSession, NULL, False, 0.0, 0.0, 0.0, content.c_str()));


    return 0;
}

int WfdRtspClient::rtspSigmaCmd(int cmdtype, char *data, int datalen)
{
    WFD_LOG_ENTER();

    switch (cmdtype)
    {
        case WFD_RTSP_SIGMA_CMD_AUDIO_ONLY:
        {
            WfdRtspProtocol& protocol = WfdRtspProtocol::instance();
            int enable = 0;

            if (!data || !datalen)
            {
                WFD_LOG_ERR("Unexpected parameter\n");
                return -1;
            }
            if (strcasecmp(data, "enable") == 0)
                enable = 1;
            else
                enable = 0;

            if(protocol.setAudioOnly(enable))

            break;
        }

        case WFD_RTSP_SIGMA_CMD_HIDC_EVT_MOUSE:
        {
            WfdRtspProtocol& protocol = WfdRtspProtocol::instance();

            if (protocol.uibcGenerateEvent(UIBC_CATEGORY_HIDC, HIDC_EVT_TYPE_MOUSE))
            {
                WFD_LOG_ERR("Failed to generate uibc-hidc mouse event\n");
            }
            break;
        }

        case WFD_RTSP_SIGMA_CMD_HIDC_EVT_KEYBOARD:
        {
            WfdRtspProtocol& protocol = WfdRtspProtocol::instance();

            if (protocol.uibcGenerateEvent(UIBC_CATEGORY_HIDC, HIDC_EVT_TYPE_KEYBOARD))
            {
                WFD_LOG_ERR("Failed to generate uibc-hidc keyboard event\n");
            }

            break;
        }

        case WFD_RTSP_SIGMA_CMD_GEN_EVT_KEYBOARD:
        {
            WfdRtspProtocol& protocol = WfdRtspProtocol::instance();

            if (protocol.uibcGenerateEvent(UIBC_CATEGORY_GENERIC, GENERIC_EVT_TYPE_KEYBOARD))
            {
                WFD_LOG_ERR("Failed to generate uibc-gen keyboard event\n");
            }
            break;
        }

        default:
        {
            WFD_LOG_ERR("Unknown cmdtype:%d\n", cmdtype);
            return -1;
        }
    }

    return 0;
}

int WfdRtspClient::getRtpStats(char *buf, int len)
{
    WFD_PUSH_PLAYER_STATS_T *rtps;

    if (!buf || !len)
        return -1;
    rtps = (WFD_PUSH_PLAYER_STATS_T *)PushPlayer::instance().getRTPStats();
    if (!rtps)
    {
        WFD_LOG_ERR("Fail to get rtp stats\n");
        return -1;
    }

    if (sizeof(WFD_PUSH_PLAYER_STATS_T) != len)
    {
        WFD_LOG_ERR("Statistics structure size does not match!! (%d vs %d)"
                "Please check your code\n", sizeof(WFD_PUSH_PLAYER_STATS_T), len);
        return -1;
    }
    memcpy(buf, (char *)rtps, sizeof(WFD_PUSH_PLAYER_STATS_T));

    return 0;

}


int WfdRtspClient::getSourceIp(string & ip)
{
    ip = mIp.substr(0, mIp.find(':'));  // sub the ":xxxx" (port part)
    return 0;
}

void WfdRtspClient::cancelNegTimeout()
{
    WFD_LOG_ENTER();

    mCancelNeg = true;
    if(mParameterSema.bTimeWait())
    {
        mParameterSema.notifyAll();
    }
    if(mSetupSema.bTimeWait())
    {
        mSetupSema.notifyAll();
    }
    if(mPlaySema.bTimeWait())
    {
        mPlaySema.notifyAll();
    }
}

//======================  Private Functions ======================

int WfdRtspClient::buildTcpConnection()
{
    WFD_LOG_INFO("buildTcpConnection to URL:[%s]\n", fBaseURL);
    int ret = 0;
    ret = openConnection();
    if(ret < 0)
    {
        WFD_LOG_ERR("buildTcpConnection tcp connect failed\n");
        return -1;
    }
    WFD_LOG_INFO("buildTcpConnection tcp connect success\n");
    return WFD_OK;
}

int WfdRtspClient::waitForOPTIONS()
{
    WFD_LOG_ENTER();
    updateState(SRC2SNK_OPTIONS);
    int i = 0;
    for(i = 0; i < 5; i++)
    {
        if(mIsOptionsFinished)
        {
            return 0;
        }
        WFD_LOG_DEBUG("%s: Loop %d \n", __FUNCTION__, i);
        usleep(200 * 1000);
    }

    if(!mOptionsSema.timedWait(10000))
    {
        WFD_LOG_ERR("Error waitForOPTIONS timeout!\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_RTSP_TIMEOUT);
#endif
        return -1;
    }

    return 0;
}

int WfdRtspClient::waitForSETUPFinished()
{
    WFD_LOG_ENTER();
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error waitForSETUPFinished CancelNeg true!\n");
        return -1;
    }
    if(!mIsSetupFinished && !mSetupSema.timedWait(30000))
    {
        WFD_LOG_ERR("waitForSETUPFinished timeout!\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_RTSP_TIMEOUT);
#endif
        return -1;
    }
    if(mCancelNeg)
    {
        WFD_LOG_ERR("Error waitForSETUPFinished CancelNeg true!\n");
        return -1;
    }

    return 0;
}

int WfdRtspClient::waitForParameterFinished()
{
    WFD_LOG_ENTER();
    
    if(mCancelNeg)
    {
        WFD_LOG_ERR("CancelNeg true!\n");
        return -1;
    }
    if(!mIsParameterFinished && !mParameterSema.timedWait(40000))
    {
        WFD_LOG_ERR("Error waitForParameterFinished timeout!\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_RTSP_TIMEOUT);
#endif
        return -1;
    }
    return 0;
}

int WfdRtspClient::waitForM7PlayFinished()
{
    WFD_LOG_ENTER();
    if(mCancelNeg)
    {
        WFD_LOG_ERR("CancelNeg true!\n");
        return -1;
    }
    if(!mIsM7PlayFinished && !mPlaySema.timedWait(20000))
    {
        WFD_LOG_ERR("Error waitForM7PlayFinished timeout!\n");
    #ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_RTSP_TIMEOUT);
    #endif
        return -1;
    }
    return 0;
}

int WfdRtspClient::waitForTearDownFinished()
{
    WFD_LOG_ENTER();
    int i = 0;
    for(i = 0; i < 5; i++)
    {
        if(mIsTearDownFinished)
        {
            return 0;
        }
        WFD_LOG_DEBUG("%s: Loop %d \n", __FUNCTION__, i);
        usleep(200 * 1000);
    }
    if(!mTearDownSema.timedWait(10000))
    {
        WFD_LOG_ERR("Error waitForTearDownFinished timeout!\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_RTSP_TIMEOUT);
#endif
        return -1;
    }

    return 0;
}

int WfdRtspClient::waitForHDCPFinish()
{
    WFD_LOG_ENTER();
    if (wfd_is_need_hdcp())
    {
        // wait timeout 8sec (80 * 100ms)
        for(int i = 0; i < 80; i++)
        {
            WFD_LOG_DEBUG( "%s: Loop %d \n", __FUNCTION__, i);
            if (mCancelNeg)
                return -1;
            if (wfd_is_end_hdcp())
                break;

            //sleep 100ms for HDCP negoniate
            usleep(100 * 1000);
        }
        return 0;
    }

    WFD_LOG_DEBUG("waitForHDCPFinish no need HDCP");
    return 0;
}


int WfdRtspClient::startEventLoop()
{
    WFD_LOG_ENTER();
    exitEventLoop = 0;
    exitTransportLoop = 0;
    watcher.start((void*)this);
    transportWatcher.start((void*)this);
    WFD_LOG_INFO("Exiting startEventLoop\n");
    return 0;
}

int WfdRtspClient::getTimeString(char *buf, int size)
{
    time_t rawtime;
    struct tm *curtime;
    int res = 0;

    if (!buf || !size)
        return -1;
    memset(buf, 0, size);
    time(&rawtime);
    curtime = localtime (&rawtime);
    res = strftime(buf, size, "%a, %b %d %Y %H:%M:%S GMT", curtime);
    return res;
}

int WfdRtspClient::replyOPTIONS(int resultCode, const char* resultString)
{
    WFD_LOG_ENTER();
    /*
     *MODIFY BY KUN.CHEN, if it's a request from source, the resultCode is the cseq
     */
    //fCSeq = resultCode;
    char tmpBuf[2 * RTSP_PARAM_STRING_MAX];
    char timestr[64];
    this->getTimeString(timestr, sizeof(timestr));
    //strncpy(timestr, "Mon, Oct 10 2011 12:12:12 GMT", 30);
    snprintf((char*)tmpBuf, sizeof(tmpBuf),
             "RTSP/1.0 200 OK\r\nCSeq: %d\r\nDate: %s\r\nPublic: org.wfa.wfd1.0, GET_PARAMETER, SET_PARAMETER\r\n\r\n",
             resultCode, timestr);
    /*
    snprintf((char*)tmpBuf, sizeof(tmpBuf),
             "RTSP/1.0 200 OK\r\nCSeq: %d\r\nPublic: org.wfa.wfd1.0, GET_PARAMETER, SET_PARAMETER\r\n\r\n",
             fCSeq);
    */
    WFD_LOG_INFO("===== Sending M1 Response =====\n");
    wfdDumpRtsp("M1 Response", tmpBuf);
    int ret = send(fOutputSocketNum, tmpBuf, strlen(tmpBuf), 0);
    if (ret < 0)
    {
        WFD_LOG_INFO("send options reply's data done, ret:%d, errno=%s\n", ret, strerror(errno));
    }
    WFD_LOG_INFO("send options reply's data done, ret:%d\n", ret);

    updateState();
    return 0;
}

int WfdRtspClient::replyGET_PARAMETER(int resultCode, const char* resultString)
{
    WFD_LOG_ENTER();
    WfdRtspProtocol& protocol = WfdRtspProtocol::instance();
    if(protocol.parse(this, resultString))
    {
        WFD_LOG_ERR("Error:protocol parse fail\n");
        return -1;
    }
    /*
     *MODIFY BY KUN.CHEN, if it's a request from source, the resultCode is the cseq
     */
//  fCSeq = resultCode;
    /*
        * In case received M3 request again to break original CSeq
        */
    int replyCSeq = resultCode;

    string sendBuf, result;
    char num[10] = { 0 };
    char cseqStr[10]={0};

    if(string(resultString).find("Session:") != string::npos)   // WFD keep-alive signal
    {
        replyReq(0, replyCSeq);
        return 0;
    }

    protocol.getResult(result);
    snprintf(num,sizeof(num), "%d", result.size());
    snprintf(cseqStr, sizeof(cseqStr),"%d", replyCSeq);
    sendBuf = "RTSP/1.0 200 OK\r\nCSeq: " + string(cseqStr) + "\r\nContent-Length: " + string(num)
            + string("\r\n") + string("Content-Type: text/parameters\r\n\r\n");
    sendBuf += result;

    WFD_LOG_INFO( "===== Sending M3 Response =====\n");
    wfdDumpRtsp("M3 Response", sendBuf.c_str());
    int ret = send(fOutputSocketNum, sendBuf.c_str(), sendBuf.size(), 0);
    if (ret < 0)
    {
        WFD_LOG_INFO("send get_parameter reply's data done, ret:%d, errno=%s\n", ret, strerror(errno));
    }
    WFD_LOG_INFO("send get_parameter reply's data done, ret:%d\n", ret);
    updateState();
    return 0;
}

/**
 *  replySET_PARAMETER  -  reply source's SET_PARAMETER
 *
 *  Returns:    1 on Need more data, 0 on Succees, -1 on Error
 */
int WfdRtspClient::replySET_PARAMETER(int resultCode, const char* resultString)
{
    WfdRtspProtocol& protocol = WfdRtspProtocol::instance();
    if(protocol.parse(resultString))
    {
        WFD_LOG_ERR("Error replyGET_PARAMETER protocol parse fail \n");
        return -1;
    }

    /*
     *MODIFY BY KUN.CHEN, if it's a request from source, the resultCode is the cseq
     */
    /*
       Note: The fCSeq is supposed to be incremental in each of our RTSP Request message.
       So we should not be setting it to the peer's CSeq value.
     */
    //fCSeq = resultCode;

    string tmp = resultString;
    string replyStr;
    if(tmp.find("wfd_trigger_method: SETUP") != string::npos)
    {
        WFD_LOG_DEBUG("===== Received M5 Request (trigger SETUP) =====\n");
        WFD_LOG_DEBUG("===== Sending M5 Resonse =====\n");
        replyReq(0, resultCode);
        WFD_LOG_INFO( "sink reply source's trigger setup request ok\n");
        mIsParameterFinished = true;
        mParameterSema.notifyAll();       // for waitForParameterFinished()
        WFD_LOG_INFO( "sink send setup request to source\n");
        if (mCancelNeg==False)
        sendSETUP();
    }
    else if(tmp.find("wfd_trigger_method: PLAY") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M5 Request (trigger PLAY) =====\n");
        WFD_LOG_INFO( "===== Sending M5 Resonse =====\n");
        if(mState == SNK2SRC_SET_PARAMETER_STANDBY)
        {
            updateState(SRC2SNK_SET_PARAMETER);
        }
        replyReq(0, resultCode);
        WFD_LOG_INFO( "sink reply source's trigger play request ok\n");
#ifdef ENABLE_WFD_CLIENT
        WFDClient::getInstance().mediaPlay();
#endif
#if 0
        play();
#endif
    }
    else if(tmp.find("wfd_trigger_method: PAUSE") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M5 Request (trigger PAUSE) =====\n");
        WFD_LOG_INFO( "===== Sending M5 Resonse =====\n");
        if(mState == SNK2SRC_SET_PARAMETER_STANDBY || mState == SRC2SNK_SET_PARAMETER_STANDBY || isInStandByMode)
        {
            replyReq(406, resultCode);
            WFD_LOG_ERR( "sink reply source's trigger pause request fail\n");
        }
        else
        {
            replyReq(0, resultCode);
            WFD_LOG_INFO("sink reply source's trigger pause request ok");
#ifdef ENABLE_WFD_CLIENT
            WFDClient::getInstance().mediaPause();
#endif
        }
    }
    else if(tmp.find("wfd_trigger_method: TEARDOWN") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M5 Request (trigger TEARDOWN) =====\n");
#ifdef __ANDROID__
        wfd_send_command(RTSP_REASON_REQUESTED_BY_PEER);
        wfd_send_command(RTSP_REASON_RTSP_DISCONNECTED);
#endif
        WFD_LOG_INFO( "===== Sending M5 Resonse =====\n");
        replyReq(0, resultCode);
        WFD_LOG_INFO("sink reply source's trigger teardown request ok\n");
        //disconnect();
/*
#ifdef ENABLE_WFD_CLIENT
       WFDClient::getInstance().mediaTearDown();
#endif
*/
        int ret = sendTEARDOWN();
        if(ret)
        {
            WFD_LOG_ERR( "send teardown failed, ret = %d \n", ret);
        #ifdef __ANDROID__
            wfd_send_command(RTSP_REASON_NEGOTIATION_FAILED);
        #endif
            return -1;
        }
        exitEventLoop = 1;
    }
    else if(tmp.find("sony_ext_01: ") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M100 Request (sony_ext_01) =====\n");
        const char  *string = tmp.c_str();
        const char  *ext_string ;
        int tcp_port1 = 0;
        int tcp_port2 = 0;
        int trans_mode = 0;
        int buf_size = 0;
        static int first_trans = 1 ;
        int ret ;
        ext_string = strstr(string, "sony_ext_01:");
        if( sscanf(ext_string, "sony_ext_01: %d %d %d %d",
            &tcp_port1, &tcp_port2, &trans_mode,&buf_size) == 4 )
            {
                replyReq(0, resultCode);
                WFD_LOG_INFO( "sink reply source's M100 request ok\n");
                WFD_LOG_INFO( "tcp_port1 = %d,tcp_port2 =%d,trans_mode =%d,buf_size =%d\n"
                            ,tcp_port1, tcp_port2, trans_mode,buf_size);
                PotocolTCPPort = tcp_port1;
                WFD_LOG_INFO( "sink send M100 to source\n");
                WFD_LOG_DEBUG("transport start,listen Port = %d\n",PotocolTCPPort);
                if(trans_mode != TransportTCP)
                {
                   TransportTCP = trans_mode;
                   /*
                   if (first_trans)
                   {
                       exitTransportLoop = 0;
                       transportWatcher.start((void*)this);
                       first_trans = 0 ;
                   }
                   */  if(TransportTCP == 0)
                       changeTransport();

                }
                else
                {
                    WFD_LOG_ERR( "Same mode , no need Trans\n");
                }
                WFD_LOG_INFO( "Exiting WfdRtspClient::transport\n");
            }
        else
        {
           WFD_LOG_ERR( "sink not support message:%s\n",string);
        }
    }
    else if(tmp.find("wfd_standby") != string::npos && !(tmp.find("wfd_standby_resume_capability") != string::npos))    // Source enter standby mode
    {
        WFD_LOG_INFO( "===== Received M12 Request (trigger STANDBY) =====\n");
        /*
        if (wfd_rtsp_conf && !wfd_rtsp_conf->enable_standby)
        {
            WFD_LOG_ERR( "===== Sending M12 Resonse (406) =====\n");
            replyReq(406, resultCode);
        }
        else
        */
        {
            WFD_LOG_INFO( "===== Sending M12 Resonse (200 OK)=====\n");
            replyReq(0, resultCode);
            updateState(SRC2SNK_SET_PARAMETER_STANDBY);
            isInStandByMode = 1;
        }
    }
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    else if(tmp.find("sony_ext_10: ") != string::npos)
    {
        WFD_LOG_INFO( "===== Received M120 Request (sony_ext_10) =====\n");
        if(mIsM7PlayFinished)
        {
            const char  *string = tmp.c_str();
            const char  *ext_string ;
            int max_volumn = 0;
            int curr_volumn = 0;
            int config_mute = 0;
            int reserved =0;

            ext_string = strstr(string, "sony_ext_10:");
            if( sscanf(ext_string, "sony_ext_10: %d %d %d %d",
                &max_volumn, &curr_volumn, &config_mute,&reserved) == 4 )
            {
                char str_send_cmd[256] = {0} ;
                char str_tmp[32] = {0} ;
                if(config_mute != 0)
                {
                    WFD_LOG_ERR( "Error : config_mute:%d\n",config_mute);
                    replyReq(500, resultCode);
                }
                else
                {
                    WFD_LOG_INFO( "Set Volumn:(%d/%d)\n",curr_volumn,max_volumn);
                    //if(android::AudioSystem::setStreamVolumeIndex(AUDIO_STREAM_MUSIC,curr_volumn,AUDIO_DEVICE_OUT_DEFAULT) != 0)
                    if(true)
                    {
                      #ifdef __ANDROID__
                        strcat(str_send_cmd,RTSP_STATUS_UPDATE_SET_VOLUME_FAIL);
                        sprintf(str_tmp,"%d",curr_volumn);
                        strcat(str_send_cmd,str_tmp);
                        wfd_send_command(str_send_cmd);
                      #endif
                        WFD_LOG_ERR( "Set Volumn FAILED\n");
                        replyReq(501, resultCode);
                    }
                    else
                    {
                     #ifdef __ANDROID__
                       strcat(str_send_cmd,RTSP_STATUS_UPDATE_SET_VOLUME_DONE);
                       sprintf(str_tmp,"%d",curr_volumn);
                       strcat(str_send_cmd,str_tmp);
                       wfd_send_command(str_send_cmd);
                     #endif
                        WFD_LOG_ERR( "Set Volumn DONE\n");
                        replyReq(0, resultCode);
                    }
                }
                updateState(SRC2SNK_SET_PARAMETER);
            }
            else
            {
               WFD_LOG_ERR( "SINK not support:%s\n",string);
            }
        }
        else
            WFD_LOG_ERR( "mIsM7PlayFinished is false, M7 should finish before M120\n");
    }
#endif
    else
    {
        WFD_LOG_INFO( "===== Received M4 Request =====\n");
        WFD_LOG_INFO( "===== Sending M4 Response =====\n");
        replyReq(0, resultCode);
        WFD_LOG_INFO( "sink reply source's set_parameter request ok\n");
    }
    return 0;
}

int WfdRtspClient::replySETUP(int resultCode, const char* resultString)
{
    WFD_LOG_ENTER();
    bool bSuccess = false;

    // Then, setup the "RTPSource"s for the session:
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() == NULL)
        {
            WFD_LOG_ERR("warning");
            continue; // was not initiated
        }

        if (subsession->sink != NULL)/*already be set*/
        {
            continue;
        }

        //unsigned int type = getBufType(subsession);
//      unsigned int type = mediatype_video;
        unsigned int type = mediatype_av;       // WFD spec: TS stream
        if (type == 0)
        {
            WFD_LOG_ERR("error type=%d", type);
            continue;
        }

        {
            //iSetupCount--;
            /*set mediay info*/
            //client->setMediaInfo(subsession, type);
        }

        WFDMediaSink *sink = NULL;
        if ((type != mediatype_audio) && (strcmp(subsession->codecName(), "H264") == 0))
        {
            sink = WFDH264Sink::createNew(*env, subsession->fmtp_spropparametersets(),
                                                type, fileSinkBufferSize);
        }
        else if ((type == mediatype_audio) &&
                    ((strcmp(subsession->codecName(), "AC3") == 0) ||
                     (strcmp(subsession->codecName(), "EAC3") == 0) ||
                     (strcmp(subsession->codecName(), "MPEG4-GENERIC") == 0) ||
                     (strcmp(subsession->codecName(), "MP4A-LATM") == 0)))
        {
            sink = WFDAACSink::createNew(*env, type, fileSinkBufferSize, subsession);
        }
        else
        {
            sink = WFDMediaSink::createNew(*env, type, fileSinkBufferSize);
        }
        WFD_LOG_INFO("subsesion codec name = %s,SessionId = %s \n", subsession->codecName(), subsession->sessionId);
        subsession->sink = sink;
        if (subsession->sink == NULL)
        {
            WFD_LOG_ERR("error");
        }
        else
        {
            subsession->sink->startPlaying(*(subsession->readSource()),
                                                subsessionAfterPlaying,
                                                    subsession);
            // Also set a handler to be called if a RTCP "BYE" arrives
            // for this subsession:
            if (subsession->rtcpInstance() != NULL)
            {
                subsession->rtcpInstance()->setByeHandler(subsessionAfterPlaying, subsession);
            }

            bSuccess = true;
        }
        break;
    }

    updateState();
    return bSuccess ;
}

int WfdRtspClient::sendOPTIONS()
{
    WFD_LOG_ENTER();
    /*
    char tmpBuf[2 * RTSP_PARAM_STRING_MAX];
    snprintf((char*)tmpBuf, sizeof(tmpBuf),
             "OPTIONS * RTSP/1.0\r\nCSeq: %d\r\nRequire: org.wfa.wfd1.0\r\n\r\n", ++fCSeq);
    send(fOutputSocketNum, tmpBuf, strlen(tmpBuf), 0);
    */
    WFD_LOG_DEBUG("===== Sending M2 Request =====\n");
    sendOptionsCommand(wfdAfterOPTIONS, mAuth);
    WFD_LOG_DEBUG("send options request's data done");
    updateState();
    return 0;
}

int WfdRtspClient::sendSETUP()
{
    WFD_LOG_ENTER();

    string version = "v=0\r\n";
    string owner = string("o=- 1312183067511609 1 IN IP4 ") + mIp + string("\r\n");
    string sessionName = "s=MPEG Transport Stream, streamed by the LIVE555 Media Server\r\n";
    string info = "i=wfd1.0\r\n";
    string time = "t=0 0\r\n";
    string control = string("a=control:") + string("rtsp://") + mIp.substr(0, mIp.find(':')) + string("/wfd1.0/streamid=0\r\n");
    string attr = "a=tool:LIVE555 Streaming Media v2011.06.14\r\n";
    attr += "a=type:broadcast\r\n";
    attr += control;
    attr += "a=range:npt=0-\r\n";
    attr += "a=x-qt-text-nam:MPEG Transport Stream, streamed by the LIVE555 Media Server\r\n";
    attr += "a=x-qt-text-inf:wfd1.0\r\n";
    string media = "m=video 19900 RTP/AVPF/UDP 33\r\n";
    //string connection = "c=IN IP4 0.0.0.0\r\n";
    string connection = string("c=IN IP4 ") + mIp.substr(0, mIp.find(':')) + string("\r\n");
    string bandwidth = "b=AS:77824\r\n"; //set 77824 for memory page alignment, don't modify it


    string uri = "\r\n";
    string email = "\r\n";
    string phone = "\r\n";
    string repeat = "\r\n";
    string zone = "\r\n";
    string key = "\r\n";

    string sdpDescription = version + owner + sessionName + info + time +
                        attr + media + connection + bandwidth + control;
    WFD_LOG_INFO("sdpDescription:\n%s ", sdpDescription.c_str());
#ifdef __ANDROID__
    mSession = MediaSession::createNew(*env, sdpDescription.c_str(), true);
#else
    mSession = MediaSession::createNew(*env, sdpDescription.c_str());
#endif
    assert(mSession);

    if(!mSession->hasSubsessions())
    {
        WFD_LOG_ERR("no media subsession \n");
        Medium::close(mSession);
        mSession = NULL;
        return -1;
    }
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;

    while((subsession = iter.next()) != NULL)
    {
        /*
         *kun.chen this only work on one subsession
         */
        //subsession->setClientPortNum(1010);

        if(!subsession->initiate(-1))
        {
            WFD_LOG_ERR("subsession init failed\n");
            continue;
        }
        if(subsession->rtpSource() != NULL)
        {
            int socketNum = subsession->rtpSource()->RTPgs()->socketNum();
            unsigned newBufferSize = setReceiveBufferTo(*env, socketNum, maxBufSize);
            UNUSED(newBufferSize);
        }
        WFD_LOG_DEBUG("===== Sending M6 Request =====\n");
        updateState(SNK2SRC_SETUP);
        sendSetupCommand(*subsession, wfdAfterSetUp, False, False, False, mAuth);
        WFD_LOG_DEBUG("send setup request's data done\n");
    }

    return 0;
}

int WfdRtspClient::sendPLAY()
{
    WFD_LOG_ENTER();

    if(mState == SRC2SNK_REPLY_SETUP || mState == SRC2SNK_REPLY_PAUSE
       || mState == SRC2SNK_SET_PARAMETER || mState == SNK2SRC_REPLY_SET_PARAMETER
       || mState == SNK2SRC_PAUSE || mState == SNK2SRC_SET_PARAMETER_STANDBY
       || mState == SRC2SNK_SET_PARAMETER_STANDBY || mState == SNK2SRC_REPLY_GET_PARAMETER)
    {
        updateState(SNK2SRC_PLAY);
        if(mSession==NULL || mCancelNeg)
        {
            WFD_LOG_ERR("mSession is NULL or mCancelNeg is true");
            return -1;
        }
        WFD_LOG_INFO( "===== Sending M7 Request =====\n");
        sendPlayCommand(*mSession, wfdAfterPlay, 0, mSession->playEndTime(), 1.0f, mAuth);
    }
    else
    {
        WFD_LOG_ERR("Error sendPLAY bad state = %d", mState);
        return -1;
    }

    return 0;
}

int WfdRtspClient::sendPAUSE()
{
    WFD_LOG_ENTER();
    /* note, the state could be SRC2SNK_SET_PARAMETER if this is a triggered method */
    if(mState != SRC2SNK_REPLY_SETUP && mState != SRC2SNK_REPLY_PLAY
       && mState != SRC2SNK_SET_PARAMETER && mState != SNK2SRC_REPLY_SET_PARAMETER
       && mState != SNK2SRC_REPLY_GET_PARAMETER && mState != SRC2SNK_SET_PARAMETER_STANDBY)
    {
        WFD_LOG_ERR( "Error WfdRtspClient::sendPAUSE bad state = %d \n", mState);
        return -1;
    }

    WFD_LOG_DEBUG("begin send pause request's data...");
    updateState(SNK2SRC_PAUSE);
    WFD_LOG_DEBUG("===== Sending M9 Request =====\n");
    sendPauseCommand(*mSession, wfdAfterPause, mAuth);
    WFD_LOG_INFO("send pause request's data done\n");

    return 0;
}


int WfdRtspClient::sendTEARDOWN()
{
    WFD_LOG_ENTER();
    updateState(SNK2SRC_TEARDOWN);
    WFD_LOG_DEBUG("===== Sending M8 Request =====\n");
    sendTeardownCommand(*mSession, wfdAfterTearDown, mAuth);
    WFD_LOG_INFO("send teardown request's data done\n");
    return 0;
}

int WfdRtspClient::closeMediaSession()
{
    WFD_LOG_ENTER();
    if(mSession == NULL)
    {
        return 0;
    }

    MediaSubsessionIterator iter(*mSession);
    MediaSubsession* subsession;
    while ((subsession = iter.next()) != NULL)
    {
        Medium::close(subsession->sink);
        subsession->sink = NULL;
    }

    Medium::close(mSession);
    mSession = NULL;
    WFD_LOG_INFO("exit %s\n",__FUNCTION__);

    return 0;
}
int WfdRtspClient::parseResponseString(const char* respStr)
{
    WFD_LOG_ENTER();
    return 0;
}

void WfdRtspClient::updateState(WfdState next)
{
    ScopedMutex sm(mStateLocker);
    WFD_LOG_INFO( "current state : %d\n", mState);
    if (next != UNKNOWN)
    {
        mState = next;
        WFD_LOG_INFO( "next state : %d\n", mState);
        return;
    }
    switch(mState)
    {
        case SRC2SNK_OPTIONS:
            mState = SNK2SRC_REPLY_OPTIONS;
            break;
        case SNK2SRC_REPLY_OPTIONS:
            mState = SNK2SRC_OPTIONS;
            break;
        case SNK2SRC_OPTIONS:
            mState = SRC2SNK_REPLY_OPTIONS;
            break;
        case SRC2SNK_GET_PARAMETER:
            mState = SNK2SRC_REPLY_GET_PARAMETER;
            break;
        case SRC2SNK_SET_PARAMETER:
            mState = SNK2SRC_REPLY_SET_PARAMETER;
            break;
        case SNK2SRC_SETUP:
            mState = SRC2SNK_REPLY_SETUP;
            break;
        case SNK2SRC_PLAY:
            mState = SRC2SNK_REPLY_PLAY;
            break;
        case SNK2SRC_PAUSE:
            mState = SRC2SNK_REPLY_PAUSE;
            break;
        case SNK2SRC_TEARDOWN:
            mState = SRC2SNK_REPLY_TEARDOWN;
            break;
        case SNK2SRC_SET_PARAMETER:
            mState = SRC2SNK_REPLY_SET_PARAMETER;
            break;
        case SNK2SRC_SET_PARAMETER_STANDBY:
            // State not change
            break;
        case SRC2SNK_SET_PARAMETER_STANDBY:
            mState = SRC2SNK_SET_PARAMETER;
            break;
        default:
            WFD_LOG_ERR( "This state(%d) needn't be change\n", mState);
            break;
    }
    WFD_LOG_INFO( "next state : %d\n", mState);
}

void WfdRtspClient::replyReq(int iErrcode, unsigned int reqCSeq)
{
    static char replyStr[256];

    memset(replyStr, 0, sizeof(replyStr));

    if (iErrcode == 0)
    {
        //replyStr = "RTSP/1.0 200 OK\r\nCSeq: 5\r\nDate: Mon, Jul 11 2011 06:51:04 GMT\r\n\r\n";
        snprintf(replyStr, sizeof(replyStr), "RTSP/1.0 200 OK\r\nCSeq: %d\r\n\r\n", reqCSeq);
        wfdDumpRtsp("Response", replyStr);
        int ret = send(fOutputSocketNum, replyStr, strlen(replyStr), 0);
        if (ret < 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d, errno=%s\n", iErrcode, ret, strerror(errno));
        }
        else if (ret == 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d\n", iErrcode, ret);
        }
        updateState();
    }
    else if (iErrcode == 405)
    {
        snprintf(replyStr, sizeof(replyStr), "RTSP/1.0 405 Method Not Allowed\r\nCSeq: %d\r\n\r\n", reqCSeq);
        wfdDumpRtsp("Response", replyStr);
        int ret = send(fOutputSocketNum, replyStr, strlen(replyStr), 0);
        if (ret < 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d, errno=%s\n", iErrcode, ret, strerror(errno));
        }
        else if (ret == 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d\n", iErrcode, ret);
        }
        updateState();
    }
    else if(iErrcode == 406)
    {
        snprintf(replyStr, sizeof(replyStr), "RTSP/1.0 406 in-standby-mode\r\nCSeq: %d\r\n\r\n", reqCSeq);
        wfdDumpRtsp("Response", replyStr);
        int ret = send(fOutputSocketNum, replyStr, strlen(replyStr), 0);
        if (ret < 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d, errno=%s\n", iErrcode, ret, strerror(errno));
        }
        else if (ret == 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d\n", iErrcode, ret);
        }
    }
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    else if(iErrcode == 500)
    {
        snprintf(replyStr, sizeof(replyStr), "RTSP/1.0 303 See Other\r\nCSeq: %d\r\nContent-Type:text/parameters\r\nContent-Length:18\r\n\r\nsony_ext_10: 500\r\n\r\n", reqCSeq);
        wfdDumpRtsp("Response", replyStr);
        int ret = send(fOutputSocketNum, replyStr, strlen(replyStr), 0);
        if (ret < 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d, errno=%s\n", iErrcode, ret, strerror(errno));
        }
        else if (ret == 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d\n", iErrcode, ret);
        }
        updateState();
    }
    else if(iErrcode == 501)
    {
        snprintf(replyStr, sizeof(replyStr), "RTSP/1.0 303 See Other\r\nCSeq: %d\r\nContent-Type:text/parameters\r\nContent-Length:18\r\n\r\nsony_ext_10: 501\r\n\r\n", reqCSeq);
        wfdDumpRtsp("Response", replyStr);
        int ret = send(fOutputSocketNum, replyStr, strlen(replyStr), 0);
        if (ret < 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d, errno=%s\n", iErrcode, ret, strerror(errno));
        }
        else if (ret == 0)
        {
            WFD_LOG_INFO("replyReq iErrcode:%d, ret:%d\n", iErrcode, ret);
        }
        updateState();
    }
#endif
}

string WfdRtspClient::num2str(const int & num)
{
    char tmp[10] = {0};
    if(num >= 0)
    {
        snprintf(tmp, sizeof(tmp),"%d", num);
    }
    else
    {
        snprintf(tmp, sizeof(tmp),"-%d", num);
    }
    return string(tmp);
}

void WfdRtspClient::changeTransport(void)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            //(subsession->readSource())->stopGettingFrames();
            subsession->sink->stopPlaying();
            WFD_LOG_INFO(">stopGettingFrames()\n");
            ((MPEG2TransportStreamFramer*)(subsession->readSource()))->switchTransport(transportTCPPort, TransportTCP);
            WFD_LOG_INFO(">switchTransport sockethd= %d,fTCP= %d\n",transportTCPPort,TransportTCP);
            subsession->sink->startPlaying(*(subsession->readSource()), subsessionAfterPlaying, subsession);
            WFD_LOG_INFO(">startPlaying\n");
            ((WFDMediaSink*)subsession->sink)->switch_protocol(TransportTCP);

            #ifdef PROTOCOL_API
                 WFDClient::getInstance().setProtocol(TransportTCP);
            #endif
            //fHavepacketlost = true;
        }
    }
}

bool WfdRtspClient::startHDCP()
{
    WFD_LOG_ENTER();
#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
    WFD_LOG_DEBUG("Start HDCP2.x...... begin\n");
    mHDCPHandle = dlopen(WFD_HDCP_LIB_PATH, RTLD_LAZY);
    if (!mHDCPHandle)
    {
        WFD_LOG_ERR("2Error: dlerror = %s\n", dlerror());
        return false;
    }

    void (*HDCP2_SetMiracastHdcpStatusExCB)(Fn_HDCP22_GetMiracastHdcpStatusEx);
    *(void**)(&HDCP2_SetMiracastHdcpStatusExCB) = dlsym(mHDCPHandle, "HDCP2_SetMiracastHdcpStatusExCB");
    if (!HDCP2_SetMiracastHdcpStatusExCB)
    {
        WFD_LOG_ERR("dlsym:HDCP2_SetMiracastHdcpStatusCB dlerror = %s\n", dlerror());
        dlclose(mHDCPHandle);
        return false;
    }

    int (*HDCP2_InitMiracast)(ST_HDCP_MIRACAST_DATA *);
    *(void**)(&HDCP2_InitMiracast) = dlsym(mHDCPHandle, "HDCP2_InitMiracast");
    if (!HDCP2_InitMiracast)
    {
        WFD_LOG_ERR("dlsym:HDCP2_InitMiracast dlerror = %s\n", dlerror());
        dlclose(mHDCPHandle);
        return false;
    }

    HDCP2_SetMiracastHdcpStatusExCB(wfd_hdcp_callback);
    memset(&mHDCP_miracast_data, 0, sizeof(ST_HDCP_MIRACAST_DATA));
    mHDCP_miracast_data.s32HdcpPort = WFD_HDCP2X_PORT;
    mHDCP_miracast_data.bIsRx = TRUE;
    if (HDCP2_InitMiracast(&mHDCP_miracast_data) == false)
    {
        WFD_LOG_ERR( "HDCP2.x Rx start fail (HDCP2_InitMiracast)!\n");
        dlclose(mHDCPHandle);
        return false;
    }
    WFD_LOG_DEBUG("HDCP2.x Rx started--\n");
    wfd_set_need_hdcp(true);

#else
    /*  Modified in WFD TBRE-1.
        As being a DUT, the UCC will not ask you to enable HDCP,
        so you'll have to enbale it by default.
        Only if UCC asks you to DisableAll, then you need to disable. */
    if (hdcp2x_rx_start(WFD_HDCP2X_PORT, NULL) != 0)
    {
        WFD_LOG_ERR( "HDCP2.x Rx start fail (hdcp2x_rx_start)!\n");
        return false;
    }
    WFD_LOG_DEBUG( "HDCP2.x Rx started\n");
    hdcp2x_set_wfd_state_call_back(wfd_hdcp_callback);
    wfd_set_need_hdcp(true);
#endif /* HDCP_ON_UTOPIA */
#endif /* ENABLE_HDCP2X_RX */
    return true;
}
bool WfdRtspClient::stopHDCP()
{
    WFD_LOG_ENTER();
#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
    if (wfd_is_need_hdcp())
    {
        if (mHDCPHandle == NULL)
        {
            WFD_LOG_ERR("stopHDCP wfd_is_need_hdcp, mHDCPHandle == NULL!\n");
            return false;
        }
        int (*HDCP2_DeinitMiracast)(ST_HDCP_MIRACAST_DATA *);
        *(void**)(&HDCP2_DeinitMiracast) = dlsym(mHDCPHandle, "HDCP2_DeinitMiracast");
        if (HDCP2_DeinitMiracast(&mHDCP_miracast_data) == false)
        {
            WFD_LOG_ERR("stopHDCP HDCP2_DeinitMiracast failed!\n");
            dlclose(mHDCPHandle);
            return false;
        }
        dlclose(mHDCPHandle);
        return true;
    }
#else
    hdcp2x_rx_stop(-1);
#endif /* HDCP_ON_UTOPIA */
#endif /* ENABLE_HDCP2X_RX */
    return true;
}

#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
void WfdRtspClient::wfd_hdcp_callback(ST_HDCP_STATUS status)
{
    WFD_LOG_INFO("Receive HDCP status: %d\n", status.enHdcpStatus);
    switch(status.enHdcpStatus)
    {
        case EN_HDCP_AUTH_SUCCESS:
            wfd_set_hdcp_authed(true);
        case EN_HDCP_AUTH_FAIL:
            wfd_set_end_hdcp(true);
            break;
        case EN_HDCP_AUTH_PROCESSING:
            wfd_set_need_hdcp(true);
            break;
        default:
            WFD_LOG_ERR("Unable handle HDCP event %d\n", status.enHdcpStatus);
            break;
    }
}
#else
int WfdRtspClient::wfd_hdcp_callback(int event)
{
    WFD_LOG_INFO( "Receive HDCP event %d\n", event);
    switch(event)
    {
        case HDCP2X_RX_EKS_OK:
        case HDCP2X_RX_EKS_FAIURE:
            wfd_set_end_hdcp(true);
            break;
        case HDCP2X_NEEDED:
            wfd_set_need_hdcp(true);
            break;
        default:
            WFD_LOG_ERR("Unable handle HDCP event %d\n", event);
            break;
    }
    return 0;
}
#endif
#endif

bool WfdRtspClient::wfd_is_need_hdcp()
{
    return is_need_hdcp;
}

bool WfdRtspClient::wfd_is_end_hdcp()
{
    return is_hdcp_end;
}

bool WfdRtspClient::wfd_is_hdcp_authed()
{
    return is_hdcp_authed;
}

void WfdRtspClient::wfd_set_need_hdcp(bool enable)
{
   is_need_hdcp = enable;
}

void WfdRtspClient::wfd_set_end_hdcp(bool enable)
{
    is_hdcp_end = enable;
}

void WfdRtspClient::wfd_set_hdcp_authed(bool enable)
{
    is_hdcp_authed = enable;
}

void WfdRtspClient::wfd_reset_hdcp_flag()
{
    is_hdcp_end = false;
    is_need_hdcp = false;
    is_hdcp_authed = false;
}

#ifdef CC_S_PLATFORM
void WfdRtspClient::setRecvBufferSize(unsigned bufferSize)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            ((WFDMediaSink*)subsession->sink)->setRecvBufferSize(bufferSize);
        }
    }
}

unsigned WfdRtspClient::getRecvBufferSize(void)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    unsigned bufferSize = 0;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            bufferSize = ((WFDMediaSink*)subsession->sink)->getRecvBufferSize();
            break;
        }
    }

    return bufferSize;
}

void WfdRtspClient::setPlayBufferSize(unsigned bufferSize)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            ((WFDMediaSink*)subsession->sink)->setPlayBufferSize(bufferSize);
        }
    }
}

unsigned WfdRtspClient::getPlayBufferSize(void)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    unsigned bufferSize = 0;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            bufferSize = ((WFDMediaSink*)subsession->sink)->getPlayBufferSize();
            break;
        }
    }

    return bufferSize;
}

void WfdRtspClient::setTCPPreBufferSize(unsigned bufferSize)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            ((WFDMediaSink*)subsession->sink)->setTCPPreBufferSize(bufferSize);
        }
    }
}

unsigned WfdRtspClient::getTCPPreBufferSize(void)
{
    MediaSubsessionIterator iter(*mSession);
    MediaSubsession *subsession = NULL;
    unsigned bufferSize = 0;

    while ((subsession = iter.next()) != NULL)
    {
        if (subsession->readSource() != NULL)
        {
            bufferSize = ((WFDMediaSink*)subsession->sink)->getTCPPreBufferSize();
            break;
        }
    }

    return bufferSize;
}

#endif

#ifdef WFD_READ_TS_FROM_FILE
void *readTsMainThread(void *arg)
{
    FILE *fdes = NULL;
    int fsize = 0;
    int rsize = 0, total_rsize = 0;
    unsigned char *rbuf = NULL;
    #define BLOCK_SIZE_PER_READ     4512
    char tsname[256];

    WFD_LOG_DEBUG( "Entering %s\n", __FUNCTION__);

    /* setting hdcp keys for test */
    //hdcp2x_rx_setKeysforCryptoTest(4352, 4113);
    memset(tsname, 0, sizeof(tsname));
    if (wfd_rtsp_conf && strlen(wfd_rtsp_conf->ts_read_name))
    {
        snprintf(tsname, sizeof(tsname), "%s", wfd_rtsp_conf->ts_read_name);
    }
    else
    {
        snprintf(tsname, sizeof(tsname), "%s/%s", READ_TS_FILE_PATH, READ_TS_FILE_NAME_DEFAULT);
    }

    fdes = fopen(tsname, "rb");
    if (!fdes)
    {
        WFD_LOG_ERR( "fopen %s error!\n", tsname);
        goto ts_out;
    }
    else
        WFD_LOG_INFO( "fopen %s success\n", tsname);
    /* seek to the eof to get file len */
    if (fseek(fdes, 0, SEEK_END) < 0)
    {
        WFD_LOG_ERR( "fseek(SEEK_END) error!\n");
        goto ts_out;
    }
    fsize = ftell(fdes);
    if (fsize <= 0)
    {
        WFD_LOG_ERR( "ftell=(%d) is incorrect!\n", fsize);
        goto ts_out;
    }
    WFD_LOG_ERR( "file_len = %d\n", fsize);
    /* seek again to the beginning */
    if (fseek(fdes, 0, SEEK_SET) < 0)
    {
        WFD_LOG_ERR( "fseek(SEEK_SET) error!\n");
        goto ts_out;
    }
    rbuf = (unsigned char *)malloc(BLOCK_SIZE_PER_READ);
    if (!rbuf)
    {
        WFD_LOG_ERR( "%s: malloc error!\n", __FUNCTION__);
        goto ts_out;
    }
    while (enableReadTsFlag)
    {
        if (total_rsize + BLOCK_SIZE_PER_READ > fsize)
        {
            WFD_LOG_DEBUG( "File reach EOF (remain:%d bytes)\n", (fsize-total_rsize));
            //break;
            /* repeat track */
            /* seek again to the beginning */
            if (fseek(fdes, 0, SEEK_SET) < 0)
            {
                WFD_LOG_ERR( "fseek(SEEK_SET) error!\n");
                goto ts_out;
            }
            total_rsize = 0;
        }
        memset(rbuf, 0, BLOCK_SIZE_PER_READ);
        rsize = fread(rbuf, 1, BLOCK_SIZE_PER_READ, fdes);
        if (rsize != BLOCK_SIZE_PER_READ)
        {
            WFD_LOG_ERR( "%s: fread error, requested=%d, read=%d, total_rsize=%d (err=%s)\n",
                    __FUNCTION__, BLOCK_SIZE_PER_READ, rsize, total_rsize, strerror(errno));
            break;
        }
        /* send to CMPB */
        PushPlayer::instance().SendDataFromTsFile(rbuf, BLOCK_SIZE_PER_READ);
        total_rsize += BLOCK_SIZE_PER_READ;
        usleep(1000);
    }

    PushPlayer::instance().StopSendDataFromTsFile();
    WFD_LOG_ERR( "Exiting %s\n", __FUNCTION__);
ts_out:
    if (fdes)
        fclose(fdes);
    if (rbuf)
        free(rbuf);

    return NULL;
}

void WfdRtspClient::readTsFromFile(int aud_only)
{
    pthread_t readTsFileThread;
    pthread_attr_t ptAttr;
    struct sched_param ptSchedParam;
    int ptPolicy;

    pthread_attr_init(&ptAttr);

    PushPlayer::instance().SendDataFromTsFile_SetAudOnly(aud_only);

    ptSchedParam.sched_priority = 40;
    pthread_attr_setschedparam(&ptAttr, &ptSchedParam);
    pthread_attr_getschedpolicy(&ptAttr, &ptPolicy);
    pthread_attr_setschedpolicy(&ptAttr, SCHED_RR);
    pthread_attr_getschedpolicy(&ptAttr, &ptPolicy);

    enableReadTsFlag = 1;
    if (pthread_create(&readTsFileThread, &ptAttr, readTsMainThread, NULL) != 0)
    {
        WFD_LOG_INFO( "%s: failed to create thread\n", __FUNCTION__);
    }

}


#endif /* WFD_READ_TS_FROM_FILE */

}
