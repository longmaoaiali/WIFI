#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include "WfdRtspPlayer.h"
#include "Utils.h"
#include "myCfg.h"

using namespace rtsp;
using namespace std;

int main(int argc, char **argv)
{
    if (argc < 3)
    {
        cout<<"Usage:./wfd.bin IP PORT"<<endl;
        return 0;
    }

    string strUrl;
    string cmd;
    bool bTcp = false;
    bool bLog = false;
    bool bFile = false;
    bool bCmpb = true;
    bool bOnlyCount = false;
    bool bCmpbPlayAudio = true;
    bool bCmpbPlayVideo = true;

    strUrl = string("rtsp://") + string(argv[1]) + string(":") + string(argv[2]);
    cout<<"The Url: "<<strUrl<<endl;

    argc -= 3;
    argv++;
    argv++;
    argv++;

    while (argc > 0)
    {
        if (strcmp(argv[0], "t=1") == 0)
            bTcp = true;
        else if (strcmp(argv[0], "l=1") == 0)
            bLog = true;
        else if (strcmp(argv[0], "f=1") == 0)
            bFile = true;
        else if (strcmp(argv[0], "c=0") == 0)
            bCmpb = false;
        else if (strcmp(argv[0], "o=1") == 0)
            bOnlyCount = true;
        else if (strcmp(argv[0], "a=0") == 0)
            bCmpbPlayAudio = false;
        else if (strcmp(argv[0], "v=0") == 0)
            bCmpbPlayVideo = false;
        argc--;
        argv++;
    }

    rtsp::setLog(bLog);
    rtsp::saveLocalFile(bFile);
    rtsp::saveCmpbPlay(bCmpb);
    rtsp::setTcpFlag(bTcp);
    rtsp::setOnlyCount(bOnlyCount);
    rtsp::setCmpbPlayAudio(bCmpbPlayAudio);
    rtsp::setCmpbPlayVideo(bCmpbPlayVideo);

    init_rpc();
    WfdRtspPlayer *player = new WfdRtspPlayer();
    if (NULL == player)
    {
        cout<<"create player error!"<<endl;
        return 0;
    }

    int iRet = 0;

    while(1)
    {
        cout<<"Please input the cmd:"<<endl;
        cout<<"exit"<<endl;
        cout<<"open"<<endl;
        cout<<"play"<<endl;
        cout<<"pause"<<endl;
        cout<<"unpuase"<<endl;
        cout<<"stop"<<endl;
        cout<<"close"<<endl;
        cout<<"info"<<endl;
        cout<<"idr"<<endl;
        cout<<"standby"<<endl;
        cin>>cmd;

        if (0 == cmd.compare("exit"))
        {
            if(player->state() != WfdRtspPlayer::CLOSED)
            {
                player->stop();
                player->close();
            }
            return 0;
        }
        else if (0 == cmd.compare("open"))
        {
            iRet = player->open(strUrl);
        }
        else if (0 == cmd.compare("play"))
        {
            iRet = player->play();
        }
        else if (0 == cmd.compare("pause"))
        {
            iRet = player->pause();
        }
        else if (0 == cmd.compare("unpause"))
        {
            iRet = player->unPause();
        }
        else if (0 == cmd.compare("stop"))
        {
            iRet = player->stop();
        }
        else if (0 == cmd.compare("close"))
        {
            iRet = player->close();
        }
        else if(0 == cmd.compare("info"))
        {
            char sid[16] = {0};
            player->getRtpSessionId(sid);
            WFD_LOG_DEBUG("session id is %s", sid);
        }
        else if(0 == cmd.compare("idr"))
        {
            player->sendIDRRequest();
            WFD_LOG_DEBUG("send IDR done");
        }
        else if(0 == cmd.compare("standby"))
        {
            player->enterStandbyMode();
            WFD_LOG_DEBUG("enter standy mode");
        }
        else
        {
            //
        }

        if (0 != iRet)
        {
            cout<<"send cmd error!"<<endl;
            player->stop();
            player->close();
            return 0;
        }
    }

    return 0;
}

