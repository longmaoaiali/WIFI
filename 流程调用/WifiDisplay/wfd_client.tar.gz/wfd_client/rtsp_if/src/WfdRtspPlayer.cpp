#define WFD_LOG_TAG "WfdRtspPlayer"

#include "WfdRtspPlayer.h"
#include <assert.h>
#include <algorithm>

#include "WfdRtspClient.h"
#include "PushPlayer.h"
#include "Utils.h"
#include "ScopedMutex.h"
#include "ThreadObject.h"
#include "WFD_common.h"
#include "WFDClient.h"
#include "wfd_client_internal.h"

using namespace std;
namespace rtsp
{
WfdRtspPlayer::WfdRtspPlayer()
{
    mClient = NULL;
    mCancelNeg = false;
    mState = WfdRtspPlayer::CLOSED;
}

WfdRtspPlayer::~WfdRtspPlayer()
{
    if (mClient)
    {
        delete mClient;
        mClient = NULL;
    }

    if (mState > WfdRtspPlayer::OPENING && mState < WfdRtspPlayer::STOPPED)
    {
        if (false == PushPlayer::instance().stop())
        {

            WFD_LOG_DEBUG("WfdRtspPlayer::stop \n");
        }
    }
}

int WfdRtspPlayer::open(const std::string &url, bool fast_connection)
{
    WFD_LOG_INFO("WfdRtspPlayer::open url = %s \n", url.c_str());
    int ret = -1;

    if(mState != WfdRtspPlayer::CLOSED)
    {
        WFD_LOG_ERR("WfdRtspPlayer::open bad state %d \n", mState);
        return WFD_ERR_STATUS_NOT_MATCH;
    }

    if(url.find("rtsp://") == std::string::npos)
    {

        WFD_LOG_ERR("Error WfdRtspPlayer::open url is not correct \n");
        return WFD_ERR_INV_ARG;
    }

    mState = WfdRtspPlayer::OPENING;
    mClient = WfdRtspClient::createNew(url.c_str());
    assert(mClient != NULL);
    ret = mClient->connect(fast_connection);
    if(ret)
    {
        WFD_LOG_ERR("Error WfdRtspPlayer::open client connect failed, ret = %d \n", ret);
        return ret;
    }
#ifdef NEED_BUFFER_POOL
    MediaInfo media;
    ret = mClient->getMediaInfo(media);
    if(ret)
    {
        WFD_LOG_ERR( "Error WfdRtspPlayer::open get media info failed, ret = %d \n", ret);
        return -3;
    }

    if (false == PushPlayer::instance().SetMediaInfo(media))
    {
        WFD_LOG_ERR( "Error WfdRtspPlayer::open set media info failed \n");
        return -4;
    }
#endif
    if(mCancelNeg)
    {
        mCancelNeg = false;
        return -3;
    }
    mState = WfdRtspPlayer::OPENED;
    return WFD_OK;
}

int WfdRtspPlayer::play()
{
    WFD_LOG_ENTER();
    int ret = 0;
#ifdef CC_S_PLATFORM
    if (mState == WfdRtspPlayer::PAUSED)
    {
        return this->unPause();
    }
#endif
    ret = mClient->play();
    if(ret)
    {
#ifdef __ANDROID__
        wfd_send_command(RTSP_EVENT_PLAY_FAIL);
#endif
        WFD_LOG_ERR( "Error WfdRtspPlayer::play client play failed, ret = %d \n", ret);
        return -2;
    }

    if (false == PushPlayer::instance().play())
    {
#ifdef __ANDROID__
        wfd_send_command(RTSP_EVENT_PLAY_FAIL);
#endif
        WFD_LOG_ERR("Error WfdRtspPlayer::play PushPlayer play failed \n");
        return -1;
    }

    mState = WfdRtspPlayer::PLAYING;
#ifdef __ANDROID__
    wfd_send_command(RTSP_EVENT_PLAY_SUCCESS);
#endif
    return WFD_OK;
}

int WfdRtspPlayer::pause()
{
    WFD_LOG_ENTER();
    int ret = 0;

    ret = mClient->pause();
    if(ret)
    {
        WFD_LOG_ERR("Error WfdRtspPlayer::pause client pause faled, ret = %d \n", ret);
        return -2;
    }

#ifndef CC_S_PLATFORM // gary mark here for don't pause CMPB, just pause WFD source to stop RTP streaming
    if (false == PushPlayer::instance().pause())
    {
        WFD_LOG_ERR("Error WfdRtspPlayer::pause pushplay pause faled\n");
        return -1;
    }
#endif
    mState = WfdRtspPlayer::PAUSED;

    return WFD_OK;
}

int WfdRtspPlayer::unPause()
{
    WFD_LOG_ENTER();
    int ret = 0;
    ret = mClient->unPause();
    if(ret)
    {
        WFD_LOG_ERR("Error WfdRtspPlayer::unpause client unPause faled, ret = %d \n", ret);
        return -2;
    }
#ifndef CC_S_PLATFORM // gary mark here for don't resume CMPB, just resume WFD source to play RTP streaming
    if (false == PushPlayer::instance().resume())
    {
        WFD_LOG_ERR("Error WfdRtspPlayer::unpause PushPlayer unPause faled!\n");
        return -1;
    }
#endif

    mState = WfdRtspPlayer::PLAYING;
    return WFD_OK;
}

int WfdRtspPlayer::stop()
{
    WFD_LOG_ENTER();
    if (false == PushPlayer::instance().stop())
    {
#ifdef __ANDROID__
        wfd_send_command(RTSP_EVENT_STOP_FAIL);
#endif
        WFD_LOG_ERR( "Error WfdRtspPlayer::stop PushPlayer stop failed \n");
        return -2;
    }
    int ret = 0;
    ret = mClient->disconnect();
    if(ret)
    {
#ifdef __ANDROID__
        wfd_send_command(RTSP_EVENT_STOP_FAIL);
#endif
        WFD_LOG_ERR( "Error WfdRtspPlayer::stop client disconnect failed, ret = %d \n", ret);
        return -1;
    }

    mState = WfdRtspPlayer::STOPPED;
#ifdef __ANDROID__
    wfd_send_command(RTSP_EVENT_STOP_SUCCESS);
#endif
    return WFD_OK;
}

int WfdRtspPlayer::close()
{
    WFD_LOG_ENTER();
    if(mClient)
    {
        delete mClient;
        mClient = NULL;
    }

    mState = WfdRtspPlayer::CLOSED;
    return WFD_OK;
}

WfdRtspPlayer::State WfdRtspPlayer::state() const
{
    return mState;
}

int WfdRtspPlayer::getRtpSessionId(char * sid)
{
    WFD_LOG_ENTER();
    if (!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->getRtpSessionId(sid);
    WFD_LOG_ERR("get session id is %s\n", sid);
    return WFD_OK;
}

int WfdRtspPlayer::sendIDRRequest()
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->sendIDRRequest();
    return WFD_OK;
}

int WfdRtspPlayer::enterStandbyMode()
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->enterStandbyMode();
    return WFD_OK;
}

int WfdRtspPlayer::uibcGenEvent(int isMultiTouch)
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->uibcGenEvent(isMultiTouch);
    return WFD_OK;
}

int WfdRtspPlayer::uibcCapUpdate(char *type)
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->uibcCapUpdate(type);
    return WFD_OK;
}

int WfdRtspPlayer::rtspSigmaCmd(int cmdtype, char *data, int datalen)
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->rtspSigmaCmd(cmdtype, data, datalen);
    return WFD_OK;
}


int WfdRtspPlayer::getRtpStats(char *buf, int len)
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    return mClient->getRtpStats(buf, len);
}

#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
bool WfdRtspPlayer::sendSetParameterCmd(char * para_value)
{
    WFD_LOG_ENTER();
    if(!mClient)
    {
        WFD_LOG_ERR("client is null\n");
        return WFD_ERR_FAILED;
    }
    mClient->sendSetParameterCmd(para_value);
    return WFD_OK;
}
#endif


#ifdef CC_S_PLATFORM
void WfdRtspPlayer::setRecvBufferSize(unsigned bufferSize)
{
    mClient->setRecvBufferSize(bufferSize);
}

unsigned WfdRtspPlayer::getRecvBufferSize(void)
{
    return mClient->getRecvBufferSize();
}

void WfdRtspPlayer::setPlayBufferSize(unsigned bufferSize)
{
    mClient->setPlayBufferSize(bufferSize);
}

unsigned WfdRtspPlayer::getPlayBufferSize(void)
{
    return mClient->getPlayBufferSize();
}

void WfdRtspPlayer::setTCPPreBufferSize(unsigned bufferSize)
{
    mClient->setTCPPreBufferSize(bufferSize);
}

unsigned WfdRtspPlayer::getTCPPreBufferSize(void)
{
    return mClient->getTCPPreBufferSize();
}
#endif

int WfdRtspPlayer::cancelNegTimeout()
{
    WFD_LOG_INFO("cancelNegTimeout %d\n",mState);
    if(mState == WfdRtspPlayer::OPENING)
    {
        mCancelNeg = true;
        if(!mClient)
        {
            WFD_LOG_ERR("client is null\n");
            return WFD_ERR_FAILED;
        }
        mClient->cancelNegTimeout();
        return WFD_OK;
    }
    return WFD_OK;
}

}
