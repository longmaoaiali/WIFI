#ifndef WFD_RTSP_CLIENT_H
#define WFD_RTSP_CLIENT_H

#include <string>
#include <vector>
#include "RTSPClient.hh"
#include "Semaphore.h"
#include "Mutex.h"
#include "PushPlayer.h"

#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
#include <hdcpApp.h>
#endif
#endif

enum
{
    UIBC_CATEGORY_GENERIC = 0,
    UIBC_CATEGORY_HIDC
};

enum
{
    GENERIC_EVT_TYPE_SINGLE_TOUCH = 0,
    GENERIC_EVT_TYPE_MULTI_TOUCH,
    GENERIC_EVT_TYPE_MOUSE,
    GENERIC_EVT_TYPE_KEYBOARD,
};

enum
{
    HIDC_EVT_TYPE_KEYBOARD = 0,
    HIDC_EVT_TYPE_MOUSE
};

class UsageEnvironment;
class Authenticator;
class MediaSession;
class MediaSubsession;

namespace rtsp
{
class WfdRtspSenderInit;
class WfdRtspClient : public RTSPClient
{
public:
    static WfdRtspClient* createNew(char const* rtspURL,
                        responseHandler* handler = wfdRtspResponseHandler,
                        char const* username = NULL, char const* pwd = NULL);
    static void wfdRtspResponseHandler(RTSPClient* rtspClient,
                        int resultCode, char* resultString);
    static void wfdAfterOPTIONS(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterSetUp(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterPlay(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterPause(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterTearDown(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterIDR(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void wfdAfterStandBy(RTSPClient* rtspClient, int resultCode, char* resultString);
    static void subsessionAfterPlaying(void* clientData);
    int connect(bool fast_connection = false);
    int play();
    int pause();
    int unPause();
    int disconnect();
    int getMediaInfo(MediaInfo& media);
    int getRtpSessionId(char* sid);
    int sendIDRRequest();
    int enterStandbyMode();
    int uibcGenEvent(int isMultiTouch);
    int uibcCapUpdate(char *type);
    int rtspSigmaCmd(int cmdtype, char *data, int datalen);
    int getRtpStats(char *buf, int len);
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    bool sendSetParameterCmd(char * para_value);
#endif

    int getSourceIp(std::string& ip);
    void changeTransport(void);
#ifdef CC_S_PLATFORM
    void setRecvBufferSize(unsigned bufferSize);
    unsigned getRecvBufferSize(void);
    void setPlayBufferSize(unsigned bufferSize);
    unsigned getPlayBufferSize(void);
    void setTCPPreBufferSize(unsigned bufferSize);
    unsigned getTCPPreBufferSize(void);
#endif
    void cancelNegTimeout();
    bool startHDCP();
    bool stopHDCP();
    int waitForHDCPFinish();

    ~WfdRtspClient();

    int isInStandByMode;
    int getTimeString(char *buf, int size);
private:
    explicit WfdRtspClient(responseHandler* handler,
                        char const* rtspURL, int verbosityLevel,
                        char const* applicationName, portNumBits tunnelOverHTTPPortNum);

    int waitForOPTIONS();
    int waitForSETUPFinished();
    int waitForParameterFinished();
    int waitForM7PlayFinished();
    int waitForTearDownFinished();
    int buildTcpConnection();
    int startEventLoop();
    int replyOPTIONS(int resultCode, const char* resultString);
    int replyGET_PARAMETER(int resultCode, const char* resultString);
    int replySET_PARAMETER(int resultCode, const char* resultString);
    int replySETUP(int resultCode, const char* resultString);
    int sendOPTIONS();
    int sendSETUP();
    int sendPLAY();
    int sendPAUSE();
    int sendTEARDOWN();
    int parseResponseString(const char* respStr);
    std::string num2str(const int& num);
#ifdef WFD_READ_TS_FROM_FILE
    void readTsFromFile(int aud_only);
#endif

private:
    enum WfdState
    {
        SRC2SNK_OPTIONS             = 0,
        SNK2SRC_REPLY_OPTIONS,
        SNK2SRC_OPTIONS,
        SRC2SNK_REPLY_OPTIONS,
        SRC2SNK_GET_PARAMETER,
        SNK2SRC_REPLY_GET_PARAMETER,    // 5
        SRC2SNK_SET_PARAMETER,
        SNK2SRC_REPLY_SET_PARAMETER,
        SNK2SRC_SETUP,
        SRC2SNK_REPLY_SETUP,
        SNK2SRC_PLAY,                   // 10
        SRC2SNK_REPLY_PLAY,
        SNK2SRC_PAUSE,
        SRC2SNK_REPLY_PAUSE,
        SNK2SRC_TEARDOWN,
        SRC2SNK_REPLY_TEARDOWN,         // 15
        SNK2SRC_SET_PARAMETER,
        SNK2SRC_SET_PARAMETER_STANDBY,
        SRC2SNK_REPLY_SET_PARAMETER,
        SRC2SNK_SET_PARAMETER_STANDBY,
        UNKNOWN,
    } mState;
    Authenticator*                  mAuth;
    MediaSession*                   mSession;
    Semaphore                       mOptionsSema;
    Semaphore                       mSetupSema;
    Semaphore                       mParameterSema;
    Semaphore                       mPlaySema;
    Semaphore                       mTearDownSema;
    bool                            mIsOptionsFinished;
    bool                            mIsSetupFinished;
    bool                            mIsM7PlayFinished;
    bool                            mIsParameterFinished;
    bool                            mIsTearDownFinished;
    responseHandler*                mWfdRtspResponseHandler;
    std::string                     mUrl;
    std::string                     mIp;
    Mutex                           mLocker;
    Mutex                           mStateLocker;
    MediaInfo*                      mMediaInfo;
    volatile bool                   mCancelNeg;

private:
    void updateState(WfdState next = UNKNOWN);
    void replyReq(int iErrcode, unsigned int reqSeq);
    int closeMediaSession();

#ifdef ENABLE_HDCP2X_RX
#ifdef HDCP_ON_UTOPIA
    void* mHDCPHandle;
    ST_HDCP_MIRACAST_DATA mHDCP_miracast_data;
    static void wfd_hdcp_callback(ST_HDCP_STATUS status);
#else
    static int wfd_hdcp_callback(int event);
#endif
#endif

public:
    static bool is_hdcp_authed;
    static bool is_need_hdcp;
    static bool is_hdcp_end;
    static bool wfd_is_need_hdcp();
    static bool wfd_is_end_hdcp();
    static bool wfd_is_hdcp_authed();
    static void wfd_set_need_hdcp(bool enable);
    static void wfd_set_end_hdcp(bool enable);
    static void wfd_set_hdcp_authed(bool enable);
    static void wfd_reset_hdcp_flag();
};

}

#endif
