#ifndef WFD_RTSP_UIBC_PACKET
#define WFD_RTSP_UIBC_PACKET

#define HIDC_USB_MOUSE_VALUE_LEN        4
#define HIDC_USB_KEYBOARD_VALUE_LEN     8

#define UIBC_HDR_LEN                    4
#define UIBC_HIDC_BODY_LEN_KEYBOARD     13
#define UIBC_HIDC_BODY_LEN_MOUSE        9

namespace rtsp
{

class WfdRtspUibcPacket
{
public:
    enum UIBC_CATEGORY
    {
        UIBC_UNKNOWN = -1,
        UIBC_GENERIC,
        UIBC_HIDC,
    };

    enum GENERIC_ID
    {
        GENERIC_UNKNOWN = -1,
        LEFT_MOUSE_DOWN = 0,
        TOUCH_DOWN      = 0,
        LEFT_MOUSE_UP   = 1,
        TOUCH_UP        = 1,
        MOUSE_MOVE      = 2,
        TOUCH_MOVE      = 2,
        KEY_DOWN        = 3,
        KEY_UP,
        ZOOM,
        VERTICAL_SCROLL,
        HORIZONTAL_SCROLL,
        ROTATE,
    };

    enum HID_TYPE
    {
        HID_TYPE_KEYBOARD = 0,
        HID_TYPE_MOUSE
    };

    enum GENERIC_TYPE
    {
        GEN_TYPE_SINGLETOUCH = 0,
        GEN_TYPE_MULTITOUCH,
        GEN_TYPE_MOUSE,
        GEN_TYPE_KEYBOARD
    };

    enum HID_INPUT_PATH
    {
        HID_INPUT_PATH_INFRARED = 0,
        HID_INPUT_PATH_USB,
        HID_INPUT_PATH_BT,
        HID_INPUT_PATH_ZIGBEE,
        HID_INPUT_PATH_WIFI,
        HID_INPUT_PATH_RSVD
    };

    struct uibc_body_generic_s
    {
        unsigned char input_type_id;
        unsigned short length;
        unsigned char describe[64];
    };

    struct uibc_body_hidc_s
    {
        unsigned char input_path;
        unsigned char hid_type;
        unsigned char usage;
        unsigned short length;
        unsigned char hidc_value[64];
    };

    struct uibc_packet_hdr_s
    {
        #if 0
        unsigned short version : 3; /* version: b0~2 */
        unsigned short T : 1; /* T: b3 */
        unsigned short rsvd : 8; /* Reserved: b4~11 */
        unsigned short input_category : 4; /* Input Category: b12~15 */
        #else
        unsigned short input_category : 4; /* Input Category: b12~15 */
        unsigned short rsvd : 8; /* Reserved: b4~11 */
        unsigned short T : 1; /* T: b3 */
        unsigned short version : 3; /* version: b0~2 */
        #endif
        unsigned short length; /* Length: b16~31 */
        /* unsigned short timestamp; */ /* Timestamp(Optional): b32~47*/
    };

    struct uibc_packet_s
    {
        struct uibc_packet_hdr_s hdr;

        union
        {
            struct uibc_body_generic_s uibc_gen;
            struct uibc_body_hidc_s uibc_hidc;
        } u_body;
    };

    struct hid_keyboard_input_report_s
    {
        unsigned char modifier_keys;
        unsigned char reserved;
        unsigned char keycode1;
        unsigned char keycode2;
        unsigned char keycode3;
        unsigned char keycode4;
        unsigned char keycode5;
        unsigned char keycode6;
    };

    struct hid_mouse_input_report_s
    {
        unsigned char buttons;
        unsigned char x_disp;
        unsigned char y_disp;
        unsigned char dev_specific;
    };


    WfdRtspUibcPacket();
    ~WfdRtspUibcPacket();
    int setCategory(UIBC_CATEGORY category);
    int setGenericId(GENERIC_ID genericId);
    int setHidType(HID_TYPE hidType);
    int setGenType(GENERIC_TYPE genType);
    int setCoordinate(int x, int y);
    int setCoordinates(int x1, int y1, int x2, int y2);
    int setKeyCodes(int key1, int key2 = 0);
    int setZoom(int x, int y, int intTime, int fracTime);
    int setScrolls(int vertAmount, int horizAmount);
    int setRotate(int intPortion, int fracPortion);
    int getTranData(unsigned char* buffer, int len, void *data);

private:
    int setVersion(int version);
    int enableTimestamp(bool enabled = true);
    int reset();
    void int2uchar(const int& integer, unsigned char& char1, unsigned char& char2, unsigned char& char3, unsigned char& char4);
    int calBodyLen();

private:
    int             mVersion;
    bool            mIsTimestampEnabled;
    UIBC_CATEGORY   mCategory;
    int             mTimestamp;
    GENERIC_ID      mGenericId;
    int             mPointNum;
    int             mX1;
    int             mY1;
    int             mX2;
    int             mY2;
    int             mKey1;
    int             mKey2;
    int             mZoomX;
    int             mZoomY;
    int             mZoomIntTime;
    int             mZoomFracTime;
    int             mVScrollAmount;
    int             mHScrollAmount;
    int             mRotateInt;
    int             mRotateFrac;
    HID_TYPE        mHidType;
    GENERIC_TYPE    mGenType;
};

}
#endif
