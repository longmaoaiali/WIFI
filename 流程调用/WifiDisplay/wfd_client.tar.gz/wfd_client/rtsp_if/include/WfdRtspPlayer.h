#ifndef WFD_RTSP_PLAYER_H
#define WFD_RTSP_PLAYER_H

#include "WfdRtspClient.h"
#include "Mutex.h"

namespace rtsp
{
class WfdRtspClient;
class WfdRtspPlayer 
{
public:
    enum State
    {
        OPENING     = 0 ,
        OPENED          ,
        PLAYING         ,
        PAUSED          ,
        STOPPED         ,
        CLOSED          ,
    };
    WfdRtspPlayer();
    ~WfdRtspPlayer();
    int open(const std::string &url, bool fast_connection = false);
    int play();
    int pause();
    int unPause();
    int stop();
    int close();
    State state() const;
    int getRtpSessionId(char* sid);
    int sendIDRRequest();
    int enterStandbyMode();
    int uibcGenEvent(int isMultiTouch);
    int uibcCapUpdate(char *type);
    int rtspSigmaCmd(int cmdtype, char *data, int datalen);
    int getRtpStats(char *buf, int len);
    int cancelNegTimeout();
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    bool sendSetParameterCmd(char * para_value);
#endif

#ifdef CC_S_PLATFORM
    void setRecvBufferSize(unsigned bufferSize);
    unsigned getRecvBufferSize(void);
    void setPlayBufferSize(unsigned bufferSize);
    unsigned getPlayBufferSize(void);
    void setTCPPreBufferSize(unsigned bufferSize);
    unsigned getTCPPreBufferSize(void);
#endif

private:
    volatile State   mState;
    WfdRtspClient*   mClient;
    volatile bool                   mCancelNeg;
};
}

#endif
