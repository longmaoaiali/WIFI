#ifndef WFD_RTSP_PROTOCOL
#define WFD_RTSP_PROTOCOL

#include "Semaphore.h"
#include "Mutex.h"
#include "PushPlayer.h"
#include "WfdRtspUibcPacket.h"
#include "WfdRtspClient.h"
#include <string>
#include <queue>



/* values of wfd-connector-type */
#define WFD_CONNECTOR_TYPE_VGA                  "00"
#define WFD_CONNECTOR_TYPE_SVIDEO               "01"
#define WFD_CONNECTOR_TYPE_COMPOSITE_VIDEO      "02"
#define WFD_CONNECTOR_TYPE_COMPONENT_VIDE       "03"
#define WFD_CONNECTOR_TYPE_DVI                  "04"
#define WFD_CONNECTOR_TYPE_HDMI                 "05"
#define WFD_CONNECTOR_TYPE_RESERVED1            "06"
#define WFD_CONNECTOR_TYPE_WIFI_DISPLAY         "07"
#define WFD_CONNECTOR_TYPE_JAP_D_CONNECTOR      "08"
#define WFD_CONNECTOR_TYPE_SDI                  "09"
#define WFD_CONNECTOR_TYPE_DISPLAY_PORT         "0a"
#define WFD_CONNECTOR_TYPE_RESERVED2            "0b"
#define WFD_CONNECTOR_TYPE_UDI                  "0c"
#define WFD_CONNECTOR_TYPE_NO_ACTIVE            "fe"
#define WFD_CONNECTOR_TYPE_NONE                 "ff"

enum SEGMENTS
{
    WFD_AUDIO_CODECS        = 0,
    WFD_VIDEO_FORMATS,
    WFD_3D_FORMATS,
    WFD_CONTENT_PROTECTION,
    WFD_DISPLAY_EDID,
    WFD_COUPLED_SINK,
    WFD_CLIENT_RTP_PORTS,
    WFD_PRESENTATION_URL,
    WFD_TRIGGER_METHOD,
    WFD_UIBC_CAPABILITY,
    WFD_PREFERRED_DISPLAY_MODE,
    WFD_I2C,
    WFD_STANDBY_RESUME_CAPABILITY,
    WFD_CONNECTOR_TYPE,
    RDS_SINK_VERSION, /* For Intel's special RTSP parameter found during PF#2 */
    WFD_AV_FORMAT_CHANGE_TIMING,
    WFD_UIBC_SETTING,
    SONY_EXT_TCPSTREAM,
    SONY_EXT_02_AVC,
    SONY_EXT_03_HEVC,
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    SONY_EXT_10_VOLUMN,
#endif
    WFD_SEGMENT_MAX,
};

namespace rtsp
{

/**
 *   This class now only support for analyzing wfd_xxx .
 */
class WfdRtspProtocol
{
public:
    WfdRtspProtocol();
    ~WfdRtspProtocol();
    static WfdRtspProtocol& instance();
    int parse(const std::string& prtclStr);
    int parse(WfdRtspClient* client, const std::string& prtclStr);
    int parseI2C(const unsigned char* buffer, int length);
    int getResult(std::string& result);
    int getI2CResult(unsigned char* buffer, int bufSize);
    int getMediaInfo(MediaInfo& mediaInfo);
    int getI2CPort(unsigned int& port);
    bool isUibcEnabled() const;
    int getUibcPort(unsigned int& port);
    int getSourceIp(std::string& ip);
    std::string num2str(const unsigned int & num);
    std::string array2str(unsigned char* array, int size);
    void dumpHex(const unsigned char* hexBuffer, int length);
    int inputUibcPacket(WfdRtspUibcPacket* packet);
    int uibcGenerateEvent(int category, int eventType);
    int setAudioOnly(int audOnly);
    int mUibcGenOneEvent;
    int mUibcEventCategory;
    int mUibcEventType;


protected:

private:
    int parseToMeta(const std::string& str, const std::string& token, std::vector<std::string>& result);
    int handleWfdAudioCodecs(const std::string& str);
#ifdef MTK_WFD_4K_SUPPORT
    int handleWfd2VideoFormats(const std::string& str);
    int getIndex_4k(const char* str);
#endif
    int handleWfdVideoFormats(const std::string& str);
    int handle3DFormats(const std::string& str);
    int handleContentProtection(const std::string& str);
    int handleDisplayEdid(const std::string& str);
    int handleCoupledSink(const std::string& str);
    int handleClientRtpPorts(const std::string& str);
    int handlePresentationUrl(const std::string& str);
    int handleTriggerMethod(const std::string& str);
    int handleUibcCapability(const std::string & str);
    int handleUibcSetting(const std::string & str);
    int handlePreferredDisplayMode(const std::string & str);
    int handleI2C(const std::string & str);
    int handleStandbyResumeCapability(const std::string & str);
    int handleConnectorType(const std::string & str);
    int handleRdsSinkVersion(const std::string & str);
    int handleAVFormatChangeTiming(const std::string & str);
    int handleSONYTcpStream(const  std::string & str);
    int handleSONY4KAVC(const  std::string & str);
    int handleSONY4KHEVC(const  std::string & str);
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    int handleSONYVolumnControl(const std::string & str);
#endif
    int loadEdid();
    int getIndex(const char* str);//for note2

    UINT32 getCEAVideoFormat(UINT32 maxH, UINT32 maxW, UINT32 maxFps);
    UINT32 getVESAVideoFormat(UINT32 maxH, UINT32 maxW, UINT32 maxFps);
    UINT32 getHHVideoFormat(UINT32 maxH, UINT32 maxW, UINT32 maxFps);

private:
    enum SEGMENTS
    {
        WFD_AUDIO_CODECS        = 0,
        WFD_VIDEO_FORMATS,
        #ifdef MTK_WFD_4K_SUPPORT
        WFD2_VIDEO_FORMATS,
        #endif
        WFD_3D_FORMATS,
        WFD_CONTENT_PROTECTION,
        WFD_DISPLAY_EDID,
        WFD_COUPLED_SINK,
        WFD_CLIENT_RTP_PORTS,
        WFD_PRESENTATION_URL,
        WFD_TRIGGER_METHOD,
        WFD_UIBC_CAPABILITY,
        WFD_PREFERRED_DISPLAY_MODE,
        WFD_I2C,
        WFD_STANDBY_RESUME_CAPABILITY,
        WFD_CONNECTOR_TYPE,
        RDS_SINK_VERSION, /* For Intel's special RTSP parameter found during PF#2 */
        WFD_AV_FORMAT_CHANGE_TIMING,
        WFD_UIBC_SETTING,
        SONY_EXT_TCPSTREAM,
        SONY_EXT_02_AVC,
        SONY_EXT_03_HEVC,
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
        SONY_EXT_10_VOLUMN,
#endif
        WFD_SEGMENT_MAX,
    };

    enum State
    {
        WFD_GET_PARAMETER   = 0,
        WFD_SET_PARAMETER,
        UNKNOWN,
    } mState;

    static const char* keys[WFD_SEGMENT_MAX];

    Mutex       mLocker;
    std::string mResult;
    std::string mAudioResult;
    std::string mVideoResult;
    #ifdef MTK_WFD_4K_SUPPORT
    std::string mVideo2Result;
    #endif
    std::string mCntPrtResult;
    std::string mDisplayResult;
    std::string mCoupledSinkResult;
    std::string m3DResult;
    std::string mSONYExt01Result;
    std::string mSONYExt02Result;
    std::string mSONYExt03Result;
#ifdef CONFIG_AUDIO_VOLUMN_CONTROL_SUPPORT
    std::string mSONYExt10Result;
#endif

    std::string mUibcResult;
    std::string mPrfDisplayModeResult;
    std::string mI2CResult;
    std::string mStandbyResumeResult;
    std::string mConnectorTypeResult;
    std::string mRdsSinkVersion;
    std::string mClientRtpPortsResult;

    MediaInfo*  mMediaInfo;
    unsigned int mI2CPort;
    char        mI2CAckBuf[1024];
    int         mI2CAckLen;
    unsigned char mFakeEDID[256];
    unsigned int mUibcPort;
    bool        mIsUibcEnabled;
    WfdRtspClient* mClient;
};
}

#endif
