/*----------------------------------------------------------------------------*
 * Copyright Statement:                                                       *
 *                                                                            *
 *   This software/firmware and related documentation ("MediaTek Software")   *
 * are protected under international and related jurisdictions'copyright laws *
 * as unpublished works. The information contained herein is confidential and *
 * proprietary to MediaTek Inc. Without the prior written permission of       *
 * MediaTek Inc., any reproduction, modification, use or disclosure of        *
 * MediaTek Software, and information contained herein, in whole or in part,  *
 * shall be strictly prohibited.                                              *
 * MediaTek Inc. Copyright (C) 2010. All rights reserved.                     *
 *                                                                            *
 *   BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND     *
 * AGREES TO THE FOLLOWING:                                                   *
 *                                                                            *
 *   1)Any and all intellectual property rights (including without            *
 * limitation, patent, copyright, and trade secrets) in and to this           *
 * Software/firmware and related documentation ("MediaTek Software") shall    *
 * remain the exclusive property of MediaTek Inc. Any and all intellectual    *
 * property rights (including without limitation, patent, copyright, and      *
 * trade secrets) in and to any modifications and derivatives to MediaTek     *
 * Software, whoever made, shall also remain the exclusive property of        *
 * MediaTek Inc.  Nothing herein shall be construed as any transfer of any    *
 * title to any intellectual property right in MediaTek Software to Receiver. *
 *                                                                            *
 *   2)This MediaTek Software Receiver received from MediaTek Inc. and/or its *
 * representatives is provided to Receiver on an "AS IS" basis only.          *
 * MediaTek Inc. expressly disclaims all warranties, expressed or implied,    *
 * including but not limited to any implied warranties of merchantability,    *
 * non-infringement and fitness for a particular purpose and any warranties   *
 * arising out of course of performance, course of dealing or usage of trade. *
 * MediaTek Inc. does not provide any warranty whatsoever with respect to the *
 * software of any third party which may be used by, incorporated in, or      *
 * supplied with the MediaTek Software, and Receiver agrees to look only to   *
 * such third parties for any warranty claim relating thereto.  Receiver      *
 * expressly acknowledges that it is Receiver's sole responsibility to obtain *
 * from any third party all proper licenses contained in or delivered with    *
 * MediaTek Software.  MediaTek is not responsible for any MediaTek Software  *
 * releases made to Receiver's specifications or to conform to a particular   *
 * standard or open forum.                                                    *
 *                                                                            *
 *   3)Receiver further acknowledge that Receiver may, either presently       *
 * and/or in the future, instruct MediaTek Inc. to assist it in the           *
 * development and the implementation, in accordance with Receiver's designs, *
 * of certain softwares relating to Receiver's product(s) (the "Services").   *
 * Except as may be otherwise agreed to in writing, no warranties of any      *
 * kind, whether express or implied, are given by MediaTek Inc. with respect  *
 * to the Services provided, and the Services are provided on an "AS IS"      *
 * basis. Receiver further acknowledges that the Services may contain errors  *
 * that testing is important and it is solely responsible for fully testing   *
 * the Services and/or derivatives thereof before they are used, sublicensed  *
 * or distributed. Should there be any third party action brought against     *
 * MediaTek Inc. arising out of or relating to the Services, Receiver agree   *
 * to fully indemnify and hold MediaTek Inc. harmless.  If the parties        *
 * mutually agree to enter into or continue a business relationship or other  *
 * arrangement, the terms and conditions set forth herein shall remain        *
 * effective and, unless explicitly stated otherwise, shall prevail in the    *
 * event of a conflict in the terms in any agreements entered into between    *
 * the parties.                                                               *
 *                                                                            *
 *   4)Receiver's sole and exclusive remedy and MediaTek Inc.'s entire and    *
 * cumulative liability with respect to MediaTek Software released hereunder  *
 * will be, at MediaTek Inc.'s sole discretion, to replace or revise the      *
 * MediaTek Software at issue.                                                *
 *                                                                            *
 *   5)The transaction contemplated hereunder shall be construed in           *
 * accordance with the laws of Singapore, excluding its conflict of laws      *
 * principles.  Any disputes, controversies or claims arising thereof and     *
 * related thereto shall be settled via arbitration in Singapore, under the   *
 * then current rules of the International Chamber of Commerce (ICC).  The    *
 * arbitration shall be conducted in English. The awards of the arbitration   *
 * shall be final and binding upon both parties and shall be entered and      *
 * enforceable in any court of competent jurisdiction.                        *
 *---------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
 * Description: For Wi-Fi Display (WFD) SIGMA
 *
 *---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                    include files
-----------------------------------------------------------------------------*/
#define WFD_LOG_TAG "wfd_sigma"

#include <stdio.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <sys/socket.h> /* for socket(), connect(), send(), and recv() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include <errno.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <ctype.h>
#include <pthread.h>

#include "wfd_client_internal.h"
#include "wfd_client_export.h"

#include "WFD_common.h"
#include "Utils.h"


/*-----------------------------------------------------------------------------
                    customizable macros
----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                    macros, defines
----------------------------------------------------------------------------*/
#define MTK_WFD_SIGMA_PORT          2472
#define MTK_WFD_SIGMA_IF            "lo"
#define MTK_WFD_SIGMA_MAXPENDING    2
#define MTK_WFD_SIGMA_THREAD_NAME   "wfd_sigma"
#define MTK_WFD_SIGMA_STACK_SIZE    1024*4
#define MTK_WFD_SIGMA_THREAD_PRIO   100
#define MTK_WFD_SIGMA_TIMEOUT       5000 //ms
#define MTK_WFD_SIGMA_RCV_BUF_SIZE  1024
#define MTK_WFD_SIGMA_RSP_BUF_SIZE  1024
#define MTK_WFD_SIGMA_SCRIPT        "/3rd_rw/sigma/mtksigma_start_wfd.sh"
#define MTK_WFD_SIGMA_RESET_SCRIPT  "/3rd_rw/sigma/mtksigma_reset.sh"
#ifndef max
#define max(x, y)   ((x) >= (y) ? (x) : (y))
#endif

#define WFD_SIGMA_CMD_SIZE  sizeof(struct wfd_sigma_cmd_hdr)

#define MTK_WFD_SIGMA_START_MAX_RETRY 10
#define MTK_WFD_SIGMA_DUT_THREAD_NAME   "wfd_sigma_dut"

#define PATH_PROC_NET_DEV       "/proc/net/dev"
#define IF_BUF_SIZE             512
#define WIFI_IF_ID_MAX          WIFI_DEV_NUM
#ifndef IFNAMSIZ
    #define IFNAMSIZ            16
#endif


#define SIGLOG(x...) \
    do { \
        WFD_LOG_INFO( "[SIGMA]" x);\
    } while(0)

/*-----------------------------------------------------------------------------
                    typedefs, enums, structures
----------------------------------------------------------------------------*/
struct wfd_sigma_sockfds
{
    int *mainfd;      /* main socket fd */
    int *connfd;       /* tcp connecton socket fd */
};

struct wfd_sigma_cmd_hdr
{
    int len; /* length of the whole cmd message */
    int type; /* type of the message */
};

struct wfd_sigma_cmd
{
    struct wfd_sigma_cmd_hdr hdr;
    char data[32];
};

struct wfd_client_cli_cmd_struct
{
    int cli_type;
    int data_len;
    char data[64];
};

enum
{
    WFD_VIDEO_FORMAT_TYPE_CEA = 0,
    WFD_VIDEO_FORMAT_TYPE_VESA,
    WFD_VIDEO_FORMAT_TYPE_HH
};


/* cmd list */
enum
{
    MTK_WFD_SIGMA_CMD_INIT = 0,
    MTK_WFD_SIGMA_CMD_RTSP_START, /* Start RTSP */
    MTK_WFD_SIGMA_CMD_RTSP_PLAY, /* M7 */
    MTK_WFD_SIGMA_CMD_RTSP_PAUSE, /* M10 */
    MTK_WFD_SIGMA_CMD_RTSP_TEARDOWN, /* M9 */
    MTK_WFD_SIGMA_CMD_RTSP_SEND_IDR_REQ, /* 5 */
    MTK_WFD_SIGMA_CMD_RSP_OK, /* response OK */
    MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN, /* response Unknown error */
    MTK_WFD_SIGMA_CMD_RTSP_ENTER_STANDBY,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_SINGLE,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_MULTI, /* 10 */
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_CAP_UPDATE,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_HIDC_EVENT_KEYBOARD,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_HIDC_EVENT_MOUSE,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_ENABLE_GENERIC,
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_ENABLE_HIDC, /* 15 */
    MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_KEYBOARD,
    MTK_WFD_SIGMA_CMD_RTSP_SET_WFD_DEV_TYPE,
    MTK_WFD_SIGMA_CMD_RTSP_ENABLE_HDCP2X,
    MTK_WFD_SIGMA_CMD_RTSP_SET_VIDEO_FORMAT,
    MTK_WFD_SIGMA_CMD_RTSP_SET_AUDIO_FORMAT,
    MTK_WFD_SIGMA_CMD_RTSP_CONF_RESET,
    MTK_WFD_SIGMA_CMD_SET_SESSION_AVAIL,
    MTK_WFD_SIGMA_CMD_DISABLE_ALL,
    MTK_WFD_SIGMA_CMD_RTSP_ENABLE_STANDBY,
    MTK_WFD_SIGMA_CMD_RTSP_ENABLE_I2C,
    MTK_WFD_SIGMA_CMD_RTSP_ENABLE_EDID,
    /* add new sigma cmds above this comment */
    MTK_WFD_SIGMA_CMD_WFD_CLIENT_CLI,
    MTK_WFD_SIGMA_CMD_MAX
};

enum
{
    WFD_CLI_CMD_SHOW_STATS = 0,
    WFD_CLI_CMD_DUMPTS_SET_NAME,
    WFD_CLI_CMD_DUMPTS_ENABLE,
    WFD_CLI_CMD_RTSP_START_IP_PORT,
    WFD_CLI_CMD_SET_TS_FILENAME,
    WFD_CLI_CMD_RTSP_PAUSE, /* 5 */
    WFD_CLI_CMD_RTSP_STOP,
 #ifdef CC_S_PLATFORM
    /* For SONY FY16 */
    WFD_CLI_CMD_AVSYNC_FREERUN,             /* avsync freerun */

    WFD_CLI_CMD_RECEIVE_BUFFER,             /* recvbuffer */
    WFD_CLI_CMD_DECODE_BUFFER,              /* decbuffer */
    WFD_CLI_CMD_TCPPRE_BUFFER,              /* tcpprebuffer */

    WFD_CLI_CMD_STREAM_DUMP_START,          /* streamdump /xxx/dumpts.bin */
    WFD_CLI_CMD_STREAM_DUMP_STOP,           /* streamdump stop */
    WFD_CLI_CMD_STREAM_DUMP_STATUS,         /* streamdump status */
    WFD_CLI_CMD_STREAM_DUMP_PATH,           /* streamdump path */

    WFD_CLI_CMD_WFD_RTSP_PAUSE,             /* rtsp pause */
    WFD_CLI_CMD_WFD_RTSP_PLAY,              /* rtsp play */
 #endif
    WFD_CLI_CMD_MAX
};


/*-----------------------------------------------------------------------------
                    function declarations
----------------------------------------------------------------------------*/
struct timeval *wfd_sigma_set_timer(int secs, int usecs, struct timeval *tv);
static int wfd_sigma_get_if_addr(char *ifname, struct sockaddr_in *sa);
static int wfd_sigma_accept_tcp_conn(int servSock);
static int wfd_sigma_set_sockfd(fd_set *fdset, int *maxfdn1, struct wfd_sigma_sockfds *fds);
//static void wfd_sigma_dump(char *buf, int len);
static int wfd_sigma_send(int sock, char *buf, int bufLen);
static int wfd_sigma_cmd_process(char *buf, int bufLen);
static int wfd_sigma_cmd_process_init(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_start(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_play(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_pause(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_teardown(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_sendIdrReq(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_enterStandby(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcGenEventMulti(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcGenEventSingle(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcCapUpdate(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcHidcEventKeyboard(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcHidcEventMouse(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_start_wfa_dut(void);
static int wfd_sigma_cmd_process_rtsp_uibcCapEnableHidc(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcCapEnableGeneric(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_uibcGenEventKeyboard(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_setWfdDevType(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_enableHdcp2x(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_setVideoFormat(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_confReset(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_setSessionAvail(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_sigmaDisableAll(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_enableStandby(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_enableI2c(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_rtsp_enableEdid(struct wfd_sigma_cmd *cmdP);
static int wfd_sigma_cmd_process_wfd_client_cli(struct wfd_sigma_cmd *cmdP);
static void wfd_sigma_main(void * pvArg);
static int wfd_sigma_thread_create(pthread_t *pid, void *(*start_routine)(void*), void *argv);
static void wfd_sigma_cmd_wfd_cli_show_stats(void);
static int wfd_sigma_cmd_wfd_cli_dumpts_set_name(char *tsname);
static int wfd_sigma_cmd_wfd_cli_dumpts_set_enable(int enable);
static int wfd_sigma_cmd_wfd_cli_rtsp_start_ip_port(char *ip,char *port);
static int wfd_sigma_cmd_wfd_cli_set_st_filename(char *tsname);
void wfd_sigma_execute_shell_cmd(char *s_cmd);


/*-----------------------------------------------------------------------------
                    externed functions
----------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
                    global variables
----------------------------------------------------------------------------*/
int mtkWfdSigmaSockFd = -1;
int mtkWfdSigmaConnSockFd = -1;
int wfdSigmaExitFlag = 0;

static int mtkWfdSigmaStarted = 0;
static int mtkWfdSigmaWfaDutStartInProgress = 0;

int wfd_sigma_start(void)
{
    pthread_t h_wfd_sigma_thread;

    if (mtkWfdSigmaStarted)
    {
        SIGLOG("MTK-Sigma already started ....\n");
        return 0;
    }
    if (wfd_sigma_thread_create((pthread_t *)&h_wfd_sigma_thread,
                        (void *)&wfd_sigma_main,
                        NULL) != 0)
    {
        SIGLOG("Sigma thread create failed!\n");
        return (-1);
    }
    mtkWfdSigmaStarted = 1;
    return 0;

}


static void wfd_sigma_main(void * pvArg)
{
    int ret = 0;
    int maxfdn1 = -1;
    fd_set fdset;
    int nfds = 0;
    struct sockaddr_in servAddr; /* Local address */
    const int on = 1;
    struct wfd_sigma_sockfds sigma_fds;
    struct timeval toutvalp, *tovalp; /* Timeout for select() */
    char *recvBuf = NULL;
    int recvBytes = 0;

    SIGLOG("Sigma thread is running\n");
    /* Create socket for incoming connections */
    if ((mtkWfdSigmaSockFd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    {
        SIGLOG("%s: socket failed\n", __FUNCTION__);
        ret = -1;
        goto wfd_sigma_out;
    }
    /* Construct local address structure */
    memset(&servAddr, 0, sizeof(servAddr));
    wfd_sigma_get_if_addr(MTK_WFD_SIGMA_IF, &servAddr);
    servAddr.sin_family = AF_INET;        /* Internet address family */
    //servAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    servAddr.sin_port = htons(MTK_WFD_SIGMA_PORT);              /* Local port */

    setsockopt(mtkWfdSigmaSockFd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

    /* Bind to the local address */
    if (bind(mtkWfdSigmaSockFd, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0)
    {
        SIGLOG("%s: bind failed\n", __FUNCTION__);
        ret = -1;
        goto wfd_sigma_out;
    }

    /* Mark the socket so it will listen for incoming connections */
    if (listen(mtkWfdSigmaSockFd, MTK_WFD_SIGMA_MAXPENDING) < 0)
    {
        SIGLOG("%s: listen failed\n", __FUNCTION__);
        ret = -1;
        goto wfd_sigma_out;
    }

    SIGLOG("Sigma connection opened\n");

    /* execute start script for wfd sigma */
    //SIGLOG("Executing [%s]\n");
    //system(MTK_WFD_SIGMA_SCRIPT);

    SIGLOG("Start to receive...\n");

    recvBuf = malloc(MTK_WFD_SIGMA_RCV_BUF_SIZE);
    if (!recvBuf)
    {
        SIGLOG("%s: malloc failed\n", __FUNCTION__);
        ret = -1;
        goto wfd_sigma_out;
    }

    wfd_sigma_start_wfa_dut();
    while (!wfdSigmaExitFlag)
    {
        sigma_fds.mainfd = &mtkWfdSigmaSockFd;
        sigma_fds.connfd = &mtkWfdSigmaConnSockFd;
        wfd_sigma_set_sockfd(&fdset, &maxfdn1, &sigma_fds);
        nfds = 0;
        memset(&toutvalp, 0, sizeof(struct timeval));
        tovalp = wfd_sigma_set_timer(2, 0, &toutvalp);

        if ( (nfds = select(maxfdn1, &fdset, NULL, NULL, tovalp)) < 0)
        {
            if (errno == EINTR)
                continue;        /* back to for() */
            else
                SIGLOG("%s: select failed\n", __FUNCTION__);
        }
        if (nfds == 0)
        {
            //SIGLOG("%s: select timeout\n", __FUNCTION__);
            //SIGLOG("%s: waiting for wfa_dut command...\n", __FUNCTION__);
            continue;
        }
        if (FD_ISSET(mtkWfdSigmaSockFd, &fdset))
        {
            /* Incoming connection request */
            mtkWfdSigmaConnSockFd = wfd_sigma_accept_tcp_conn(mtkWfdSigmaSockFd);
            if(mtkWfdSigmaConnSockFd == -1)
            {
                SIGLOG("%s: Failed to open control link socket\n", __FUNCTION__);
                continue;
            }
        }

        /* Control Link port event*/
        if(mtkWfdSigmaConnSockFd >= 0 && FD_ISSET(mtkWfdSigmaConnSockFd, &fdset))
        {
            memset(recvBuf, 0, MTK_WFD_SIGMA_RCV_BUF_SIZE);
            recvBytes = recv(mtkWfdSigmaConnSockFd, recvBuf, MTK_WFD_SIGMA_RCV_BUF_SIZE, 0);
            if (recvBytes < 0)
            {
                SIGLOG("%s: Error at recv\n", __FUNCTION__);
                continue;
            }
            else if (recvBytes == 0)
            {
                SIGLOG("%s: dut socket is closed\n", __FUNCTION__);
                mtkWfdSigmaConnSockFd = -1;
                continue;
            }
            SIGLOG("%s: --- Received cmd from sigma dut, length=%d ---\n", __FUNCTION__, recvBytes);
            wfd_sigma_cmd_process(recvBuf, recvBytes);

        }

    } /* while() */

    ret = 0;

 wfd_sigma_out:

    SIGLOG("Sigma thread is terminated\n");
    if (mtkWfdSigmaSockFd != -1)
    {
        close(mtkWfdSigmaSockFd);
        mtkWfdSigmaSockFd = -1;
    }
    if (mtkWfdSigmaConnSockFd != -1)
    {
        close(mtkWfdSigmaConnSockFd);
        mtkWfdSigmaConnSockFd = -1;
    }
    if (recvBuf)
        free(recvBuf);

    wfdSigmaExitFlag = 0;
    mtkWfdSigmaStarted = 0;

    return;
}

static int wfd_sigma_cmd_process(char *buf, int bufLen)
{
    struct wfd_sigma_cmd *cmdP = NULL;
    int cmdType = -1;
    int ret = 0;

    if (!buf || !bufLen)
        return -1;

    //wfd_sigma_dump(buf, bufLen);

    cmdP = (struct wfd_sigma_cmd *)buf;
    SIGLOG("%s: cmd->type = %d, len=%d\n", __FUNCTION__, cmdP->hdr.type, cmdP->hdr.len);
    cmdType = cmdP->hdr.type;
    switch (cmdType)
    {
        case (MTK_WFD_SIGMA_CMD_INIT):
            wfd_sigma_cmd_process_init(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_START):
            wfd_sigma_cmd_process_rtsp_start(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_PLAY):
            wfd_sigma_cmd_process_rtsp_play(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_PAUSE):
            wfd_sigma_cmd_process_rtsp_pause(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_TEARDOWN):
            wfd_sigma_cmd_process_rtsp_teardown(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_SEND_IDR_REQ):
            wfd_sigma_cmd_process_rtsp_sendIdrReq(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_ENTER_STANDBY):
            wfd_sigma_cmd_process_rtsp_enterStandby(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_SINGLE):
            wfd_sigma_cmd_process_rtsp_uibcGenEventSingle(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_KEYBOARD):
            wfd_sigma_cmd_process_rtsp_uibcGenEventKeyboard(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_GEN_EVENT_MULTI):
            wfd_sigma_cmd_process_rtsp_uibcGenEventMulti(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_HIDC_EVENT_KEYBOARD):
            wfd_sigma_cmd_process_rtsp_uibcHidcEventKeyboard(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_HIDC_EVENT_MOUSE):
            wfd_sigma_cmd_process_rtsp_uibcHidcEventMouse(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_CAP_UPDATE):
            wfd_sigma_cmd_process_rtsp_uibcCapUpdate(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_ENABLE_HIDC):
            wfd_sigma_cmd_process_rtsp_uibcCapEnableHidc(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_UIBC_ENABLE_GENERIC):
            wfd_sigma_cmd_process_rtsp_uibcCapEnableGeneric(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_SET_WFD_DEV_TYPE):
            wfd_sigma_cmd_process_rtsp_setWfdDevType(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_ENABLE_HDCP2X):
            wfd_sigma_cmd_process_rtsp_enableHdcp2x(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_SET_VIDEO_FORMAT):
            wfd_sigma_cmd_process_rtsp_setVideoFormat(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_SET_AUDIO_FORMAT):
            //wfd_sigma_cmd_process_rtsp_setAudioFormat(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_CONF_RESET):
            wfd_sigma_cmd_process_rtsp_confReset(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_SET_SESSION_AVAIL):
            wfd_sigma_cmd_process_rtsp_setSessionAvail(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_DISABLE_ALL):
            wfd_sigma_cmd_process_rtsp_sigmaDisableAll(cmdP);
            break;

        case (MTK_WFD_SIGMA_CMD_RTSP_ENABLE_STANDBY):
            wfd_sigma_cmd_process_rtsp_enableStandby(cmdP);
            break;
        case (MTK_WFD_SIGMA_CMD_RTSP_ENABLE_I2C):
            wfd_sigma_cmd_process_rtsp_enableI2c(cmdP);
            break;
        case (MTK_WFD_SIGMA_CMD_RTSP_ENABLE_EDID):
            wfd_sigma_cmd_process_rtsp_enableEdid(cmdP);
            break;
        case (MTK_WFD_SIGMA_CMD_WFD_CLIENT_CLI):
            wfd_sigma_cmd_process_wfd_client_cli(cmdP);
            break;

        default:
            SIGLOG("%s: Received unknown cmd->type = %d, len=%d\n",
                __FUNCTION__, cmdP->hdr.type, cmdP->hdr.len);
            ret = -1;
            break;
    }
    sleep(1);

    return ret;
}

static int wfd_sigma_thread_create(pthread_t *pid, void *(*start_routine)(void*), void *argv)
{
    int res;

    res = pthread_create((pthread_t *)pid, NULL, start_routine, argv);
    if (res < 0)
    {
        SIGLOG("pthread_create error\n");
        return -1;
    }

    return 0;
}


int wfd_sigma_init_wfd(void)
{
    if (wfd_client_start(NULL) != 0)
    {
        SIGLOG("Failed to start wfd client\n");
        return -1;
    }
    return 0;
}


static int wfd_sigma_cmd_process_init(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_sigma_init_wfd() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_start(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char ip_str[24] = "";
    char port_str[8] = "";
    int rtsp_port = 0;
    char *ptr1 = NULL, *ptr2=NULL;
    char sid[128];

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    /* Parse the data format as:
            ip_addr_string:port:
        example:
            192.168.1.100:554:
    */
    ptr1 = strchr(cmdP->data, ':');
    if (!ptr1)
    {
        SIGLOG("%s, ip address not found\n", __FUNCTION__);
        return -1;
    }
    strncpy(ip_str, cmdP->data, ptr1 - cmdP->data);
    ptr1++;
    ptr2 = strchr(ptr1, ':');
    if (!ptr2)
    {
        SIGLOG("%s, port not found\n", __FUNCTION__);
        return -1;
    }
    strncpy(port_str, ptr1, ptr2 - ptr1);
    rtsp_port = atoi(port_str);
    SIGLOG("ipaddr=[%s], port=[%d]\n", ip_str, rtsp_port);
    if (wfd_client_rtsp_start(ip_str, rtsp_port, 0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
        rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    }
    else
    {
        /* send back with RTP session Id */
        char *pSessionId = NULL;
        pSessionId = (char *)wfd_client_get_rtpSessionId();
        if (!pSessionId)
        {
            SIGLOG("%s: fail to get session id\n", __FUNCTION__);
            rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
            rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
        }
        else
        {
            memset(sid, 0, sizeof(sid));
            strncpy(sid, pSessionId, sizeof(sid)-1);
            /* rtp session id is stored as
                [session-id]:
             */
            SIGLOG("%s: session id=[%s]\n", __FUNCTION__, sid);
            snprintf(rcmdP->data, sizeof(rcmdP->data), "%s:", sid);
            rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + strlen(rcmdP->data) + 1;
            rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;
        }
    }

    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_play(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_play() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}


static int wfd_sigma_cmd_process_rtsp_pause(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_pause() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_teardown(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_stop() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_sendIdrReq(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_send_IDRReq() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}


static int wfd_sigma_cmd_process_rtsp_enterStandby(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_enter_standby_mode() != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}


static int wfd_sigma_cmd_process_rtsp_uibcGenEventSingle(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_uibc_gen_event(0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_uibcGenEventKeyboard(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_sigma_cmd(WFD_RTSP_SIGMA_CMD_GEN_EVT_KEYBOARD, NULL, 0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_uibcGenEventMulti(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_uibc_gen_event(1) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_uibcHidcEventKeyboard(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_sigma_cmd(WFD_RTSP_SIGMA_CMD_HIDC_EVT_KEYBOARD, NULL, 0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_uibcHidcEventMouse(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[256];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_sigma_cmd(WFD_RTSP_SIGMA_CMD_HIDC_EVT_MOUSE, NULL, 0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_uibcCapUpdate(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char cap[64] = "";

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    /* Parse the data format as:
        Mouse
        Keyboard
        SingleTouch
        ...etc
        Only one type is carried.
    */
    strncpy(cap, cmdP->data, sizeof(cap)-1);
    SIGLOG("Uibc Cap Update, Type=[%s]\n", cap);
    if (wfd_client_uibc_cap_update(cap))
    {
        SIGLOG("%s: Uibc Cap Update Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}


static int wfd_sigma_cmd_process_rtsp_uibcCapEnableHidc(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char cap[64] = "";
    int captype = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(cap, cmdP->data, sizeof(cap)-1);
    captype = WFD_UIBC_CAP_HIDC;
    SIGLOG("Uibc Cap Enable = HIDC\n");
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_UIBC_CAP_TYPE, &captype, sizeof(captype)) != 0)
    {
        SIGLOG("%s: Uibc Cap Enable Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_uibcCapEnableGeneric(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char cap[64] = "";
    int captype = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(cap, cmdP->data, sizeof(cap)-1);
    SIGLOG("Uibc Cap Enable = Generic\n");
    captype = WFD_UIBC_CAP_GENERIC;
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_UIBC_CAP_TYPE, &captype, sizeof(captype)) != 0)
    {
        SIGLOG("%s: Uibc Cap Enable Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}

static int wfd_sigma_cmd_process_rtsp_setWfdDevType(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int i4_ret = 0;
    int enableAudOnly = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("WfdDevType is set to %s\n", str);
    /* if Secondary-Sink (audio-only) device */
    if (strcasecmp(str, "S-Sink") == 0)
    {
        enableAudOnly = 1;
    }
    else /* if Primary-sink (av-capable) device */
    {
        enableAudOnly = 0;
    }
    i4_ret = wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_AUDIO_ONLY, &enableAudOnly, sizeof(enableAudOnly));

    if (i4_ret != 0)
    {
        SIGLOG("%s: Set WfdDevType Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
    {
        {
            /* Issue private commands to set WfdDevType to driver */
            char cmdstr[64];
            memset(cmdstr, 0, sizeof(cmdstr));
            if (enableAudOnly)
                snprintf(cmdstr, sizeof(cmdstr), "iwpriv ra0 set WfdDevType=2");
            else
                snprintf(cmdstr, sizeof(cmdstr), "iwpriv ra0 set WfdDevType=1");
            wfd_sigma_execute_shell_cmd(cmdstr);
        }
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;
    }

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_enableHdcp2x(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int enable = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("HDCP2.X is set to %s\n", str);
    if (strcasecmp(str, "enable") == 0)
        enable = 1;
    else
        enable = 0;
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_HDCP2X_ENABLE, &enable, sizeof(enable)) != 0)
    {
        SIGLOG("%s: Set HDCP Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_setVideoFormat(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    unsigned char *vidFmt = NULL;
    int vidFmtSize = 0;

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    vidFmtSize = (int)cmdP->data[0];
    vidFmt = (unsigned char *)&cmdP->data[1];
    SIGLOG("Set Video Format (size=%d)\n", vidFmtSize);

    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_VIDEO_FORMAT, vidFmt, vidFmtSize) != 0)
    {
        SIGLOG("%s: Set Video Format Failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_setSessionAvail(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int enabled = 0;
    char cmdstr[64];

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("Session Available bit is set to %s\n", str);
    if (strcasecmp(str, "enable") == 0)
    {
        enabled = 1;
    }
    memset(cmdstr, 0, sizeof(cmdstr));
    if (enabled)
         snprintf(cmdstr, sizeof(cmdstr), "iwpriv ra0 set WfdSessionAvail=1");
    else
         snprintf(cmdstr, sizeof(cmdstr), "iwpriv ra0 set WfdSessionAvail=0");

    wfd_sigma_execute_shell_cmd(cmdstr);

    rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;
    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_enableStandby(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int enable = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("Standby feature is set to %s\n", str);
    if (strcasecmp(str, "enable") == 0)
        enable = 1;
    else
        enable = 0;
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_STANDBY_ENABLE, &enable, sizeof(enable)) != 0)
    {
        SIGLOG("%s: Set Standby mode failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_enableI2c(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int enable = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("I2C feature is set to %s\n", str);
    if (strcasecmp(str, "enable") == 0)
        enable = 1;
    else
        enable = 0;
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_I2C_ENABLE, &enable, sizeof(enable)) != 0)
    {
        SIGLOG("%s: Set I2C mode failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_enableEdid(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;
    char str[64] = "";
    int enable = 0;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;

    strncpy(str, cmdP->data, sizeof(str)-1);
    SIGLOG("EDID feature is set to %s\n", str);
    if (strcasecmp(str, "enable") == 0)
        enable = 1;
    else
        enable = 0;

    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_EDID_ENABLE, &enable, sizeof(enable)) != 0)
    {
        SIGLOG("%s: Set EDID mode failed!\n", __FUNCTION__);
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_wfd_client_cli(struct wfd_sigma_cmd *cmdP)
{
    /* Remark: This cmd is created to be used by some platforms that do not have
               a CLI interface to issue wfd CLI cmds. For example, Android platform
               does not have MTK CLI interface.
               With this new sigma cmd, we can create a test program to issue cmds to
               this sigma thread, and pass to wfd_client module to achieve the same
               way as CLI does.
     */
        char rbuf[512];
        struct wfd_sigma_cmd *rcmdP = NULL;
        struct wfd_client_cli_cmd_struct    *cli_p = NULL;

        cli_p = (struct wfd_client_cli_cmd_struct *)(cmdP->data);
        if (!cli_p) return -1;
        SIGLOG("Enter [android] %s\n", __FUNCTION__);

        #ifdef CC_S_PLATFORM
        memset(rbuf, 0, sizeof(rbuf));
        rcmdP = (struct wfd_sigma_cmd *)&rbuf;
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;
        rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 4;
        #endif

        switch (cli_p->cli_type)
        {
            case (WFD_CLI_CMD_SHOW_STATS):
            {
                wfd_sigma_cmd_wfd_cli_show_stats();
                break;
            }
            case (WFD_CLI_CMD_DUMPTS_SET_NAME):
            {
                char tsname[128];
                memset(tsname, 0, sizeof(tsname));
                strncpy(tsname, cli_p->data, sizeof(tsname)-1);
                if (wfd_sigma_cmd_wfd_cli_dumpts_set_name(tsname) != 0)
                    SIGLOG("%s: Set ts name failed!\n", __FUNCTION__);
                break;
            }
            case (WFD_CLI_CMD_DUMPTS_ENABLE):
            {
                int dump_enable = 0;
                memcpy((char *)&dump_enable, cli_p->data, sizeof(dump_enable));
                SIGLOG("%s: Dump TS enable = %d\n", __FUNCTION__, dump_enable);
                if (wfd_sigma_cmd_wfd_cli_dumpts_set_enable(dump_enable) != 0)
                    SIGLOG("%s: Set ts enable(=%d) failed!\n", __FUNCTION__, dump_enable);
                break;
            }
            case (WFD_CLI_CMD_RTSP_START_IP_PORT):
            {

                char ip_str[24] = "";
                char port_str[8] = "";
                //int rtsp_port = 0;
                char *ptr1 = NULL;

                ptr1 = strchr(cli_p->data, ':');
                if (!ptr1)
                {
                    SIGLOG("%s, ip address not found\n", __FUNCTION__);
                    return -1;
                }
                strncpy(ip_str, cli_p->data, ptr1 - cli_p->data);

                //strncpy(port_str, (ptr1+1), sizeof(cli_p->data));
                strncpy(port_str, (ptr1+1), sizeof(cli_p->data) - (ptr1 + 1 - cli_p->data));

                //rtsp_port = atoi(port_str);
                SIGLOG("%s, ipaddr=[%s], port=[%s]\n", __FUNCTION__, ip_str, port_str);
                if (wfd_sigma_cmd_wfd_cli_rtsp_start_ip_port(ip_str, port_str) != 0)
                {
                    SIGLOG("%s: rtsp start ip port failed!\n", __FUNCTION__);
                }
                break;
            }
            case (WFD_CLI_CMD_SET_TS_FILENAME):
            {
                char tsname[128];
                memset(tsname, 0, sizeof(tsname));
                strncpy(tsname, cli_p->data, sizeof(tsname)-1);
                if (wfd_sigma_cmd_wfd_cli_set_st_filename(tsname) != 0)
                    SIGLOG("%s: Set play dumped filename failed!\n", __FUNCTION__);
                break;
            }
          #ifdef CC_S_PLATFORM
            case (WFD_CLI_CMD_AVSYNC_FREERUN):
            {
                /* TODO: */
                int ret = 0;
                int avsync_freerun = -1;

                memcpy((char *)&avsync_freerun, cli_p->data, sizeof(avsync_freerun));

                if (avsync_freerun > 0)
                {
                    ret = wfd_client_avsync_set_freerun(1);
                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else if (avsync_freerun == 0)
                {
                    ret = wfd_client_avsync_set_freerun(0);
                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else
                {
                    ret = wfd_client_avsync_get_freerun();
                    rcmdP->data[0] = ret;
                    rcmdP->data[1] = ret;   // add a data for increase the rsp length
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1 + 1;
                }
                break;
            }

            case (WFD_CLI_CMD_RECEIVE_BUFFER):
            {
                /* TODO: */
                int ret = 0;
                int buff_size = -1;

                memcpy((char *)&buff_size, cli_p->data, sizeof(buff_size));

                if (buff_size >= 0)
                {
                    /* Set stream receive buffer size from buff_size */
                    // TODO:
                    wfd_client_set_recv_buffer_size(buff_size);

                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else
                {
                    /* Get stream receive buffer size to buff_size */
                    char num_str[16];

                    // TODO:
                    buff_size = wfd_client_get_recv_buffer_size();

                    memset(num_str, 0, sizeof(num_str));
                    snprintf(num_str, sizeof(num_str), "%d", buff_size);
                    snprintf(num_str, sizeof(num_str), "%d", buff_size);

                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + strlen(num_str) + 1;
                }
                break;
            }
            case (WFD_CLI_CMD_DECODE_BUFFER):
            {
                /* TODO: */
                int ret = 0;
                int buff_size = -1;

                memcpy((char *)&buff_size, cli_p->data, sizeof(buff_size));

                if (buff_size >= 0)
                {
                    /* Set stream play buffer size from buff_size */
                    // TODO:
                    wfd_client_set_play_buffer_size(buff_size);

                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else
                {
                    /* Get stream play buffer size to buff_size */
                    char num_str[16];

                    // TODO:
                    buff_size = wfd_client_get_play_buffer_size();

                    memset(num_str, 0, sizeof(num_str));
                    snprintf(num_str, sizeof(num_str), "%d", buff_size);
                    strncpy(rcmdP->data, num_str, sizeof(num_str));

                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + strlen(num_str) + 1;
                }
                break;
            }
            case (WFD_CLI_CMD_TCPPRE_BUFFER):
            {
                /* TODO: */
                int ret = 0;
                int buff_size = -1;

                memcpy((char *)&buff_size, cli_p->data, sizeof(buff_size));

                if (buff_size >= 0)
                {
                    /* Set stream TCP pre-buffer size from buff_size */
                    // TODO:
                    wfd_client_set_tcp_pre_buffer_size(buff_size);

                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else
                {
                    /* Get stream TCP pre-buffer size to buff_size */
                    char num_str[16];

                    // TODO:
                    buff_size = wfd_client_get_tcp_pre_buffer_size();

                    memset(num_str, 0, sizeof(num_str));
                    snprintf(num_str, sizeof(num_str), "%d", buff_size);
                    strncpy(rcmdP->data, num_str, sizeof(num_str));

                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + strlen(num_str) + 1;
                }
                break;
            }

            case (WFD_CLI_CMD_STREAM_DUMP_START):
            {
                int ret = 0;
                char tsname[256];
                memset(tsname, 0, sizeof(tsname));
                strncpy(tsname, cli_p->data, sizeof(tsname)-1);
                ret = wfd_client_dump_ts_start(tsname);
                if (ret != 0)
                    SIGLOG("%s: streamdump start failed!\n", __FUNCTION__);
                rcmdP->data[0] = ret;
                rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                break;
            }

            case (WFD_CLI_CMD_STREAM_DUMP_STOP):
            {
                int ret = 0;
                ret = wfd_client_dump_ts_stop();
                if (ret != 0)
                    SIGLOG("%s: streamdump stop failed!\n", __FUNCTION__);
                rcmdP->data[0] = ret;
                rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                break;
            }

            case (WFD_CLI_CMD_STREAM_DUMP_STATUS):
            {
                int status = wfd_client_dump_ts_is_enable();
                rcmdP->data[0] = status;
                rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                break;
            }

            case (WFD_CLI_CMD_STREAM_DUMP_PATH):
            {
                int ret = 0;
                char path[512];

                memset(path, 0, sizeof(path));
                ret = wfd_client_dump_ts_get_path(path);
                if (ret != 0)
                {
                    SIGLOG("%s: streamdump get path failed!\n", __FUNCTION__);
                    rcmdP->data[0] = ret;
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                }
                else
                {
                    memset(rcmdP->data, 0, sizeof(rcmdP->data));
                    strncpy(rcmdP->data, path, sizeof(rcmdP->data) - 1);
                    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + strlen(rcmdP->data) + 1;
                }
                break;
            }

            case (WFD_CLI_CMD_WFD_RTSP_PAUSE):
            {
                int ret = 0;

                ret = wfd_client_rtsp_pause();
                if (ret != 0)
                    SIGLOG("%s: RTSP pause failed!\n", __FUNCTION__);

                rcmdP->data[0] = ret;
                rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                break;
            }
            case (WFD_CLI_CMD_WFD_RTSP_PLAY):
            {
                int ret = 0;

                ret = wfd_client_rtsp_play();
                if (ret != 0)
                    SIGLOG("%s: RTSP play failed!\n", __FUNCTION__);

                rcmdP->data[0] = ret;
                rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE + 1;
                break;
            }
          #endif

            default:
                SIGLOG("Unknown CLI type, cli_type = %d,cli_data = %s,data_len = %d\n",cli_p->cli_type,cli_p->data,cli_p->data_len);
                break;
        }
     #ifndef CC_S_PLATFORM
        memset(rbuf, 0, sizeof(rbuf));
        rcmdP = (struct wfd_sigma_cmd *)&rbuf;
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;
        rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
     #endif
        /* send rsp */
        wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);
        return 0;
}

static int wfd_sigma_cmd_process_rtsp_confReset(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[140];
    struct wfd_sigma_cmd *rcmdP = NULL;

    SIGLOG("%s\n", __FUNCTION__);
    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;


    wfd_client_rtsp_conf_reset();
    rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;
}

static int wfd_sigma_cmd_process_rtsp_sigmaDisableAll(struct wfd_sigma_cmd *cmdP)
{
    char rbuf[64];
    struct wfd_sigma_cmd *rcmdP = NULL;

    memset(rbuf, 0, sizeof(rbuf));
    rcmdP = (struct wfd_sigma_cmd *)&rbuf;
    if (wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_SIGMA_DISABLE_ALL, NULL, 0) != 0)
    {
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_ERROR_UNKNOWN;
    }
    else
        rcmdP->hdr.type = MTK_WFD_SIGMA_CMD_RSP_OK;

    rcmdP->hdr.len = WFD_SIGMA_CMD_SIZE+4;
    /* send rsp */
    wfd_sigma_send(mtkWfdSigmaConnSockFd, rbuf, rcmdP->hdr.len);

    return 0;

}


static int wfd_sigma_send(int sock, char *buf, int bufLen)
{
    int bytesSent = 0;
    if(bufLen == 0)
        return 0;

    bytesSent = send(sock, buf, bufLen, 0);

    if(bytesSent == -1)
    {
        SIGLOG("%s: Error at send\n", __FUNCTION__);
    }

    return bytesSent;
}

/*
static void wfd_sigma_dump(char *buf, int len)
{
    int pos = 0;
    if (!buf)
        return;

    fprintf(stderr, "Dumping buf (len=%d):\n---------", len);
    while(pos < len)
    {
        if (pos%8 == 0)
        {
            fprintf(stderr,"\n%04d| ", pos);
        }
        fprintf(stderr, "%02x ", buf[pos]);
        pos ++;
    }
    fprintf(stderr, "\n---------\n");
}
*/

static int wfd_sigma_accept_tcp_conn(int servSock)
{
    int clntSock;                /* Socket descriptor for client */
    struct sockaddr_in clntAddr; /* Client address */
    socklen_t clntLen;        /* Length of client address data structure */

    /* Set the size of the in-out parameter */
    clntLen = sizeof(clntAddr);

    /* Wait for a client to connect */
    if ((clntSock = accept(servSock, (struct sockaddr *) &clntAddr,
           &clntLen)) < 0)
    {
        SIGLOG("%s: accept failed\n", __FUNCTION__);
        exit(1);
    }

    /* clntSock is connected to a client! */
    return clntSock;
}

static int wfd_sigma_set_sockfd(fd_set *fdset, int *maxfdn1, struct wfd_sigma_sockfds *fds)
{

    if(fdset == NULL)
        return -1;
    FD_ZERO(fdset);
    if(*fds->mainfd!= -1)
    {
        FD_SET(*fds->mainfd, fdset);
        *maxfdn1 = max(*maxfdn1-1, *fds->mainfd) + 1;
    }
    if(*fds->connfd!= -1)
    {
         FD_SET(*fds->connfd, fdset);
         *maxfdn1 = max(*maxfdn1-1, *fds->connfd) + 1;
    }
    return 0;
}

static int wfd_sigma_get_if_addr(char *ifname, struct sockaddr_in *sa)
{
    struct ifreq ifr;
    int fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_IP);

    if(fd < 0)
    {
        SIGLOG("%s: socket failed\n", __FUNCTION__);
        return -1;
    }
    strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
    ifr.ifr_addr.sa_family = AF_INET;
    if(ioctl(fd, SIOCGIFADDR, &ifr) == 0)
    {
         memcpy(sa, (struct sockaddr_in *)&ifr.ifr_addr, sizeof(struct sockaddr_in));
    }
    else
    {
         return -1;
    }
    close(fd);
    return 0;

}

int wfd_sigma_restart(void)
{
    int retries = 0;
    char cmdStr[64]="";

    wfdSigmaExitFlag = 1;
    while (retries < MTK_WFD_SIGMA_START_MAX_RETRY)
    {
        if (mtkWfdSigmaStarted == 0)
        {
            /* kill previous processes */
            snprintf(cmdStr, sizeof(cmdStr), "sh %s", MTK_WFD_SIGMA_RESET_SCRIPT);
            system(cmdStr);
            usleep(50000);
            return wfd_sigma_start();
        }
        retries ++;
        sleep(1);
    }
    return -1;
}


struct timeval *wfd_sigma_set_timer(int secs, int usecs, struct timeval *tv)
{
    struct timeval *mytv;

    tv->tv_sec = secs ;             /* timeout (secs.) */
    tv->tv_usec = usecs;            /* 0 microseconds */

    if(tv->tv_sec == 0 && tv->tv_usec == 0)
        mytv = NULL;
    else
        mytv = tv;

    return mytv;
}

static char *wfd_sigma_get_devifname(char *name, char *p)
{
    while (isspace(*p))
    p++;
    while (*p)
    {
        if (isspace(*p))
            break;
        if (*p == ':')
        {   /* could be an alias */
            char *dot = p, *dotname = name;
            *name++ = *p++;
            while (isdigit(*p))
            *name++ = *p++;
            if (*p != ':')
            {   /* it wasn't, backup */
                p = dot;
                name = dotname;
            }
            if (*p == '\0')
            return NULL;
            p++;
            break;
        }
        *name++ = *p++;
    }
    *name++ = '\0';
    return p;
}



int wfd_sigma_check_if_ready(char *ifname)
{
    FILE *fh = NULL;
    char *buf = NULL;
    int ret = 0;

    if (!ifname || !strlen(ifname))
        return 0;

    fh = fopen(PATH_PROC_NET_DEV, "r");
    if (!fh)
    {
        SIGLOG("%s: Error cannot open %s\n", __FUNCTION__, PATH_PROC_NET_DEV);
        ret = 0;
        goto if_out;
    }

    buf = malloc(IF_BUF_SIZE);
    if (!buf)
    {
        SIGLOG("%s: Fail to allocate size=%d\n", __FUNCTION__, IF_BUF_SIZE);
        ret = 0;
        goto if_out;
    }
    memset(buf, 0, IF_BUF_SIZE);

    fgets(buf, IF_BUF_SIZE, fh);    /* eat buf line */
    fgets(buf, IF_BUF_SIZE, fh);
    while (fgets(buf, IF_BUF_SIZE, fh))
    {
        char *s, name[IFNAMSIZ]="";
        s = wfd_sigma_get_devifname(name, buf);
        if (strcmp(name, ifname)==0)
        {
            ret = 1;
            goto if_out;
        }

    }
    if (ferror(fh))
    {
        SIGLOG("ferror at %s\n", PATH_PROC_NET_DEV);
        ret = 0;
        goto if_out;
    }

if_out:
    if (fh)
        fclose(fh);
    if (buf)
        free(buf);

    return ret;
}


static void wfd_sigma_start_wfa_dut_thread(void * pvArg)
{
    int tries = 0;
    char cmdStr[64]="";

    while (tries < MTK_WFD_SIGMA_START_MAX_RETRY)
    {
        if (wfd_sigma_check_if_ready("p2p0"))
        {
            SIGLOG("Starting wfa_dut script...\n");
            snprintf(cmdStr, sizeof(cmdStr), "sh %s", MTK_WFD_SIGMA_SCRIPT);

            wfd_sigma_execute_shell_cmd(cmdStr);
            break;
        }
        sleep(1);
        tries ++;
    }
    if (tries == MTK_WFD_SIGMA_START_MAX_RETRY)
        SIGLOG("Failed to start wfa_dut (interface not found)\n");

    mtkWfdSigmaWfaDutStartInProgress = 0;
    return;
}

static int wfd_sigma_start_wfa_dut(void)
{
    int h_wfd_sigma_start_wfa_thread;

    if (mtkWfdSigmaWfaDutStartInProgress)
    {
        SIGLOG("MTK-Sigma wfa_dut start is in progress, ignore ...\n");
        return 0;
    }
    mtkWfdSigmaWfaDutStartInProgress = 1;
    if (wfd_sigma_thread_create((void *)&h_wfd_sigma_start_wfa_thread,
                        (void *)&wfd_sigma_start_wfa_dut_thread,
                        NULL) != 0)
    {
        SIGLOG("Sigma thread (start_wfa_dut) create failed!\n");
        mtkWfdSigmaWfaDutStartInProgress = 0;
        return (-1);
    }

    return 0;
}


static void wfd_sigma_cmd_wfd_cli_show_stats(void)
{
    WFD_PUSH_PLAYER_STATS_T *rtps = NULL;
    int i4_ret = 0;

    rtps = (WFD_PUSH_PLAYER_STATS_T *)malloc(sizeof(WFD_PUSH_PLAYER_STATS_T));
    if (!rtps)
        return;
    memset(rtps, 0, sizeof(WFD_PUSH_PLAYER_STATS_T));
    i4_ret = wfd_client_get_rtp_stats((char *)rtps, sizeof(WFD_PUSH_PLAYER_STATS_T));
    /* note, the return is true or false */
    if (i4_ret <= 0)
    {
        SIGLOG("Failed to get RTP stats\n");
    }
    else
    {
        SIGLOG("\n[WFD Statistics]\n-------------------------\n");
        SIGLOG("Total received bytes:\t\t%u\n", rtps->total_received_size);
        SIGLOG("Total consumed bytes:\t\t%u\n", rtps->total_consumed_size);
        SIGLOG("Buf write idx:\t\t\t%d\n", rtps->buf_w_idx);
        SIGLOG("Buf read idx:\t\t\t%d\n", rtps->buf_r_idx);
        SIGLOG("Buf write position:\t\t%d\n", rtps->buf_w_start_pos);
        SIGLOG("Buffered bytes:\t\t\t%d\n", rtps->buffered_size);
        SIGLOG("Total buffer size:\t\t%d\n", rtps->total_size);
        SIGLOG("Out-of-buffer count:\t\t%d\n", rtps->oob_count);
        SIGLOG("CMPB GetBuffer err count:\t%d\n", rtps->cmpb_getbuffer_error_count);
        SIGLOG("CMPB SendData err count:\t%d\n", rtps->cmpb_senddata_error_count);
        SIGLOG("CMPB HeaderParse fail count:\t%d\n", rtps->header_parse_fail_count);
        SIGLOG("Audio PID:\t\t\t%d\n", rtps->audio_pid);
        SIGLOG("Video PID:\t\t\t%d\n", rtps->video_pid);
        SIGLOG("Audio codec:\t\t\t%d\n", rtps->audio_codec);
        SIGLOG("Video codec:\t\t\t%d\n", rtps->video_codec);
        SIGLOG("Player status:\t\t\t%d\n", rtps->pushplayer_status);
        SIGLOG("-------------------------\n");
    }

    if (rtps)
        free(rtps);
    return;



}

static int wfd_sigma_cmd_wfd_cli_dumpts_set_name(char *tsname)
{
    if (!tsname || !strlen(tsname))
        return -1;

    //return wfd_client_dump_ts_set_path(tsname);
     return -1;
}

static int wfd_sigma_cmd_wfd_cli_dumpts_set_enable(int enable)
{
    //return wfd_client_dump_ts_set_enable(enable);
	 return -1;
}

static int wfd_sigma_cmd_wfd_cli_rtsp_start_ip_port(char *ip,char *port)
{
    int port_int = atoi(port);
    SIGLOG("Enter %s\n", __FUNCTION__);
    return wfd_client_rtsp_start(ip, port_int, 0 /*fast_connection*/);

}

static int wfd_sigma_cmd_wfd_cli_set_st_filename(char *tsname)
{

    int i4_ret = 0;

    SIGLOG("Enter %s\n", __FUNCTION__);

    if (!tsname || !strlen(tsname))
        return -1;

    i4_ret = wfd_client_rtsp_conf_reset();
    if (i4_ret < 0)
       {
        SIGLOG("wfd_rtsp_conf_init failed \n");
        return -1;
       }

    //i4_ret = wfd_client_rtsp_conf_set(WFD_RTSP_CONF_TYPE_TS_READ_NAME, tsname, strlen(tsname));
    /* note, the return is true or false */
    if (i4_ret < 0)
       {
           SIGLOG("wfd_client_rtsp_conf_set failed \n");
           return -1;
        }
    else
        return 0;

}
void wfd_sigma_execute_shell_cmd(char *s_cmd)
{
    if (!s_cmd)
        return;
    SIGLOG("Issuing cmd: (%s)\n", s_cmd);
    /* FixMe!!!!
        Can you use system() directly in every platform?!!
     */
    system(s_cmd);

}


