/*
 * HairTunes - RAOP packet handler and slave-clocked replay engine
 * Copyright (c) James Laird 2011
 * All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <openssl/aes.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>

#include "hairtunes.h"
#include <sys/signal.h>
#include <fcntl.h>
#include "airplay_if.h"

#ifdef AF_INET6
#undef AF_INET6
#endif

#ifdef FANCY_RESAMPLING
#include <samplerate.h>
#endif

#include <assert.h>
static int debug = 0;

#include "alac.h"

#define AUDIO_DSP_PLAY
#ifdef AUDIO_DSP_PLAY
#include "airplay_mw_if.h"
#else
#include <ao/ao.h>
#endif

//#define DEBUG_PACKET
#ifdef DEBUG_PACKET
#include "gsl/gl_types.h"
#include "gsl/gl_timer.h"
#define HAIRTUNE_PACKET_DEBUG(fmt, arg...) printf(""fmt, ##arg)
#else
#define HAIRTUNE_PACKET_DEBUG(fmt, arg...) ((void) 0)
#endif

// and how full it needs to be to begin (must be <BUFFER_FRAMES)
#define START_FILL    282

#define MAX_PACKET      2048
#define TIMESTAMP_DIFF_TH 46000
typedef unsigned short seq_t;

// global options (constant after init)
static unsigned char aeskey[16], aesiv[16];
static AES_KEY aes;
static char *rtphost = 0;
static int dataport = 0, controlport = 0, timingport = 0;
static int fmtp[32];
static int sampling_rate;
static int frame_size;

static int buffer_start_fill;

//#ifndef AUDIO_DSP_PLAY
static char *libao_driver = NULL;
static char *libao_devicename = NULL;
static char *libao_deviceid = NULL;	// ao_options expects "char*"
//#endif

// FIFO name and file handle
//static char *pipename = "/media/sda1/airplay_audio";
static char *pipename = NULL;
static int pipe_handle = -1;

#define FRAME_BYTES (4*frame_size)
// maximal resampling shift - conservative
#define OUTFRAME_BYTES (4*(frame_size+3))

static alac_file *decoder_info = NULL;

#ifdef FANCY_RESAMPLING
static int fancy_resampling = 1;
static SRC_STATE *src;
#endif
static int rtp_sockets[2];		// data, control
#ifdef AF_INET6
static struct sockaddr_in6 rtp_client;
#else
static struct sockaddr_in rtp_client;
#endif
static int rtpPort = 6000;
static double bf_playback_rate = 1.0;

// interthread variables
// stdin->decoder
static double volume = 1.0;
static int fix_volume = 0x10000;
static pthread_mutex_t vol_mutex = PTHREAD_MUTEX_INITIALIZER;
//static int hairtunes_running = 0;
//#define BUF_KEY ftok("/airplaybuf", 0)

// mutex-protected variables
static seq_t ab_read, ab_write;
static int ab_buffering = 1, ab_synced = 0;
static pthread_mutex_t ab_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t ab_buffer_ready = PTHREAD_COND_INITIALIZER;

static pthread_t rtp_thread = 0;
static pthread_t audio_thread = 0;
static timer_update_cbk_t timer_update_cbk = NULL;
static bool is_first_timestamp = TRUE;
static unsigned int first_timestamp = 0;

typedef struct audio_buffer_entry {	// decoded audio packets
	int ready;
	signed short *data;
} abuf_t;
static abuf_t audio_buffer[BUFFER_FRAMES];
#define BUFIDX(seqno) ((seq_t)(seqno) % BUFFER_FRAMES)

//#define DEBUG_LEVEL_1
//#define DEBUG_LEVEL_2

#if defined(DEBUG_LEVEL_1) ||defined(DEBUG_LEVEL_2)
#define hairtunes_slog(arg, fmt...)	printf("[%s][%d]"arg, __FUNCTION__, __LINE__, ##fmt)
#define HAIRTUNES_SLOG()	printf("[%s][%d]\n", __FUNCTION__, __LINE__)
#else
#define hairtunes_slog(arg, fmt...)	do{}while(0)
#define HAIRTUNES_SLOG()	do{}while(0)
#endif

#if defined(DEBUG_LEVEL_1)
#define hairtunes_debug(arg, fmt...)	printf("[%s][%d]"arg, __FUNCTION__, __LINE__, ##fmt)
#define HAIRTUNES_debug()	printf("[%s][%d]\n", __FUNCTION__, __LINE__)
#else
#define hairtunes_debug(arg, fmt...)	do{}while(0)
#define HAIRTUNES_debug()	do{}while(0)
#endif

static int init_rtp(void);
static void init_buffer(void);
static int init_output(void);
static void rtp_request_resend(seq_t first, seq_t last);
static void ab_resync(void);
static void buffer_put_packet(seq_t seqno, char *data, int len);
static short *buffer_get_frame(void);
static void rtp_request_resend(seq_t first, seq_t last);
static void init_buffer(void);
static int stuff_buffer(double playback_rate, short *inptr, short *outptr);
static void init_pipe(const char *pipe);
static void init_dsp();

void hairtunes_reset_timestamp(void)
{
	hairtunes_debug("Reset sync timestamp\n");
	is_first_timestamp = TRUE;
	first_timestamp = 0;
}

static void die(char *why)
{
	hairtunes_slog( "FATAL: %s\n", why);
	exit(1);
}

#ifdef HAIRTUNES_STANDALONE
static int hex2bin(unsigned char *buf, char *hex)
{
	int i, j;
	if (strlen(hex) != 0x20)
		return 1;
	for (i = 0; i < 0x10; i++)
	{
		if (!sscanf(hex, "%2X", &j))
			return 1;
		hex += 2;
		*buf++ = j;
	}
	return 0;
}
#endif

static inline unsigned int _read_u32(const char *buf) 
{
	return ((unsigned int)(buf[0] & 0xff) << 24) |
		   ((unsigned int)(buf[1] & 0xff) << 16) |
	       ((unsigned int)(buf[2] & 0xff) <<  8) |
	       ((unsigned int)(buf[3] & 0xff));
}

static void *rtp_thread_func(void *arg)
{
	HAIRTUNES_SLOG();
	socklen_t si_len = sizeof(rtp_client);
	char packet[MAX_PACKET];
	char *pktp;
	seq_t seqno;
	seq_t last_seqno = 0;
	unsigned int last_timestamp = 0;
	#ifdef DEBUG_PACKET
	int time = GL_GetTimestamp();
	int last_time = 0;
	int tmp_time = 0;
	#endif
	while (1)
	{
		#ifdef DEBUG_PACKET
		tmp_time = GL_GetTimestamp();
		#endif
		ssize_t plen = recvfrom(rtp_sockets[0], packet, sizeof(packet), 0, (struct sockaddr *)&rtp_client, &si_len);
		#ifdef DEBUG_PACKET
		HAIRTUNE_PACKET_DEBUG("r=%d,", GL_GetTimestamp() - tmp_time);
		#endif
		if (plen < 0)
			break;
		assert(plen <= MAX_PACKET);
		char type = packet[1] & ~0x80;
		#ifdef DEBUG_PACKET
		if (type == 0x56)
		{
			int i = 0;
			for (i = 0; i < 10; i++)
			{
				HAIRTUNE_PACKET_DEBUG("%x ", (unsigned char)packet[i]);
			}
			HAIRTUNE_PACKET_DEBUG(",");
		}

		HAIRTUNE_PACKET_DEBUG("p=%x,", type);
		HAIRTUNE_PACKET_DEBUG("l=%d,", plen);
		#endif
		if (type == 0x54)
		{
			unsigned int curr_timestamp = _read_u32(&packet[4]);

			if (is_first_timestamp)
			{
				is_first_timestamp = FALSE;
				first_timestamp = curr_timestamp;
				last_timestamp = curr_timestamp;
				HAIRTUNE_PACKET_DEBUG("FirstTimeStamp=%u\n", first_timestamp);
			}
			if (timer_update_cbk)
			{
				if ((curr_timestamp - last_timestamp) > TIMESTAMP_DIFF_TH)
				{
					printf("[Warning]Timestamp Burst! curr=%u last=%u diff=%u\n", curr_timestamp, last_timestamp, (curr_timestamp - last_timestamp));
				}
				last_timestamp = curr_timestamp;
				timer_update_cbk((curr_timestamp-first_timestamp+22050)/44100);
			}
			HAIRTUNE_PACKET_DEBUG("\n");
			continue;
		}

		if (type == 0x60 || type == 0x56)
		{						// audio data / resend
			pktp = packet;
			if (type == 0x56)
			{
				pktp += 4;
				plen -= 4;
			}
			seqno = ntohs(*(unsigned short *)(pktp + 2));

			// adjust pointer and length
			pktp += 12;
			plen -= 12;

			// check if packet contains enough content to be reasonable
			if (plen >= 16)
			{
				if (((last_seqno + 1) != seqno) && (type != 0x56))
				{
					HAIRTUNE_PACKET_DEBUG("need%d,but%d,", last_seqno+1, seqno);
				}
				if (type != 0x56)
				{
					last_seqno = seqno;
				}
				buffer_put_packet(seqno, pktp, plen);
				HAIRTUNE_PACKET_DEBUG("n=%d,", seqno);
			}
			// resync?
			if (type == 0x56 && seqno == 0)
			{
				hairtunes_slog("Suspected resync request packet received. Initiating resync.\n");
				pthread_mutex_lock(&ab_mutex);
				ab_resync();
				pthread_mutex_unlock(&ab_mutex);
			}
		}
		#ifdef DEBUG_PACKET
		time = GL_GetTimestamp();
		if (last_time)
			HAIRTUNE_PACKET_DEBUG("t=%d\n", time - last_time);
		last_time = time;
		#endif
	}
	return 0;
}

static void *audio_thread_func(void *arg)
{
	HAIRTUNES_SLOG();
#ifndef AUDIO_DSP_PLAY
	ao_device *dev = arg;
#endif
	int play_samples;

	signed short buf_fill __attribute__ ((unused));
	signed short *inbuf, *outbuf, *silence;
	outbuf = malloc(OUTFRAME_BYTES);
	silence = malloc(OUTFRAME_BYTES);
	int i;

	for (i = 0; i < OUTFRAME_BYTES / 2; i++)
	{
		silence[i] = 0;
	}

#ifdef FANCY_RESAMPLING
	float *frame, *outframe;
	SRC_DATA srcdat;
	if (fancy_resampling)
	{
		frame = malloc(frame_size * 2 * sizeof(float));
		outframe = malloc(2 * frame_size * 2 * sizeof(float));

		srcdat.data_in = frame;
		srcdat.data_out = outframe;
		srcdat.input_frames = FRAME_BYTES;
		srcdat.output_frames = 2 * FRAME_BYTES;
		srcdat.src_ratio = 1.0;
		srcdat.end_of_input = 0;
	}
#endif
	hairtunes_slog( "start get audio data\n");

	int ret = Airplay_MW_IF_AudioPlay();
	if (ret != AIRPLAY_MW_SUCCESS)
	{
		hairtunes_slog( "Play audio on dsp failed!\n");
	}

	while (1)
	{
		if (ab_buffering)
		{
			inbuf = silence;
		}
		else
		{
			do
			{
				inbuf = buffer_get_frame();
			}
			while (!inbuf);
		}

#ifdef FANCY_RESAMPLING
		if (fancy_resampling)
		{
			int i;
			pthread_mutex_lock(&vol_mutex);
			for (i = 0; i < 2 * FRAME_BYTES; i++)
			{
				frame[i] = (float)inbuf[i] / 32768.0;
				frame[i] *= volume;
			}
			pthread_mutex_unlock(&vol_mutex);
			srcdat.src_ratio = bf_playback_rate;
			src_process(src, &srcdat);
			assert(srcdat.input_frames_used == FRAME_BYTES);
			src_float_to_short_array(outframe, outbuf, FRAME_BYTES * 2);
			play_samples = srcdat.output_frames_gen;
		}
		else
#endif

			play_samples = stuff_buffer(bf_playback_rate, inbuf, outbuf);

		if (pipename)
		{
#if 1
			if (pipe_handle == -1)
			{
				// attempt to open pipe - block if there are no readers
				pipe_handle = open(pipename, O_WRONLY | O_CREAT);
				printf( "pipe_handle = %d\n", pipe_handle);
			}

			// only write if pipe open (there's a reader)
			if (pipe_handle != -1)
			{
				//printf( "feed dsp data: %d\n", play_samples*4);           
				//Airplay_AudioPlay_WriteData(outbuf, play_samples*4);
				//if (write(pipe_handle, outbuf, play_samples*4) == -1) {
				// write failed - do anything here?
				// SIGPIPE is handled elsewhere...
				//}
			}
#endif
		}
		else
		{
#ifdef AUDIO_DSP_PLAY
			//printf( "Write buffer: %d\n", play_samples*4);
			{
				#if 0
				int shmid = shmget(BUF_KEY, 0, 0);
				void *buf = shmat(shmid, 0, 0);
				int curpid = -1;
				memcpy(&curpid, buf + 8, 4);
				shmdt(buf);
				//printf( "Curpid = %d, getpid: %d\n", curpid, getpid());
				if (curpid != getpid())
				{
					printf( "Curpid: %d, getpid: %d, getppid %d, exit!\n", curpid, getpid(), getppid());
					//sleep(1);
					char cmd[20] = { 0 };
					sprintf(cmd, "kill %d", getppid());
					kill(getppid(), SIGTERM);
					//system(cmd);
					exit(0);
				}
				#endif
			}
			Airplay_MW_IF_AudioWriteData(outbuf, play_samples * 4);
#else
			ao_play(dev, (char *)outbuf, play_samples * 4);
#endif
		}
	}
	HAIRTUNES_SLOG();
	return 0;
}

static int init_decoder(void)
{
	HAIRTUNES_SLOG();

	alac_file *alac = NULL;

	frame_size = fmtp[1];		// stereo samples
	sampling_rate = fmtp[11];

	int sample_size = fmtp[3];
	if (sample_size != 16)
		die("only 16-bit samples supported!");

	if (decoder_info)	//feng.yang
	{
		decoder_info->samplesize = sample_size;
		decoder_info->numchannels = 2;
		decoder_info->bytespersample = (sample_size / 8) * 2;
	}
	else
	{
		alac = create_alac(sample_size, 2);
		if (!alac)
			return 1;
		decoder_info = alac;
	}

	alac->setinfo_max_samples_per_frame = frame_size;
	alac->setinfo_7a = fmtp[2];
	alac->setinfo_sample_size = sample_size;
	alac->setinfo_rice_historymult = fmtp[4];
	alac->setinfo_rice_initialhistory = fmtp[5];
	alac->setinfo_rice_kmodifier = fmtp[6];
	alac->setinfo_7f = fmtp[7];
	alac->setinfo_80 = fmtp[8];
	alac->setinfo_82 = fmtp[9];
	alac->setinfo_86 = fmtp[10];
	alac->setinfo_8a_rate = fmtp[11];

	if (decoder_info)	//feng.yang
	{
		if (decoder_info->predicterror_buffer_a) free(decoder_info->predicterror_buffer_a);
		if (decoder_info->predicterror_buffer_b) free(decoder_info->predicterror_buffer_b);
		if (decoder_info->outputsamples_buffer_a) free(decoder_info->outputsamples_buffer_a);
		if (decoder_info->outputsamples_buffer_b) free(decoder_info->outputsamples_buffer_b);
		if (decoder_info->uncompressed_bytes_buffer_a) free(decoder_info->uncompressed_bytes_buffer_a);
		if (decoder_info->uncompressed_bytes_buffer_b) free(decoder_info->uncompressed_bytes_buffer_b);
	}
	
	allocate_buffers(alac);
	return 0;
}

int _Flush_AudioPlay(int fd_socket)
{
	HAIRTUNES_SLOG();

	//set client addr in shair buffer
	struct sockaddr_storage addr;
	char ipstr[14] = {0};
	socklen_t len = sizeof addr;
	getpeername(fd_socket, (struct sockaddr *)&addr, &len);
	// deal with both IPv4 and IPv6:
	if (addr.ss_family == AF_INET)
	{
		struct sockaddr_in *s = (struct sockaddr_in *)&addr;
		inet_ntop(AF_INET, &s->sin_addr, ipstr, sizeof ipstr);
	}
	#ifdef AF_INET6
	else
	{
		char ipv6str[64];
		struct sockaddr_in6 *s = (struct sockaddr_in6 *)&addr;
		inet_ntop(AF_INET6, &s->sin6_addr, ipv6str, sizeof ipv6str);
		strcpy(ipstr, strrchr(ipv6str, ':')+1);
	}
	#endif

	hairtunes_slog("audio addr: %s\n", ipstr);
	int shmid = shmget(BUF_KEY, SHAIR_BUF_SIZE, SHM_R|SHM_W|IPC_CREAT);
	if (shmid != -1)
	{
		void *buff = shmat(shmid, 0, 0);
		memcpy(buff, &ipstr, IPV4ADDR_SIZE);
		shmdt(buff);
	}
	//----end

	//size_t msgrcved = 0;
	AirplayMsg_t airplaymsg;
	airplaymsg.msgtype = MSG_TYPE_REQUEST;
	airplaymsg.msgbody.msg = AIRPLAY_AUDIO_FLUSH;
	airplaymsg.msgbody.pid = getpid();
	airplaymsg.msgbody.ppid = getppid();
	int msgid = msgget(MSG_AIR_MW_KEY, S_IRUSR|S_IWUSR|IPC_CREAT);
	msgsnd(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), IPC_NOWAIT);
	hairtunes_debug("send run audio message to airplay middleware!!!!!\n");

	//msgrcved = msgrcv(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), MSG_TYPE_RESPONSE, 0);
	msgrcv(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), MSG_TYPE_RESPONSE, 0);
	return 0;
}

int _Start_AudioPlay(int fd_socket)
{
	HAIRTUNES_SLOG();

	//set client addr in shair buffer
	struct sockaddr_storage addr;
	char ipstr[14] = {0};
	socklen_t len = sizeof addr;
	getpeername(fd_socket, (struct sockaddr *)&addr, &len);
	// deal with both IPv4 and IPv6:
	if (addr.ss_family == AF_INET)
	{
		struct sockaddr_in *s = (struct sockaddr_in *)&addr;
		inet_ntop(AF_INET, &s->sin_addr, ipstr, sizeof ipstr);
	}
	#ifdef AF_INET6
	else
	{
		char ipv6str[64];
		struct sockaddr_in6 *s = (struct sockaddr_in6 *)&addr;
		inet_ntop(AF_INET6, &s->sin6_addr, ipv6str, sizeof ipv6str);
		strcpy(ipstr, strrchr(ipv6str, ':')+1);
	}
	#endif

	hairtunes_slog("audio addr: %s\n", ipstr);
	int shmid = shmget(BUF_KEY, SHAIR_BUF_SIZE, SHM_R|SHM_W|IPC_CREAT);
	if (shmid != -1)
	{
		void *buff = shmat(shmid, 0, 0);
		memcpy(buff, &ipstr, IPV4ADDR_SIZE);
		shmdt(buff);
	}
	//----end

	//size_t msgrcved = 0;
	AirplayMsg_t airplaymsg;
	airplaymsg.msgtype = MSG_TYPE_REQUEST;
	airplaymsg.msgbody.msg = AIRPLAY_AUDIO_START;
	airplaymsg.msgbody.pid = getpid();
	airplaymsg.msgbody.ppid = getppid();
	int msgid = msgget(MSG_AIR_MW_KEY, S_IRUSR|S_IWUSR|IPC_CREAT);
	msgsnd(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), IPC_NOWAIT);
	hairtunes_debug("send run audio message to airplay middleware!!!!!\n");

	//msgrcved = msgrcv(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), MSG_TYPE_RESPONSE, 0);
	msgrcv(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), MSG_TYPE_RESPONSE, 0);
	switch (airplaymsg.msgbody.msg)
	{
		case AIRPLAY_AUDIO_START:
			hairtunes_debug("[Shairport][L:%04d]recieve response from airplay middleware: run success airplay audio!!!!!\n", __LINE__);
			return 0;
			break;
		case AIRPLAY_SHAIRPORT_STOP:
			hairtunes_debug("[Shairport][L:%04d]recieve response from airplay middleware: run fail airplay audio!!!!!\n", __LINE__);
			return -1;
			break;
		default:
			break;
	}

	return 0;
}

void hairtunes_setvolume(double f)
{
	HAIRTUNES_SLOG();

	assert(f <= 0);
	hairtunes_debug("set volume: %lf\n", f);
	pthread_mutex_lock(&vol_mutex);
	volume = pow(10.0, 0.05 * f);
	fix_volume = 65536.0 * volume;
	pthread_mutex_unlock(&vol_mutex);
}

void hairtunes_register_cbk(timer_update_cbk_t cbk)
{
	timer_update_cbk = cbk;
}

void hairtunes_setflush()
{
	HAIRTUNES_SLOG();
	pthread_mutex_lock(&ab_mutex);
	ab_resync();
	pthread_mutex_unlock(&ab_mutex);
}

void hairtunes_exit()
{
	HAIRTUNES_SLOG();
	rtp_socket_close();	
	if (rtp_thread)
	{
		void *exitcode = NULL;
		pthread_cancel(rtp_thread);
		pthread_join(rtp_thread, &exitcode);
		rtp_thread = 0;
	}
	if (audio_thread)
	{
		void *exitcode = NULL;
		pthread_cancel(audio_thread);
		pthread_join(audio_thread, &exitcode);
		audio_thread = 0;
	}
	Airplay_MW_IF_AudioStop();
	//hairtunes_setflush();
	if (decoder_info)	//feng.yang
	{
		if (decoder_info->input_buffer) decoder_info->input_buffer = NULL;
		if (decoder_info->predicterror_buffer_a) free(decoder_info->predicterror_buffer_a);
		if (decoder_info->predicterror_buffer_b) free(decoder_info->predicterror_buffer_b);
		if (decoder_info->outputsamples_buffer_a) free(decoder_info->outputsamples_buffer_a);
		if (decoder_info->outputsamples_buffer_b) free(decoder_info->outputsamples_buffer_b);
		if (decoder_info->uncompressed_bytes_buffer_a) free(decoder_info->uncompressed_bytes_buffer_a);
		if (decoder_info->uncompressed_bytes_buffer_b) free(decoder_info->uncompressed_bytes_buffer_b);
		free(decoder_info);
		decoder_info = NULL;
	}
	int i = 0;
	for (i = 0; i < BUFFER_FRAMES; i++)
	{
		if (audio_buffer[i].data)
		{
			free(audio_buffer[i].data);
			audio_buffer[i].data = NULL;
		}
	}
}

void hairtunes_reset()
{
	HAIRTUNES_SLOG();
	Airplay_MW_IF_AudioStop();

	rtp_socket_close();	
	if (rtp_thread)
	{
		void *exitcode = NULL;
		pthread_cancel(rtp_thread);
		pthread_join(rtp_thread, &exitcode);
	}
	rtp_thread = 0;
	hairtunes_setflush();
	
}
int hairtunes_decoder_init()
{
	HAIRTUNES_SLOG();
	alac_file *alac = NULL;

	frame_size = fmtp[1];		// stereo samples
	sampling_rate = fmtp[11];

	int sample_size = fmtp[3];
	if (sample_size != 16)
		die("only 16-bit samples supported!");

	if (decoder_info)	//feng.yang
	{
		if (decoder_info->input_buffer) decoder_info->input_buffer = NULL;
		if (decoder_info->predicterror_buffer_a) free(decoder_info->predicterror_buffer_a);
		if (decoder_info->predicterror_buffer_b) free(decoder_info->predicterror_buffer_b);
		if (decoder_info->outputsamples_buffer_a) free(decoder_info->outputsamples_buffer_a);
		if (decoder_info->outputsamples_buffer_b) free(decoder_info->outputsamples_buffer_b);
		if (decoder_info->uncompressed_bytes_buffer_a) free(decoder_info->uncompressed_bytes_buffer_a);
		if (decoder_info->uncompressed_bytes_buffer_b) free(decoder_info->uncompressed_bytes_buffer_b);
		free(decoder_info);
	}

	alac = create_alac(sample_size, 2);
	if (!alac)
		return 1;
	decoder_info = alac;

	alac->setinfo_max_samples_per_frame = frame_size;
	alac->setinfo_7a = fmtp[2];
	alac->setinfo_sample_size = sample_size;
	alac->setinfo_rice_historymult = fmtp[4];
	alac->setinfo_rice_initialhistory = fmtp[5];
	alac->setinfo_rice_kmodifier = fmtp[6];
	alac->setinfo_7f = fmtp[7];
	alac->setinfo_80 = fmtp[8];
	alac->setinfo_82 = fmtp[9];
	alac->setinfo_86 = fmtp[10];
	alac->setinfo_8a_rate = fmtp[11];
	
	allocate_buffers(alac);
	return 0;
}

void hairtunes_buffer_init(void)
{
	HAIRTUNES_SLOG();
	int i;
	for (i = 0; i < BUFFER_FRAMES; i++)
	{
		if (!audio_buffer[i].data)
			audio_buffer[i].data = malloc(OUTFRAME_BYTES);
		else	//feng.yang
			memset(audio_buffer[i].data, 0x0, OUTFRAME_BYTES);
	}
	ab_resync();
}

int hairtunes_rtp_init(void)
{
	HAIRTUNES_SLOG();
	struct sockaddr_in si;
	int type = AF_INET;
	struct sockaddr *si_p = (struct sockaddr *)&si;
	socklen_t si_len = sizeof(si);
	unsigned short *sin_port = &si.sin_port;
	memset(&si, 0, sizeof(si));
#ifdef AF_INET6
	struct sockaddr_in6 si6;
	type = AF_INET6;
	si_p = (struct sockaddr *)&si6;
	si_len = sizeof(si6);
	sin_port = &si6.sin6_port;
	memset(&si6, 0, sizeof(si6));
#endif

	si.sin_family = AF_INET;
#ifdef SIN_LEN
	si.sin_len = sizeof(si);
#endif
	si.sin_addr.s_addr = htonl(INADDR_ANY);
#ifdef AF_INET6
	si6.sin6_family = AF_INET6;
#ifdef SIN6_LEN
	si6.sin6_len = sizeof(si);
#endif
	si6.sin6_addr = in6addr_any;
	si6.sin6_flowinfo = 0;
#endif

	int sock = -1, csock = -1;	// data and control (we treat the streams the same here)
	unsigned short port = rtpPort;
	while (1)
	{
		if (sock < 0)
			sock = socket(type, SOCK_DGRAM, IPPROTO_UDP);
#ifdef AF_INET6
		if (sock == -1 && type == AF_INET6)
		{
			// try fallback to IPv4
			type = AF_INET;
			si_p = (struct sockaddr *)&si;
			si_len = sizeof(si);
			sin_port = &si.sin_port;
			continue;
		}
#endif
		if (sock == -1)
			die("Can't create data socket!");

		if (csock < 0)
			csock = socket(type, SOCK_DGRAM, IPPROTO_UDP);
		if (csock == -1)
			die("Can't create control socket!");

		*sin_port = htons(port);
		int bind1 = bind(sock, si_p, si_len);
		*sin_port = htons(port + 1);
		int bind2 = bind(csock, si_p, si_len);

		if (bind1 != -1 && bind2 != -1)
			break;
		if (bind1 != -1)
		{
			close(sock);
			sock = -1;
		}
		if (bind2 != -1)
		{
			close(csock);
			csock = -1;
		}

		port += 3;
	}

	hairtunes_debug("port: %d\n", port);	// let our handler know where we end up listening
	hairtunes_debug("cport: %d\n", port + 1);

	rtpPort+=3;
	if (rtpPort > 6060)	//just don't want the port become to large
		rtpPort = 6000;
	//pthread_t rtp_thread;
	rtp_sockets[0] = sock;
	rtp_sockets[1] = csock;
	/*
	int shmid = shmget(BUF_KEY, 0, 0);
	void *buf = shmat(shmid, 0, 0);
	memcpy(buf + 12, &sock, 4);
	memcpy(buf + 16, &csock, 4);
	shmdt(buf);
	*/
	hairtunes_slog( "rtp_sockets[0]: %d, rtp_sockets[1]: %d\n", rtp_sockets[0], rtp_sockets[1]);
	pthread_attr_t AVAttr;
	pthread_attr_init(&AVAttr);
	pthread_attr_setstacksize(&AVAttr, 1*1024*1024);
	pthread_create(&rtp_thread, &AVAttr, rtp_thread_func, (void *)rtp_sockets);
	pthread_attr_destroy(&AVAttr);
	return port;
}

int hairtunes_output_init(void)
{
	HAIRTUNES_SLOG();
	void *arg = 0;

	if (pipename)
	{
		//init_pipe(pipename);
	}
	else
	{
#ifdef AUDIO_DSP_PLAY
		init_dsp();
#else
		//arg = init_ao();
#endif
	}

#ifdef FANCY_RESAMPLING
	int err;
	if (fancy_resampling)
		src = src_new(SRC_SINC_MEDIUM_QUALITY, 2, &err);
	else
		src = 0;
#endif

	if(audio_thread)
	{
		Airplay_MW_IF_AudioPlay();
	}
	else
	{
		//pthread_t audio_thread;
		pthread_attr_t AVAttr;
		pthread_attr_init(&AVAttr);
		pthread_attr_setstacksize(&AVAttr, 1*1024*1024);
		pthread_create(&audio_thread, &AVAttr, audio_thread_func, arg);
		pthread_attr_destroy(&AVAttr);
	}

	return 0;
}
void hairtunes_setparam(char *pAeskey, char *pAesiv, char *fmtpstr, int pCtrlPort, int pTimingPort,
				   int pDataPort, char *pRtpHost, char *pPipeName, int bufStartFill)
{
	HAIRTUNES_SLOG();

	if (pAeskey != NULL)
		memcpy(aeskey, pAeskey, sizeof(aeskey));
	if (pAesiv != NULL)
		memcpy(aesiv, pAesiv, sizeof(aesiv));
	if (pRtpHost != NULL)
		rtphost = pRtpHost;
	if (pPipeName != NULL)
		pipename = pPipeName;
	
	libao_driver = NULL;
	libao_devicename = NULL;
	libao_deviceid = NULL;

	controlport = pCtrlPort;
	timingport = pTimingPort;
	dataport = pDataPort;
	if (bufStartFill < 0)
		bufStartFill = START_FILL;
	buffer_start_fill = bufStartFill;

	AES_set_decrypt_key(aeskey, 128, &aes);

	memset(fmtp, 0, sizeof(fmtp));
	int i = 0;
	char *arg;
	while ((arg = strsep(&fmtpstr, " \t")))
		fmtp[i++] = atoi(arg);
}
int hairtunes_init(char *pAeskey, char *pAesiv, char *fmtpstr, int pCtrlPort, int pTimingPort,
				   int pDataPort, char *pRtpHost, char *pPipeName, char *pLibaoDriver, char *pLibaoDeviceName, char *pLibaoDeviceId, int bufStartFill, char *serverport)
{
	#if 0
	if (pAeskey != NULL)
		memcpy(aeskey, pAeskey, sizeof(aeskey));
	if (pAesiv != NULL)
		memcpy(aesiv, pAesiv, sizeof(aesiv));
	if (pRtpHost != NULL)
		rtphost = pRtpHost;
	if (pPipeName != NULL)
		pipename = pPipeName;
	if (pLibaoDriver != NULL)
		libao_driver = pLibaoDriver;
	if (pLibaoDeviceName != NULL)
		libao_devicename = pLibaoDeviceName;
	if (pLibaoDeviceId != NULL)
		libao_deviceid = pLibaoDeviceId;

	controlport = pCtrlPort;
	timingport = pTimingPort;
	dataport = pDataPort;
	if (bufStartFill < 0)
		bufStartFill = START_FILL;
	buffer_start_fill = bufStartFill;
	hairtunes_running = 1;

	AES_set_decrypt_key(aeskey, 128, &aes);

	memset(fmtp, 0, sizeof(fmtp));
	int i = 0;
	char *arg;
	while ((arg = strsep(&fmtpstr, " \t")))
		fmtp[i++] = atoi(arg);
	#endif
	
	//if(_Start_AudioPlay())
	//	return EXIT_SUCCESS;
	
	init_decoder();
	init_buffer();
	int port = init_rtp();					// open a UDP listen port and start a listener; decode into ring buffer
	sprintf(serverport, "%d", port);
	//fflush(stdout);
	init_output();				// resample and output from ring buffer

	/*
	char line[128];
	int in_line = 0;
	int n;
	double f;
	while (fgets(line + in_line, sizeof(line) - in_line, stdin))
	{

		n = strlen(line);
		if (line[n - 1] != '\n')
		{
			in_line = strlen(line) - 1;
			if (n == sizeof(line) - 1)
				in_line = 0;
			continue;
		}
		if (sscanf(line, "vol: %lf\n", &f))
		{
			assert(f <= 0);
			if (debug)
				printf( "VOL: %lf\n", f);
			pthread_mutex_lock(&vol_mutex);
			volume = pow(10.0, 0.05 * f);
			fix_volume = 65536.0 * volume;
			pthread_mutex_unlock(&vol_mutex);
			continue;
		}
		if (!strcmp(line, "exit\n"))
		{
			exit(0);
		}
		if (!strcmp(line, "flush\n"))
		{
			pthread_mutex_lock(&ab_mutex);
			ab_resync();
			pthread_mutex_unlock(&ab_mutex);
			if (debug)
				printf( "FLUSH\n");
		}
	}
	printf( "bye!\n");
	fflush(stderr);
	*/

	return EXIT_SUCCESS;
}

#ifdef HAIRTUNES_STANDALONE
int main(int argc, char **argv)
{
	char *hexaeskey = 0, *hexaesiv = 0;
	char *fmtpstr = 0;
	char *arg;
	assert(RAND_MAX >= 0x10000);	// XXX move this to compile time
	while ((arg = *++argv))
	{
		if (!strcasecmp(arg, "iv"))
		{
			hexaesiv = *++argv;
			argc--;
		}
		else if (!strcasecmp(arg, "key"))
		{
			hexaeskey = *++argv;
			argc--;
		}
		else if (!strcasecmp(arg, "fmtp"))
		{
			fmtpstr = *++argv;
		}
		else if (!strcasecmp(arg, "cport"))
		{
			controlport = atoi(*++argv);
		}
		else if (!strcasecmp(arg, "tport"))
		{
			timingport = atoi(*++argv);
		}
		else if (!strcasecmp(arg, "dport"))
		{
			dataport = atoi(*++argv);
		}
		else if (!strcasecmp(arg, "host"))
		{
			rtphost = *++argv;
		}
		else if (!strcasecmp(arg, "pipe"))
		{
			if (libao_driver || libao_devicename || libao_deviceid)
			{
				die("Option 'pipe' may not be combined with 'ao_driver', 'ao_devicename' or 'ao_deviceid'");
			}

			pipename = *++argv;
		}
		else if (!strcasecmp(arg, "ao_driver"))
		{
			if (pipename)
			{
				die("Option 'ao_driver' may not be combined with 'pipe'");
			}

			libao_driver = *++argv;
		}
		else if (!strcasecmp(arg, "ao_devicename"))
		{
			if (pipename || libao_deviceid)
			{
				die("Option 'ao_devicename' may not be combined with 'pipe' or 'ao_deviceid'");
			}

			libao_devicename = *++argv;
		}
		else if (!strcasecmp(arg, "ao_deviceid"))
		{
			if (pipename || libao_devicename)
			{
				die("Option 'ao_deviceid' may not be combined with 'pipe' or 'ao_devicename'");
			}

			libao_deviceid = *++argv;
		}
#ifdef FANCY_RESAMPLING
		else if (!strcasecmp(arg, "resamp"))
		{
			fancy_resampling = atoi(*++argv);
		}
#endif
	}

	if (!hexaeskey || !hexaesiv)
		die("Must supply AES key and IV!");

	if (hex2bin(aesiv, hexaesiv))
		die("can't understand IV");
	if (hex2bin(aeskey, hexaeskey))
		die("can't understand key");
	//return hairtunes_init(NULL, NULL, fmtpstr, controlport, timingport, dataport, NULL, NULL, NULL, NULL, NULL, START_FILL);
}
#endif

static void init_buffer(void)
{
	int i;
	for (i = 0; i < BUFFER_FRAMES; i++)
	{
		if (!audio_buffer[i].data)
			audio_buffer[i].data = malloc(OUTFRAME_BYTES);
		else	//feng.yang
			memset(audio_buffer[i].data, 0x0, OUTFRAME_BYTES);
	}
	ab_resync();
}

static void ab_resync(void)
{
	int i;
	for (i = 0; i < BUFFER_FRAMES; i++)
		audio_buffer[i].ready = 0;
	ab_synced = 0;
	ab_buffering = 1;
}

// the sequence numbers will wrap pretty often.
// this returns true if the second arg is after the first
static inline int seq_order(seq_t a, seq_t b)
{
	signed short d = b - a;
	return d > 0;
}

static void alac_decode(short *dest, char *buf, int len)
{
	unsigned char packet[MAX_PACKET];
	assert(len <= MAX_PACKET);

	unsigned char iv[16];
	int aeslen = len & ~0xf;
	memcpy(iv, aesiv, sizeof(iv));
	AES_cbc_encrypt((unsigned char *)buf, packet, aeslen, &aes, iv, AES_DECRYPT);
	memcpy(packet + aeslen, buf + aeslen, len - aeslen);

	int outsize;

	decode_frame(decoder_info, packet, dest, &outsize);

	if (outsize != FRAME_BYTES)
		hairtunes_slog("[%s][%d]outsize: %d, FRAME_BYTES: %d\n", __FUNCTION__, __LINE__, outsize, FRAME_BYTES);
	assert(outsize == FRAME_BYTES);
}

static void buffer_put_packet(seq_t seqno, char *data, int len)
{
	abuf_t *abuf = 0;
	short buf_fill;

	pthread_mutex_lock(&ab_mutex);
	if (!ab_synced)
	{
 		ab_write = seqno - 1;
        ab_read = seqno;
        ab_synced = 1;
	}
	if (seqno == ab_write + 1)
	{							// expected packet
		abuf = audio_buffer + BUFIDX(seqno);
		ab_write = seqno;
	}
	else if (seq_order(ab_write, seqno))
	{							// newer than expected
		HAIRTUNE_PACKET_DEBUG("s=%d,c=%d,", ab_write + 1, ((seqno - 1) - (ab_write + 1) + 1));
		rtp_request_resend(ab_write + 1, seqno - 1);
		abuf = audio_buffer + BUFIDX(seqno);
		ab_write = seqno;
	}
	else if (seq_order(ab_read, seqno))
	{							// late but not yet played
		abuf = audio_buffer + BUFIDX(seqno);
		HAIRTUNE_PACKET_DEBUG("d=%d,", seqno);
	}
	else
	{							// too late.
		HAIRTUNE_PACKET_DEBUG("e=%d,", seqno);
		hairtunes_slog( "\nlate packet %04X (%04X:%04X)\n", seqno, ab_read, ab_write);
	}
	buf_fill = ab_write - ab_read;
	pthread_mutex_unlock(&ab_mutex);

	if (abuf)
	{
		alac_decode(abuf->data, data, len);
		abuf->ready = 1;
	}

	pthread_mutex_lock(&ab_mutex);
	if (ab_buffering && buf_fill >= buffer_start_fill)
	{
		ab_buffering = 0;
		pthread_cond_signal(&ab_buffer_ready);
	}
	pthread_mutex_unlock(&ab_mutex);
}

int rtp_socket_close()
{
	if (rtp_sockets[0])
	{
		hairtunes_slog( "close rtp_socket[0]: %d\n", rtp_sockets[0]);
		close(rtp_sockets[0]);
	}
	rtp_sockets[0] = 0;
	if (rtp_sockets[1])
	{
		hairtunes_slog( "close rtp_socket[1]: %d\n", rtp_sockets[1]);
		close(rtp_sockets[1]);
	}
	rtp_sockets[1] = 0;
	return 0;
}

static void rtp_request_resend(seq_t first, seq_t last)
{
	if (seq_order(last, first))
		return;

	hairtunes_slog( "requesting resend on %d packets (port %d)\n", last - first + 1, controlport);

	char req[8];				// *not* a standard RTCP NACK
	req[0] = 0x80;
	req[1] = 0x55 | 0x80;		// Apple 'resend'
	*(unsigned short *)(req + 2) = htons(1);	// our seqnum
	*(unsigned short *)(req + 4) = htons(first);	// missed seqnum
	*(unsigned short *)(req + 6) = htons(last - first + 1);	// count

#ifdef AF_INET6
	rtp_client.sin6_port = htons(controlport);
#else
	rtp_client.sin_port = htons(controlport);
#endif
	sendto(rtp_sockets[0], req, sizeof(req), 0, (struct sockaddr *)&rtp_client, sizeof(rtp_client));
}

int init_rtp(void)
{
	struct sockaddr_in si;
	int type = AF_INET;
	struct sockaddr *si_p = (struct sockaddr *)&si;
	socklen_t si_len = sizeof(si);
	unsigned short *sin_port = &si.sin_port;
	memset(&si, 0, sizeof(si));
#ifdef AF_INET6
	struct sockaddr_in6 si6;
	type = AF_INET6;
	si_p = (struct sockaddr *)&si6;
	si_len = sizeof(si6);
	sin_port = &si6.sin6_port;
	memset(&si6, 0, sizeof(si6));
#endif

	si.sin_family = AF_INET;
#ifdef SIN_LEN
	si.sin_len = sizeof(si);
#endif
	si.sin_addr.s_addr = htonl(INADDR_ANY);
#ifdef AF_INET6
	si6.sin6_family = AF_INET6;
#ifdef SIN6_LEN
	si6.sin6_len = sizeof(si);
#endif
	si6.sin6_addr = in6addr_any;
	si6.sin6_flowinfo = 0;
#endif

	int sock = -1, csock = -1;	// data and control (we treat the streams the same here)
	unsigned short port = 6000;
	while (1)
	{
		if (sock < 0)
			sock = socket(type, SOCK_DGRAM, IPPROTO_UDP);
#ifdef AF_INET6
		if (sock == -1 && type == AF_INET6)
		{
			// try fallback to IPv4
			type = AF_INET;
			si_p = (struct sockaddr *)&si;
			si_len = sizeof(si);
			sin_port = &si.sin_port;
			continue;
		}
#endif
		if (sock == -1)
			die("Can't create data socket!");

		if (csock < 0)
			csock = socket(type, SOCK_DGRAM, IPPROTO_UDP);
		if (csock == -1)
			die("Can't create control socket!");

		*sin_port = htons(port);
		int bind1 = bind(sock, si_p, si_len);
		*sin_port = htons(port + 1);
		int bind2 = bind(csock, si_p, si_len);

		if (bind1 != -1 && bind2 != -1)
			break;
		if (bind1 != -1)
		{
			close(sock);
			sock = -1;
		}
		if (bind2 != -1)
		{
			close(csock);
			csock = -1;
		}

		port += 3;
	}

	hairtunes_debug("port: %d\n", port);	// let our handler know where we end up listening
	hairtunes_debug("cport: %d\n", port + 1);

	pthread_t rtp_thread;
	rtp_sockets[0] = sock;
	rtp_sockets[1] = csock;
	/*
	int shmid = shmget(BUF_KEY, 0, 0);
	void *buf = shmat(shmid, 0, 0);
	memcpy(buf + 12, &sock, 4);
	memcpy(buf + 16, &csock, 4);
	shmdt(buf);
	*/
	hairtunes_slog( "rtp_sockets[0]: %d, rtp_sockets[1]: %d\n", rtp_sockets[0], rtp_sockets[1]);
	pthread_attr_t AVAttr;		
	pthread_attr_init(&AVAttr);
	pthread_attr_setstacksize(&AVAttr, 1*1024*1024);
	pthread_create(&rtp_thread, &AVAttr, rtp_thread_func, (void *)rtp_sockets);
	pthread_attr_destroy(&AVAttr);
	return port;
}

static short lcg_rand(void)
{
	static unsigned long lcg_prev = 12345;
	lcg_prev = lcg_prev * 69069 + 3;
	return lcg_prev & 0xffff;
}

static inline short dithered_vol(short sample)
{
	static short rand_a, rand_b;
	long out;

	out = (long)sample *fix_volume;
	if (fix_volume < 0x10000)
	{
		rand_b = rand_a;
		rand_a = lcg_rand();
		out += rand_a;
		out -= rand_b;
	}
	return out >> 16;
}

typedef struct {
	double hist[2];
	double a[2];
	double b[3];
} biquad_t;

static void biquad_init(biquad_t * bq, double a[], double b[])
{
	bq->hist[0] = bq->hist[1] = 0.0;
	memcpy(bq->a, a, 2 * sizeof(double));
	memcpy(bq->b, b, 3 * sizeof(double));
}

static void biquad_lpf(biquad_t * bq, double freq, double Q)
{
	double w0 = 2.0 * M_PI * freq * frame_size / (double)sampling_rate;
	double alpha = sin(w0) / (2.0 * Q);

	double a_0 = 1.0 + alpha;
	double b[3], a[2];
	b[0] = (1.0 - cos(w0)) / (2.0 * a_0);
	b[1] = (1.0 - cos(w0)) / a_0;
	b[2] = b[0];
	a[0] = -2.0 * cos(w0) / a_0;
	a[1] = (1 - alpha) / a_0;

	biquad_init(bq, a, b);
}

static double biquad_filt(biquad_t * bq, double in)
{
	double w = in - bq->a[0] * bq->hist[0] - bq->a[1] * bq->hist[1];
	double out = bq->b[1] * bq->hist[0] + bq->b[2] * bq->hist[1] + bq->b[0] * w;
	bq->hist[1] = bq->hist[0];
	bq->hist[0] = w;

	return out;
}

static double bf_est_drift = 0.0;	// local clock is slower by
static biquad_t bf_drift_lpf;
static double bf_est_err = 0.0, bf_last_err;
static biquad_t bf_err_lpf, bf_err_deriv_lpf;
static double desired_fill;
static int fill_count;

static void bf_est_reset(short fill)
{
	biquad_lpf(&bf_drift_lpf, 1.0 / 180.0, 0.3);
	biquad_lpf(&bf_err_lpf, 1.0 / 10.0, 0.25);
	biquad_lpf(&bf_err_deriv_lpf, 1.0 / 2.0, 0.2);
	fill_count = 0;
	bf_playback_rate = 1.0;
	bf_est_err = bf_last_err = 0;
	desired_fill = fill_count = 0;
}

static void bf_est_update(short fill)
{
    // the rate-matching system needs to decide how full to keep the buffer.
    // the initial fill is present when the system starts to output samples,
    // but most output chains will instantly gobble their own buffer's worth of
    // data. we average for a while to decide where to draw the line.
    if (fill_count < 1000) {
        desired_fill += (double)fill/1000.0;
        fill_count++;
        return;
    } else if (fill_count == 1000) {
        // this information could be used to help estimate our effective latency?
        fill_count++;
    }

#define CONTROL_A   (1e-4)
#define CONTROL_B   (1e-1)

	double buf_delta = fill - desired_fill;
	bf_est_err = biquad_filt(&bf_err_lpf, buf_delta);
	double err_deriv = biquad_filt(&bf_err_deriv_lpf, bf_est_err - bf_last_err);
	double adj_error = CONTROL_A * bf_est_err;

	bf_est_drift = biquad_filt(&bf_drift_lpf, CONTROL_B * (adj_error + err_deriv) + bf_est_drift);

	if (debug)
		printf( "bf %d err %f drift %f desiring %f ed %f estd %f\n", fill, bf_est_err, bf_est_drift, desired_fill, err_deriv, err_deriv + adj_error);
	bf_playback_rate = 1.0 + adj_error + bf_est_drift;

	bf_last_err = bf_est_err;
}

// get the next frame, when available. return 0 if underrun/stream reset.
static short *buffer_get_frame(void)
{
	short buf_fill;
	seq_t read;
	abuf_t *abuf = 0;
	unsigned short next;
	int i;

	pthread_mutex_lock(&ab_mutex);

	buf_fill = ab_write - ab_read;
	if (buf_fill < 1 || !ab_synced || ab_buffering)
	{							// init or underrun. stop and wait
		printf("[warning]fill=%d sync=%d buffering=%d\n", buf_fill, ab_synced, ab_buffering); 
		if (ab_synced)
			hairtunes_slog( "\nunderrun.\n");

		ab_buffering = 1;
		pthread_cond_wait(&ab_buffer_ready, &ab_mutex);
		ab_read++;
		buf_fill = ab_write - ab_read;
		bf_est_reset(buf_fill);
		pthread_mutex_unlock(&ab_mutex);

		return 0;
	}
	if (buf_fill >= BUFFER_FRAMES)
	{							// overrunning! uh-oh. restart at a sane distance
		printf("[warning]%s(%d)buf_fill overflow\n", __FUNCTION__, __LINE__); 
		hairtunes_slog( "\noverrun.\n");
		ab_read = ab_write - buffer_start_fill;
	}
	read = ab_read;
	ab_read++;
	buf_fill = ab_write - ab_read;
	bf_est_update(buf_fill);

	// check if t+16, t+32, t+64, t+128, ... (START_FILL / 2)
	// packets have arrived... last-chance resend
	if (!ab_buffering)
	{
		for (i = 16; i < (START_FILL / 2); i = (i * 2))
		{
			next = ab_read + i;
			abuf = audio_buffer + BUFIDX(next);
			if (!abuf->ready)
			{
				rtp_request_resend(next, next);
			}
		}
	}

	abuf_t *curframe = audio_buffer + BUFIDX(read);
	if (!curframe->ready)
	{
		hairtunes_slog( "\nmissing frame.\n");
		memset(curframe->data, 0, FRAME_BYTES);
	}
	curframe->ready = 0;
	pthread_mutex_unlock(&ab_mutex);

	return curframe->data;
}

static int stuff_buffer(double playback_rate, short *inptr, short *outptr)
{
	int i;
	int stuffsamp = frame_size;
	int stuff = 0;
	double p_stuff;

	p_stuff = 1.0 - pow(1.0 - fabs(playback_rate - 1.0), frame_size);

	if (rand() < p_stuff * RAND_MAX)
	{
		stuff = playback_rate > 1.0 ? -1 : 1;
		stuffsamp = rand() % (frame_size - 1);
	}

	pthread_mutex_lock(&vol_mutex);
	for (i = 0; i < stuffsamp; i++)
	{							// the whole frame, if no stuffing
		*outptr++ = dithered_vol(*inptr++);
		*outptr++ = dithered_vol(*inptr++);
	};
	if (stuff)
	{
		if (stuff == 1)
		{
			if (debug)
				printf( "+++++++++\n");
			// interpolate one sample
			*outptr++ = dithered_vol(((long)inptr[-2] + (long)inptr[0]) >> 1);
			*outptr++ = dithered_vol(((long)inptr[-1] + (long)inptr[1]) >> 1);
		}
		else if (stuff == -1)
		{
			if (debug)
				printf( "---------\n");
			inptr++;
			inptr++;
		}
		for (i = stuffsamp; i < frame_size + stuff; i++)
		{
			*outptr++ = dithered_vol(*inptr++);
			*outptr++ = dithered_vol(*inptr++);
		}
	}
	pthread_mutex_unlock(&vol_mutex);

	return frame_size + stuff;
}

#define NUM_CHANNELS 2

static void handle_broken_fifo()
{
	close(pipe_handle);
	pipe_handle = -1;
}

static void init_pipe(const char *pipe)
{
	// make the FIFO and catch the broken pipe signal
	mknod(pipe, S_IFIFO | 0644, 0);
	signal(SIGPIPE, handle_broken_fifo);
}

#ifdef AUDIO_DSP_PLAY
static void init_dsp()
{

	int ret = Airplay_MW_IF_AudioStop();
	if (ret != AIRPLAY_MW_SUCCESS)
	{
		hairtunes_slog( "Stop audio on dsp failed!\n");
	}
	ret = Airplay_MW_IF_AudioInit();
	if (ret != AIRPLAY_MW_SUCCESS)
	{
		hairtunes_slog( "Initial audio dsp play failed!\n");
	}
}
#else
static void *init_ao(void)
{
	ao_initialize();

	int driver;
	if (libao_driver)
	{
		// if a libao driver is specified on the command line, use that
		driver = ao_driver_id(libao_driver);
		if (driver == -1)
		{
			die("Could not find requested ao driver");
		}
	}
	else
	{
		// otherwise choose the default
		driver = ao_default_driver_id();
	}

	ao_sample_format fmt;
	memset(&fmt, 0, sizeof(fmt));

	fmt.bits = 16;
	fmt.rate = sampling_rate;
	fmt.channels = NUM_CHANNELS;
	fmt.byte_format = AO_FMT_NATIVE;

	ao_option *ao_opts = NULL;
	if (libao_deviceid)
	{
		ao_append_option(&ao_opts, "id", libao_deviceid);
	}
	else if (libao_devicename)
	{
		ao_append_option(&ao_opts, "dev", libao_devicename);
		// Old libao versions (for example, 0.8.8) only support
		// "dsp" instead of "dev".
		ao_append_option(&ao_opts, "dsp", libao_devicename);
	}

	ao_device *dev = ao_open_live(driver, &fmt, ao_opts);
	if (dev == NULL)
	{
		die("Could not open ao device");
	}

	return dev;
}
#endif
static int init_output(void)
{
	HAIRTUNES_SLOG();

	void *arg = 0;

	if (pipename)
	{
		init_pipe(pipename);
	}
	else
	{
#ifdef AUDIO_DSP_PLAY
		init_dsp();
#else
		arg = init_ao();
#endif
	}

#ifdef FANCY_RESAMPLING
	int err;
	if (fancy_resampling)
		src = src_new(SRC_SINC_MEDIUM_QUALITY, 2, &err);
	else
		src = 0;
#endif

	pthread_t audio_thread;
	pthread_attr_t AVAttr;
	pthread_attr_init(&AVAttr);
	pthread_attr_setstacksize(&AVAttr, 1*1024*1024);
	pthread_create(&audio_thread, &AVAttr, audio_thread_func, arg);
	pthread_attr_destroy(&AVAttr);
	return 0;
}
