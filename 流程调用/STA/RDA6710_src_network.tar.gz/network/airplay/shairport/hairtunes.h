#ifndef _HAIRTUNES_H_
#define _HAIRTUNES_H_
typedef void (*timer_update_cbk_t)(unsigned int);

int _Start_AudioPlay(int fd_socket);
int _Flush_AudioPlay(int fd_socket);

void hairtunes_setvolume(double f);

void hairtunes_setflush();
void hairtunes_exit();
void hairtunes_reset();
int hairtunes_decoder_init();
void hairtunes_buffer_init(void);
int hairtunes_rtp_init(void);
int hairtunes_output_init(void);
void hairtunes_setparam(char *pAeskey, char *pAesiv, char *fmtpstr, int pCtrlPort, int pTimingPort, int pDataPort, char *pRtpHost, char *pPipeName, int bufStartFill);

int hairtunes_init(char *pAeskey, char *pAesiv, char *fmtpstr, int pCtrlPort, int pTimingPort,
         int pDataPort, char *pRtpHost, char*pPipeName, char *pLibaoDriver, char *pLibaoDeviceName, char *pLibaoDeviceId,
         int bufStartFill, char *serverport);
int rtp_socket_close();
void hairtunes_register_cbk(timer_update_cbk_t cbk);
void hairtunes_reset_timestamp(void);
// default buffer size
// needs to be a power of 2 because of the way BUFIDX(seqno) works
#define BUFFER_FRAMES  512

#endif 
