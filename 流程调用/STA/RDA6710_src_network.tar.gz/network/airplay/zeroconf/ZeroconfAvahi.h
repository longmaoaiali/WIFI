//#pragma once
/*
 *      Copyright (C) 2005-2012 Team XBMC
 *      http://www.xbmc.org
 *
 *  This Program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *
 *  This Program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with XBMC; see the file COPYING.  If not, see
 *  <http://www.gnu.org/licenses/>.
 *
 */
 #ifndef __ZEROCONF_AVAHI_H__
#define  __ZEROCONF_AVAHI_H__

//#include "system.h"

#define HAS_AVAHI
#ifdef HAS_AVAHI
#include <stdio.h>
#include <string.h>
#include <pthread.h>
//#include <memory>
//#include <map>
//#include <string>
//#include "network/Zeroconf.h"

//#include <boost/shared_ptr.hpp>
#include "avahi-client/client.h"
#include "avahi-client/publish.h"
#include "avahi-common/defs.h"
#include "avahi-client/client.h"
#include "avahi-common/thread-watch.h"
#include "avahi-common/alternative.h"
#include "avahi-common/error.h"
#include "avahi-common/malloc.h"
#include "types.h"
#include "stddef.h"
#include "ZeroconfAvahi.h"
#include "gsl/gl_types.h"

#if 0
class CZeroconfAvahi : public CZeroconf
{
public:
        CZeroconfAvahi();
        ~CZeroconfAvahi();

protected:
        //implement base CZeroConf interface
        virtual bool doPublishService(const std::string& fcr_identifier,
                                      const std::string& fcr_type,
                                      const std::string& fcr_name,
                                      unsigned int f_port,
                                      std::map<std::string, std::string> txt);

        virtual bool doRemoveService(const std::string& fcr_ident);

        virtual void doStop();

private:
        ///this is where the client calls us if state changes
        static void clientCallback(AvahiClient* fp_client, AvahiClientState f_state, void*);
        ///here we get notified of group changes
        static void groupCallback(AvahiEntryGroup *fp_group, AvahiEntryGroupState f_state, void *);
        //shutdown callback; works around a problem in avahi < 0.6.24 see destructor for details
        static void shutdownCallback(AvahiTimeout *fp_e, void *);

        ///creates the avahi client;
        ///@return true on success
        bool createClient();

        //don't access stuff below without stopping the client thread
        //see http://avahi.org/wiki/RunningAvahiClientAsThread
        //and use struct ScopedEventLoopBlock

        //helper struct for holding information about creating a service / AvahiEntryGroup
        //we have to hold that as it's needed to recreate the service
        class ServiceInfo;
        typedef std::map<std::string, boost::shared_ptr<ServiceInfo> > tServiceMap;

        //goes through a list of todos and publishs them (takes the client a param, as it might be called from
        // from the callbacks)
        void updateServices(AvahiClient* fp_client);
        //helper that actually does the work of publishing
        void addService(tServiceMap::mapped_type fp_service_info, AvahiClient* fp_client);

        AvahiClient* mp_client;
        AvahiThreadedPoll* mp_poll;

        //this holds all published and unpublished services including info on howto create them
        tServiceMap m_services;

        //2 variables below are needed for workaround of avahi bug (see destructor for details)
        bool m_shutdown;
        pthread_t m_thread_id;
};
#endif

#define SER_NAME_LEN 256
#define SER_TYPE_LEN 128
#define ONRUN_PUBLISH_SERVICE 1
#define SHUTDOWN_PUBLISH_SERVICE 2

typedef enum
{
        AVAHI_RAOP_SERVICE,
        AVAHI_AIRPLAY_SERVICE,
        AVAHI_SERVICE_MAX
} AvahiSerType;
///helper to store information on howto create an avahi-group to publish
typedef struct _ServiceInfo
{
        int m_shutdown;  //0 onrun  1 shutdown
        AvahiSerType  SerType;
        char type[SER_TYPE_LEN];
        char  SerName[SER_NAME_LEN];
        unsigned int Port;
        AvahiStringList* Txt;
        AvahiEntryGroup* mp_group;
        AvahiClient* mp_client;
        AvahiThreadedPoll* mp_poll;
        pthread_t m_thread_id;
}ServiceInfo;

//implement base CZeroConf interface
extern int AvahidoPublishService(ServiceInfo* pAvahiServic, AvahiSerType  SerType, char*  SerName, unsigned int Port, AvahiStringList*   txt);

extern int AvahidoRemoveService(ServiceInfo* pAvahiServic);

void AvahidoStop(ServiceInfo* pAvahiServic);

///this is where the client calls us if state changes
void AvahiclientCallback(AvahiClient* fp_client, AvahiClientState f_state, void*fp_data);
///here we get notified of group changes
void AvahigroupCallback(AvahiEntryGroup *fp_group, AvahiEntryGroupState f_state, void *fp_data);
//shutdown callback; works around a problem in avahi < 0.6.24 see destructor for details
void AvahishutdownCallback(AvahiTimeout *fp_e, void *fp_data);

///creates the avahi client;
///@return true on success
int AvahicreateClient(ServiceInfo* pAvahiServic);

//don't access stuff below without stopping the client thread
//see http://avahi.org/wiki/RunningAvahiClientAsThread
//and use struct ScopedEventLoopBlock

//goes through a list of todos and publishs them (takes the client a param, as it might be called from
// from the callbacks)
void AvahiupdateServices(AvahiClient* fp_client);
//helper that actually does the work of publishing

void AvahiaddService(ServiceInfo * fp_service_info, AvahiClient* fp_client);
extern ServiceInfo* ZeroconfAvahiNew();
extern void ZeroconfAvahiFree(ServiceInfo* pAvahiServic);

//AvahiClient* mp_client;
//AvahiThreadedPoll* mp_poll;

//this holds all published and unpublished services including info on howto create them
// tServiceMap m_services;

 // int m_shutdown;
 //pthread_t m_thread_id;

#endif // HAS_AVAHI


#endif
