/*
 *      Copyright (C) 2005-2012 Team XBMC
 *      http://www.xbmc.org
 *
 *  This Program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2, or (at your option)
 *  any later version.
 *
 *  This Program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with XBMC; see the file COPYING.  If not, see
 *  <http://www.gnu.org/licenses/>.
 *
 */

//#include "PlatformDefs.h"
#include "ZeroconfAvahi.h"

#ifdef HAS_AVAHI

//#include <iostream>
//#include <sstream>
//#include <cassert>
//#include <unistd.h> //gethostname

//#include <utils/log.h>

#define ZERO_AVAHI_TRACE
#ifdef ZERO_AVAHI_TRACE
#define ZeroAvahiPrintf(fmt, arg...) printf( "[ZeroconfAvahi][FUNC:%s][LINE:%d]"fmt"\n",   __FUNCTION__, __LINE__, ##arg)
#else
#define ZeroAvahiPrintf(fmt, arg...)
#endif

ServiceInfo* ZeroconfAvahiNew()
{
        ZeroAvahiPrintf();
        ServiceInfo* pAvahiServic = (ServiceInfo*)GL_MemAlloc(sizeof(ServiceInfo));
        if(!pAvahiServic)
                return NULL;

        memset(pAvahiServic, 0x0, sizeof(ServiceInfo));
        if (! (pAvahiServic->mp_poll = avahi_threaded_poll_new()))
        {
                ZeroAvahiPrintf("CZeroconfAvahi::CZeroconfAvahi(): Could not create threaded poll object");
                //TODO: throw exception?
                return NULL;
        }
        if (!AvahicreateClient(pAvahiServic))
        {
                ZeroAvahiPrintf("CZeroconfAvahi::CZeroconfAvahi(): Could not create client");
                //yeah, what if not? but should always succeed
        }

        //start event loop thread
        if (avahi_threaded_poll_start(pAvahiServic->mp_poll) < 0)
        {
                ZeroAvahiPrintf("CZeroconfAvahi::CZeroconfAvahi(): Failed to start avahi client thread");
        }

        return pAvahiServic;
}

void ZeroconfAvahiFree(ServiceInfo* pAvahiServic)
{
        ZeroAvahiPrintf();
        if(!pAvahiServic)
                return ;

        if (pAvahiServic->mp_poll)
        {
                //normally we would stop the avahi thread here and do our work, but
                //it looks like this does not work -> www.avahi.org/ticket/251
                //so instead of calling
                //avahi_threaded_poll_stop(mp_poll);
                //we set m_shutdown=true, post an event and wait for it to stop itself
                struct timeval tv = { 0, 0 }; //TODO: does tv survive the thread?
                AvahiTimeout* lp_timeout;
                {
                        avahi_threaded_poll_lock(pAvahiServic->mp_poll);
                        const AvahiPoll* cp_apoll = avahi_threaded_poll_get(pAvahiServic->mp_poll);
                        pAvahiServic->m_shutdown = SHUTDOWN_PUBLISH_SERVICE;
                        lp_timeout = cp_apoll->timeout_new(cp_apoll,
                                                           &tv,
                                                           AvahishutdownCallback,
                                                           (void*)pAvahiServic/* this*/);

                        avahi_threaded_poll_unlock(pAvahiServic->mp_poll);
                }

                //now wait for the thread to stop
                //assert(m_thread_id);
                pthread_join(pAvahiServic->m_thread_id, NULL);
                avahi_threaded_poll_get(pAvahiServic->mp_poll)->timeout_free(lp_timeout);
        }

        //free the client (frees all browsers, groups, ...)
        if (pAvahiServic->mp_client)
                avahi_client_free(pAvahiServic->mp_client);
        if (pAvahiServic->mp_poll)
                avahi_threaded_poll_free(pAvahiServic->mp_poll);

        if(pAvahiServic)
        {
                GL_MemFree(pAvahiServic);
                pAvahiServic = NULL;
        }
}

int AvahidoPublishService(ServiceInfo* pAvahiServic,
                          AvahiSerType  SerType,
                          char*  SerName,
                          unsigned int Port,
                          AvahiStringList*       txt)
{
        ZeroAvahiPrintf();
        if(!pAvahiServic)
                return false;
        //AvahiThreadedPoll* tempmp_poll = pAvahiServic->mp_poll;
		//tempmp_poll = NULL;

        avahi_threaded_poll_lock(pAvahiServic->mp_poll);

        //create service info and add it to service map
        pAvahiServic->m_shutdown = ONRUN_PUBLISH_SERVICE;
        pAvahiServic->SerType = SerType;
        strncpy(pAvahiServic->SerName, SerName, SER_NAME_LEN);
        pAvahiServic->Port = Port;
        pAvahiServic->Txt = txt;
        switch(SerType)
        {
                case AVAHI_RAOP_SERVICE:
                        strcpy(pAvahiServic->type,  "_raop._tcp");
                        break;
                case AVAHI_AIRPLAY_SERVICE:
                        strcpy(pAvahiServic->type,  "_airplay._tcp");
                        break;
                default:
                        break;
        }

        //if client is already running, directly try to add the new service
        if ( pAvahiServic->mp_client && avahi_client_get_state(pAvahiServic->mp_client) ==  AVAHI_CLIENT_S_RUNNING )
        {
                //client's already running, add this new service
                AvahiaddService(pAvahiServic, pAvahiServic->mp_client);
        }
        else
        {
                ZeroAvahiPrintf( "CZeroconfAvahi::doPublishService: client not running, queued for publishing");
        }
        ZeroAvahiPrintf();

        avahi_threaded_poll_unlock(pAvahiServic->mp_poll);
        return true;
}

int AvahidoRemoveService(ServiceInfo* pAvahiServic)
{
        ZeroAvahiPrintf();
        if(!pAvahiServic)
                return false;

        if(ONRUN_PUBLISH_SERVICE != pAvahiServic->m_shutdown)
                return true;
        ZeroAvahiPrintf();

        avahi_threaded_poll_lock(pAvahiServic->mp_poll);
        if (pAvahiServic->mp_group)
        {
                avahi_entry_group_free(pAvahiServic->mp_group);
                pAvahiServic->mp_group = 0;
        }

        if(pAvahiServic->Txt)
        {
                avahi_string_list_free(pAvahiServic->Txt);
                pAvahiServic->Txt = NULL;
        }

        pAvahiServic->m_shutdown = SHUTDOWN_PUBLISH_SERVICE;

        avahi_threaded_poll_unlock(pAvahiServic->mp_poll);
        ZeroAvahiPrintf();

        return true;
}

void AvahidoStop(ServiceInfo* pAvahiServic)
{
        ZeroAvahiPrintf();
        if(!pAvahiServic)
                return ;

        avahi_threaded_poll_lock(pAvahiServic->mp_poll);

        if (pAvahiServic->mp_group)
        {
                avahi_entry_group_free(pAvahiServic->mp_group);
                pAvahiServic->mp_group = 0;
        }

        if(pAvahiServic->Txt)
        {
                avahi_string_list_free(pAvahiServic->Txt);
                pAvahiServic->Txt = NULL;
        }
        pAvahiServic->m_shutdown = SHUTDOWN_PUBLISH_SERVICE;

        avahi_threaded_poll_unlock(pAvahiServic->mp_poll);
}

void AvahiclientCallback(AvahiClient* fp_client, AvahiClientState f_state, void*fp_data)
{
        ZeroAvahiPrintf();
        ServiceInfo* p_instance = (ServiceInfo*)fp_data;

        //store our thread ID and check for shutdown -> check details in destructor
        p_instance->m_thread_id = pthread_self();

        if (p_instance->m_shutdown == SHUTDOWN_PUBLISH_SERVICE)
        {
                avahi_threaded_poll_quit(p_instance->mp_poll);
                return;
        }
        switch(f_state)
        {
                case AVAHI_CLIENT_S_RUNNING:
                        ZeroAvahiPrintf("CZeroconfAvahi::clientCallback: client is up and running");
                        AvahiupdateServices(fp_client);
                        break;

                case AVAHI_CLIENT_FAILURE:
                {
                        int i;
                        ZeroAvahiPrintf("CZeroconfAvahi::clientCallback: client failure. avahi-daemon stopped? Recreating client...");
                        //We were forced to disconnect from server. now free and recreate the client object
                        avahi_client_free(fp_client);
                        p_instance->mp_client = 0;
                        //freeing the client also frees all groups and browsers, pointers are undefined afterwards, so fix that now
                        for(i = 0; i < AVAHI_SERVICE_MAX; i++)
                        {
                                ;// AvahiSerArry[i].mp_group= 0;
                        }
                        //AvahicreateClient();
                }
                break;

                case AVAHI_CLIENT_S_COLLISION:
                case AVAHI_CLIENT_S_REGISTERING:
                        //HERE WE SHOULD REMOVE ALL OF OUR SERVICES AND "RESCHEDULE" them for later addition
                        ZeroAvahiPrintf("CZeroconfAvahi::clientCallback: uiuui; coll or reg, anyways, resetting groups");
                        {
                                int i;
                                for(i = 0; i < AVAHI_SERVICE_MAX; i++)
                                {
                                        ;//  if ( AvahiSerArry[i].mp_group)
                                        //    avahi_entry_group_reset( AvahiSerArry[i].mp_group);
                                }
                        }
                        break;

                case AVAHI_CLIENT_CONNECTING:
                        ZeroAvahiPrintf("CZeroconfAvahi::clientCallback: avahi server not available. But may become later...");
                        break;
        }
}

void AvahigroupCallback(AvahiEntryGroup *fp_group, AvahiEntryGroupState f_state, void *fp_data)
{
        ServiceInfo* p_instance = (ServiceInfo*)fp_data;
        //store our thread ID and check for shutdown -> check details in destructor
        ZeroAvahiPrintf();
        p_instance->m_thread_id = pthread_self();
        if (p_instance->m_shutdown == SHUTDOWN_PUBLISH_SERVICE)
        {
                avahi_threaded_poll_quit(p_instance->mp_poll);
                return;
        }

        switch (f_state)
        {
                case AVAHI_ENTRY_GROUP_ESTABLISHED :
                        // The entry group has been established successfully
                        ZeroAvahiPrintf("CZeroconfAvahi::groupCallback: Service successfully established");
                        break;

                case AVAHI_ENTRY_GROUP_COLLISION :
                {
                        //need to find the ServiceInfo struct for this group
                        int i;
                        for(i = 0; i < AVAHI_SERVICE_MAX; i++)
                        {
                                // if ( AvahiSerArry[i].mp_group == fp_group)
                                break;
                        }
#if 0
                        if( it != p_instance->m_services.end() )
                        {
                                char* alt_name = avahi_alternative_service_name( it->second->m_name.c_str() );
                                it->second->m_name = alt_name;
                                avahi_free(alt_name);
                                ZeroAvahiPrintf("CZeroconfAvahi::groupCallback: Service name collision. Renamed to: %s", it->second->m_name.c_str());
                                p_instance->addService(it->second, p_instance->mp_client);
                        }
#endif
                        break;
                }

                case AVAHI_ENTRY_GROUP_FAILURE:
                        ZeroAvahiPrintf("CZeroconfAvahi::groupCallback: Entry group failure: %s ",
                                        (fp_group) ?
                                        avahi_strerror(avahi_client_errno(avahi_entry_group_get_client(fp_group)))
                                        : "Unknown");
                        //free the group and set to 0 so it may be added later
                        if (fp_group)
                        {
                                //need to find the ServiceInfo struct for this group
                                /*    int i;
                                    for(i = 0; i < AVAHI_SERVICE_MAX; i++)
                                    {
                                            if ( AvahiSerArry[i].mp_group == fp_group)
                                            {
                                                    avahi_entry_group_free( AvahiSerArry[i].mp_group);
                                                    AvahiSerArry[i].mp_group = 0;
                                                    if ( AvahiSerArry[i].Txt)
                                                    {
                                                            avahi_string_list_free(AvahiSerArry[i].Txt);
                                                            AvahiSerArry[i].Txt= NULL;
                                                    }
                                                    break;
                                            }
                                    }*/
                        }
                        break;

                case AVAHI_ENTRY_GROUP_UNCOMMITED:
                case AVAHI_ENTRY_GROUP_REGISTERING:
                default:
                        break;
        }
}

void AvahishutdownCallback(AvahiTimeout *fp_e, void *fp_data)
{
        ServiceInfo* p_instance = (ServiceInfo*)fp_data;
        //should only be called on shutdown
        ZeroAvahiPrintf();
        if (p_instance->m_shutdown == SHUTDOWN_PUBLISH_SERVICE)
        {
                avahi_threaded_poll_quit(p_instance->mp_poll);
        }
}

int AvahicreateClient(ServiceInfo* pAvahiServic)
{
        ZeroAvahiPrintf();
        if (pAvahiServic->mp_client)
        {
                avahi_client_free(pAvahiServic->mp_client);
        }
        pAvahiServic->mp_client = avahi_client_new(avahi_threaded_poll_get(pAvahiServic->mp_poll),
                                  AVAHI_CLIENT_NO_FAIL, &AvahiclientCallback,(void*)pAvahiServic,0);
        if (!pAvahiServic->mp_client)
                return false;
        return true;
}

void AvahiupdateServices(AvahiClient* fp_client)
{
        //  int i;
        ZeroAvahiPrintf();
        /*for(i = 0; i < AVAHI_SERVICE_MAX; i++)
        {
                if (!AvahiSerArry[i].mp_group )
                        AvahiaddService(&AvahiSerArry[i], fp_client);
        }*/
}

void AvahiaddService(ServiceInfo * fp_service_info, AvahiClient* fp_client)
{
        //assert(fp_client);
        ZeroAvahiPrintf();
        //create the group if it doesn't exist
        if (!fp_service_info->mp_group)
        {
                ZeroAvahiPrintf();
                if (!(fp_service_info->mp_group = avahi_entry_group_new(fp_client, &AvahigroupCallback, (void*)fp_service_info)))
                {
                        ZeroAvahiPrintf();
                        fp_service_info->mp_group = 0;
                        return;
                }
        }

        ZeroAvahiPrintf();

        // add entries to the group if it's empty
        int ret;
        if (avahi_entry_group_is_empty(fp_service_info->mp_group))
        {
                ZeroAvahiPrintf();
                if ((ret = avahi_entry_group_add_service_strlst(fp_service_info->mp_group, AVAHI_IF_UNSPEC, AVAHI_PROTO_UNSPEC, 0,
                                fp_service_info->SerName,
                                fp_service_info->type, NULL, NULL, fp_service_info->Port, fp_service_info->Txt) < 0))
                {
                        ZeroAvahiPrintf();
                        if (ret == AVAHI_ERR_COLLISION)
                        {
                                char* alt_name = avahi_alternative_service_name(fp_service_info->SerName);
                                strcpy(fp_service_info->SerName, alt_name);
                                avahi_free(alt_name);
                                ZeroAvahiPrintf();
                                AvahiaddService(fp_service_info, fp_client);
                                return;
                        }
                        ZeroAvahiPrintf();
                        return;
                }
        }
        ZeroAvahiPrintf();

        // Tell the server to register the service
        if ((ret = avahi_entry_group_commit(fp_service_info->mp_group)) < 0)
        {
                ZeroAvahiPrintf();

                // TODO what now? reset the group? free it?
        }
        ZeroAvahiPrintf();
}

#endif // HAS_AVAHI

