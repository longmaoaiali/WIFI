
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "http_parser.h"

//#define HTTP_PARSER_DEBUG

#define http_parser_printf(fmt, arg...)	printf("[HTTP PARSER][%s][%d]"fmt, __FUNCTION__, __LINE__, ##arg)

#ifdef HTTP_PARSER_DEBUG
#define HTTP_FUNC_INFO()	printf("[HTTP PARSER][%s][%d]\n", __FUNCTION__, __LINE__)
#define LINE() printf("[HTTP PARSER][LINE: %d]\n", __LINE__)
#else
#define HTTP_FUNC_INFO()	do{}while(0)
#define LINE()	do{}while(0)
#endif

#define CHECK_POINTER(XX) \
	do{	\
		if (XX == NULL)\
			return;	\
	}while(0)

		
#define  CR 13
#define  LF 10
#define  ANY 256

typedef enum Action {
	// make lower case
	LOWER = 0x1,

	// convert current character to null.
	NULLIFY = 0x2,

	// set the header index to the current position
	SET_HEADER_START = 0x4,

	// set the key index to the current position
	SET_KEY = 0x8,

	// set value index to the current position.
	SET_VALUE = 0x10,

	// store current key/value pair.
	STORE_KEY_VALUE = 0x20,

	// sets content start to current position + 1
	SET_CONTENT_START = 0x40
}ParserHeadAction_e;

typedef struct FSM_{
	ParserState_e curState;
	int c;
	ParserState_e nextState;
	unsigned actions;
}FSM;

static void StrAppend(HttpParser_t *pstHttpParser, const char *source, unsigned len)
{
	HTTP_FUNC_INFO();

	//http_parser_printf("Source string: %s\n", source);

	unsigned origion = pstHttpParser->dCurDataLen;	//not include '\0'
	void *dest = pstHttpParser->pTotalData;
	if (dest == NULL)
	{
		dest = (void *)malloc(origion + len +1);
		if (dest)
			memset(dest, 0x0, origion+len +1);
	}
	else
	{
		dest = (void *)realloc(pstHttpParser->pTotalData, origion + len+1);
		if (dest)
			memset(dest+origion, 0x0, len+1);
	}
	if (!dest)
	{
		return;
	}
	memcpy(dest+origion, (void *)source, len);
	//memcpy(&p[origion], (void *)source, len);
	pstHttpParser->dCurDataLen += len; 
	pstHttpParser->pTotalData = dest;
	//p[gpstHttpParser->dCurDataLen] = '\0';
}

static int StrFindChar(HttpParser_t *pstHttpParser, const char c, unsigned startPos)
{
	HTTP_FUNC_INFO();

	unsigned origion = pstHttpParser->dCurDataLen;
	unsigned i = 0;
	char *p = (char *)pstHttpParser->pTotalData;
	for (i = startPos; i<origion; i++)
	{
		if (p[i] == c)
		{
			return i;
		}
	}
	//if (i >= origion)
	{
		return -1;
	}
}
static void parseHeader(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	FSM fsm[] = {
		{ p_request_line,		CR, 	p_request_line_cr,		NULLIFY 									},
		{ p_request_line,		ANY,	p_request_line, 	0										},
		{ p_request_line_cr,		LF, 		p_request_line_crlf,		0									},
		{ p_request_line_crlf,	CR, 		p_request_line_crlfcr,	0									},
		{ p_request_line_crlf,	ANY,	p_key,				SET_HEADER_START | SET_KEY | LOWER	},
		{ p_request_line_crlfcr,	LF, 		p_content,			SET_CONTENT_START					},
		{ p_key,				':',		p_key_colon,			NULLIFY 								},
		{ p_key,				ANY,	p_key,				LOWER								},
		{ p_key_colon,			' ',		p_key_colon_sp, 	0										},
		{ p_key_colon_sp,		ANY,	p_value,				SET_VALUE							},
		{ p_value,				CR, 		p_value_cr, 		NULLIFY | STORE_KEY_VALUE				},
		{ p_value,				ANY,	p_value,				0									},
		{ p_value_cr,			LF, 		p_value_crlf,			0									},
		{ p_value_crlf, 			CR, 		p_value_crlfcr, 		0									},
		{ p_value_crlf, 			ANY,	p_key,				SET_KEY | LOWER 						},
		{ p_value_crlfcr,		LF, 		p_content,			SET_CONTENT_START					},
		{ p_error,				ANY,	p_error,				0									}
	};
	
	unsigned i = 0;
	char *pszData = (char *)pstHttpParser->pTotalData;
	unsigned _parsedTo = pstHttpParser->dParserTo;
	unsigned _length = pstHttpParser->dCurDataLen;
	ParserState_e _state = pstHttpParser->eParserState;
	
	for(i = _parsedTo; i < _length; ++i)
	{
		unsigned d = 0;
		char c = pszData[i];
		//http_parser_printf("pszData[%d]: %c\n", i, c);
		ParserState_e nextState = p_error;

		for (d = 0; d < sizeof(fsm) / sizeof(FSM); ++d)
		{
			if (fsm[d].curState == _state && (c == fsm[d].c || fsm[d].c == ANY))
			{
				nextState = fsm[d].nextState;

				if (fsm[d].actions & LOWER)
				{
					pszData[i] = tolower(pszData[i]);
				}

				if (fsm[d].actions & NULLIFY)
				{
					pszData[i] = 0;
				}

				if (fsm[d].actions & SET_HEADER_START)
				{
					pstHttpParser->dHeaderStart = i;
					//_headerStart = i;
				}

				if (fsm[d].actions & SET_KEY)
				{
					pstHttpParser->dKeyIndex = i;
					//_keyIndex = i;
				}

				if (fsm[d].actions & SET_VALUE)
				{
					pstHttpParser->dValueIndex = i;
					//_valueIndex = i;
				}

				if (fsm[d].actions & SET_CONTENT_START)
				{
					pstHttpParser->dContentStart = i+1;
					//_contentStart = i + 1;
				}

				if (fsm[d].actions & STORE_KEY_VALUE) 
				{
					// store position of first character of key.
					pstHttpParser->aKeys[pstHttpParser->dCurKeyNum++] = pstHttpParser->dKeyIndex;
					//_keys.push_back( _keyIndex );
					
				}

				break;
			}
	        }

		pstHttpParser->eParserState = _state = nextState;

		if (_state == p_content)
		{
			const char* str = getValue(pstHttpParser, "content-length");
			if (str)
			{
				pstHttpParser->dContentLen = atoi(str);
			}
			break;
	        }
	}

	pstHttpParser->dParserTo = _length;
}
static bool parseRequestLine(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	int sp1;
	int sp2;
	char *p = (char *)pstHttpParser->pTotalData;
	
	sp1 = StrFindChar(pstHttpParser, ' ', 0);
	//sp1 = _data.find( ' ', 0 );
	if (sp1 == -1) return false;
	sp2 = StrFindChar(pstHttpParser, ' ', sp1 + 1 );
	if (sp2 == -1) return false;

	p[sp1] = 0;
	p[sp2] = 0;
	pstHttpParser->dUriIndex = sp1+1;
	//_uriIndex = sp1 + 1;
	return true;
}

void releaseBytes(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	if (pstHttpParser->pTotalData)
		free(pstHttpParser->pTotalData);
	pstHttpParser->pTotalData = NULL;
}
AddDataState_e addBytes(HttpParser_t *pstHttpParser, const char* bytes, unsigned len )
{
	HTTP_FUNC_INFO();
	
	//http_parser_printf("eAddDataState: %d\n", pstHttpParser->eAddDataState);
	if (pstHttpParser->eAddDataState != AddDataIncomplete)
	{
		return pstHttpParser->eAddDataState;
	}
	/*
	gpstHttpParser->pTotalData = (void *)realloc(gpstHttpParser->dCurDataLen+len+1);
	memcpy(gpstHttpParser->pTotalData[gpstHttpParser->dCurDataLen], bytes, len);
	gpstHttpParser->dCurDataLen += len;
	gpstHttpParser->pTotalData[gpstHttpParser->dCurDataLen] = '\0';
	*/
	StrAppend(pstHttpParser, bytes, len);
	if (pstHttpParser->eParserState < p_content)
	{
		parseHeader(pstHttpParser);
	}

	if (pstHttpParser->eParserState == p_error)
	{
		pstHttpParser->eAddDataState = AddDataError;
	}
	else if (pstHttpParser->eParserState == p_content)
	{
		if (pstHttpParser->dContentLen == 0 
			||pstHttpParser->dCurDataLen-pstHttpParser->dContentStart >= pstHttpParser->dContentLen)
		{
			if (parseRequestLine(pstHttpParser))
			{
				pstHttpParser->eAddDataState = AddDataDone;
			}
			else
			{
				pstHttpParser->eAddDataState = AddDataError;
			}
		}
	}

	return pstHttpParser->eAddDataState;
}
const char* getMethod(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	char *p = (char *)pstHttpParser->pTotalData;
	return &p[0];
}
const char* getUri(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	char *p = (char *)pstHttpParser->pTotalData;
	return &p[pstHttpParser->dUriIndex];
}
const char* getQueryString(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	const char *position = getUri(pstHttpParser);
	while (*position)
	{
		if (*position == '?')
		{
			position++;
			break;
		}
		position++;
	}
	return position;
}
const char* getBody(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	if (pstHttpParser->dContentLen > 0)
	{
		char *p = (char *)pstHttpParser->pTotalData;
		return &p[pstHttpParser->dContentStart];
	}
	else
	{
		return NULL;
	}
}

const char* getItemFromBody(HttpParser_t *pstHttpParser, const char* key , int *len)
{
	HTTP_FUNC_INFO();

	const char *p = getBody(pstHttpParser);
	if (p)
	{
		char *tmpKey = NULL, *q_1 = NULL, *q_2= NULL;
		tmpKey = strstr(p, key);
		if (tmpKey)
		{
			LINE();
			q_1 = strchr(tmpKey+strlen(key)+strlen("</key>"), '>');
			if (q_1)
			{
				LINE();
				q_1++;
				q_2 = strchr(q_1, '<');
				if (q_2)
				{
					LINE();
					*len=q_2-q_1;
					return q_1;
				}
			}
		}
		else
		{
			return NULL;
		}
	}

	return NULL;
}
// key should be in lower case when looking up.
const char* getValue(HttpParser_t *pstHttpParser, const char* key )
{
	HTTP_FUNC_INFO();

	unsigned i = 0;
	unsigned index = 0;
	char *p = (char *)pstHttpParser->pTotalData;
	for (i = 0; i< pstHttpParser->dCurKeyNum; i++)
	{
		index = pstHttpParser->aKeys[i];
		if (strcmp(&p[index], key) == 0)
		{
			return &p[index+strlen(key)+2];
		}
	}

	return NULL;
}
unsigned getContentLength(HttpParser_t *pstHttpParser)
{
	HTTP_FUNC_INFO();

	return pstHttpParser->dContentLen;
}


