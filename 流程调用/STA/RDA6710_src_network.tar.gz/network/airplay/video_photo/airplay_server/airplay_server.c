#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <arpa/inet.h>
#include <time.h>
#include <ctype.h>
#include <fcntl.h>
#include <signal.h>

#include "gsl/gl_types.h"
#include "plist/plist.h"
//#include "types.h"
#include "airplay_server.h"
#include "airplay_if.h"
#include "dpswrape.h"

//-------------
#include "avahi-client/client.h"
#include "avahi-client/publish.h"
#include "avahi-common/defs.h"
#include "avahi-client/client.h"
#include "avahi-common/thread-watch.h"
#include "avahi-common/alternative.h"
#include "avahi-common/error.h"
#include "avahi-common/malloc.h"
#include "ZeroconfAvahi.h"

//#define SERVER_TRACE
#define SERVER_WARN
#define SERVER_ERROR

//#include "net/net_app/net_types.h"
//extern int  Net_IF_GetAddrsInfo(int sdEthIF, AddrsType_e eAddrType, char *buf);

#define SERVER_DEBUG

#ifdef SERVER_TRACE
#define airplay_log_trace(format, arg...)	printf("[AirlayServer Trace]"format, ##arg)
#else
#define airplay_log_trace(format, arg...)	do{}while(0)
#endif
#ifdef SERVER_WARN
#define airplay_log_warn(format, arg...)	printf("[AirlayServer Warn]"format, ##arg)
#else
#define airplay_log_warn(format, arg...)	do{}while(0)
#endif
#define airplay_log_error(format, arg...)	printf("[AirlayServer Error]"format, ##arg)

#ifdef SERVER_DEBUG
#define AIRPLAY_FUNC_INFO()	airplay_log_trace("[%s][%d]\n", __FUNCTION__, __LINE__)
#define LINE() airplay_log_trace("LINE: %d\n", __LINE__)
#else
#define AIRPLAY_FUNC_INFO()	do{}while(0)
#define LINE() do{}while(0)
#endif
#define RESPONED_HEADER_LEN	(50)

#define INVALID_SOCKET	(-1)
#define BACKLOG_MAX	(10)
#define PTHREAD_STACK_SIZE (4096)	//temp
#define CONNECT_MAX	(10)
#define RECEIVEBUFFER 	(1024)
#define PWD_SIZE	(256)
#define AIRPLAY_PORT	(7000)
#define SERVER_NAME	"Sunplus_AirPlay_xmc"

//define airplay status
#define AIRPLAY_STATUS_OK                  200
#define AIRPLAY_STATUS_SWITCHING_PROTOCOLS 101
#define AIRPLAY_STATUS_NEED_AUTH           401
#define AIRPLAY_STATUS_FORBIDDEN           403
#define AIRPLAY_STATUS_NOT_FOUND           404
#define AIRPLAY_STATUS_METHOD_NOT_ALLOWED  405
#define AIRPLAY_STATUS_NOT_IMPLEMENTED     501
#define AIRPLAY_STATUS_NO_RESPONSE_NEEDED  1000

#define AUTH_REALM "AirPlay"
#define AUTH_REQUIRED "WWW-Authenticate: Digest realm=\""  AUTH_REALM  "\", nonce=\"%s\"\r\n"
#define AIRPLAY_SERVER_VERSION_STR "101.28"

#define PLAYBACK_INFO  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>duration</key>\r\n"\
"<real>%f</real>\r\n"\
"<key>loadedTimeRanges</key>\r\n"\
"<array>\r\n"\
"\t\t<dict>\r\n"\
"\t\t\t<key>duration</key>\r\n"\
"\t\t\t<real>%f</real>\r\n"\
"\t\t\t<key>start</key>\r\n"\
"\t\t\t<real>0.0</real>\r\n"\
"\t\t</dict>\r\n"\
"</array>\r\n"\
"<key>playbackBufferEmpty</key>\r\n"\
"<true/>\r\n"\
"<key>playbackBufferFull</key>\r\n"\
"<false/>\r\n"\
"<key>playbackLikelyToKeepUp</key>\r\n"\
"<true/>\r\n"\
"<key>position</key>\r\n"\
"<real>%f</real>\r\n"\
"<key>rate</key>\r\n"\
"<real>%d</real>\r\n"\
"<key>readyToPlay</key>\r\n"\
"<true/>\r\n"\
"<key>seekableTimeRanges</key>\r\n"\
"<array>\r\n"\
"\t\t<dict>\r\n"\
"\t\t\t<key>duration</key>\r\n"\
"\t\t\t<real>%f</real>\r\n"\
"\t\t\t<key>start</key>\r\n"\
"\t\t\t<real>0.0</real>\r\n"\
"\t\t</dict>\r\n"\
"</array>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define PLAYBACK_INFO_NOT_READY  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>readyToPlay</key>\r\n"\
"<false/>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define SERVER_INFO  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>deviceid</key>\r\n"\
"<string>%s</string>\r\n"\
"<key>features</key>\r\n"\
"<integer>119</integer>\r\n"\
"<key>model</key>\r\n"\
"<string>AppleTV2,1</string>\r\n"\
"<key>protovers</key>\r\n"\
"<string>1.0</string>\r\n"\
"<key>srcvers</key>\r\n"\
"<string>"AIRPLAY_SERVER_VERSION_STR"</string>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define EVENT_INFO "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>category</key>\r\n"\
"<string>%s</string>\r\n"\
"<key>state</key>\r\n"\
"<string>%s</string>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"\

#define SLIDESHOW_EVENT_STOP_LOAD "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>category</key>\r\n"\
"<string>%s</string>\r\n"\
"<key>sessionID</key>\r\n"\
"<integer>%d</integer>\r\n"\
"<key>state</key>\r\n"\
"<string>%s</string>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define SLIDESHOW_EVENT_PLAY "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>category</key>\r\n"\
"<string>slideshow</string>\r\n"\
"<key>lastAssetID</key>\r\n"\
"<integer>%d</integer>\r\n"\
"<key>sessionID</key>\r\n"\
"<integer>%d</integer>\r\n"\
"<key>state</key>\r\n"\
"<string>playing</string>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define SLIDESHOW_FEATURES  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
"<plist version=\"1.0\">\r\n"\
"<dict>\r\n"\
"<key>themes</key>\r\n"\
"<array>\r\n"\
"<dict>\r\n"\
"<key>key</key>\r\n"\
"<string>Classic</string>\r\n"\
"<key>name</key>\r\n"\
"<string>Classic</string>\r\n"\
"</dict>\r\n"\
"</array>\r\n"\
"</dict>\r\n"\
"</plist>\r\n"

#define SLIDESHOW_RESPONE  "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"\
	"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\r\n"\
	"<plist version=\"1.0\">\r\n"\
	"<dict/>\r\n"\
	"</plist>\r\n"

const char *eventStrings[] = {"playing", "paused", "loading", "stopped"};

typedef enum {
	EVENT_NONE=-1,
	EVENT_PLAYING=0,
	EVENT_PAUSED=1,
	EVENT_LOADING=2,
	EVENT_STOPPED=3,
}Event_e;
typedef enum{
	SLIDESHOW_NOTHING = 0,
	SLIDESHOW_LOADING = 1,
	SLIDESHOW_PLAYING = 2,
	SLIDESHOW_STOPPED = 3,
}SlideAction_e;

typedef struct TcpClient_t_{
	int sdSocket;
	struct sockaddr stCliAddr;
	socklen_t dAddrLen;

	int sessionCounter;
	bool bAuthenticated;
	char authNonce[15]; //MD5
	Event_e eLastEvent;
	HttpParser_t stHttpParser;	//every tcp connection has a httpparser
}TcpClient_t;

typedef struct{
	int SlideShowTime;
	int lastID;
	int sessionID;
	int photoID;
	int eventSocket;
	int slideshowSocket;
	SlideAction_e elastSlideAction;
	//TcpClient_t *pstTcpClient;
	char slideshow_session[40];
	//char *pszHttpReq;
}SlideShowInfo_t;

typedef struct{
	int eventSocket;
	int sessionID;
	//TcpClient_t *pstTcpClient;
	Event_e eLastPlayState;
	char mediaplay_session[40];
	//char *pszHttpReq;
}MediaPlayInfo_t;

typedef struct ReverseSocket_t_{
	int sdSocket;
	char szSessionID[50];
	socklen_t dAddrLen;
}ReverseSocket_t;

typedef struct AirPlayServiceInfo_t_{
	char szType[10];
	char szName[10];
	int sdPort;
	//AvahiStringList * pstTxt;
	//AvahiEntryGroup* pstGroup;
}AirPlayServiceInfo_t;

typedef struct AirplayThread_t_{
	pthread_t hThread;
	bool bValidFlag;
}AirplayThread_t;

typedef enum PlayingMediaType_e_{
	PLAYING_NONE,
	PLAYING_PHOTO,
	PLAYING_VIDEO,
}MediaType_e;
typedef struct _AirplayServer_t{
	int dIsPlaying;
	//char tHWID[MACADDR_SIZE];
	char szMacAddr_Hex[MACADDR_HEX];

	MediaType_e eCurPlayType;

	unsigned dConnectionCnt;
	//this is not very effective, as a pointer would be better, for move memory bettween array member
	TcpClient_t stTcpClient[CONNECT_MAX];

	unsigned dReverseSocketCnt;
	ReverseSocket_t stReversSocket[CONNECT_MAX];

	int sdServerSocket;
	int sdPort;
	bool bNonLocal;

	bool bUsePwd;
	char szPwd[PWD_SIZE];
	//AvahiClient* pstAvahiClient;
	char *location;
	AirPlayServiceInfo_t stAirPlayService;
	SlideShowInfo_t stSlideShowInfo;
	MediaPlayInfo_t stVideoPlayInfo;

	bool bStopFlag;
	AirplayThread_t stAirplaySrvThead;
	AirplayThread_t stAirplayMsgThead;

}AirplayServer_t;

ServiceInfo* gpAirPlayService;
static AirplayServer_t *gstAirplayServerInfo = NULL;
static int avahi_pid = -1;
//HttpParser_t *gpstHttpParser = NULL;
static void Airplay_StopServer(bool bWait);
static int startAvahi(const char *pServerName, int pPort);
//static void endAvahi();
static void Airplay_Disconnect(TcpClient_t *pstConnection)
{
	if (pstConnection->sdSocket != INVALID_SOCKET)
	{
		//CSingleLock lock (m_critSection); for c++
		unsigned int i = 0;
		for (i = 0; i < gstAirplayServerInfo->dReverseSocketCnt; i++)
		{
			if (gstAirplayServerInfo->stReversSocket[i].sdSocket != INVALID_SOCKET
				&& pstConnection->sdSocket == gstAirplayServerInfo->stReversSocket[i].sdSocket)
			{
				if (i+1 == gstAirplayServerInfo->dReverseSocketCnt)
				{
					memset(&gstAirplayServerInfo->stReversSocket[i], 0x0, sizeof(ReverseSocket_t));
					gstAirplayServerInfo->stReversSocket[i].sdSocket = INVALID_SOCKET;
				}
				else	//move the last one to the current position
				{
					memcpy(&gstAirplayServerInfo->stReversSocket[i],
						&gstAirplayServerInfo->stReversSocket[gstAirplayServerInfo->dReverseSocketCnt-1],
							sizeof(ReverseSocket_t));
					memset(&gstAirplayServerInfo->stReversSocket[gstAirplayServerInfo->dReverseSocketCnt-1],
						0x0,
							sizeof(ReverseSocket_t));
					gstAirplayServerInfo->stReversSocket[gstAirplayServerInfo->dReverseSocketCnt-1].sdSocket = INVALID_SOCKET;
				}
				gstAirplayServerInfo->dReverseSocketCnt--;
				airplay_log_trace("dReverseSocketCnt: %u!\n", gstAirplayServerInfo->dReverseSocketCnt);
			}
		}

		//shutdown(pstConnection->sdSocket, SHUT_RDWR);
		close(pstConnection->sdSocket);
		pstConnection->sdSocket = INVALID_SOCKET;
		//delete m_httpParser;	end http parser
		if (pstConnection->stHttpParser.pTotalData)
		{
			free(pstConnection->stHttpParser.pTotalData);
		}
		memset(&pstConnection->stHttpParser, 0x0, sizeof(HttpParser_t));
		pstConnection->stHttpParser.eAddDataState = AddDataIncomplete;
		pstConnection->bAuthenticated = false;
	}
}
static void Airplay_EraseConnection(TcpClient_t *pstConnection)
{
	//unsigned i = 0;
	//unsigned dAddr = (unsigned)pstConnection;
	unsigned dConnectionCnt = gstAirplayServerInfo->dConnectionCnt;
	if (dConnectionCnt-1 == 0)
		gstAirplayServerInfo->dConnectionCnt = 0;
	else
		gstAirplayServerInfo->dConnectionCnt--;

	//use the end one instead of the current one
	if ((unsigned)pstConnection != (unsigned)&gstAirplayServerInfo->stTcpClient[dConnectionCnt-1])
		memcpy(pstConnection, &gstAirplayServerInfo->stTcpClient[dConnectionCnt-1], sizeof(TcpClient_t));
	memset(&gstAirplayServerInfo->stTcpClient[dConnectionCnt-1], 0x0, sizeof(TcpClient_t));

	/*
	for (i=0; i<dConnectionCnt; i++)	//find the erase one
	{
		if ((unsigned)(&gstAirplayServerInfo->stTcpClient[i])==dAddr)
			break;
	}

	for (; i<dConnectionCnt; i++)	//move the next one to the current one
	{
		memcpy(&gstAirplayServerInfo->stTcpClient[i], &gstAirplayServerInfo->stTcpClient[i+1], sizeof(TcpClient_t));
	}
	*/
}

/******************************************\
*
*
*
\******************************************/
static void Airplay_Deinitialzie()
{
	unsigned i = 0;
	for (i = 0; i < gstAirplayServerInfo->dConnectionCnt; i++)
		Airplay_Disconnect(&gstAirplayServerInfo->stTcpClient[i]);

	gstAirplayServerInfo->dConnectionCnt = 0;
	memset(gstAirplayServerInfo->stTcpClient, 0x0, CONNECT_MAX*sizeof(TcpClient_t));
	//here should clear the reverse socket
	//m_reverseSockets.clear();
	//disconnect reverse
	ReverseSocket_t *pstReversSocket = gstAirplayServerInfo->stReversSocket;
	for (i = 0; i<gstAirplayServerInfo->dReverseSocketCnt; i++)
	{
		//shutdown(pstReversSocket[i].sdSocket, SHUT_RDWR);
		close(pstReversSocket[i].sdSocket);
		pstReversSocket[i].sdSocket = INVALID_SOCKET;
	}
	gstAirplayServerInfo->dReverseSocketCnt = 0;

	if (gstAirplayServerInfo->sdServerSocket!= INVALID_SOCKET)
	{
		//shutdown(gstAirplayServerInfo->sdServerSocket, SHUT_RDWR);
		close(gstAirplayServerInfo->sdServerSocket);
		gstAirplayServerInfo->sdServerSocket = INVALID_SOCKET;
	}
}

static bool Airplay_Initialize(AirplayServer_t *pstServerInfo)
{
	AIRPLAY_FUNC_INFO();
	Airplay_Deinitialzie();

	struct sockaddr_in stMyAddr;

	stMyAddr.sin_family = AF_INET;
	stMyAddr.sin_port = htons(pstServerInfo->sdPort);

	if (pstServerInfo->bNonLocal)
		stMyAddr.sin_addr.s_addr = INADDR_ANY;
	else
		inet_pton(AF_INET, "127.0.0.1", &stMyAddr.sin_addr.s_addr);

	//create an endpoint for communication
	if ((pstServerInfo->sdServerSocket = socket(PF_INET, SOCK_STREAM, 0))== INVALID_SOCKET)
	{
		airplay_log_error("Failed to create server socket!\n");
		return false;
	}
	else
		airplay_log_trace("Successed to create server socket!\n");
	//bind the socket to a address
	if (bind(pstServerInfo->sdServerSocket, (struct sockaddr*)&stMyAddr, sizeof(stMyAddr)) < 0)
	{
		airplay_log_error("Failed to bind server socket!\n");
		close(pstServerInfo->sdServerSocket);
		return false;
	}
	else
		airplay_log_trace("Successed to bind server socket!\n");
	//listen the socket
	if (listen(pstServerInfo->sdServerSocket, BACKLOG_MAX) < 0)
	{
		airplay_log_error("Failed to set listen!\n");
		close(pstServerInfo->sdServerSocket);
		return false;
	}
	else
		airplay_log_trace("Successed to set listen!\n");

	airplay_log_trace("Successfully initialized!\n");

	return true;
}

#if 0
static char *AirPlay_calcResponse(const char *username,
                        const char *password,
                        const char *realm,
                        const char *method,
                        const char *digestUri,
                        const char *nonce)
{
	return NULL;
}
#endif
static bool AirPlay_checkAuthorization(TcpClient_t *pstTcpClient, char *authorization, char *method, char * uri)
{
	AIRPLAY_FUNC_INFO();

	bool authValid = true;

	char * username = NULL, *p = NULL;

	if (!authorization)
		return false;

	//first get username - we allow all usernames for airplay (usually it is AirPlay)
	username = strstr(authorization, "username");

	if (!username)
	{
		authValid = false;
	}

	//second check realm
	if (authValid)
	{
		p = strstr(authorization, "realm");
		if (p && strcmp(p, AUTH_REALM) != 0)	//this is not same
		{
			authValid = false;
		}
	}

	//third check nonce
	if (authValid)
	{
		p = strstr(authorization, "nonce");
		//if (p && strcmp(authorization, ) != 0)
		{
			authValid = false;
		}
	}

	//forth check uri
	if (authValid)
	{
		p = strstr(authorization, "uri");
		if (p && strcmp(authorization, uri) != 0)
		{
			authValid = false;
		}
	}

	//last check response
#if 0
	if (authValid)
	{
		
		char realm[] = AUTH_REALM;
		char *ourResponse = AirPlay_calcResponse(username, gstAirplayServerInfo->szPwd,realm, method, uri, pstTcpClient->authNonce);
		//calcResponse(username, ServerInstance->m_password, realm, method, uri, m_authNonce);

        char *theirResponse = NULL;//strstr(authorization, "response");

		if (ourResponse && theirResponse && strcmp(ourResponse, theirResponse))
		{
			authValid = false;
			airplay_log_trace("AirAuth: response mismatch - our: %s theirs: %s\n", ourResponse, theirResponse);
		}
		else
        {
			airplay_log_trace("AirAuth: successfull authentication from AirPlay clienn");
		}
	}
#endif
	pstTcpClient->bAuthenticated = authValid;
	return pstTcpClient->bAuthenticated;
}

static void AirPlay_ComposeReverseEvent(TcpClient_t *pstTcpClient,
	char **reverseHeader, char **reverseBody, char* sessionId, Event_e state)
{
	MediaPlayInfo_t *pstMPInfo = &(gstAirplayServerInfo->stVideoPlayInfo);
	AIRPLAY_FUNC_INFO();

	if (pstTcpClient->eLastEvent != state)
	{
		switch (state)
		{
			case EVENT_PLAYING:
			case EVENT_LOADING:
			case EVENT_PAUSED:
			case EVENT_STOPPED:
				pstMPInfo->eLastPlayState = state;
				int len = strlen(EVENT_INFO)+strlen(eventStrings[state])+strlen("video")+1;
				*reverseBody = (char *)malloc(len);	//should be free by the call function
				bzero(*reverseBody, len);
				if (gstAirplayServerInfo->eCurPlayType == PLAYING_PHOTO)
					sprintf(*reverseBody, EVENT_INFO, "photo", eventStrings[state]);
				else if (gstAirplayServerInfo->eCurPlayType == PLAYING_VIDEO)
					sprintf(*reverseBody, EVENT_INFO, "video", eventStrings[state]);
				airplay_log_trace("AIRPLAY: sending event: %s\n", eventStrings[state]);
				break;
			default:
				break;
		}
		char x_apple_name[21] = {0};	//store name "x-apple-session-id: " or "x-apple-device-id: "
		if (getValue(&pstTcpClient->stHttpParser, "x-apple-session-id"))
		{
			strcpy(x_apple_name, "X-Apple-Session-ID: ");
		}
		else if (getValue(&pstTcpClient->stHttpParser, "x-apple-device-id"))
		{
			strcpy(x_apple_name, "X-Apple-Device-ID: ");
		}
		else
		{
			strcpy(x_apple_name, "X-Apple-Session-ID: ");
		}
		int len= strlen("POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: ")
			+8/*No. of body size*/
			+strlen("\r\n")
			+strlen(x_apple_name)
			+strlen("\r\n")
			+1;

		if (sessionId)
		{
			*reverseHeader = (char *)malloc(len+strlen(sessionId));
			memset(*reverseHeader, 0x0, len+strlen(sessionId));
			sprintf(*reverseHeader, "POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\n%s%s\r\n",
				strlen(*reverseBody), x_apple_name, sessionId);
		}
		else
		{
			*reverseHeader = (char *)malloc(len);
			memset(*reverseHeader, 0x0, len);
			sprintf(*reverseHeader, "POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\n%s\r\n",
				strlen(*reverseBody), x_apple_name);
		}
		pstTcpClient->eLastEvent = state;
	}
}

static void _AirPlay_StopSlideShow(void)
{
	SlideShowInfo_t *pstSSnfo = &(gstAirplayServerInfo->stSlideShowInfo);

	AIRPLAY_FUNC_INFO();

	Airplay_MW_IF_SetClientAddr(0, NULL);

	int len_header = strlen("POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n")
			+8/*No. of body size*/
			+strlen(pstSSnfo->slideshow_session);/*session string length*/
	int len_body = +strlen(SLIDESHOW_EVENT_PLAY)	/*max body length*/
			+8/*lastAssetID*/
			+8/*sessionID*/
			+8;/*state string length*/

	char *presponse = (char *)malloc(len_header+len_body);
	char *pbody = (char *)malloc(len_body);

	sprintf(pbody, SLIDESHOW_EVENT_STOP_LOAD, "slideshow",pstSSnfo->sessionID, "stopped");
	sprintf(presponse,
		"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
		strlen(pbody), pstSSnfo->slideshow_session, pbody);
	airplay_log_trace("response stopped event:\n%s\n", presponse);
	send(pstSSnfo->eventSocket, presponse, strlen(presponse), 0);

	free(presponse);
	free(pbody);
	//memset(pstSSnfo, 0x0, sizeof(SlideShowInfo_t));
	pstSSnfo->slideshowSocket = INVALID_SOCKET;
	pstSSnfo->elastSlideAction = SLIDESHOW_NOTHING;

	airplay_log_trace("slide show end!\n");
}

#ifdef SUPPORT_MUSIC_BGPLAY

static void _AirPlay_PlaySlideShow(int fd_socket)
{
	SlideShowInfo_t *pstSSnfo = &(gstAirplayServerInfo->stSlideShowInfo);

	AIRPLAY_FUNC_INFO();

	//set client address
	struct sockaddr_storage addr;
	char ipstr[14];
	socklen_t len = sizeof addr;
	getpeername(fd_socket, (struct sockaddr *)&addr, &len);
	// deal with both IPv4 and IPv6:
	if (addr.ss_family == AF_INET)
	{
		struct sockaddr_in *s = (struct sockaddr_in *)&addr;
		inet_ntop(AF_INET, &s->sin_addr, ipstr, sizeof ipstr);
	}
	else
	{
		char ipv6str[64];
		struct sockaddr_in6 *s = (struct sockaddr_in6 *)&addr;
		inet_ntop(AF_INET6, &s->sin6_addr, ipv6str, sizeof ipv6str);
		strcpy(ipstr, strrchr(ipv6str, ':')+1);
	}
	airplay_log_trace("Peer IP address: %s\n", ipstr);
	Airplay_MW_IF_SetClientAddr(0, ipstr);

	int len_header = strlen("POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n")
			+8/*No. of body size*/
			+strlen(pstSSnfo->slideshow_session);/*session string length*/
	int len_body = +strlen(SLIDESHOW_EVENT_PLAY)	/*max body length*/
			+8/*lastAssetID*/
			+8/*sessionID*/
			+8;/*state string length*/

	char *presponse = (char *)malloc(len_header+len_body);
	char *pbody = (char *)malloc(len_body);

	sprintf(pbody, SLIDESHOW_EVENT_PLAY, 1, pstSSnfo->sessionID);
	sprintf(presponse,
		"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
		strlen(pbody), pstSSnfo->slideshow_session, pbody);
	airplay_log_trace("response playing event:\n%s\n", presponse);
	send(pstSSnfo->eventSocket, presponse, strlen(presponse), 0);

	free(presponse);
	free(pbody);

	airplay_log_trace("slide show playing!\n");
}
#endif
static void AirPlay_ComposeReverseSlideShow(TcpClient_t *pstTcpClient,
	char **reverseHeader, char **reverseBody, char** sessionId, SlideAction_e eSlideAction)
{
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	AIRPLAY_FUNC_INFO();

	char x_apple_name[21] = {0};	//store name "x-apple-session-id: " or "x-apple-device-id: "
	int len =0;
	if (getValue(&pstTcpClient->stHttpParser, "x-apple-session-id"))
	{
		strcpy(x_apple_name, "X-Apple-Session-ID: ");
	}
	else if (getValue(&pstTcpClient->stHttpParser, "x-apple-device-id"))
	{
		strcpy(x_apple_name, "X-Apple-Device-ID: ");
	}
	else
	{
		strcpy(x_apple_name, "X-Apple-Session-ID: ");
	}

	if (*sessionId)
	{
		free(*sessionId);
	}
	*sessionId = (char *)malloc(strlen(pstSlideShowInfo->slideshow_session)+1);
	memset(*sessionId, 0x0, strlen(pstSlideShowInfo->slideshow_session)+1);
	strcpy(*sessionId, pstSlideShowInfo->slideshow_session);

	/*
		here use "text/x-apple-plist+xml" replace the "application/x-apple-binary-plist"
		because we can't handle correct for all photos with plist, some photo may cause crash!
	*/
	//len = strlen("GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Length: 0\r\nAccept: application/x-apple-binary-plist\r\nX-Apple-Session-ID: ")
	len = strlen("GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: 0\r\nX-Apple-Session-ID: ")
			+8/*No. of body size*/
			+strlen("\r\n")
			+strlen(pstSlideShowInfo->slideshow_session)
			+strlen("\r\n")
			+1;
		if (*sessionId)
		{
			*reverseHeader = (char *)malloc(len);
			memset(*reverseHeader, 0x0, len);
		//	sprintf(*reverseHeader, "GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Length: 0\r\nAccept: application/x-apple-binary-plist\r\nX-Apple-Session-ID: %s\r\n",
		//		pstSlideShowInfo->slideshow_session);
			sprintf(*reverseHeader, "GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: 0\r\nX-Apple-Session-ID: %s\r\n",
				pstSlideShowInfo->slideshow_session);
		}
		else
		{
			*reverseHeader = (char *)malloc(len);
			memset(*reverseHeader, 0x0, len);
			sprintf(*reverseHeader, "GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: 0\r\n%s\r\n",
				x_apple_name);
		}

	pstSlideShowInfo->elastSlideAction = eSlideAction;
}

static void AirPlay_ComposeAuthRequestAnswer(TcpClient_t *pstTcpClient, char **responseHeader, char **responseBody)
{
	char randomStr[7] = {0};	//
	short random = rand();
	sprintf(randomStr, "%i", random);
	//strcpy(pstTcpClient->authNonce, GetMD5(randomStr));
	*responseHeader = (char *)malloc(strlen(AUTH_REQUIRED)+strlen(pstTcpClient->authNonce)+1);
	sprintf(*responseHeader, AUTH_REQUIRED, pstTcpClient->authNonce);
	*responseHeader[strlen(AUTH_REQUIRED)+strlen(pstTcpClient->authNonce)] = '\0';
}

#if 0
static void _AirPlay_SlideShowRoutine(SlideShowInfo_t *pstSlideShowInfo)
{
	SlideShowInfo_t *pstSSnfo = pstSlideShowInfo;

	AIRPLAY_FUNC_INFO();

	//start slide show
	int slideshowbreak = 0;
	int len_header = strlen("POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n")
			+8/*No. of body size*/
			+strlen(pstSSnfo->slideshow_session);/*session string length*/
	int len_body = +strlen(SLIDESHOW_EVENT_PLAY)	/*max body length*/
			+8/*lastAssetID*/
			+8/*sessionID*/
			+8;/*state string length*/

	char *presponse = (char *)malloc(len_header+len_body);
	char *pbody = (char *)malloc(len_body);

	/*
		here we should send the post event to the correct reverse socket, loading and playing event seem not usefull;
		but here to get slideshow photo would only recieve empty data, i don't no how to fix the problem, so don't use it!
	*/
	while (!slideshowbreak)
	{
		memset(presponse, 0x0, len_header+len_body);
		memset(pbody, 0x0, len_body);
		if (pstSSnfo->elastSlideAction == SLIDESHOW_LOADING)
		{
			/*
			sprintf(pbody, SLIDESHOW_EVENT_STOP_LOAD, pstSSnfo->sessionID, "loading");
			sprintf(presponse,
				"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
				strlen(pbody), pstSSnfo->slideshow_session, pbody);
			airplay_log_trace("response loading event:\n%s\n", presponse);
			send(pstSSnfo->eventSocket, presponse, strlen(presponse), 0);
			*/
			sleep(3);
		}
		else if (pstSSnfo->elastSlideAction == SLIDESHOW_STOPPED)
		{
			sprintf(pbody, SLIDESHOW_EVENT_STOP_LOAD, pstSSnfo->sessionID, "stopped");
			sprintf(presponse,
				"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
				strlen(pbody), pstSSnfo->slideshow_session, pbody);
			airplay_log_trace("response stopped event:\n%s\n", presponse);
			send(pstSSnfo->eventSocket, presponse, strlen(presponse), 0);
			slideshowbreak = 1;
		}
		else if (pstSSnfo->elastSlideAction == SLIDESHOW_PLAYING)
		{
			/*
			//for post event
			sprintf(pbody, SLIDESHOW_EVENT_PLAY, pstSSnfo->lastID, pstSSnfo->sessionID);
			sprintf(presponse,
				"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
				strlen(pbody), pstSSnfo->slideshow_session, pbody);
			airplay_log_trace("response playing event:\n%s\n", presponse);
			send(pstSSnfo->eventSocket, presponse, strlen(presponse), 0);
			//for get slide show
			sprintf(presponse,
				("GET /slideshows/1/assets/1 HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: 0\r\nX-Apple-Session-ID: %s\r\n"),
				pstSSnfo->slideshow_session);
			airplay_log_trace("send to revers socket: %d\n%s\n", pstSSnfo->slideshowSocket, presponse);
			send(pstSSnfo->slideshowSocket, presponse, strlen(presponse), 0);
			*/
			sleep(pstSSnfo->SlideShowTime);

		}
		else
		{
			slideshowbreak = 1;
		}
	}

	free(presponse);
	free(pbody);
	memset(pstSSnfo, 0x0, sizeof(pstSSnfo));

	airplay_log_trace("slide show end!\n");
}
static void _AirPlay_StartSlideShow(void)
{
	SlideShowInfo_t *pstSlideShowInfo = &gstAirplayServerInfo->stSlideShowInfo;

	pstSlideShowInfo->lastID = 0;
	pstSlideShowInfo->SlideShowTime = 0;

	//start slide show thread
	pthread_t hThread;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, PTHREAD_STACK_SIZE);
	if (pthread_create(&hThread,
					&attr,
					(void*(*)(void*))_AirPlay_SlideShowRoutine/*thread function*/,
					(void *)pstSlideShowInfo) == 0)
	{
		airplay_log_trace("success to create slideshow thread!\n");
	}
	else
	{
		airplay_log_error("Failed to create slideshow thread!\n");
	}
	pthread_attr_destroy(&attr);

}
#endif
static void _Airplay_StopMediaPlay()
{
	MediaPlayInfo_t *pstMPInfo = &(gstAirplayServerInfo->stVideoPlayInfo);
	//SlideShowInfo_t *pstSSInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	AIRPLAY_FUNC_INFO();

	int len_header = strlen("POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n")
			+8/*No. of body size*/
			+strlen(pstMPInfo->mediaplay_session);/*session string length*/
	int len_body = +strlen(SLIDESHOW_EVENT_STOP_LOAD)	/*max body length, the slideshow or video event*/
			+8/*media category*/
			+8/*sessionID*/
			+8;/*state string length*/

	char *presponse = (char *)malloc(len_header+len_body);
	char *pbody = (char *)malloc(len_body);
    memset(pbody, 0, len_body);
	int fd_socket = pstMPInfo->eventSocket;

	if (gstAirplayServerInfo->eCurPlayType == PLAYING_PHOTO)
	{
		sprintf(pbody, SLIDESHOW_EVENT_STOP_LOAD, "photo", pstMPInfo->sessionID,"stopped");
	}
	else if (gstAirplayServerInfo->eCurPlayType == PLAYING_VIDEO)
	{
		sprintf(pbody, EVENT_INFO, "video", "stopped");
	}
	sprintf(presponse,
		"POST /event HTTP/1.1\r\nContent-Type: text/x-apple-plist+xml\r\nContent-Length: %d\r\nX-Apple-Session-ID: %s\r\n\r\n%s",
		strlen(pbody), pstMPInfo->mediaplay_session, pbody);
	airplay_log_trace("response stopped event:\n%s\n", presponse);
	send(fd_socket, presponse, strlen(presponse), 0);

	free(presponse);
	free(pbody);
	memset(pstMPInfo, 0x0, sizeof(MediaPlayInfo_t));
	pstMPInfo->eLastPlayState = EVENT_NONE;
	pstMPInfo->eventSocket = INVALID_SOCKET;

	airplay_log_trace("media play end!\n");
}
static int _ProcessReq_Reverse(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);
	MediaPlayInfo_t *pstMPInfo = &(gstAirplayServerInfo->stVideoPlayInfo);

	char * purpose = (char *)getValue(pstHttpParser, "x-apple-purpose");

	airplay_log_trace("socket: %d, purpose: %s\n", pstTcpClient->sdSocket, purpose);

	*responseHeader = (char *)malloc(strlen("Upgrade: PTTH/1.0\r\nConnection: Upgrade\r\n")+1);
	memset(*responseHeader, 0x0, strlen("Upgrade: PTTH/1.0\r\nConnection: Upgrade\r\n")+1);
	strcpy(*responseHeader, "Upgrade: PTTH/1.0\r\nConnection: Upgrade\r\n");

	//if (purpose)
	if (purpose && !strcmp(purpose, "slideshow"))
	{
		//for slide show use...
		strcpy(pstSlideShowInfo->slideshow_session, *sessionId);
		pstSlideShowInfo->elastSlideAction = SLIDESHOW_LOADING;
		pstSlideShowInfo->slideshowSocket = pstTcpClient->sdSocket;
		pstSlideShowInfo->sessionID = pstTcpClient->sessionCounter;
		//_AirPlay_StartSlideShow();
	}
	else //if(!strcmp(purpose, "event"))
	{
		if (pstMPInfo->eLastPlayState > EVENT_NONE && pstMPInfo->eventSocket != INVALID_SOCKET)
		{
			_Airplay_StopMediaPlay();
		}
		strcpy(pstMPInfo->mediaplay_session, *sessionId);
		pstMPInfo->eventSocket = pstTcpClient->sdSocket;
		pstMPInfo->sessionID = pstTcpClient->sessionCounter;
		pstSlideShowInfo->eventSocket = pstTcpClient->sdSocket;
		pstSlideShowInfo->sessionID = pstTcpClient->sessionCounter;
	}

	return AIRPLAY_STATUS_SWITCHING_PROTOCOLS;
}

static int _ProcessReq_Rate(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId, char * queryString)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);

	char * uri = (char *)getUri(pstHttpParser);
	//char * queryString = (char *)getQueryString(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);

		const char* found = strstr(queryString, "value=");
		int rate = found?(int)(atof(found + strlen("value=")) + 0.5f):0;

	airplay_log_trace("AIRPLAY: got request %s with rate: %i\n", uri, rate);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
			!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}
	else if (rate == 0)
	{
		/*pause Player*/
		Airplay_MW_IF_PlayPause();
		//if (g_application.m_pPlayer && g_application.m_pPlayer->IsPlaying() && !g_application.m_pPlayer->IsPaused())
		//{
		//	CApplicationMessenger::Get().MediaPause();
			AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_PAUSED);
		//}
	}
	else
	{
		/*playing Player*/
		Airplay_MW_IF_PlayResume();
		//if (g_application.m_pPlayer && g_application.m_pPlayer->IsPlaying() && g_application.m_pPlayer->IsPaused())
		//{
		//	CApplicationMessenger::Get().MediaPause();
			AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_PLAYING);
		//}
	}

	return AIRPLAY_STATUS_OK;
}

static int _ProcessReq_Volume(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId, char * queryString)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);

	char * uri = (char *)getUri(pstHttpParser);
	//char * queryString = (char *)getQueryString(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);

	const char* found = strstr(queryString, "volume=");
	float volume = found?(float)strtod(found + strlen("volume="), NULL):0;

	airplay_log_trace("AIRPLAY: got request %s with volume %f\n", uri, volume);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
		!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}
	else if (volume >= 0 && volume <= 1)
	{
		int oldVolume = Airplay_MW_IF_Get_Volume();//g_application.GetVolume(); get volume from device
		volume *= 16;

		if (oldVolume != (int)volume)
		{
			//set volume, show volume bar
			Airplay_MW_IF_Set_Volume((int)volume);
		}
	}

	return AIRPLAY_STATUS_OK;
}

static int _ProcessReq_Play(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
	{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	char * uri = (char *)getUri(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);
	char * contentType = (char *)getValue(pstHttpParser, "content-type");
	char * body = (char *)getBody(pstHttpParser);

		char * location = NULL;
		float position = 0.0;

		airplay_log_trace("AIRPLAY: got request %s\n", uri);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
			!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
		{
		return AIRPLAY_STATUS_NEED_AUTH;
		}
		else if (contentType && !strcmp(contentType, "application/x-apple-binary-plist"))
		{
			LINE();
			gstAirplayServerInfo->dIsPlaying++;
			#if 1
			//CAirPlayServer::m_isPlaying++;

			//if (m_pLibPlist->Load())
			//{
				//m_pLibPlist->EnableDelayedUnload(false);

			const char* bodyChr = getBody(pstHttpParser);

			airplay_log_trace("bodyChr: %s\n", bodyChr);

			plist_t dict = NULL;
			plist_from_bin(bodyChr, getContentLength(pstHttpParser), &dict);

			if (plist_dict_get_size(dict))
			{
				LINE();
				plist_t tmpNode = plist_dict_get_item(dict, "Start-Position");

				if (tmpNode)
				{
					double tmpDouble = 0;
					plist_get_real_val(tmpNode, &tmpDouble);
					position = (float)tmpDouble;
					airplay_log_trace("Start position: %f\n", position);
				}

				tmpNode = plist_dict_get_item(dict, "Content-Location");

					if (tmpNode)
					{
						char *tmpStr = NULL;
					plist_get_string_val(tmpNode, &tmpStr);
					if (tmpStr)
					{
						location = (char *)malloc(strlen(tmpStr)+1);
						strcpy(location, tmpStr);
						location[strlen(tmpStr)] = '\0';
						LINE();
						free(tmpStr);
					}
				}
				if (dict)
				{
					plist_free(dict);
				}
				LINE();
			}
			else
			{
			}
			#endif
		}
		else
		{
			LINE();
			//CAirPlayServer::m_isPlaying++;
			gstAirplayServerInfo->dIsPlaying++;
			// Get URL to play
			char * start = strstr(body, "Content-Location: ");

			if (start)
			{
				start += strlen("Content-Location: ");
				char * end = strchr(start, '\n');
				location = (char *)malloc(end-start+1);
				strncpy(location, start, end-start);
				location[end-start] = '\0';
				airplay_log_trace("location: %s\n", location);
				//location = body.Mid(start, end - start);
			}
			else
				return AIRPLAY_STATUS_NOT_IMPLEMENTED;

			start = strstr(body, "Start-Position");

			if (start)
			{
				start += strlen("Start-Position: ");
				char * end = strchr(start, '\n');
				char * positionStr = (char *)malloc(end-start+1);
				memset(positionStr, 0x0, end-start+1);
				//body.Mid(start, end - start);
				strncpy(positionStr, start, end-start);
				airplay_log_trace("positionStr: %s\n", positionStr);
				position = (float)atof(positionStr);
				if (positionStr) free(positionStr);
			}
		}

		{
			char userAgent[] = "AppleCoreMedia/1.0.0.8F455 (AppleTV; U; CPU OS 4_3 like Mac OS X; de_de)";
			/*-------start encode the url--------*/
			char strTmp[10] = {0};
			int i = 0, kar, len = strlen(userAgent);
			char *p = (char *)malloc(len *2+1);
			memset(p, 0x0, len *2+1);
			for (i = 0; i<len; ++i)
			{
				kar = (unsigned char)userAgent[i];
				if (isalnum(kar) || strchr("-_.!()" , kar) ) // Don't URL encode these according to RFC1738
				{
					sprintf(strTmp, "%c", kar);
					strcat(p, strTmp);
				}
				else
				{
					sprintf(strTmp, "%%%2.2x", kar);
					strncat(p, strTmp, strlen(strTmp));
				}
			}

			/*-------end encode the url--------*/
			//here save the location
			if (gstAirplayServerInfo->location)
				free(gstAirplayServerInfo->location);
			gstAirplayServerInfo->location = malloc(strlen(location)+1);
			memset(gstAirplayServerInfo->location, 0x0, strlen(location)+1);
			strcpy(gstAirplayServerInfo->location, location);

			//Airplay_MW_IF_PlayStar(AIRPLAY_VIDEO_MEDIA, gstAirplayServerInfo->location);
			if (location)
			{
				len = strlen(location);
				location = (char *)realloc(location, len+strlen("|User-Agent=")+strlen(p)+1);
				sprintf(location+len, "|User-Agent=%s", p);
				location[len+strlen("|User-Agent=")+strlen(p)] = '\0';
			}
			if(p)free(p);

			if (location)
			airplay_log_trace("location: %s\n", location);

			/*play the file by property*/
			#if 0
			AirplayMsg_t airplaymsg;
			airplaymsg.msgtype = MSG_TYPE_REQUEST;
			airplaymsg.msgbody.msg = AIRPLAY_VIDEO_START;
			airplaymsg.msgbody.pid = getpid();
			airplaymsg.msgbody.ppid = getppid();
			int msgid = msgget(MSG_AIR_MW_KEY, S_IRUSR|S_IWUSR|IPC_CREAT);
			msgsnd(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), IPC_NOWAIT);
			printf("\n\n	send play video message to airplay middleware!!!!!\n\n");
			#endif

			//CFileItem fileToPlay(location, false);
			//fileToPlay.SetProperty("StartPercent", position * 100.0f);
			//CApplicationMessenger::Get().MediaPlay(fileToPlay);
			if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_PLAYING ||pstSlideShowInfo->elastSlideAction == SLIDESHOW_LOADING)
			{
				_AirPlay_StopSlideShow();
			}
			if (gstAirplayServerInfo->eCurPlayType == PLAYING_PHOTO)
			{
				_Airplay_StopMediaPlay();
			}
			gstAirplayServerInfo->eCurPlayType = PLAYING_VIDEO;
			int sdMwRet = Airplay_MW_IF_PlayPosition(AIRPLAY_VIDEO_MEDIA, gstAirplayServerInfo->location, (unsigned)(position*10000));
			if (sdMwRet == AIRPLAY_MW_SUCCESS)
			{
				/*send event*/
				AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_PLAYING);
			}
			else	//start app failed, sould disconnect the socket
			{
				/*send event*/
				AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_STOPPED);
				if (location) free(location);
				return AIRPLAY_STATUS_FORBIDDEN;
			}
		}
		if (location) free(location);

	return AIRPLAY_STATUS_OK;
	}

static int _ProcessReq_Scrub(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId, char * queryString)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);

	char * uri = (char *)getUri(pstHttpParser);
	//char * queryString = (char *)getQueryString(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);

	airplay_log_trace("AIRPLAY: got request %s, method: %s, queryString: %s\n", uri, method, queryString);
	airplay_log_trace("gstAirplayServerInfo->bUsePwd: %d\n", gstAirplayServerInfo->bUsePwd);
	airplay_log_trace("pstTcpClient->bAuthenticated: %d\n", pstTcpClient->bAuthenticated);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
		!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}
	else if (!strcmp(method, "GET"))
	{
		unsigned TotalTime = 0;
		unsigned TimeSec = 0;
		airplay_log_trace("AIRPLAY: got GET request %s\n", uri);

		//if (g_application.m_pPlayer && g_application.m_pPlayer->GetTotalTime())
		{
			//float position = ((float) g_application.m_pPlayer->GetTime()) / 1000;
			//responseBody.Format("duration: %d\r\nposition: %f", g_application.m_pPlayer->GetTotalTime() / 1000, position);
		}
		Airplay_MW_IF_VideoGetDuration(&TotalTime);
		Airplay_MW_IF_VideoGetElapsedTime((unsigned*) &TimeSec);
		if (TotalTime > 0)
		{
			int len;
			float position = ((float) TimeSec);

			len= strlen("Content-Type: text/Parameters\r\n") + 1;
			*responseHeader = (char *)malloc(len);
			memset(*responseHeader, 0x0, len);
			strcpy(*responseHeader, "Content-Type: text/Parameters\r\n");

			len = strlen("duration: ")+strlen("\r\nposition: ")+16*2+1;
			*responseBody = (char *)malloc(len);
			memset(*responseBody, 0x0, len);
			sprintf(*responseBody, "duration: %.6f\r\nposition: %.6f", ((float)TotalTime), position);
		}
		else
		{
			return AIRPLAY_STATUS_METHOD_NOT_ALLOWED;
		}
	}
	else
	{
		const char* found = strstr(queryString, "position=");

		if (found)
		{
			long long position = (long long) (atof(found + strlen("position=")));
			//g_application.m_pPlayer->SeekTime(position);
			Airplay_MW_IF_VideoGoto(position);
			airplay_log_trace("AIRPLAY: got POST request %s with pos %lld\n", uri, position);
		}
	}

	return AIRPLAY_STATUS_OK;
}

static int _ProcessReq_Stop(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	char * uri = (char *)getUri(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);

		airplay_log_trace("AIRPLAY: got request %s\n", uri);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
			!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}
	else
	{
		//if (IsPlaying()) //only stop player if we started him
		//{
		//	CApplicationMessenger::Get().MediaStop();
		Airplay_MW_IF_PlayStop();
		gstAirplayServerInfo->dIsPlaying--;
		//	CAirPlayServer::m_isPlaying--;
		//}
		//else //if we are not playing and get the stop request - we just wanna stop picture streaming
		{
		//	g_windowManager.PreviousWindow();
		}
		//just video sould reverse
		if (pstSlideShowInfo->elastSlideAction > SLIDESHOW_NOTHING)
		{
			_AirPlay_StopSlideShow();
		}
		_Airplay_StopMediaPlay();
		AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_STOPPED);
		}

	return AIRPLAY_STATUS_OK;
	}

static int need_authenticate(TcpClient_t *pstTcpClient)
{
    HttpParser_t*    pstHttpParser    = &(pstTcpClient->stHttpParser);
	char* uri           = (char *)getUri(pstHttpParser);
	char* authorization = (char *)getValue(pstHttpParser, "authorization");
	char* method        = (char *)getMethod(pstHttpParser);

    /*No password using*/
    if(gstAirplayServerInfo->bUsePwd != TRUE)
        return 0;

    /*Already authenticated*/
    if(pstTcpClient->bAuthenticated == TRUE)
        return 0;

    /*Check authorization*/
    if(AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri)==TRUE)
       return 0;

    return 1;
}

static int _ProcessReq_Photo(TcpClient_t *pstTcpClient,char **responseHeader,
	char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	HttpParser_t*    pstHttpParser    = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t* pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	unsigned length     = getContentLength(pstHttpParser);
	char* uri           = (char *)getUri(pstHttpParser);
	char* body          = (char *)getBody(pstHttpParser);

	airplay_log_trace("AIRPLAY: got request %s, content length: %u\n", uri, length);

	if (need_authenticate(pstTcpClient)==1)
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}

    if(length <= 0)
    {
        return AIRPLAY_STATUS_OK;
    }

	LINE();
	FILE *tmpFile = NULL;
	char tmpFileName[] = TEMP_PHOTO_NAME_JPG;

    /*PNG image*/
    if (length > 3 && body[1] == 'P' && body[2] == 'N' && body[3] == 'G')
    {
    	strcpy(tmpFileName, TEMP_PHOTO_NAME_PNG);
    }

    if (!gstAirplayServerInfo->location)
    {
        gstAirplayServerInfo->location = malloc(strlen(tmpFileName)+1);
    }

    memset(gstAirplayServerInfo->location, 0x0, strlen(tmpFileName)+1);
    strcpy(gstAirplayServerInfo->location, tmpFileName);

    LINE();

    if ((tmpFile=fopen(tmpFileName, "w+")) == NULL)
    {
    	return AIRPLAY_STATUS_OK;
    }

    LINE();
    int writtenBytes = 0;

    if (!strcmp(uri, "/photo"))
    {
    	LINE();
    	//this must be another device want to play photo, so stop the slide show
    	if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_PLAYING)
    	{
    		_AirPlay_StopSlideShow();
    	}
    	LINE();
    	writtenBytes = fwrite(body, sizeof(char), length, tmpFile);
    }
    else if (!strcmp(uri, "200"))
    {
    	//if the state has changed, don't write data
    	if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_PLAYING)
    	{
    		writtenBytes = fwrite(body, sizeof(char), length, tmpFile);
    	}
    }

    LINE();
    fclose(tmpFile);

    /*Receiving image data done*/
    if (writtenBytes > 0 && (unsigned int)writtenBytes == length)
    {
    	//show picture by system
    	airplay_log_trace("show picture (location: %s) !\n", tmpFileName);
    	gstAirplayServerInfo->eCurPlayType = PLAYING_PHOTO;

         if (Airplay_MW_IF_PlayStar(AIRPLAY_PHOTO_MEDIA, gstAirplayServerInfo->location))
    	{
    		Xbmc_disconnect();
    		return AIRPLAY_STATUS_FORBIDDEN;
    	}

    	if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_PLAYING)
    	{
    		sleep(pstSlideShowInfo->SlideShowTime);
    		AirPlay_ComposeReverseSlideShow(pstTcpClient, reverseHeader, reverseBody, sessionId, SLIDESHOW_PLAYING);
    		return AIRPLAY_STATUS_NO_RESPONSE_NEEDED;
    	}

    }
    else
    {
    	airplay_log_error("AirPlayServer: Error writing tmpFile.\n");
    }

	//slide show, auto get the next one
	/*
	if (pstTcpClient->elastRevAction == REV_ACTION_SLIDESHOW)
	{
		sleep(3);
		AirPlay_ComposeReverseSlideShow(pstTcpClient, reverseHeader, reverseBody, sessionId);
	}
	*/

	return AIRPLAY_STATUS_OK;
}

static int _ProcessReq_PBInfo(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);

	char * uri = (char *)getUri(pstHttpParser);
	char * authorization = (char *)getValue(pstHttpParser, "authorization");
	char *method = (char *)getMethod(pstHttpParser);

	airplay_log_trace("AIRPLAY: got request %s\n", uri);

	float position = 0.0f;
	float duration = 0.0f;
	float cachePosition = 0.0f;
	bool playing = false;
	int len;

	unsigned TotalTime = 0;
	unsigned ElapsedTime = 0;
	unsigned pPlayState = 0;
	Airplay_MW_IF_VideoGetDuration(&TotalTime);
	Airplay_MW_IF_VideoGetElapsedTime(&ElapsedTime);
	Airplay_MW_IF_VideoGetPlayState(& pPlayState);

	airplay_log_trace("AIRPLAY: got request %s\n", uri);
	airplay_log_trace("current time: %f, total time: %f, pPlayState: %u\n", (float)ElapsedTime, (float)TotalTime, pPlayState);

	if (gstAirplayServerInfo->bUsePwd && !pstTcpClient->bAuthenticated &&
			!AirPlay_checkAuthorization(pstTcpClient, authorization, method, uri))
	{
		return AIRPLAY_STATUS_NEED_AUTH;
	}
	else
	{
		LINE();
		if (TotalTime > 0)
		{
			position = ((float) ElapsedTime);
			duration = ((float) TotalTime);
			if(2 == pPlayState)//AVP_PLAY_STATE_PLAY
				playing = true;
			else
				playing = false;

			cachePosition = position;
		}


		len = strlen(PLAYBACK_INFO)+16*5+1;
		airplay_log_trace("responseBody len: %d\n", len);
		*responseBody = (char *)malloc(len);
		memset(*responseBody, 0x0, len);
		sprintf(*responseBody, PLAYBACK_INFO, duration, cachePosition, position, (playing ? 1 : 0), duration);
		airplay_log_trace("responseBody after copy len: %d\n", strlen(*responseBody));
		//responseBody.Format(PLAYBACK_INFO, duration, cachePosition, position, (playing ? 1 : 0), duration);

		len = strlen("Content-Type: text/x-apple-plist+xml\r\n")+1;
		airplay_log_trace("responseHeader len: %d\n", len);
		*responseHeader = (char *)malloc(len);
		memset(*responseHeader, 0x0, len);
		strcpy(*responseHeader,  "Content-Type: text/x-apple-plist+xml\r\n");
		airplay_log_trace("responseHeader after copy len: %d\n", strlen(*responseHeader));
		//responseHeader = "Content-Type: text/x-apple-plist+xml\r\n";

		if (pPlayState == 2)	//AVP_PLAY_STATE_PLAY
		{
			AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_PLAYING);
		}
		else if (pPlayState == 7)	//AVP_PLAY_STATE_PAUSE
		{
			AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_PAUSED);
		}
		else
		{
			AirPlay_ComposeReverseEvent(pstTcpClient, reverseHeader, reverseBody, *sessionId, EVENT_LOADING);
		}
		}

	return AIRPLAY_STATUS_OK;
}

static int get_slideshow_duration(HttpParser_t* pstHttpParser)
{
    int len;
    char* temp_str; //start position of string(without null terminated)
    char duration_in_string[10] = {0};
    int duration_in_integer = DEFAULT_SLIDESHOW_DURATION;

    if ( (temp_str = (char *)getItemFromBody(pstHttpParser, "slideDuration" , &len)) != NULL)
	{
	    strncpy(duration_in_string,temp_str,len);
        duration_in_integer = atoi(duration_in_string);

        /*Do not exceed maximum duration allowed*/
	    if(duration_in_integer>MAX_SLIDESHOW_DURATION)
        {
            duration_in_integer = MAX_SLIDESHOW_DURATION;
        }
	}

    return duration_in_integer;

}

static SlideAction_e get_slideshow_playing_state(HttpParser_t* pstHttpParser, int* last_id)
{
    int len;
    char* temp_str; //start position of string(without null terminated)

    if ( (temp_str=(char *)getItemFromBody(pstHttpParser, "state", &len)) != NULL)
	{
		if (!strncmp(temp_str, "playing", len))
		{
            if(last_id != NULL)
                *last_id = 1;

            return SLIDESHOW_PLAYING;
		}
		else if (!strncmp(temp_str, "stopped", len))
		{
		    if(last_id != NULL)
			    *last_id = 0;

            return SLIDESHOW_STOPPED;
		}

	}

    return SLIDESHOW_STOPPED;
}

static int create_slideshow_response(char **responseHeader, char **responseBody)
{
    int len;
    len = strlen(SLIDESHOW_RESPONE)+1;
	*responseBody = (char *)malloc(len);
	memset(*responseBody , 0x0, len);
	strcpy(*responseBody, SLIDESHOW_RESPONE);

	len = strlen("Content-Type: text/x-apple-plist+xml\r\n")+1;
	*responseHeader = (char *)malloc(len);
	memset(*responseHeader, 0x0, len);
	strcpy(*responseHeader, "Content-Type: text/x-apple-plist+xml\r\n");

    return 1;
}

static int _ProcessReq_SlideShow(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

    /*Get slide duration*/
    pstSlideShowInfo->SlideShowTime = get_slideshow_duration(pstHttpParser);

    /*Get playing state*/
    pstSlideShowInfo->elastSlideAction = get_slideshow_playing_state(pstHttpParser, &(pstSlideShowInfo->lastID));
    airplay_log_trace("slideshow %d in %ds\n", pstSlideShowInfo->elastSlideAction, pstSlideShowInfo->SlideShowTime);

    /*print out request*/
	airplay_log_trace("AIRPLAY: got request %s\n", (char *)getUri(pstHttpParser));

    /*Response*/
	create_slideshow_response(responseHeader,responseBody);


	if (pstSlideShowInfo->elastSlideAction != SLIDESHOW_STOPPED)
	    AirPlay_ComposeReverseSlideShow(pstTcpClient, reverseHeader, reverseBody, sessionId, SLIDESHOW_PLAYING);

	#ifdef SUPPORT_MUSIC_BGPLAY
	if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_STOPPED)
		_AirPlay_StopSlideShow();
	else
		_AirPlay_PlaySlideShow(pstTcpClient->sdSocket);
	#endif

	return AIRPLAY_STATUS_OK;
}

static int _ProcessReq_204(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	_AirPlay_StopSlideShow();

	return AIRPLAY_STATUS_NO_RESPONSE_NEEDED;
}
static int AirPlay_ProcessRequest(TcpClient_t *pstTcpClient,
	char **responseHeader, char **responseBody, char **reverseHeader, char **reverseBody, char **sessionId)
{
	AIRPLAY_FUNC_INFO();

	HttpParser_t *pstHttpParser = &(pstTcpClient->stHttpParser);
	SlideShowInfo_t *pstSlideShowInfo = &(gstAirplayServerInfo->stSlideShowInfo);

	char * uri = (char *)getUri(pstHttpParser);
	char * queryString = (char *)getQueryString(pstHttpParser);
	//char * body = (char *)getBody(pstHttpParser);
	char * cursessionId = (char *)getValue(pstHttpParser, "x-apple-session-id");
	char *p = NULL;
	int status = AIRPLAY_STATUS_OK;

	if (!cursessionId)
	{
		cursessionId = "00000000-0000-0000-0000-000000000000";
		//cursessionId = (char *)getValue(pstHttpParser, "x-apple-device-id");	//for itunes the name is device id
	}
	if (cursessionId)
	{
		airplay_log_trace("cursessionId: %s\n", cursessionId);
		*sessionId = (char *)malloc(strlen(cursessionId)+1);
		memset(*sessionId, 0x0, strlen(cursessionId)+1);
		strcpy(*sessionId, cursessionId);
	}

	if ((p= strchr(uri, '?')))
	{
		*p = '\0';
	}

	airplay_log_trace("uri: %s, socket: %d\n", uri, pstTcpClient->sdSocket);
	// This is the socket which will be used for reverse HTTP
	// negotiate reverse HTTP via upgrade
	if (!strcmp(uri, "/reverse"))
	{
		status = _ProcessReq_Reverse(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}

	// The rate command is used to play/pause media.
	// A value argument should be supplied which indicates media should be played or paused.
	// 0.000000 => pause
	// 1.000000 => play
	else if (!strcmp(uri, "/rate"))
	{
		status = _ProcessReq_Rate(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId, queryString);
	}

	// The volume command is used to change playback volume.
	// A value argument should be supplied which indicates how loud we should get.
	// 0.000000 => silent
	// 1.000000 => loud
	else if (!strcmp(uri, "/volume"))
	{
		status = _ProcessReq_Volume(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId, queryString);
	}

	// Contains a header like format in the request body which should contain a
	// Content-Location and optionally a Start-Position
	else if (!strcmp(uri, "/play"))
	{
		status = _ProcessReq_Play(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}
	// Used to perform seeking (POST request) and to retrieve current player position (GET request).
	// GET scrub seems to also set rate 1 - strange but true
	else if (!strcmp(uri, "/scrub"))
	{
		status = _ProcessReq_Scrub(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId, queryString);
	}
	// Sent when media playback should be stopped
	else if (!strcmp(uri, "/stop"))
	{
		status = _ProcessReq_Stop(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}
	// RAW JPEG data is contained in the request body
	else if (!strcmp(uri, "/photo"))
	{
		status = _ProcessReq_Photo(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}
	else if (!strcmp(uri, "/playback-info"))
	{
		status = _ProcessReq_PBInfo(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}

	else if (!strcmp(uri, "/server-info"))
	{
		airplay_log_trace("AIRPLAY: got request %s\n", uri);
		int len = strlen(SERVER_INFO)+strlen(gstAirplayServerInfo->szMacAddr_Hex)+strlen(AIRPLAY_SERVER_VERSION_STR);
		airplay_log_trace("responseBody max length: %d\n", len);
		*responseBody = (char *)malloc(len);
		memset(*responseBody , 0x0, len);
		sprintf(*responseBody, SERVER_INFO, gstAirplayServerInfo->szMacAddr_Hex);

		len = strlen("Content-Type: text/x-apple-plist+xml\r\n")+1;
		airplay_log_trace("responseHeader max length: %d\n", len);
		*responseHeader = (char *)malloc(len);
		memset(*responseHeader, 0x0, len);
		strcpy(*responseHeader, "Content-Type: text/x-apple-plist+xml\r\n");
	}

	else if (!strcmp(uri, "/slideshow-features"))
	{
		airplay_log_trace("AIRPLAY: got request %s\n", uri);
		//airplay_log_trace("AIRPLAY: got body %s\n", body);
		int len = strlen(SLIDESHOW_FEATURES)+1;
		airplay_log_trace("responseBody max length: %d\n", len);
		*responseBody = (char *)malloc(len);
		memset(*responseBody , 0x0, len);
		strcpy(*responseBody, SLIDESHOW_FEATURES);

		len = strlen("Content-Type: text/x-apple-plist+xml\r\n")+1;
		airplay_log_trace("responseHeader max length: %d\n", len);
		*responseHeader = (char *)malloc(len);
		memset(*responseHeader, 0x0, len);
		strcpy(*responseHeader, "Content-Type: text/x-apple-plist+xml\r\n");

	// Ignore for now.
	}

	else if (!strncmp(uri, "/slideshows", strlen("/slideshows")))
	{
		status = _ProcessReq_SlideShow(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
	}

	else if (!strcmp(uri, "200")) //response OK from the event reverse message
	{
		if (pstSlideShowInfo->elastSlideAction == SLIDESHOW_PLAYING)
		{
			status = _ProcessReq_Photo(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
		}
	}

	else if (!strcmp(uri, "204"))
	{
		if (pstSlideShowInfo->elastSlideAction > SLIDESHOW_NOTHING)
		{
			status = _ProcessReq_204(pstTcpClient,responseHeader, responseBody, reverseHeader, reverseBody, sessionId);
		}
	}
	else if (!strcmp(uri, "404") ||!strcmp(uri, "500") )
	{
		status = AIRPLAY_STATUS_NO_RESPONSE_NEEDED;
	}

	else if (!strcmp(uri, "/authorize"))
	{
	// DRM, ignore for now.
	}

	else if (!strcmp(uri, "/setProperty"))
	{
		status = AIRPLAY_STATUS_NOT_FOUND;
	}
	else if (!strcmp(uri, "/getProperty"))
	{
		status = AIRPLAY_STATUS_NOT_FOUND;
	}
	else
	{
		airplay_log_trace("AIRPLAY Server: unhandled request [%s]\n", uri);
		status = AIRPLAY_STATUS_NOT_IMPLEMENTED;
	}

	if (status == AIRPLAY_STATUS_NEED_AUTH)
	{
		AirPlay_ComposeAuthRequestAnswer(pstTcpClient, responseHeader, responseBody);
	}

	return status;
}
static void AirPlay_PushBuffer(TcpClient_t *pstTcpClient, const char *buffer, int len)
{
	//AIRPLAY_FUNC_INFO();

	//airplay_log_trace("buffer: %s\n", buffer);
	AddDataState_e eAddDataState = addBytes(&pstTcpClient->stHttpParser, buffer, len);

	if (eAddDataState == AddDataDone)
	{
		char *pszResponseHeader = NULL; //these memory should be free after done
		char *pszResponseBody = NULL;
		char *pszReverseHeader = NULL;
		char *pszReverseBody = NULL;
		char *pszSessionID = NULL;
		char szStatusMsg[20] = "OK";
		int status = AirPlay_ProcessRequest(pstTcpClient,
			&pszResponseHeader, &pszResponseBody, &pszReverseHeader, &pszReverseBody, &pszSessionID);
		int sdReverseSocket = INVALID_SOCKET;

		//airplay_log_trace("responseBody:\n%s\n", pszResponseBody);
		//airplay_log_trace("responseHeader:\n%s\n", pszResponseHeader);
		switch(status)
		{
			case AIRPLAY_STATUS_NOT_IMPLEMENTED:
				strcpy(szStatusMsg, "Not Implemented");
				break;
			case AIRPLAY_STATUS_SWITCHING_PROTOCOLS:
				strcpy(szStatusMsg, "Switching Protocols");
				if (pszSessionID)
				{
					gstAirplayServerInfo->stReversSocket[gstAirplayServerInfo->dReverseSocketCnt].sdSocket
						= pstTcpClient->sdSocket;
					strcpy(gstAirplayServerInfo->stReversSocket[gstAirplayServerInfo->dReverseSocketCnt++].szSessionID,
						pszSessionID);
				}
				//reverseSockets[sessionId] = m_socket;//save this socket as reverse http socket for this sessionid
				break;
			case AIRPLAY_STATUS_NEED_AUTH:
				strcpy(szStatusMsg, "Unauthorized");
				break;
			case AIRPLAY_STATUS_NOT_FOUND:
				strcpy(szStatusMsg, "Not Found");
				break;
			case AIRPLAY_STATUS_METHOD_NOT_ALLOWED:
				strcpy(szStatusMsg, "Method Not Allowed");
				break;
			case AIRPLAY_STATUS_FORBIDDEN:
				strcpy(szStatusMsg, "Forbidden");
				break;
			default:
				break;
		}

		//prepare the response
		char *pszResonse = NULL;
		const time_t ltime = time(NULL);
		char *pszDate = asctime(gmtime(&ltime));
		pszDate[strlen(pszDate) - 1] = '\0'; // remove \n
		int dLen = 0;/*the size must enough to store http informantion*/
		dLen = strlen("HTTP/1.1 ")+16/*status*/+1/*blank*/+strlen(szStatusMsg)+1/*\n*/+strlen("Date: ")+strlen(pszDate)+strlen("\r\n")
			+((pszResponseHeader)?strlen(pszResponseHeader):0)
			+((pszResponseBody)?(strlen("Content-Length: ")+16/*No. of body size*/+strlen("\r\n")):0)
			+strlen("\r\n")
			+((pszResponseBody)?strlen(pszResponseBody):0)
			+1;

		pszResonse = (char *)malloc(dLen);
		memset(pszResonse, 0x0, dLen);
		sprintf(pszResonse, "HTTP/1.1 %d %s\nDate: %s\r\n", status, szStatusMsg, pszDate);
		if (pszResponseHeader)
		{
			strcat(pszResonse, pszResponseHeader);
		}
		if (pszResponseBody)
		{
			sprintf(pszResonse+strlen(pszResonse), "Content-Length: %d\r\n", strlen(pszResponseBody));
		}
		strcat(pszResonse, "\r\n");
		if (pszResponseBody)
		{
			strcat(pszResonse, pszResponseBody);
		}

		// Send the response
		//don't send response on AIRPLAY_STATUS_NO_RESPONSE_NEEDED
		if (status != AIRPLAY_STATUS_NO_RESPONSE_NEEDED)
		{
			airplay_log_trace("ClientSocket: %d, Response:\n%s\n", pstTcpClient->sdSocket, pszResonse);
			send(pstTcpClient->sdSocket, pszResonse, strlen(pszResonse), 0);
		}

		// Send event status per reverse http socket (play, loading, paused)
		// if we have a reverse header and a reverse socket
		bool bIsSocket = false;
		if(pszReverseHeader && pszSessionID)
		{
			unsigned int i = 0;
			for (i = 0; i<gstAirplayServerInfo->dReverseSocketCnt; i++)
			{
				if (!strcmp(gstAirplayServerInfo->stReversSocket[i].szSessionID, pszSessionID))
				{
					dLen = ((pszReverseHeader)?strlen(pszReverseHeader):0)
							+strlen("\r\n")
							+((pszReverseBody)?strlen(pszReverseBody):0)
							+1;
					if(pszResonse) free(pszResonse);
					pszResonse = (char *)malloc(dLen);
					memset(pszResonse, 0x0, dLen);

					strcpy(pszResonse, pszReverseHeader);
					sdReverseSocket = gstAirplayServerInfo->stReversSocket[i].sdSocket;

					strcat(pszResonse, "\r\n");
					if(pszReverseBody)
					{
						strcat(pszResonse, pszReverseBody);
					}
					bIsSocket = true;
				}
			}
		}
		if (bIsSocket == false)
		{
			pszResonse = (char *)realloc(pszResonse, dLen+strlen("\r\n")+((pszReverseBody)?strlen(pszReverseBody):0)+1);
			strcpy(pszResonse+dLen, "\r\n");
			//memset(pszResonse+dLen, 0x0, 1);
			//strcat(pszResonse, "\r\n");
			if(pszReverseBody)
			{
				strcat(pszResonse, pszReverseBody);
			}
		}
		if(sdReverseSocket != INVALID_SOCKET)
		{
			airplay_log_trace("ReverseSocket: %d, Response:\n%s\n", sdReverseSocket, pszResonse);
			send(sdReverseSocket, pszResonse, strlen(pszResonse), 0);//send the event status on the eventSocket
		}
		if(pszResonse){free(pszResonse);}
		if(pszResponseHeader){	free(pszResponseHeader);}
		if(pszResponseBody){free(pszResponseBody);}
		if(pszReverseHeader){free(pszReverseHeader);}
		if(pszReverseBody){free(pszReverseBody);}
		if(pszSessionID){free(pszSessionID);}

		//reset httpparser;
		releaseBytes(&pstTcpClient->stHttpParser);
		memset(&pstTcpClient->stHttpParser, 0x0, sizeof(HttpParser_t));
		pstTcpClient->stHttpParser.eAddDataState = AddDataIncomplete;
	}
}

static void Airplay_AddConnection(TcpClient_t *pstConnection)
{
	unsigned dConnectionCnt = gstAirplayServerInfo->dConnectionCnt;
	if (dConnectionCnt+1 > CONNECT_MAX)
	{
		airplay_log_warn("Too much connection, should alloc more memery!\n");
	}
	else
	{
		gstAirplayServerInfo->dConnectionCnt++;
	}

	memcpy(&gstAirplayServerInfo->stTcpClient[dConnectionCnt], pstConnection, sizeof(TcpClient_t));
}

static void Airplay_ServerRoutine(void *param)
{
	AIRPLAY_FUNC_INFO();

	AirplayServer_t *pstServerInfo = (AirplayServer_t *)param;

	int sdServerSocket = pstServerInfo->sdServerSocket;
	pstServerInfo->bStopFlag = false;

	AIRPLAY_FUNC_INFO();

	int sessionCounter = 0;
	int  nread = 0;
	char *buffer = (char *)malloc(RECEIVEBUFFER);
	memset(buffer, 0x0, RECEIVEBUFFER);
	prctl(PR_SET_NAME , "Airplay_Srv", NULL, NULL, NULL);
	while(!pstServerInfo->bStopFlag)
	{
		//airplay_log_trace("Check!\n");
		unsigned int i = 0;
		int max_fd = 0;
		fd_set rfds;	//this is a summery for socket
		struct timeval to = {1, 0};
		FD_ZERO(&rfds);	//set the rfds as empty

		FD_SET(sdServerSocket, &rfds);	//add the m_ServerSocket to rfds, the m_ServerSocket has been initialize
		max_fd = sdServerSocket;

		for (i = 0; i<pstServerInfo->dConnectionCnt; i++)
		{
			FD_SET(pstServerInfo->stTcpClient[i].sdSocket, &rfds); //add other socket of connections to rfds

			if (pstServerInfo->stTcpClient[i].sdSocket > max_fd)
				max_fd = pstServerInfo->stTcpClient[i].sdSocket; //save the max fd socket to max_fd
		}

		int res = select(max_fd + 1, &rfds, NULL, NULL, &to);	//get the count of ready sockets
		//airplay_log_trace("res = %d\n", res);
		if (res < 0)
		{
			if (pstServerInfo->bStopFlag)
				break;
			airplay_log_error("Select failed!\n");
			sleep(1);
			Airplay_Initialize(pstServerInfo);
		}
		else if (res > 0)
		{
			//airplay_log_trace("pstServerInfo->dConnectionCnt = %d\n", pstServerInfo->dConnectionCnt);
			for (i = 0; i < pstServerInfo->dConnectionCnt; i++)
			{
				int socket = pstServerInfo->stTcpClient[i].sdSocket;
				if (FD_ISSET(socket, &rfds))	  //check each socket in the rfds readable or not
				{
					nread = 0;
					memset(buffer, 0x0, RECEIVEBUFFER);
					nread = recv(socket, buffer, RECEIVEBUFFER, 0);//get buffer from the established socket
					//airplay_log_trace("nread = %d\n", nread);
					if (nread > 0)
					{
						AirPlay_PushBuffer(&pstServerInfo->stTcpClient[i], buffer, nread);
						//deal with the buffer, very important
					}

					if (nread <= 0)   //if there is no buffer in the socket, close the socket
					{
						airplay_log_trace("Disconnection detected!\n");
						Airplay_Disconnect(&pstServerInfo->stTcpClient[i]);
						//below action as <vector> erase in c++
						Airplay_EraseConnection(&pstServerInfo->stTcpClient[i]);
					}
				}
			}
			if (FD_ISSET(sdServerSocket, &rfds))//check our airplay socket in the rfds readable or not
			{
				airplay_log_trace("New connection detected!\n");
				TcpClient_t stNewConnection = {0};
				sessionCounter++;
				stNewConnection.sdSocket = INVALID_SOCKET;
				stNewConnection.bAuthenticated = false;
				stNewConnection.eLastEvent = EVENT_NONE;
				stNewConnection.stHttpParser.eAddDataState = AddDataIncomplete;
				stNewConnection.sessionCounter = sessionCounter;
				//if the airplay readable,
				//create a new socket for connection for m_ServerSocket, the old one also listen
				stNewConnection.sdSocket = accept(sdServerSocket, &stNewConnection.stCliAddr, &stNewConnection.dAddrLen);
				if (stNewConnection.sdSocket == INVALID_SOCKET)//no socket connection establish
					airplay_log_error("Accept of new connection failed!\n");
				else
				{
					airplay_log_trace("New connection added, total count: %u!\n", pstServerInfo->dConnectionCnt);
					Airplay_AddConnection(&stNewConnection);
					//m_connections.push_back(newconnection);
				}
			}
		}
	}
	if (buffer)
		free(buffer);

	Airplay_StopServer(false);

	airplay_log_trace("Success to exit airplay server(video/photo)!\n");
}
#if 0
static void Airplay_MessageRoutine(void *param)
{
	AIRPLAY_FUNC_INFO();

	AirplayServer_t *pstServerInfo = (AirplayServer_t *)param;
	return;
	size_t msgrcved = 0;
	AirplayMsg_t airplaymsg = {0};
	int msgid = msgget(MSG_AIR_SRV_KEY, S_IRUSR|S_IWUSR|IPC_CREAT);

	while(!pstServerInfo->bStopFlag)
	{
		msgrcved = msgrcv(msgid, &airplaymsg, sizeof(airplaymsg.msgbody), MSG_TYPE_RESPONSE, 0);
		switch(airplaymsg.msgbody.msg)
		{
			case AIRPLAY_VIDEO_START:
				break;
			case AIRPLAY_VIDEO_PAUSE:
				break;
			case AIRPLAY_VIDEO_STOP:
			case AIRPLAY_PHOTO_STOP:
				pstServerInfo->bStopFlag = true;
				break;
			case AIRPLAY_PHOTO_START:
				break;
			case AIRPLAY_PHOTO_PAUSE:
				break;
			case AIRPLAY_SRV_STOP:
				if (avahi_pid>0)
	{
					char cmd[]="\0";
					sprintf(cmd, "kill %d", avahi_pid);
					system(cmd);
					avahi_pid = -1;
				}
				pstServerInfo->bStopFlag = true;
				break;
			default:
				break;
		}
	}

	airplay_log_trace("Ready to exit airplay server(video/photo)...\n");
}
#endif
static void Airplay_ThreadCreate(AirplayServer_t *pstServerInfo)
{
	AIRPLAY_FUNC_INFO();

	AirplayThread_t *pThreadInfo = &pstServerInfo->stAirplaySrvThead;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, PTHREAD_STACK_SIZE);
	/*
	GL_TaskCreate("Airplay server Thread",
					(void *)(Airplay_ThreadRoutine),
					(void *)pstServerInfo,
					5,
					PTHREAD_STACK_SIZE,
					true,
					&(pThreadInfo->hThread));
	*/
	if (pthread_create(&(pThreadInfo->hThread),
					&attr,
					(void*(*)(void*))Airplay_ServerRoutine/*thread function*/,
					(void *)pstServerInfo) == 0)
	{
		pThreadInfo->bValidFlag = true;
	}
	else
	{
		airplay_log_error("Failed to create airplay server thread!\n");
	}
	pthread_attr_destroy(&attr);
#if 0
	//this is used to recieve message from other proccess
	pThreadInfo = &pstServerInfo->stAirplayMsgThead;
	pthread_attr_init(&attr);
	pthread_attr_setstacksize(&attr, PTHREAD_STACK_SIZE);
	if (pthread_create(&(pThreadInfo->hThread),
					&attr,
					(void*(*)(void*))Airplay_MessageRoutine/*thread function*/,
					(void *)pstServerInfo) == 0)
	{
		pThreadInfo->bValidFlag = true;
	}
	else
	{
		airplay_log_error("Failed to create airplay message thread!\n");
	}
	pthread_attr_destroy(&attr);
	//
#endif
}

static void Airplay_StopServer(bool bWait)
{
	AIRPLAY_FUNC_INFO();

	//this should stop the airplay service thread
	AirplayServer_t *pstAirplayServInfo = gstAirplayServerInfo;

	if (pstAirplayServInfo)
	{
		int i = 0;
		if (pstAirplayServInfo->sdServerSocket != INVALID_SOCKET)
		{
			//shutdown(pstAirplayServInfo->sdServerSocket, SHUT_RDWR);
			close(pstAirplayServInfo->sdServerSocket);
		}
		for (i = 0; i<CONNECT_MAX; i++)
		{
			if (pstAirplayServInfo->stTcpClient[i].sdSocket != INVALID_SOCKET)
			{
				//shutdown(pstAirplayServInfo->stTcpClient[i].sdSocket, SHUT_RDWR);
				close(pstAirplayServInfo->stTcpClient[i].sdSocket);
			}
			if (pstAirplayServInfo->stReversSocket[i].sdSocket != INVALID_SOCKET)
			{
				//shutdown(pstAirplayServInfo->stTcpClient[i].sdSocket, SHUT_RDWR);
				close(pstAirplayServInfo->stReversSocket[i].sdSocket);
			}
			if (pstAirplayServInfo->stTcpClient[i].stHttpParser.pTotalData)
			{
				free(pstAirplayServInfo->stTcpClient[i].stHttpParser.pTotalData);
				pstAirplayServInfo->stTcpClient[i].stHttpParser.pTotalData = NULL;
			}
		}
		if (pstAirplayServInfo->location)
			free(pstAirplayServInfo->location);
		pstAirplayServInfo->location = NULL;
		free(pstAirplayServInfo);
		gstAirplayServerInfo = NULL;
		if (bWait == true)
		{
			sleep(1);	//wait for the airplay device disconnect, may be not need!
		}
	}
}

static bool Xbmc_StartServer(int sdPort, unsigned char* tHWID, bool bNonLocal)
{
	AIRPLAY_FUNC_INFO();

	Airplay_StopServer(true);

	AirplayServer_t *pstAirplayServInfo = (AirplayServer_t *)malloc(sizeof(AirplayServer_t));
	if (!pstAirplayServInfo)
	{
		airplay_log_error("Failed to malloc server information!\n");
	}
	memset(pstAirplayServInfo, 0x0, sizeof(AirplayServer_t));
	gstAirplayServerInfo = pstAirplayServInfo;
	//gpstHttpParser = &pstAirplayServInfo->stHttpParser;

	//initialize the config info
	pstAirplayServInfo->sdPort = sdPort;
	pstAirplayServInfo->bNonLocal = bNonLocal;
	pstAirplayServInfo->sdServerSocket = INVALID_SOCKET;
	pstAirplayServInfo->bUsePwd = false;
	pstAirplayServInfo->location = NULL;

	pstAirplayServInfo->stVideoPlayInfo.eventSocket = INVALID_SOCKET;
	pstAirplayServInfo->stVideoPlayInfo.eLastPlayState = EVENT_NONE;
	pstAirplayServInfo->stSlideShowInfo.eventSocket =INVALID_SOCKET;
	pstAirplayServInfo->stSlideShowInfo.elastSlideAction = SLIDESHOW_NOTHING;

	//unsigned char tHWID[6] = { 0, 51, 52, 53, 54, 55 };
	//char tHWID_Hex[6 * 3+1];

#if 0
	#if defined(AIRPLAY_WIRELESS_CONNECT)
	Net_IF_GetAddrsInfo(1/*wifi0*/, MISC_ADDRS_MAC, (char*)tHWID);
	#else
	Net_IF_GetAddrsInfo(0/*eth0*/, MISC_ADDRS_MAC, (char*)tHWID);
	#endif
#endif
	airplay_log_trace("airplay Get Mac is %02X:%02X:%02X:%02X:%02X:%02X \n",
			tHWID[0],tHWID[1],tHWID[2],tHWID[3],tHWID[4],tHWID[5]);

	sprintf(pstAirplayServInfo->szMacAddr_Hex,
		"%02X:%02X:%02X:%02X:%02X:%02X", tHWID[0],tHWID[1],tHWID[2],tHWID[3],tHWID[4],tHWID[5]);
	//strcpy(pstAirplayServInfo->szMacAddr_Hex, tHWID_Hex);

	int i = 0;
	for (; i < CONNECT_MAX; i++)
	{
		pstAirplayServInfo->stTcpClient[i].stHttpParser.eAddDataState = AddDataIncomplete;
		pstAirplayServInfo->stTcpClient[i].bAuthenticated = false;
		pstAirplayServInfo->stTcpClient[i].sdSocket = INVALID_SOCKET;
		pstAirplayServInfo->stReversSocket[i].sdSocket = INVALID_SOCKET;
	}
	//pstAirplayServInfo->stHttpParser.eAddDataState = AddDataIncomplete;

	//initialize the socket
	if (Airplay_Initialize(pstAirplayServInfo) == true)
	{
		//create the airplay server thread
		Airplay_ThreadCreate(pstAirplayServInfo);
		return true;
	}
	else
	{
		Airplay_StopServer(false);
		airplay_log_error("Failed to run airplay service!\n");
		return false;
	}
}

static int startAvahi(const char *pServerName, int pPort)
{
#if 1
	AIRPLAY_FUNC_INFO();
	if (avahi_pid >0)	//for the avahi service had started...
	{
		airplay_log_warn("avhi service(_airplay._tcp) had started with pid: %d!\n", avahi_pid);
		return avahi_pid;
	}

	char tPort[10] = {0};
	char MacAddress[MACADDR_HEX+10+1] = {0};
	char tName[SEVERNAME_LEN] = {0};
	sprintf(tPort, "%d", pPort);
	sprintf(MacAddress, "deviceid=%s", gstAirplayServerInfo->szMacAddr_Hex);
	sprintf(tName, "%s", pServerName);
	#if 0

	struct in_addr inaddr = {};
	unsigned char tHWID[6] = { 0, 51, 52, 53, 54, 55 };

	int tIdx = 0;
	char time_info[9] = {0};
	sprintf(time_info, "%s", __TIME__);	//time_info like 12:32:23
	time_info[2] = '0';
	time_info[5] = '0';					//time_info like 12032023
	srand(atoi(time_info));	//rand from seed
	//srand(GL_GetRtc32());
	for (tIdx = 0; tIdx < 3; tIdx++)
	{
		if (tIdx > 0)
		{
			int tVal = ((rand() % 80) + 33);
			tHWID[tIdx] = tVal;
		}
		sprintf(tHWID_Hex + (tIdx * 2), "%02X", tHWID[tIdx]);
	}
	#endif
	#if 1
	int tPid  = fork();
	if (tPid == 0)
	{
#if 0
			airplay_log_trace("airplay start get mac\n");
			#if defined(AIRPLAY_WIRELESS_CONNECT)
			Net_IF_GetAddrsInfo(1, MISC_ADDRS_MAC, (char*)tHWID);
			#else
			Net_IF_GetAddrsInfo(0, MISC_ADDRS_MAC, (char*)tHWID);
			#endif
			airplay_log_trace("airplay Get Mac is %02X:%02X:%02X:%02X:%02X:%02X \n",
					tHWID[0],tHWID[1],tHWID[2],tHWID[3],tHWID[4],tHWID[5]);

			for (tIdx = 0; tIdx < 6; tIdx++)
			{
				if(tIdx < 5)
				{
					sprintf(tHWID_Hex + (tIdx * 3), "%02X", tHWID[tIdx]);
					tHWID_Hex[tIdx * 3+2] = ':';
				}
				else
					sprintf(tHWID_Hex + (tIdx * 3), "%02X", tHWID[tIdx]);
			}
#endif

		printf("===============start Avahi video/photo===========\n\n");
		//tName[0] = '\0';
		//sprintf(tName, "V/P_AirPlay@%s", tHWID_Hex);
		//strcpy(tName, "V/P_AirPlay");
		airplay_log_trace("XBMC Avahi/DNS-SD Name: %s\n", tName);
		//sprintf(tName, "%s%02X%02X%02X", "SP-MirrorBox-", tHWID[3], tHWID[4], tHWID[5]);
		//note: the deviceid should get from the system api
   		execlp("avahi-publish-service", "avahi-publish-service", tName,"_airplay._tcp", tPort, MacAddress,"features=0x1000009FF","model=S2TV,1", "srcvers=101.28",  NULL);

		printf("===============end Avahi video/photo===========\n\n");

		exit(1);
	}
	else
	{
		avahi_pid = tPid;
		airplay_log_trace("avhi service(_airplay._tcp) start with pid: %d!\n", avahi_pid);
	}
	#endif
	return tPid;
#else
	char appName[256] = {0};
	char MacAddress[30] = {0};
	AvahiStringList *txt = NULL;
	char *ptxt;
	unsigned char tHWID[6] = { 0, 51, 52, 53, 54, 55 };
	char tHWID_Hex[6 * 3+1];

#if 1
	airplay_log_trace("airplay start get mac\n");
	Net_IF_GetAddrsInfo(0, MISC_ADDRS_MAC, (char*)tHWID);
	airplay_log_trace("airplay Get Mac is %02X:%02X:%02X:%02X:%02X:%02X \n",
			tHWID[0],tHWID[1],tHWID[2],tHWID[3],tHWID[4],tHWID[5]);

	sprintf(tHWID_Hex, "%02X:%02X:%02X:%02X:%02X:%02X", tHWID[0],tHWID[1],tHWID[2],tHWID[3],tHWID[4],tHWID[5]);

#endif

	strcpy(gstAirplayServerInfo->szMacAddr_Hex, tHWID_Hex);

	sprintf(MacAddress, "deviceid=%s", tHWID_Hex);
	airplay_log_trace("airplay start get mac %s\n", MacAddress);

	txt = avahi_string_list_add(txt, MacAddress);
	//txt = avahi_string_list_add(txt, "deviceid=00:26:55:2C:55:4B");
	txt = avahi_string_list_add(txt, "features=0x77");
	txt = avahi_string_list_add(txt, "model=AppleTV2,1");
	txt = avahi_string_list_add(txt, "srcvers=101.28");

	ptxt	= avahi_string_list_to_string(txt);
	airplay_log_trace("%s\n", ptxt);

	//strcpy(appName, pServerName);
	sprintf(appName, "%s%02X%02X%02X", "SP-MirrorBox-", tHWID[3], tHWID[4], tHWID[5]);
	airplay_log_trace("appName:%s\n", appName);

	gpAirPlayService  = ZeroconfAvahiNew();
	AvahidoPublishService(gpAirPlayService,  AVAHI_AIRPLAY_SERVICE,  appName, pPort, txt);
        return 0;
#endif
}
#if 0
static void endAvahi(void)
{
	AvahidoRemoveService(gpAirPlayService);
	ZeroconfAvahiFree(gpAirPlayService);
}
#endif
void Xbmc_republish_service(char *ServerName)
{
	if (avahi_pid>0)
	{
		kill(avahi_pid, SIGTERM);
		/*int ret = system(cmd);
		if (ret)
		{
			printf("shutdown xbmc avahi with stderr: %s\n", strerror(errno));
		}*/
		int status;
		waitpid(avahi_pid, &status, 0);
		avahi_pid = -1;
	}

	startAvahi(ServerName, AIRPLAY_PORT);
}

void Xbmc_entrance(unsigned char* tHWID, char *ServerName)
{
	if (Xbmc_StartServer(AIRPLAY_PORT, tHWID, true))
	{
		gstAirplayServerInfo->bUsePwd = false;
		gstAirplayServerInfo->szPwd[0] = '\0';

		startAvahi(ServerName, AIRPLAY_PORT);

		//start recive message
		#if 0
		//1: prepear the config information
		char szInterface[] = "00:11:05:8C:54:77";	//this should get from API, now config by the user
		char szFeathers[] = "0x77";
		char szModel[] = "AppleTV2,1";
		char szSrcVer[] = "101.28";

		char szSrcIdentifier[]= "servers.airplay";
		 //szSrcName: this format like "XBMC (hostname)", xbmc would be anything, hostname should get from API
		char szSrcName[] = "XBMC (sunmedia)";
		char szSrcType[] = "_airplay._tcp";

		//2: do publish the service by the config, support by api from avahi

		//is the service running~
		if (szSrcIdentifier)
		{
			return;
		}

		//txt records to AvahiStringList
		AvahiStringList *txtList = NULL;
		txtList = avahi_string_list_add_pair(txtList, "deviceid", szInterface);
		txtList = avahi_string_list_add_pair(txtList, "features", szFeathers);
		txtList = avahi_string_list_add_pair(txtList, "model", szModel);
		txtList = avahi_string_list_add_pair(txtList, "srcvers", szSrcVer);

		//add the service to the service map

		//add the new service
		#endif
	}
}
void Xbmc_exit(void)
{
	AIRPLAY_FUNC_INFO();

	if (gstAirplayServerInfo)
	{
		gstAirplayServerInfo->bStopFlag = true;
	}

#if 1
	airplay_log_trace("exit avahi with pid = %d\n", avahi_pid);
	if (avahi_pid>0)
	{
		char cmd[10]="\0";
		sprintf(cmd, "kill %d", avahi_pid);
		kill(avahi_pid, SIGTERM);
		/*int ret = system(cmd);
		if (ret)
		{
			printf("shutdown xbmc avahi with stderr: %s\n", strerror(errno));
		}*/
		avahi_pid = -1;
	}
	while(gstAirplayServerInfo)
	{
		sleep(1);
	}
#else
	endAvahi();
#endif
}
void Xbmc_disconnect()
{
	AIRPLAY_FUNC_INFO();

	if (gstAirplayServerInfo)
	{
		if (gstAirplayServerInfo->stSlideShowInfo.elastSlideAction > SLIDESHOW_NOTHING)
		{
			_AirPlay_StopSlideShow();
		}

		if (gstAirplayServerInfo->stVideoPlayInfo.eLastPlayState > EVENT_NONE ||gstAirplayServerInfo->eCurPlayType > PLAYING_NONE)
		{
			_Airplay_StopMediaPlay();
		}
		gstAirplayServerInfo->eCurPlayType = PLAYING_NONE;

		//disconnect tcp client
		unsigned dSocketCnt = gstAirplayServerInfo->dConnectionCnt;
		TcpClient_t *pstTcpClient = gstAirplayServerInfo->stTcpClient;
		unsigned int i = 0;
		for (; i<dSocketCnt; i++)
		{
			Airplay_Disconnect(&pstTcpClient[i]);
		}
		gstAirplayServerInfo->dConnectionCnt = 0;

		ReverseSocket_t *pstReversSocket = gstAirplayServerInfo->stReversSocket;
		for (i = 0; i<gstAirplayServerInfo->dReverseSocketCnt; i++)
		{
			//shutdown(pstReversSocket[i].sdSocket, SHUT_RDWR);
			close(pstReversSocket[i].sdSocket);
			pstReversSocket[i].sdSocket = INVALID_SOCKET;
		}
		gstAirplayServerInfo->dReverseSocketCnt = 0;
	}

}

int AirPlay_Server_Listener(AirPlayMW_CallbackType_e dCallbackType, UINT32 dparam1,  UINT32 dparam2)
{
	AIRPLAY_FUNC_INFO();

	switch(dCallbackType)
	{
		case AIRPLAY_MW_CBK_START:
			break;
		default:
			break;
	}

	return 0;
}
