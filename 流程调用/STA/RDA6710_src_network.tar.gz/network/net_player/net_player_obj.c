/*******************************************************************/
/**
*
* \file	qjy_obj.c
*
* \brief	This file provides qjy objects implement. \n
*
* \note  	Copyright (c) 2010 Sunplus Technology Co., Ltd. \n
*			All rights reserved.
*
* \author cs.wei@sunmedia.com.cn
*
** Date						Author					Modification
** 10/1/29					cs.wei					create
*********************************************************************/
#define NET_PLAYER_OBJ_IMPLEMENTATION

#include <stdio.h>

#include "types.h"
#include "net_player_obj.h"
#include "net_player_debug.h"
#include "net_player_if.h"


extern Net_Player_Obj_t stObjPPlayer;
extern Net_Player_Obj_t stObjAVPlayer;

INT32 NET_Player_RegisterObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode)
{
	NET_PLAYER_TRACE();
	NET_PLAYER_ASSERT(pstNP == NULL);

	if (eMode <= NET_PLAYER_M_NULL || eMode >= NET_PLAYER_M_MAX)
	{
		NET_PLAYER_ERROR("Invalid eMode[%d] \n", eMode);
		return NET_PLAYER_FAIL;
	}

	Net_Player_Obj_t* pObj = NULL;
	switch(eMode)
	{
	case NET_PLAYER_M_P:
		pObj = (Net_Player_Obj_t*)&stObjPPlayer;
		break;
	case NET_PLAYER_M_AV:
		pObj = (Net_Player_Obj_t*)&stObjAVPlayer;
		break;
	default:
		NET_PLAYER_ERROR("undefined net player mode\n");
		return NET_PLAYER_FAIL;
	}

	if (NET_PLAYER_FAIL == pObj->OnInitialize(&pstNP->stCustomInfo))
	{
		NET_PLAYER_ERROR("Register failed!!\n");
		return NET_PLAYER_FAIL;
	}

	NET_PLAYER_PRINTF("objects[%d] == %d\n", (UINT32)eMode, (UINT32)pObj);
	pstNP->objects[eMode] = (UINT32)pObj;

	return NET_PLAYER_SUCCESS;
}

INT32 NET_Player_UnregisterObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode)
{
	NET_PLAYER_TRACE();
	NET_PLAYER_ASSERT(pstNP == NULL);

	if (eMode <= NET_PLAYER_M_NULL || eMode >= NET_PLAYER_M_MAX)
	{
		NET_PLAYER_ERROR("Invalid eMode[%d] \n", eMode);
		return NET_PLAYER_FAIL;
	}

	Net_Player_Obj_t* pObj = (Net_Player_Obj_t*)NET_Player_GetObj(pstNP, eMode);
	if (pObj != NULL)
	{
		pObj->OnFinalize();
	}

	pstNP->objects[eMode] = 0;

	return NET_PLAYER_SUCCESS;
}

Net_Player_Obj_t* NET_Player_GetObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode)
{
	NET_PLAYER_ASSERT(pstNP == NULL);

	return (Net_Player_Obj_t*)pstNP->objects[eMode];
}

