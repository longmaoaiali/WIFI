#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <unistd.h>
//#include <sistypes.h>

#include "types.h"
#include "net_player_obj.h"
#include "middleware/network/common/avp_ext.h"

#include "net_video_flow_ctrl.h"
#include "types.h"
#include "mid_sub_type.h"
#include "mid_dtv_display.h"

static Net_Player_CustomInfo_t* pstCustom;
unsigned char g_bFlowDebugON = 1;
static	MediaCtrlHandle	g_MediaCtrlHandle = {0};
static BOOL b_MediaCtrlInit = FALSE;
static BOOL b_RunavInit = FALSE;
static BOOL isRunavTaskRunning = FALSE;
static pthread_t gRunav_task;

void DLNA_MediaCtrl_IsDebugON()
{
	FILE   *fp = NULL;

	fp = fopen("/tmp/flow.debug.on", "r");
	if(fp != NULL)
	{
		g_bFlowDebugON = 1;
		fclose(fp);
	}
	else
		g_bFlowDebugON = 0;
}


void* DLNA_MediaCtrl_GetMediaCtrlHandle()
{
	return &g_MediaCtrlHandle;
}

void DLNA_MediaCtrl_UpdateStreamInfo(void *Arg)
{
	if(Arg)
	{
		short 	i, j;
		BOOL	bFind;
		AvStreamInfo	*pAvInfo = NULL;
		//SubInfoList	*pSubInfo = NULL;
		runav_stream_info_t *pStreamInfo = (runav_stream_info_t *)Arg;
		MediaCtrlHandle	*pMediaCtrlHandle;


		pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();


		FLOW_DBG("count=%d, vstream_index=%d, astream_index=%d, sstream_index=%d\n",
		         pStreamInfo->nb_streams, pStreamInfo->track_video, pStreamInfo->track_audio, pStreamInfo->track_subtitle);
		FLOW_DBG("current_prog_id=%d\n", pStreamInfo->prog_id);

		pMediaCtrlHandle->pRunavStreamInfo = pStreamInfo;

		printf("MediaCtrl_UpdateStreamInfo: step1\n");
		// Step1: Find program id.
		pMediaCtrlHandle->nTotalProgram = 0;
		pMediaCtrlHandle->nCurrentProId = pStreamInfo->prog_id;
		//pMediaCtrlHandle->nSubtitleCount = ((SubInfoList*)pStreamInfo->subtitle_info_list)->total_sub_count;
		FLOW_DBG("current, pro_id=%d, SubtileCount=%d  \n", pStreamInfo->prog_id, pMediaCtrlHandle->nSubtitleCount);
		for(i=0; i<pStreamInfo->nb_streams; i++)
		{
			FLOW_DBG("Total (%d) -- prog_id=%d, id=%d, index=%d, type=%d, lang=%s  \n",
			         i,
			         pStreamInfo->streams[i].prog_id,
			         pStreamInfo->streams[i].id,
			         pStreamInfo->streams[i].index,
			         pStreamInfo->streams[i].type,
			         pStreamInfo->streams[i].lang);

			if (pStreamInfo->streams[i].type == RUNAV_STREAM_TYPE_VIDEO)
			{
				pAvInfo = &pMediaCtrlHandle->AvStreamInfo[pMediaCtrlHandle->nTotalProgram];

				pAvInfo->nProId = pStreamInfo->streams[i].prog_id;
				pAvInfo->nType = RUNAV_STREAM_TYPE_VIDEO;

				//pSubInfo = pStreamInfo->subtitle_info_list;
				//pAvInfo->nSubtitleCount = pSubInfo->total_sub_count;


				pMediaCtrlHandle->nTotalProgram++;
			}
		}

		if(pMediaCtrlHandle->nTotalProgram == 0)	// No Video Program
		{
			pMediaCtrlHandle->bVideoNotSupport = 1;
			bFind = FALSE;
			for(i=0; i<pStreamInfo->nb_streams; i++)
			{
				if (pStreamInfo->streams[i].type == RUNAV_STREAM_TYPE_AUDIO)
				{
					for(j=0; j<pMediaCtrlHandle->nTotalProgram; j++)
					{
						if(pStreamInfo->streams[j].prog_id == pMediaCtrlHandle->AvStreamInfo[j].nProId)
							bFind = TRUE;
					}

					if(pMediaCtrlHandle->nTotalProgram == 0 || !bFind )
					{
						pMediaCtrlHandle->AvStreamInfo[pMediaCtrlHandle->nTotalProgram].nProId = pStreamInfo->prog_id;
						pMediaCtrlHandle->AvStreamInfo[pMediaCtrlHandle->nTotalProgram].nType = RUNAV_STREAM_TYPE_AUDIO;
						pMediaCtrlHandle->nTotalProgram++;
					}
				}
			}

			//if(bFind == FALSE)
			//	pMediaCtrlHandle->bAudioNotSupport = 1;
		}

		//memset(&AvStreamInfo[pStreamInfo->nb_streams],
		//			0,
		//			sizeof(AvStreamInfo)*(MAX_PROGRAM_COUNT - pStreamInfo->nb_streams) );
		for(i=0; i<pMediaCtrlHandle->nTotalProgram; i++)
		{
			FLOW_DBG("pro_id[%d] -- prog_id=%d, type=%d  \n",
			         i,
			         pMediaCtrlHandle->AvStreamInfo[i].nProId,
			         pMediaCtrlHandle->AvStreamInfo[i].nType);

			pMediaCtrlHandle->AvStreamInfo[i].nAudioCount = 0;
		}



		// Step2: Use program id of step1 to find audio.

		for(i=0; i<pMediaCtrlHandle->nTotalProgram; i++)
		{
			pAvInfo = &pMediaCtrlHandle->AvStreamInfo[i];
			for(j=0; j<pStreamInfo->nb_streams; j++)
			{
				if(pAvInfo->nProId == pStreamInfo->streams[j].prog_id
				        && pStreamInfo->streams[j].type == RUNAV_STREAM_TYPE_AUDIO)
				{
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nIndex = pStreamInfo->streams[j].index;
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nId = pStreamInfo->streams[j].id;
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nTrack = pStreamInfo->streams[j].track;
					strcpy(pAvInfo->AudioInfo[pAvInfo->nAudioCount].strLang, pStreamInfo->streams[j].lang);

					FLOW_DBG("audio[%d] -- index=%d, id=%d, tarck=%d, lang=%s   \n",
					         pAvInfo->nAudioCount,
					         pAvInfo->AudioInfo[pAvInfo->nAudioCount].nIndex,
					         pAvInfo->AudioInfo[pAvInfo->nAudioCount].nId,
					         pAvInfo->AudioInfo[pAvInfo->nAudioCount].nTrack,
					         pAvInfo->AudioInfo[pAvInfo->nAudioCount].strLang);

					pAvInfo->nAudioCount++;
				}
			}
		}


		if(pMediaCtrlHandle->nTotalProgram && pAvInfo->nAudioCount == 0)
			pMediaCtrlHandle->bAudioNotSupport = 1;
	}


}


#define UPNPAV_DMR_CB_STOP		13
#define UPNPAV_DMR_CB_SETPLAYSTATE 67

static void* _DMR_CallbackStop(void* Param)
{
	Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfDlnaCallback;
	if(pfCbListner)
	{
		pfCbListner(UPNPAV_DMR_CB_STOP, 0, 0);
	}
	pthread_exit(NULL);
}

void DLNA_MediaCtrl_EventHandler(int nEventID, void *arg)
{
	MediaCtrlHandle	*pMediaCtrlHandle;
	AL_NET_PLAYER_Event_t Event = NET_PLAYER_EVENT_END;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();


	switch(nEventID)
	{
	case RUNAV_EVENT_EOF:
	{
		FLOW_DBG("RUNAV_EVENT_EOF, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		Event = NET_PLAYER_AV_EVENT_PLAY_DONE;
		pMediaCtrlHandle->bPlay = FALSE;

		/* do not send UPNPAV_DMR_CB_STOP in runav thread, or a deadlock will occur */
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
		pthread_t tid;
		if( pthread_create(&tid, &attr, _DMR_CallbackStop, NULL) != 0)
		{
			FLOW_DBG("Failed to create thread!");
		}
		break;
	}
	case RUNAV_EVENT_VIDEO_UNSUPPORT:
		FLOW_DBG("RUNAV_EVENT_VIDEO_UNSUPPORT, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		pMediaCtrlHandle->bVideoNotSupport = 1;
		break;

	case RUNAV_EVENT_AUDIO_UNSUPPORT:
		FLOW_DBG("RUNAV_EVENT_AUDIO_UNSUPPORT, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		pMediaCtrlHandle->bAudioNotSupport = 1;
		break;

	case RUNAV_EVENT_INPROCESS:
		FLOW_DBG("RUNAV_EVENT_INPROCESS, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		pMediaCtrlHandle->bVideoNotSupport = pMediaCtrlHandle->bAudioNotSupport = 0;
		Event = NET_PLAYER_AV_EVENT_DECODE_START;
		break;

	case RUNAV_EVENT_FINISH:
		FLOW_DBG("RUNAV_EVENT_FINISH, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		if(pMediaCtrlHandle->bVideoNotSupport == 1)
		{
			Event = NET_PLAYER_AV_EVENT_INIT_FAILED;
		}
		else
		{
			Event = NET_PLAYER_AV_EVENT_INITOK;
		}
		break;

	case RUNAV_EVENT_HEAD_OF_FILE:
		FLOW_DBG("RUNAV_EVENT_HEAD_OF_FILE, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		Event = NET_PLAYER_AV_EVENT_PLAY_DONE;
		break;

	case RUNAV_EVENT_AUDIO_SUPPORT:
		FLOW_DBG("RUNAV_EVENT_AUDIO_SUPPORT, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	case RUNAV_EVENT_UNKNOWN_FORMAT:
		FLOW_DBG("RUNAV_EVENT_UNKNOWN_FORMAT, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		pMediaCtrlHandle->bVideoNotSupport = 1;
		if(b_RunavInit)
		{
			Event = NET_PLAYER_AV_EVENT_PLAY_DONE;
			pMediaCtrlHandle->bPlay = FALSE;

			/* do not send UPNPAV_DMR_CB_STOP in runav thread, or a deadlock will occur */
			pthread_attr_t attr;
			pthread_attr_init(&attr);
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
			pthread_t tid;
			if( pthread_create(&tid, &attr, _DMR_CallbackStop, NULL) != 0)
			{
				FLOW_DBG("Failed to create thread!");
			}
		}
		break;


	case RUNAV_EVENT_NEXT_PROG:
		FLOW_DBG("RUNAV_EVENT_NEXT_PROG, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	case RUNAV_EVENT_STREAM_INFO:
		if(nEventID == RUNAV_EVENT_STREAM_INFO)
			FLOW_DBG("RUNAV_EVENT_STREAM_INFO, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);

		pMediaCtrlHandle->pRunavStreamInfo = (runav_stream_info_t *)arg;
		//MediaCtrl_UpdateStreamInfo(arg);
		break;

	case RUNAV_EVENT_FILE_NOT_EXIST:
		FLOW_DBG("RUNAV_EVENT_FILE_NOT_EXIST, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		pMediaCtrlHandle->bVideoNotSupport = 1;
		break;

	case RUNAV_EVENT_OOM:
		FLOW_DBG("RUNAV_EVENT_OOM, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	case RUNAV_EVENT_SEEK_COMPLETE:
		FLOW_DBG("RUNAV_EVENT_SEEK_COMPLETE, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;


	case RUNAV_EVENT_BUFFERING_START:
		FLOW_DBG("RUNAV_EVENT_BUFFERING_START, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	case RUNAV_EVENT_BUFFERING_END:
		FLOW_DBG("RUNAV_EVENT_BUFFERING_END, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	default:
		FLOW_DBG("Unknown Event, MediaStatus=%d \n", pMediaCtrlHandle->nMediaState);
		break;

	}

	DLNA_MediaCtrl_NET_Player_PE_Event_Process(Event);
	FLOW_DBG("runav event=%d  \n", nEventID);
}

void DLNA_MediaCtrl_SetMediaMode(int nMode)
{
	MediaCtrlHandle	*pMediaCtrlHandle;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	pMediaCtrlHandle->nMediaMode = nMode;
}

int DLNA_MediaCtrl_GetMediaStatus()
{
	MediaCtrlHandle	*pMediaCtrlHandle;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->bMutexThread == 0)
		return -1;

	return pMediaCtrlHandle->nMediaState;
}

unsigned char DLNA_MediaCtrl_InitMutex()
{
	MediaCtrlHandle	*pMediaCtrlHandle;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	if(pMediaCtrlHandle->bMutexThread == 0)
	{
		if (pthread_mutex_init(&pMediaCtrlHandle->MediaCmd_Mutex, NULL) != 0)
		{
			FLOW_ERR("Initialize MediaCmd_Mutex Fail !!!\n");
			return 0;
		}

		if (pthread_mutex_init(&pMediaCtrlHandle->MediaSubtitle_Mutex, NULL) != 0)
		{
			pthread_mutex_destroy(&pMediaCtrlHandle->MediaCmd_Mutex);

			FLOW_ERR("Initialize MediaSubtitle_Mutex Fail !!!\n");
			return 0;
		}

		pMediaCtrlHandle->bMutexThread = 1;

	}

	return 1;

}


void DLNA_MediaCtrl_DestroyMutex()
{
	MediaCtrlHandle	*pMediaCtrlHandle;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	if(pMediaCtrlHandle->bMutexThread == 1)
	{
		pMediaCtrlHandle->bMutexThread = 0;
		printf("[MediaCtrl_DestroyMutex] step1\n");
		if(pthread_mutex_destroy(&pMediaCtrlHandle->MediaCmd_Mutex) != 0)
			FLOW_ERR("Destroy MediaCmd_Mutex Fail  \n");
		printf("[MediaCtrl_DestroyMutex] step2\n");
		if(pthread_mutex_destroy(&pMediaCtrlHandle->MediaSubtitle_Mutex) != 0)
			FLOW_ERR("Destroy MediaSubtitle_Mutex Fail  \n");
		printf("[MediaCtrl_DestroyMutex] step3\n");
	}
}

int DLNA_MediaCtrl_Init()
{
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	int	nRet = 0;

	printf("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	//MediaCtrl_InitMutex();

	if(pMediaCtrlHandle->nMediaState != MEDIA_IDLE)
	{
		FLOW_DBG("Media Status != MEDIA_IDLE  \n");
		return -1;
	}

	if(pMediaCtrlHandle->bMutexThread == 0)
		return -1;


	pMediaCtrlHandle->nSpeed_FF = pMediaCtrlHandle->nSpeed_FR = 0;
	pMediaCtrlHandle->nCurrentProId = 0;
	pMediaCtrlHandle->bVideoNotSupport = pMediaCtrlHandle->bAudioNotSupport = 0;
	pMediaCtrlHandle->nTotalTime = 0;
	pMediaCtrlHandle->nRunavOpt = 0;

	return nRet;

}

int  DLNA_MediaCtrl_Initialize(void* pstCusInfo)
{
	int nRet = 0;
	printf("[MediaCtrl_Initialize] in\n");
	MediaCtrlHandle *pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	pMediaCtrlHandle->nMediaState = MEDIA_IDLE;
	DLNA_MediaCtrl_InitMutex();
	pstCustom = (Net_Player_CustomInfo_t*)pstCusInfo;
	DLNA_MediaCtrl_Init();
	b_MediaCtrlInit = TRUE;
	b_RunavInit = FALSE;
	return nRet;
}

int DLNA_MediaCtrl_Finalize()
{
	int nRet = 0;
	if(b_MediaCtrlInit)
	{
		MediaCtrlHandle *pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
		if(pMediaCtrlHandle->pUrl)
		{
			free(pMediaCtrlHandle->pUrl);
			pMediaCtrlHandle->pUrl = NULL;
		}

		printf("MediaCtrl_Finalize in \n");
		DLNA_MediaCtrl_Stop();
		printf("YC: final stop complete\n");
		DLNA_MediaCtrl_DestroyMutex();
		printf("MediaCtrl_Finalize out \n");
		b_MediaCtrlInit = FALSE;
	}
	return nRet;
}

void DLNA_MediaCtrl_Exit()
{
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);
	if(pMediaCtrlHandle->nMediaState != MEDIA_IDLE)
	{
		if(b_RunavInit)
		{
			printf("YC: runav_exit in\n");
			runav_exit();
			b_RunavInit = FALSE;
			printf("YC: runav_exit out\n");
		}

		pMediaCtrlHandle->nMediaState = MEDIA_IDLE;
		pMediaCtrlHandle->bPlay = FALSE;
		FLOW_DBG("EXIT -------------------------------------------------------\n");
	}

}

static void _Player_Runav_Init_Task(void* Param)
{
	MediaCtrlHandle *pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	printf("runav init [%s] start\n", pMediaCtrlHandle->pUrl);

	if(pMediaCtrlHandle->nMediaMode == MEDIA_MUSIC)
		pMediaCtrlHandle->nRunavOpt = RUNAV_VIDEO_DISABLE; // | RUNAV_OPTION_DIRECIO_DISABLE;
	else
		pMediaCtrlHandle->nRunavOpt = RUNAV_DLNA;

	if(	runav_init(pMediaCtrlHandle->pUrl,  pMediaCtrlHandle->nRunavOpt, DLNA_MediaCtrl_EventHandler) == 0)
	{
		if(pMediaCtrlHandle->bVideoNotSupport == 1)
		{
			FLOW_DBG("runav init - video format not supported\n");
			pMediaCtrlHandle->nMediaState = MEDIA_IDLE;
			pMediaCtrlHandle->bPlay = FALSE;
			
			Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfDlnaCallback;
			if(pfCbListner)
			{
				pfCbListner(UPNPAV_DMR_CB_STOP, 0, 0);
			}

			DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_AV_EVENT_INIT_FAILED);
		}
		else
		{
			FLOW_DBG("runav init - OK\n");
			pMediaCtrlHandle->nMediaState = MEDIA_STOPPED;
			b_RunavInit = TRUE;
		}
	}
	else
	{
		FLOW_DBG("runav init - failed\n");
		pMediaCtrlHandle->nMediaState = MEDIA_IDLE;
		pMediaCtrlHandle->bPlay = FALSE;
		DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_AV_EVENT_INIT_FAILED);
	}
	printf("runav init [%s] end\n", pMediaCtrlHandle->pUrl);

	pthread_exit(NULL);
}


int DLNA_MediaCtrl_SetDataSource(const char *pUrl)
{
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);
	if(pUrl && (pMediaCtrlHandle->nMediaState == MEDIA_IDLE || pMediaCtrlHandle->nMediaState == MEDIA_STOPPED))
	{

		//pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);
		if(pMediaCtrlHandle->pUrl)
		{
			free(pMediaCtrlHandle->pUrl);
			pMediaCtrlHandle->pUrl = NULL;
		}
		pMediaCtrlHandle->pUrl = strdup(pUrl);
		if(!pMediaCtrlHandle->pUrl)
		{
			FLOW_ERR("failed to strdup!\n");
			return -1;
		}

		printf("[MediaCtrl_SetDataSource] Url = %s\n", pMediaCtrlHandle->pUrl);

		if(!isRunavTaskRunning)
		{
			pMediaCtrlHandle->nMediaState = MEDIA_TRANSITIONING;
			/* notify TransportState change in AVT LastChange */
			Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfDlnaCallback;
			if(pfCbListner)
			{
				pfCbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"TRANSITIONING", 0);
			}

			pthread_attr_t attr;
			pthread_attr_init(&attr);
			pthread_attr_setstacksize(&attr, 1*1024*1024);
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
			isRunavTaskRunning = pthread_create(&gRunav_task, &attr, (void *)_Player_Runav_Init_Task, NULL) == 0;
			pthread_attr_destroy(&attr);

			if(isRunavTaskRunning)
			{
				pthread_join(gRunav_task, NULL);
				isRunavTaskRunning = FALSE;
			}

		}

		//pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);
	}

	return 0;
}


int DLNA_MediaCtrl_SetMediaInfo(void *_MediaInfo)
{
	Net_Player_MediaInfo *MediaInfo = (Net_Player_MediaInfo*)_MediaInfo;
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG();
	if(!MediaInfo || !MediaInfo->pUrl)
	{
		return NET_PLAYER_FAIL;
	}

	FLOW_DBG("Url = %s\n", MediaInfo->pUrl);
	if(MediaInfo->eAPPB_mode == NET_PLAYER_APPB_A)
	{
		DLNA_MediaCtrl_SetMediaMode(MEDIA_MUSIC);
		MID_DISP_MediaSetSource(INPUT_TYPE_USB);
	}
	else if(MediaInfo->eAPPB_mode == NET_PLAYER_APPB_V)
	{
		DLNA_MediaCtrl_SetMediaMode(MEDIA_MOVIE);
		MID_DISP_MediaSetSource(INPUT_TYPE_MEDIA);
	}
	DLNA_MediaCtrl_SetDataSource(MediaInfo->pUrl);

	if(pMediaCtrlHandle->nMediaState != MEDIA_STOPPED)
		return NET_PLAYER_FAIL;

	return NET_PLAYER_SUCCESS;

}


int DLNA_MediaCtrl_Play()
{
	printf("MediaCtrl_Play in \n");
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d, nMediaMode = %d \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay, pMediaCtrlHandle->nMediaMode);

	if(pMediaCtrlHandle->nMediaState != MEDIA_STOPPED && pMediaCtrlHandle->nMediaState != MEDIA_PAUSED)
	{
		FLOW_ERR("state error! (%d)\n", pMediaCtrlHandle->nMediaState);
		return 1;
	}

	// need to call runav_init() again
	if(pMediaCtrlHandle->nMediaState == MEDIA_STOPPED
	        && !b_RunavInit
	        && !isRunavTaskRunning
	        && pMediaCtrlHandle->pUrl )
	{
		FLOW_DBG("need to init runav again! (%s)\n", pMediaCtrlHandle->pUrl);
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setstacksize(&attr, 1*1024*1024);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
		isRunavTaskRunning = pthread_create(&gRunav_task, &attr, (void *)_Player_Runav_Init_Task, NULL) == 0;
		pthread_attr_destroy(&attr);

		if(isRunavTaskRunning)
		{
			pthread_join(gRunav_task, NULL);
			isRunavTaskRunning = FALSE;
		}

		if(!b_RunavInit) // runav_init failed
		{
			FLOW_ERR("failed to re-init runav!\n");
			return 2;
		}
	}

	pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);

	runav_play();
	pMediaCtrlHandle->nMediaState = MEDIA_PLAYING;
	pMediaCtrlHandle->bPlay = TRUE;

	/* notify TransportState change in AVT LastChange */
	Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfDlnaCallback;
	if(pfCbListner)
	{
		pfCbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"PLAYING", 0);
	}

	pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);

	return 0;
}


int DLNA_MediaCtrl_Pause()
{
	MediaCtrlHandle	*pMediaCtrlHandle;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d  \n", pMediaCtrlHandle->nMediaState);

	if(pMediaCtrlHandle->nMediaState != MEDIA_PLAYING)
		return 1;

	pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);

	runav_pause();
	pMediaCtrlHandle->nMediaState = MEDIA_PAUSED;

	pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);

	return 0;
}


int DLNA_MediaCtrl_Stop()
{
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->nMediaState == MEDIA_STOPPED)
		return 1;

	pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);

	pMediaCtrlHandle->nMediaState = MEDIA_STOPPED;
	pMediaCtrlHandle->bPlay = FALSE;

	if(b_RunavInit)
	{
		runav_exit();
		b_RunavInit = FALSE;
	}
	pMediaCtrlHandle->nSpeed_FF = pMediaCtrlHandle->nSpeed_FR = 0;
	pMediaCtrlHandle->nCurrentProId = 0;
	pMediaCtrlHandle->bVideoNotSupport = pMediaCtrlHandle->bAudioNotSupport = 0;
	pMediaCtrlHandle->nTotalTime = 0;
	pMediaCtrlHandle->nRunavOpt = 0;

	pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);

	return 0;
}


int DLNA_MediaCtrl_FastForward()
{
#if 0
	MediaCtrlHandle	*pMediaCtrlHandle;
	int				nRet = 0;

	pMediaCtrlHandle = MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->bPlay)
	{
		//pMediaCtrlHandle->nMediaState = MEDIA_FF;
		switch(pMediaCtrlHandle->nMediaState)
		{
		case MEDIA_PLAY:
		case MEDIA_FF:
		case MEDIA_PAUSE:
		case MEDIA_FR:
		{
			if(pMediaCtrlHandle->nMediaState == MEDIA_FR)
				pMediaCtrlHandle->nSpeed_FR = 0;

			if(pMediaCtrlHandle->nMediaMode == MEDIA_MUSIC &&
			        pMediaCtrlHandle->nSpeed_FF == 0)
				MediaCtrl_Pause();


			if(pMediaCtrlHandle->nSpeed_FF == 0)
				pMediaCtrlHandle->nSpeed_FF = 1;
			else
				pMediaCtrlHandle->nSpeed_FF++;

			if(pMediaCtrlHandle->nSpeed_FF == MAX_FF_FR_SPEED)
			{
				pMediaCtrlHandle->nSpeed_FF = 0;

				//if(pMediaCtrlHandle->nMediaMode == MEDIA_MOVIE)
				MediaCtrl_Play();
			}
			else
			{
				pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);

				if(pMediaCtrlHandle->nMediaMode == MEDIA_MOVIE)
					nRet = runav_fast_forward(pMediaCtrlHandle->nSpeed_FF);

				if(nRet == 0)
					pMediaCtrlHandle->nMediaState = MEDIA_FF;

				pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);
			}
		}
		break;
		}


	}

	FLOW_DBG("nRet=%d, FF=%d, FR=%d  \n",
	         nRet, pMediaCtrlHandle->nSpeed_FF, pMediaCtrlHandle->nSpeed_FR);
	return pMediaCtrlHandle->nSpeed_FF;
#else
	return 0;
#endif
}


int DLNA_MediaCtrl_FastRewind()
{
#if 0
	MediaCtrlHandle	*pMediaCtrlHandle;
	int				nRet = 0;

	pMediaCtrlHandle = MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->bPlay)
	{

		//pMediaCtrlHandle->nMediaState = MEDIA_FF;
		switch(pMediaCtrlHandle->nMediaState)
		{
		case MEDIA_PLAY:
		case MEDIA_FF:
		case MEDIA_PAUSE:
		case MEDIA_FR:
		{
			if(pMediaCtrlHandle->nMediaState == MEDIA_FF)
				pMediaCtrlHandle->nSpeed_FF = 0;


			if(pMediaCtrlHandle->nMediaMode == MEDIA_MUSIC &&
			        pMediaCtrlHandle->nSpeed_FR == 0)
				MediaCtrl_Pause();


			if(pMediaCtrlHandle->nSpeed_FR == 0)
				pMediaCtrlHandle->nSpeed_FR = 1;
			else
				pMediaCtrlHandle->nSpeed_FR++;

			if(pMediaCtrlHandle->nSpeed_FR == MAX_FF_FR_SPEED)
			{
				pMediaCtrlHandle->nSpeed_FR = 0;

				if(pMediaCtrlHandle->nMediaMode == MEDIA_MOVIE)
					MediaCtrl_Play();
			}
			else
			{
				pthread_mutex_lock(&pMediaCtrlHandle->MediaCmd_Mutex);

				if(pMediaCtrlHandle->nMediaMode == MEDIA_MOVIE)
				{
					nRet = runav_fast_backward(pMediaCtrlHandle->nSpeed_FR);
				}

				if(nRet == 0)
					pMediaCtrlHandle->nMediaState = MEDIA_FR;

				pthread_mutex_unlock(&pMediaCtrlHandle->MediaCmd_Mutex);
			}
		}
		break;
		}

	}

	FLOW_DBG("nRet=%d, FF=%d, FR=%d  \n",
	         nRet, pMediaCtrlHandle->nSpeed_FF, pMediaCtrlHandle->nSpeed_FR);
	return pMediaCtrlHandle->nSpeed_FR;
#else
	return 0;
#endif
}
int DLNA_MediaCtrl_Goto(unsigned int dTimeSecs)
{
	int iRet = 0;
	iRet = runav_seek(dTimeSecs * 1000, RUNAV_SEEK_SET);
	if(iRet != 0)
	{
		return -1;
	}
	return 0;
}

static void * _MediaCtrl_Next(void *arg)
{
	Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfAVCallback;

	Net_Player_MediaInfo mediaInfo;
	mediaInfo.eMode = NET_PLAYER_IF_AV;
	if (pfCbListner(NET_PLAYER_CBK_GET_NEXT_URL, 0, (UINT32)&mediaInfo) == 0)
	{
		DLNA_MediaCtrl_Stop();
		DLNA_MediaCtrl_Init();
		printf("next url = [%s]\n", mediaInfo.pUrl);
		DLNA_MediaCtrl_SetMediaInfo(&mediaInfo);
		printf("YC: xxxxxxxxxxxxxxxxxxxx MediaInfo->eAPPB_mode = %d\n", mediaInfo.eAPPB_mode);
		DLNA_MediaCtrl_Play();
		pfCbListner(NET_PLAYER_CBK_SHOW_NEXT, mediaInfo.Index, 0);
	}

	pthread_detach(pthread_self());
	return NULL;
}

int DLNA_MediaCtrl_Next()
{
	MediaCtrlHandle *pMediaCtrlHandle;
	int nRet = 0;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->bPlay)
	{
		pthread_t pTaskId;
		pthread_create(&pTaskId, NULL, _MediaCtrl_Next, NULL);
	}

	return nRet;
}

static void * _MediaCtrl_Prev(void *arg)
{
	Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfAVCallback;

	Net_Player_MediaInfo mediaInfo;
	mediaInfo.eMode = NET_PLAYER_IF_AV;

	if (pfCbListner(NET_PLAYER_CBK_GET_PRE_URL, 0, (UINT32)&mediaInfo) == 0)
	{
		DLNA_MediaCtrl_Stop();
		DLNA_MediaCtrl_Init();
		printf("prev url = [%s]\n", mediaInfo.pUrl);
		DLNA_MediaCtrl_SetMediaInfo(&mediaInfo);
		DLNA_MediaCtrl_Play();
		pfCbListner(NET_PLAYER_CBK_SHOW_PREV, mediaInfo.Index, 0);
	}

	pthread_detach(pthread_self());
	return NULL;
}

int DLNA_MediaCtrl_Prev()
{
	MediaCtrlHandle *pMediaCtrlHandle;
	int nRet = 0;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();
	FLOW_DBG("nMediaState=%d, bPlay=%d  \n", pMediaCtrlHandle->nMediaState, pMediaCtrlHandle->bPlay);

	if(pMediaCtrlHandle->bPlay)
	{
		pthread_t pTaskId;
		pthread_create(&pTaskId, NULL, _MediaCtrl_Prev, NULL);
	}

	return nRet;
}

int DLNA_MediaCtrl_GetCurrentTime(UINT32 * pdParam)
{
	MediaCtrlHandle		*pMediaCtrlHandle;
	unsigned int			nCurrentTime = 0;

	pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	if(pMediaCtrlHandle->bPlay == FALSE)
		return NET_PLAYER_FAIL;

	runav_getCurrentTime(&nCurrentTime);
	*pdParam = nCurrentTime/1000;

	return NET_PLAYER_SUCCESS;
}

int _DLNA_MediaCtrl_GetDuration(UINT32 dParam)
{
	int64_t * MediaTotalTime = (int64_t *) dParam;
	if (MediaTotalTime == NULL)
	{
		FLOW_DBG("MediaTotalTime = NULL\n");
		return -1;
	}
	media_info_t Media_Info;
	memset(&Media_Info, 0x0, sizeof(media_info_t));
	runav_getinfo(&Media_Info);
	*MediaTotalTime = Media_Info.duration;
	return 0;
}

int DLNA_MediaCtrl_Set(Net_Player_Set_e eSet, UINT32 dParam)
{
	int dRtnValue = NET_PLAYER_SUCCESS;
	printf("MediaCtrl_Set: eSet = %d\n", eSet);

	switch(eSet)
	{
	case NET_PLAYER_SET_AUDIOSTREAM:
		//NET_AVPlayer_ChangeAudioStream(dParam);
		break;

	case NET_PLAYER_SET_AUDIOCHANNEL:
		//NET_AVPlayer_ChangeAudioChannel(dParam);
		break;

	case NET_PLAYER_SET_SUBPICONOFF:
		//NET_AVPlayer_SetCurrentSupicOnOff(dParam);
		break;

	case NET_PLAYER_SET_SUBPICCHANGE:
		//NET_AVPlayer_ChangeSupicStream(dParam);
		break;

	case NET_PLAYER_SET_WMKLOCKRULE:
		//AVP_IF_SetWMKLockRule();
		break;

	case NET_PLAYER_SET_WMKUNLOCKRULE:
		//AVP_IF_SetWMKUnLockRule();
		break;

	default:
		//net_avplayer_error();
		break;
	}

	return dRtnValue;
}

static int DLNA_MediaCtrl_GetPlaybackInfo(UINT32 dParam)
{
	AVPPlayBackInfo_t stInfo;
	memset(&stInfo, 0, sizeof(AVPPlayBackInfo_t));

	switch(DLNA_MediaCtrl_GetMediaStatus())
	{
	case MEDIA_IDLE:
		stInfo.eState = AVP_PLAY_STATE_IDLE;
		break;
	case MEDIA_PLAYING:
		stInfo.eState = AVP_PLAY_STATE_PLAY;
		break;
	case MEDIA_STOPPED:
		stInfo.eState = AVP_PLAY_STATE_STOP;
		break;
	case MEDIA_PAUSED:
		stInfo.eState = AVP_PLAY_STATE_PAUSE;
		break;
	case MEDIA_TRANSITIONING:
		stInfo.eState = AVP_PLAY_STATE_TRANSITIONING;
		break;
	default:
		stInfo.eState = AVP_PLAY_STATE_IDLE;
		break;
	}
	memcpy((void*)dParam, &stInfo, sizeof(AVPPlayBackInfo_t));
	return NET_PLAYER_SUCCESS;
}

#if 0
static int DLNA_MediaCtrl_GetCurrentAudioStream(UINT32 * pdParam)
{
	return NET_PLAYER_SUCCESS;
}

static int DLNA_MediaCtrl_GetTotalAudioStreamCount(UINT32 * pdParam)
{
	int i;
	MediaCtrlHandle	*pMediaCtrlHandle = DLNA_MediaCtrl_GetMediaCtrlHandle();

	for(i = 0; i < pMediaCtrlHandle->pRunavStreamInfo->nb_streams; i++)
	{
	}
	return NET_PLAYER_SUCCESS;
}

static int DLNA_MediaCtrl_GetCurrentAudioChannel(UINT32 * pdParam)
{
	return NET_PLAYER_SUCCESS;
}

static int DLNA_MediaCtrl_GetTotalAudioChannelCount(UINT32 * pdParam)
{
	return NET_PLAYER_SUCCESS;
}
#endif

int DLNA_MediaCtrl_Get(Net_Player_Get_e eGet, UINT32 dParam)
{
	int dRtnValue = NET_PLAYER_SUCCESS;
	printf("MediaCtrl_Get: eGet = %d\n", eGet);

	switch(eGet)
	{
	case NET_PLAYER_GET_ELAPSEDTIME:
		dRtnValue = DLNA_MediaCtrl_GetCurrentTime((UINT32*)dParam);
		break;
	case NET_PLAYER_GET_PLAYBACKINFO:
		dRtnValue = DLNA_MediaCtrl_GetPlaybackInfo(dParam);
		break;
	case NET_PLAYER_GET_CURRENTAUDIOSTREAMNUM:
		//dRtnValue = DLNA_MediaCtrl_GetCurrentAudioStream(pdParam);
		break;
	case NET_PLAYER_GET_TOTALAUDIOSTREAMCOUNT:
		//dRtnValue = DLNA_MediaCtrl_GetTotalAudioStreamCount(pdParam);
		break;
	case NET_PLAYER_GET_CURRENTAUDIOCHANNELNUM:
		//dRtnValue = DLNA_MediaCtrl_GetCurrentAudioChannel(pdParam);
		break;
	case NET_PLAYER_GET_TOTALAUDIOCHANNELCOUNT:
		//dRtnValue = DLNA_MediaCtrl_GetTotalAudioChannelCount(pdParam);
		break;
	case NET_PLAYER_GET_PlaySpeed:
		//NET_AVPlayer_GetSpeed((UINT32 *)dParam);
		break;
	case NET_PLAYER_GET_AUDIOSTREAMATTRIBUTE:
	{
		/*
						Net_Player_AudStrmAttribute_t* pAudioAttr = (Net_Player_AudStrmAttribute_t*)dParam;
						if (pAudioAttr != NULL)
							NET_AVPlayer_GetAudioStreamAttribute(pAudioAttr->dAudStrmIdx, pAudioAttr->pstAudStrmAttribute);
		*/
	}
	break;
	case NET_PLAYER_GET_CURRENTPOSITION://add by rui.l 0411
		//NET_AVPlayer_GetElapsedPosition((UINT64 *)dParam);
		break;
	case NET_PLAYER_GET_CURRENTTRACKSIZE://add by rui.l 0411
		_DLNA_MediaCtrl_GetDuration(dParam);
		break;

	case NET_PLAYER_GET_TOTALSUBPICCOUNT:
		//NET_AVPlayer_GetTotalSupicStreamCount((UINT32 *)dParam);
		break;

	case NET_PLAYER_GET_CURSUBPICONOFF:
		//NET_AVPlayer_GetCurrentSupicOnOff((UINT32 *)dParam);
		break;

	case NET_PLAYER_GET_CURSUBPICSTREAM:
		//NET_AVPlayer_GetCurrentSupicStreamNum((UINT32 *)dParam);
		break;

	default:
		//net_avplayer_error();
		break;
	}

	return dRtnValue;
}

const Net_Player_Obj_t  stObjAVPlayer =
{
	NET_PLAYER_M_AV,

	DLNA_MediaCtrl_Initialize,
	DLNA_MediaCtrl_Finalize,
	DLNA_MediaCtrl_SetMediaInfo,
	DLNA_MediaCtrl_Play,
	DLNA_MediaCtrl_Stop,
	DLNA_MediaCtrl_Pause,
	DLNA_MediaCtrl_FastForward,
	DLNA_MediaCtrl_FastRewind,
	DLNA_MediaCtrl_Goto,
	DLNA_MediaCtrl_Next,
	DLNA_MediaCtrl_Prev,
	DLNA_MediaCtrl_Set,
	DLNA_MediaCtrl_Get
};

