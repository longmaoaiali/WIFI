/******************************************************************************/
/**
*
* \file	qjy_obj.h
*
*
* \brief	include qjy objects. \n
*
* \note  	Copyright (c) 2010 sunmedia Technology Co., Ltd. \n
*			All rights reserved.
*
*
* \author cs.wei@sunmedia.com.cn
*
******************************************************************************/
#ifndef __NET_PLAYER_OBJ_H__
#define __NET_PLAYER_OBJ_H__

#include "net_player_if.h"

typedef enum
{
	NET_PLAYER_M_NULL = -1,

	NET_PLAYER_M_P = 1,
	NET_PLAYER_M_AV,

	NET_PLAYER_M_MAX,
} Net_Player_Mode_e;

/*
* \brief Define qjy browser data structure obj
*/
typedef struct _Net_Player_DataStructure_t
{
	UINT32 objects[NET_PLAYER_M_MAX];
	Net_Player_Mode_e eMode;

	Net_Player_CustomInfo_t stCustomInfo;
} Net_Player_DataStructure_t;


typedef	INT32 (*NPObjIntializeCBFunc)(void*);
typedef	INT32 (*NPObjFinalizeCBFunc)(void);
typedef	INT32 (*NPObjSetUrlCBFunc)(void*);
typedef	INT32 (*NPObjPlayCBFunc)(void);
typedef	INT32 (*NPObjStopCBFunc)(void);
typedef	INT32 (*NPObjPauseCBFunc)(void);
typedef	INT32 (*NPObjFFCBFunc)(UINT32 dFactor);
typedef	INT32 (*NPObjFRCBFunc)(UINT32 dFactor);
typedef	INT32 (*NPObjGotoCBFunc)(UINT32 dSecond);
typedef	INT32 (*NPObjNextCBFunc)(void);
typedef	INT32 (*NPObjPrevCBFunc)(void);
typedef	INT32 (*NPObjSetCBFunc)(Net_Player_Set_e eSet, UINT32 dParam);
typedef	INT32 (*NPObjGetCBFunc)(Net_Player_Get_e eGet, UINT32 dParam);


typedef struct Net_Player_Obj_t_
{
	Net_Player_Mode_e eMode;

	NPObjIntializeCBFunc OnInitialize;
	NPObjFinalizeCBFunc OnFinalize;
	NPObjSetUrlCBFunc OnSetMeidaInfo;
	NPObjPlayCBFunc OnPlay;
	NPObjStopCBFunc OnStop;
	NPObjPauseCBFunc OnPause;
	NPObjFFCBFunc OnFF;
	NPObjFRCBFunc OnFR;
	NPObjGotoCBFunc OnGoto;
	NPObjNextCBFunc OnNext;
	NPObjNextCBFunc OnPrev;
	NPObjSetCBFunc OnSet;
	NPObjGetCBFunc OnGet;

} Net_Player_Obj_t;


#ifdef NET_PLAYER_OBJ_IMPLEMENTATION
#define NET_PLAYER_OBJ_EXTERN
#else
#define NET_PLAYER_OBJ_EXTERN extern
#endif

NET_PLAYER_OBJ_EXTERN INT32 NET_Player_RegisterObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode);
NET_PLAYER_OBJ_EXTERN INT32 NET_Player_UnregisterObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode);
NET_PLAYER_OBJ_EXTERN Net_Player_Obj_t* NET_Player_GetObj(Net_Player_DataStructure_t *pstNP, Net_Player_Mode_e eMode);

#endif

