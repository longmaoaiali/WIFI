#ifndef _NET_PLAYER_DEBUG_H_
#define _NET_PLAYER_DEBUG_H_

#define NET_PLAYER_DBG_DEBUG
#define NET_PLAYER_DBG_TRACE
#define NET_PLAYER_DBG_ERROR
#define NET_PLAYER_DBG_WARNING
#define NET_PLAYER_DBG_ASSERT

#ifdef NET_PLAYER_DBG_DEBUG
#define NET_PLAYER_PRINTF(fmt, arg...) diag_printf("[net_player][%s][line:%d]"fmt,__FUNCTION__,__LINE__,##arg)
#else
#define NET_PLAYER_PRINTF(a,...) do{}while(0)
#endif

#define diag_printf printf

#ifdef NET_PLAYER_DBG_TRACE
#define NET_PLAYER_TRACE() diag_printf("[net_player][TRACE][%s]:[LINE]%d\n",__FUNCTION__,__LINE__)
//#define QJY_TRACE() diag_printf("[QJY][TRACE][%s][%s]:[LINE]%d\n",__FILE__,__FUNCTION__,__LINE__)
#else
#define NET_PLAYER_TRACE(a,...) do{}while(0)
#endif

#ifdef NET_PLAYER_DBG_ERROR
#define NET_PLAYER_ERROR(fmt, arg...) diag_printf("\n[net_player][ERROR][%s][%s]:[%d]"fmt,__FILE__,__FUNCTION__,__LINE__,##arg)
#else
#define NET_PLAYER_ERROR(a,...) do{}while(0)
#endif

#ifdef NET_PLAYER_DBG_WARNING
#define NET_PLAYER_WARNING(fmt, arg...) diag_printf("[net_player][WARNING][%s]:[%d]"fmt,__FUNCTION__,__LINE__,##arg)
//#define QJY_WARNING(fmt, arg...) diag_printf("[QJY][WARNING][%s][%s]:[%d]"fmt,__FILE__,__FUNCTION__,__LINE__,##arg)
#else
#define NET_PLAYER_WARNING(a,...) do{}while(0)
#endif

#ifdef NET_PLAYER_DBG_ASSERT
#define NET_PLAYER_ASSERT(a) if(a) do{diag_printf("\n[net_player][ASSERT][%s][%s]:[LINE]%d\n\n",__FILE__,__FUNCTION__,__LINE__);}while(0)
#else
#define NET_PLAYER_ASSERT(a) do{}while(0)
#endif

#define GL_FUNC_CALL(funcCall) if(GL_SUCCESS != (funcCall)) diag_printf("[GL ERROR][LINE]:[%d]\n",__LINE__)

#endif