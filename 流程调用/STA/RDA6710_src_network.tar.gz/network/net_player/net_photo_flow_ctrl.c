#include <unistd.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/prctl.h>
#include "types.h"
#include "Photo_if.h"
#include "mid_dtv_display.h"
#include "net_player_obj.h"
#include "net_photo_flow_ctrl.h"
#include "curl/curl.h"
#include "avp_ext.h"

#define DLNA_PHOTO_FILESIZE_MAX (10 << 20) // 10MB
#define UPNPAV_DMR_CB_SETPLAYSTATE 67

static Net_Player_MWCallback pfDLNACbListner = NULL;
static PhotoCtrlHandle g_PhotoCtrlHandle = {0};
static struct dlna_photo_config g_dlna_photo_config;
static bool abortDownload = false;
static bool isDecoding = false;
static bool sizeTooLarge = false;

void* PhotoCtrl_GetPhotoCtrlHandle() {
	return &g_PhotoCtrlHandle;
}

static int photo_open_file() {
	PhotoCtrlHandle *pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	PhotoAPI_StreamInfo Stream_Info;
	memset(&Stream_Info, 0x00, sizeof(PhotoAPI_StreamInfo));
	Stream_Info.StreamMode = PHOTO_STREAM_BUFFER;
	Stream_Info.DataBufAddr = pPhotoCtrlHandle->pBuf;
	Stream_Info.DataSize = pPhotoCtrlHandle->pSize;
	Stream_Info.EffectMode = PHOTO_NO_EFFECT;
	Stream_Info.EffectIdx = 0;

	if (Photo_OpenFile_Init(&Stream_Info, &(g_dlna_photo_config.thumb_info)) != TRUE) {
		return 1;
	}

	return 0;
}

static int global_variable_init() {
	memset(&g_dlna_photo_config, 0, sizeof(struct dlna_photo_config));
	PhotoAPI_Resolution PanelSize = {0};
	Photo_GetPanelSize(&PanelSize);
	g_dlna_photo_config.thumb_info.pos_X = 0;
	g_dlna_photo_config.thumb_info.pos_Y = 0;
	g_dlna_photo_config.thumb_info.thumb_Height = PanelSize.Height;
	g_dlna_photo_config.thumb_info.thumb_Width  = PanelSize.Width;
	g_dlna_photo_config.thumb_info.Is_thumb_decode = 0;

	return 0;
}

#define MINIMAL_PROGRESS_FUNCTIONALITY_INTERVAL 3

struct myprogress {
	double lastruntime;
	CURL *curl;
};

static int xferinfo(void *p, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal, curl_off_t ulnow) {
	struct myprogress *myp = (struct myprogress *)p;
	CURL *curl = myp->curl;
	double curtime = 0;

	curl_easy_getinfo(curl, CURLINFO_TOTAL_TIME, &curtime);

	/* under certain circumstances it may be desirable for certain functionality
	   to only run every N seconds, in order to do this the transaction time can
	   be used */
	if ((curtime - myp->lastruntime) >= MINIMAL_PROGRESS_FUNCTIONALITY_INTERVAL) {
		myp->lastruntime = curtime;
		fprintf(stderr, "TOTAL TIME: %f \r\n", curtime);
	}

	fprintf(stderr, "UP: %" CURL_FORMAT_CURL_OFF_T " of %" CURL_FORMAT_CURL_OFF_T
	        "  DOWN: %" CURL_FORMAT_CURL_OFF_T " of %" CURL_FORMAT_CURL_OFF_T
	        "\r\n", ulnow, ultotal, dlnow, dltotal);

	if (dltotal > DLNA_PHOTO_FILESIZE_MAX) {
		sizeTooLarge = true;
		return 1;
	}

	if (abortDownload) {
		return 1;
	} else {
		return 0;
	}
}

struct MemoryStruct {
	char *memory;
	size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
	size_t realsize = size * nmemb;
	struct MemoryStruct *mem = (struct MemoryStruct *)userp;

	char *ptr = realloc(mem->memory, mem->size + realsize + 1);
	if (ptr == NULL) {
		/* out of memory! */
		printf("not enough memory (realloc returned NULL)\n");
		return 0;
	}

	mem->memory = ptr;
	memcpy(&(mem->memory[mem->size]), contents, realsize);
	mem->size += realsize;
	mem->memory[mem->size] = 0;

	return realsize;
}

static int getDataFromUrl() {
	CURL *curl;
	CURLcode res = CURLE_OK;
	struct myprogress prog;

	struct MemoryStruct chunk;

	chunk.memory = malloc(1);	/* will be grown as needed by the realloc above */
	chunk.size = 0;	/* no data at this point */

	curl = curl_easy_init();
	if (curl) {
		prog.lastruntime = 0;
		prog.curl = curl;
		abortDownload = false;
		sizeTooLarge = false;
		PhotoCtrlHandle *pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
		pPhotoCtrlHandle->nPhotoState = PHOTO_TRANSITIONING;

		/* notify TransportState change in AVT LastChange */
		if (pfDLNACbListner) {
			pfDLNACbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"TRANSITIONING", 0);
		}

		curl_easy_setopt(curl, CURLOPT_URL, pPhotoCtrlHandle->pUrl);
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
		curl_easy_setopt(curl, CURLOPT_USERAGENT, "libcurl-agent/1.0");
		curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, xferinfo);
		curl_easy_setopt(curl, CURLOPT_XFERINFODATA, &prog);
		curl_easy_setopt(curl, CURLOPT_NOPROGRESS, 0L);
		res = curl_easy_perform(curl);
		printf("%lu bytes retrieved, res: %d\n", (unsigned long)chunk.size, res);
		if ((!abortDownload) && (!sizeTooLarge) && (res == CURLE_OK)) {
			pPhotoCtrlHandle->pBuf = chunk.memory;
			pPhotoCtrlHandle->pSize = chunk.size;
		} else {
			printf("download failed!\n");
			res = -1;
			if (sizeTooLarge) {
				sizeTooLarge = false;
				res = -2;
			}
			if (abortDownload) {
				abortDownload = false;
				res = -3;
			}
			pPhotoCtrlHandle->nPhotoState = PHOTO_STOPPED;

			/* notify TransportState change in AVT LastChange */
			if (pfDLNACbListner) {
				pfDLNACbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"STOPPED", 0);
			}
		}
		curl_easy_cleanup(curl);
	} else {
		printf("curl_easy_init failed!\n");
		return -1;
	}

	return res;
}

static NET_PPlayer_Status _translatePhotoStatus(int status) {
	switch (status) {
	case PHOTO_IDLE:
		return NET_PPLAYER_NULL;
	case PHOTO_PLAYING:
		return NET_PPLAYER_PLAY;
	case PHOTO_STOPPED:
		return NET_PPLAYER_STOP;
	case PHOTO_PAUSED:
		return NET_PPLAYER_NULL;
	case PHOTO_TRANSITIONING:
		return NET_PPLAYER_TRANSITIONING;
	default:
		return NET_PPLAYER_NULL;
	}
}

static int PhotoCtrl_GetPlaybackInfo(UINT32 dParam)
{
	AVPPlayBackInfo_t stInfo;
	memset(&stInfo, 0, sizeof(AVPPlayBackInfo_t));
	PhotoCtrlHandle *pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();

	switch(pPhotoCtrlHandle->nPhotoState)
	{
	case PHOTO_IDLE:
		stInfo.eState = AVP_PLAY_STATE_IDLE;
		break;
	case PHOTO_PLAYING:
		stInfo.eState = AVP_PLAY_STATE_PLAY;
		break;
	case PHOTO_STOPPED:
		stInfo.eState = AVP_PLAY_STATE_STOP;
		break;
	case PHOTO_PAUSED:
		stInfo.eState = AVP_PLAY_STATE_PAUSE;
		break;
	case PHOTO_TRANSITIONING:
		stInfo.eState = AVP_PLAY_STATE_TRANSITIONING;
		break;
	default:
		stInfo.eState = AVP_PLAY_STATE_IDLE;
		break;
	}
	memcpy((void*)dParam, &stInfo, sizeof(AVPPlayBackInfo_t));
	return 0;
}

int PhotoCtrl_Initialize(void* pstCusInfo) {
	PhotoCtrlHandle *pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	pPhotoCtrlHandle->nPhotoState = PHOTO_IDLE;
	pfDLNACbListner = ((Net_Player_CustomInfo_t*)pstCusInfo)->stPInfo.pfDlnaCallback;
	return 0;
}

int PhotoCtrl_Finalize() {
	PhotoCtrlHandle *pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	if (pPhotoCtrlHandle->pBuf) {
		free(pPhotoCtrlHandle->pBuf);
		pPhotoCtrlHandle->pBuf = NULL;
		pPhotoCtrlHandle->pSize = 0;
	}
	if (pPhotoCtrlHandle->pUrl) {
		free(pPhotoCtrlHandle->pUrl);
		pPhotoCtrlHandle->pUrl = NULL;
	}
	pfDLNACbListner = NULL;
	return 0;
}

int PhotoCtrl_SetMediaInfo(void *_MediaInfo) {
	Net_Player_MediaInfo *MediaInfo = (Net_Player_MediaInfo*)_MediaInfo;
	int res = -1;

	if (!MediaInfo || !MediaInfo->pUrl) {
		return 1;
	}

	PhotoCtrlHandle	*pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	if (pPhotoCtrlHandle->nPhotoState == PHOTO_IDLE || pPhotoCtrlHandle->nPhotoState == PHOTO_STOPPED) {
		if (pPhotoCtrlHandle->pBuf) {
			free(pPhotoCtrlHandle->pBuf);
			pPhotoCtrlHandle->pBuf = NULL;
			pPhotoCtrlHandle->pSize = 0;
		}

		if (pPhotoCtrlHandle->pUrl) {
			free(pPhotoCtrlHandle->pUrl);
			pPhotoCtrlHandle->pUrl = NULL;
		}

		pPhotoCtrlHandle->pUrl = strdup(MediaInfo->pUrl);
		if (!pPhotoCtrlHandle->pUrl) {
			return -1;
		}
		DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_PIC_EVENT_DECODE_START);
		res = getDataFromUrl();
		if (res != CURLE_OK) {
			printf("getDataFromUrl failed!\n");
			if (res == -2) {
				DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_PIC_EVENT_DECODE_ERROR); // file size too large
			}
			return 1;
		}
	}

	return 0;
}

int PhotoCtrl_Play() {
	int ret = -1;
	int unSupported = 0;
	PhotoCtrlHandle	*pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	if (pPhotoCtrlHandle->nPhotoState != PHOTO_STOPPED && pPhotoCtrlHandle->nPhotoState != PHOTO_TRANSITIONING) {
		printf("state error! (%d)\n", pPhotoCtrlHandle->nPhotoState);
		return -1;
	}

	if (isDecoding == true) {
		printf("last photo is decoding!\n");
		return -1;
	}

	do {
		if (!pPhotoCtrlHandle->pBuf) {
			printf("no image to display!\n");
			return -1;
		}

		MID_DISP_MediaSetSource(INPUT_TYPE_USB);
		Cmd_VipSetAPPMuteStatus(true);
		isDecoding = true;

		if (Photo_Init(0, Source_USB) != TRUE) {
			printf("Photo_Init failed!\n");
			break;
		}

		global_variable_init();

		if (abortDownload || (unSupported = photo_open_file())) {
			printf("photo_open_file failed!\n");
			Photo_Exit();
			break;
		}

		if (abortDownload || (Photo_Decode() != PHOTO_DECODE_SUCCESS)) {
			printf("photo_decode failed!\n");
			Photo_CloseFile_Exit();
			Photo_Exit();
			break;
		}

		Cmd_VipSetAPPMuteStatus(false);
		ret = 0;
	} while(0);

	isDecoding = false;

	/* notify TransportState change in AVT LastChange */
	if (pfDLNACbListner) {
		if (!ret) {
			pPhotoCtrlHandle->nPhotoState = PHOTO_PLAYING;
			pfDLNACbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"PLAYING", 0);
			DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_PIC_EVENT_DECODE_FINISH);
		} else {
			pPhotoCtrlHandle->nPhotoState = PHOTO_STOPPED;
			pfDLNACbListner(UPNPAV_DMR_CB_SETPLAYSTATE, (UINT32)"STOPPED", 0);
			if (pPhotoCtrlHandle->pBuf && unSupported) {
				DLNA_MediaCtrl_NET_Player_PE_Event_Process(NET_PLAYER_PIC_EVENT_DECODE_ERROR);
			}
		}
	}

	return ret;
}

int PhotoCtrl_Stop() {
	int retry = 0;
	PhotoCtrlHandle	*pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	if (pPhotoCtrlHandle->nPhotoState == PHOTO_STOPPED) {
		return 1;
	} else if (pPhotoCtrlHandle->nPhotoState == PHOTO_TRANSITIONING) {
		abortDownload = true;
	}

	Cmd_VipSetAPPMuteStatus(true);
	Photo_SetPicDisplay(PHOTO_DISPLAY_DISABLE, PHOTO_DISPLAY_YUV);
	Photo_Stop();
	Photo_CloseFile_Exit();
	while ((isDecoding == true) && (retry < 100)){
		printf("photo is still decoding! (%d)\n", retry);
		usleep(100000);
		retry++;
	}
	Photo_Exit();

	Photo_ClearDisplayBuffer();

	if (pPhotoCtrlHandle->pBuf) {
		free(pPhotoCtrlHandle->pBuf);
		pPhotoCtrlHandle->pBuf = NULL;
		pPhotoCtrlHandle->pSize = 0;
	}

	pPhotoCtrlHandle->nPhotoState = PHOTO_STOPPED;
	return 0;
}

int PhotoCtrl_PlayNext() {
	return 0;
}

int PhotoCtrl_PlayPre() {
	return 0;
}

int PhotoCtrl_Set(Net_Player_Set_e eSet, UINT32 dParam) {
	return 0;
}

int PhotoCtrl_Get(Net_Player_Get_e eGet, UINT32 dParam) {
	PhotoCtrlHandle	*pPhotoCtrlHandle = PhotoCtrl_GetPhotoCtrlHandle();
	int dRtnValue = 0;

	switch (eGet) {
	case NET_PLAYER_GET_PICTURESTATE:
	{
		NET_PPlayer_Status *dPicState = (NET_PPlayer_Status*)dParam;
		*dPicState = _translatePhotoStatus(pPhotoCtrlHandle->nPhotoState);
		break;
	}
	case NET_PLAYER_GET_PLAYBACKINFO:
	{
		dRtnValue = PhotoCtrl_GetPlaybackInfo(dParam);
		break;
	}
	default:
		break;
	}

	return dRtnValue;
}

const Net_Player_Obj_t stObjPPlayer =
{
	NET_PLAYER_M_P,

	PhotoCtrl_Initialize,
	PhotoCtrl_Finalize,
	PhotoCtrl_SetMediaInfo,
	PhotoCtrl_Play,
	PhotoCtrl_Stop,
	NULL,
	NULL,
	NULL,
	NULL,
	PhotoCtrl_PlayNext,
	PhotoCtrl_PlayPre,
	PhotoCtrl_Set,
	PhotoCtrl_Get,
};
