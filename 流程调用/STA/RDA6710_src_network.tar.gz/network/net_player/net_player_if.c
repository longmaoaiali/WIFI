
#include <sys/stat.h>
#include <unistd.h>

#include "gl_types.h"
#include "net_player_debug.h"
#include "net_player_if.h"
#include "net_player_obj.h"

static Net_Player_DataStructure_t* gpstNP = NULL;
static BOOL (*gPE_Hook_PostMsg)(AL_NET_PLAYER_Event_t) = NULL;
#ifdef DLNA_BG_VERSION
INT32 NET_Player_IF_MusicSel_SetMediaInfo(Net_Player_MediaInfo *MediaInfo)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, NET_PLAYER_M_AV);
		if (pObj && pObj->OnSetMeidaInfo)
			sdRet = pObj->OnSetMeidaInfo(MediaInfo);
	}
	while (0);

	return sdRet;
}
INT32 NET_Player_IF_MusicSel_Play(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}
		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, NET_PLAYER_M_AV);
		if (pObj && pObj->OnPlay)
			sdRet = pObj->OnPlay();
	}
	while (0);

	return sdRet;
}
INT32 NET_Player_IF_MusicSel_Stop(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}
		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, NET_PLAYER_M_AV);
		if (pObj && pObj->OnStop)
			sdRet = pObj->OnStop();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_MusicSel_Pause(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}
		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, NET_PLAYER_M_AV);
		if (pObj && pObj->OnPause)
			sdRet = pObj->OnPause();
	}
	while (0);

	return sdRet;
}


#endif

void DLNA_MediaCtrl_NET_Player_PE_Event_Process(UINT32 event_id)
{
	switch(event_id)
	{
	case NET_PLAYER_AV_EVENT_DECODE_START:
		NET_PLAYER_PRINTF("NET_PLAYER_AV_EVENT_DECODE_START\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_DECODE_START);
		break;

	case NET_PLAYER_AV_EVENT_INITOK:
		NET_PLAYER_PRINTF("NET_PLAYER_AV_EVENT_INITOK\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_INITOK);
		break;

	case NET_PLAYER_AV_EVENT_INIT_FAILED:
		NET_PLAYER_PRINTF("NET_PLAYER_AV_EVENT_INIT_FAILED\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_INIT_FAILED);
		break;

	case NET_PLAYER_AV_EVENT_PLAY_DONE:
		NET_PLAYER_PRINTF("NET_PLAYER_AV_EVENT_PLAY_DONE\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_PLAY_DONE);
		break;

	case NET_PLAYER_PIC_EVENT_DECODE_START:
		NET_PLAYER_PRINTF("NET_PLAYER_PIC_EVENT_DECODE_START\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_PIC_EVENT_DECODE_START);
		break;

	case NET_PLAYER_PIC_EVENT_DECODE_FINISH:
		NET_PLAYER_PRINTF("NET_PLAYER_PIC_EVENT_DECODE_FINISH\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_PIC_EVENT_DECODE_FINISH);
		break;

	case NET_PLAYER_PIC_EVENT_DECODE_ERROR:
		NET_PLAYER_PRINTF("NET_PLAYER_PIC_EVENT_DECODE_ERROR\n");
		if(gPE_Hook_PostMsg)
			gPE_Hook_PostMsg(NET_PLAYER_PIC_EVENT_DECODE_ERROR);
		break;

	default:
		NET_PLAYER_PRINTF("Unknown event 0x%X\n", event_id);
		break;
	}
}

void DLNA_MediaCtrl_NET_Player_PE_Register_MsgRouteway(BOOL (*SendMsg_Func)(AL_NET_PLAYER_Event_t))
{
	gPE_Hook_PostMsg = SendMsg_Func;
}

void DLNA_MediaCtrl_NET_Player_RegisterMsgRouteway(BOOL (*SendMsg_Func)(AL_NET_PLAYER_Event_t))
{
	DLNA_MediaCtrl_NET_Player_PE_Register_MsgRouteway(SendMsg_Func);
}

INT32 NET_Player_IF_Initialize(Net_Player_CustomInfo_t* pstCusInfo)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		if (gpstNP)
		{
			NET_PLAYER_WARNING("NET_PLAYER is initialized\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_DataStructure_t *pNewNP = NULL;
		pNewNP = (Net_Player_DataStructure_t *) GL_MemAlloc(sizeof(Net_Player_DataStructure_t));
		if (!pNewNP)
		{
			NET_PLAYER_ERROR("failed malloc QJY_DataStructure_t instance \n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}
		memset(pNewNP, 0x00, sizeof(Net_Player_DataStructure_t));
		memcpy(&pNewNP->stCustomInfo, pstCusInfo, sizeof(Net_Player_CustomInfo_t));

		NET_Player_RegisterObj(pNewNP, NET_PLAYER_M_P);
		NET_Player_RegisterObj(pNewNP, NET_PLAYER_M_AV);

		gpstNP = pNewNP;
		NET_PLAYER_WARNING("NET_PLAYER is initialized OK %p\n",gpstNP);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Finalize(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		NET_Player_UnregisterObj(pstNP, NET_PLAYER_M_P);
		NET_Player_UnregisterObj(pstNP, NET_PLAYER_M_AV);
		GL_MemFree(pstNP);
		gpstNP = NULL;
	}
	while (0);
	NET_PLAYER_TRACE();

	return sdRet;
}

INT32 NET_Player_IF_SetMediaInfo(Net_Player_MediaInfo *MediaInfo)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		if (MediaInfo->eMode== NET_PLAYER_IF_P)
			pstNP->eMode = NET_PLAYER_M_P;
		else if(MediaInfo->eMode == NET_PLAYER_IF_AV)
			pstNP->eMode = NET_PLAYER_M_AV;
		else {
			printf("unknown mode!!");
		}

		NET_PLAYER_PRINTF("%s\n", MediaInfo->pUrl);
		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnSetMeidaInfo)
			sdRet = pObj->OnSetMeidaInfo(MediaInfo);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Play(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnPlay)
			sdRet = pObj->OnPlay();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Stop(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnStop)
			sdRet = pObj->OnStop();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Pause(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnPause)
			sdRet = pObj->OnPause();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_FF(UINT32 dFactor)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnFF)
			sdRet = pObj->OnFF(dFactor);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_FR(UINT32 dFactor)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnFR)
			sdRet = pObj->OnFR(dFactor);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Goto(UINT32 dSecond)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnGoto)
			sdRet = pObj->OnGoto(dSecond);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Next(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnNext)
			sdRet = pObj->OnNext();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Prev(void)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnPrev)
			sdRet = pObj->OnPrev();
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Set(Net_Player_Set_e eSet, UINT32 dParam)
{
	NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnSet)
			sdRet = pObj->OnSet(eSet, dParam);
	}
	while (0);

	return sdRet;
}

INT32 NET_Player_IF_Get(Net_Player_Get_e eGet, UINT32 dParam)
{
	//NET_PLAYER_TRACE();

	INT32 sdRet = NET_PLAYER_SUCCESS;
	do
	{
		Net_Player_DataStructure_t *pstNP = gpstNP;
		if (pstNP == NULL)
		{
			NET_PLAYER_WARNING("Net Player uninitialized.\n");
			sdRet = NET_PLAYER_FAIL;
			break;
		}

		Net_Player_Obj_t* pObj = NET_Player_GetObj(pstNP, pstNP->eMode);
		if (pObj && pObj->OnGet)
			sdRet = pObj->OnGet(eGet, dParam);
	}
	while (0);

	return sdRet;
}


