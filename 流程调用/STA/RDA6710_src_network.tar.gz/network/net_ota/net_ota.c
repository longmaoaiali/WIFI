/* ---------------------------------------------------------------------------
** File Name : net_ota.c
**
** Description: Network OTA Updater
**
** Copyright (C) 2020 T1-Tek Inc. - All Rights Reserved
**
** Author: johnson.chen
** Date: Mon Dec 14 14:14:25 CST 2020
** -------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <dirent.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <net/if.h>
#include "types.h"
#include "net_ota.h"
#include "mid_partition_list.h"
#include "svn.h"
#include "global_CVT_DEF_FM_VERSION_STR.h"

#define SAFE_FREE(a) {if(a) {free(a); (a)=NULL;}}

#define LOCAL_PATH		"/Upgrade"
#define LOCAL_VER_FILE	"version.txt"
#define REMOTE_VER_FILE "ftp_version.txt"

#define MAX_VERSION_LEN	32


typedef struct {
	char *host;
	char *username;
	char *password;
	UINT16 port;
	char *remote_path;
	char mount_point[MID_DISK_NAME_MAX_LEN+1];

	/* for monitor thread */
	pthread_t threadID;
	pthread_cond_t cond;
	pthread_mutex_t mutex;
	bool exit_thread;
	NET_OTA_Event_Callback_t callback;
} FTP_Host_t;

static FTP_Host_t OTAServer;

static BOOL serverExist()
{
	return (OTAServer.host != NULL && OTAServer.username != NULL && OTAServer.password != NULL && OTAServer.port != 0
		&& OTAServer.remote_path != NULL);
}

static int getMountPoint(void)
{
#if defined(CONFIG_SUPPORT_NET_OTA_FROM_USB)
	int deviceCnt = MID_PartitionList_GetMountedCount();
	if(deviceCnt <= 0) {
		//printf("[OTA] No USB storage is detected!\n");
		return -1;
	}
	MID_PartitionList_GetMountName(0, OTAServer.mount_point);
	//printf("[OTA] mount_point = [%s]\n", OTAServer.mount_point);
#elif defined(CONFIG_SUPPORT_NET_OTA_FROM_MEM)
	strncpy(OTAServer.mount_point, "/tmp", sizeof(OTAServer.mount_point)-1);
#else
	#error No storage for NET OTA is selected.
#endif
	return 0;
}

static bool checkLocalPath()
{
	if(getMountPoint() != 0) {
		return false;
	}

	bool ret = true;
	char *path = NULL;
	asprintf(&path, "%s%s", OTAServer.mount_point, LOCAL_PATH);
	DIR *dir = opendir(path);
	if(!dir) {
		if(mkdir(path, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) !=0 ) {
			printf("[OTA] failed to create local_path [%s]\n", path);
			ret = false;
		}
	}
	else {
		closedir(dir);
	}
	SAFE_FREE(path);
	return ret;
}

static int getBinVersion(const char *filename, char *version)
{
	if(!checkLocalPath()) {
		return -1;
	}

	char *local = NULL;
	asprintf(&local, "%s%s/%s", OTAServer.mount_point, LOCAL_PATH, filename);
	if(!local) { // OOM
		return -1;
	}

	FILE *fp = fopen(local, "r");
	if(fp) {
		fscanf(fp, "%s", version);
		fclose(fp);
	}

	SAFE_FREE(local);

	return 0;
}

static int removeLocalFile(const char *filename)
{
	int ret = -1;
	char *local = NULL;
	asprintf(&local, "%s%s/%s", OTAServer.mount_point, LOCAL_PATH, filename);
	if(local) {
		ret = remove(local);
	}
	SAFE_FREE(local);
	return ret;
}

static void getCurrentVersion(char *version)
{
	if(version == NULL)
		return ;
#if defined(CONFIG_SUPPORT_NET_OTA_FROM_MEM)
	strncpy(version, CVT_DEF_FM_VERSION_STR, MAX_VERSION_LEN);
#else
	getBinVersion(LOCAL_VER_FILE, version);
#endif
}

static void updateCurrentVersion(void)
{
#if defined(CONFIG_SUPPORT_NET_OTA_FROM_MEM)
	// Do nothing
#else
	char *local = NULL, *remote = NULL;
	asprintf(&local, "%s%s/%s", OTAServer.mount_point, LOCAL_PATH, LOCAL_VER_FILE);
	asprintf(&remote, "%s%s/%s", OTAServer.mount_point, LOCAL_PATH, REMOTE_VER_FILE);
	if(local && remote) {
		if(remove(local) != 0)
			printf("[OTA] Failed to remove [%s]. Error:%s\n", local, strerror(errno));
		else
			printf("[OTA] Succeed to remove [%s].\n", local);

		if(rename(remote, local) != 0)
			printf("[OTA] Failed to rename [%s] to [%s]. Error:%s\n", remote, local, strerror(errno));
		else
			printf("[OTA] Succeed to rename [%s] to [%s].\n", remote, local);
	}

	SAFE_FREE(local);
	SAFE_FREE(remote);
#endif
}

NET_OTA_STATUS NET_FTP_Download(const char *host, UINT16 port, const char *username, const char *password, const char *local_file, const char *remote_file)
{
	NET_OTA_STATUS ret = NET_OTA_OK;

	if(!checkLocalPath()) {
		return NET_OTA_DOWNLOAD_FAILURE;
	}

	char *cmd = NULL;
	if(asprintf(&cmd, "wget -T 15 -O %s ftp://%s:%s@%s:%u/%s", local_file, username, password, host, port, remote_file) < 0) {
		return NET_OTA_OOM;
	}
	printf("[OTA] %s\n",cmd);
	if(system(cmd) != 0) {
		ret = NET_OTA_DOWNLOAD_FAILURE;
	}
	
	SAFE_FREE(cmd);
	return ret;
}

NET_OTA_STATUS NET_OTA_SetFTPHost(const char *host, UINT16 port, const char *username, const char *password, const char *remote_path)
{
	NET_OTA_STATUS ret = NET_OTA_OK;

	SAFE_FREE(OTAServer.host);
	SAFE_FREE(OTAServer.username);
	SAFE_FREE(OTAServer.password);
	SAFE_FREE(OTAServer.remote_path);

	if(host && username && password && port && remote_path) {
		OTAServer.host = strdup(host);
		OTAServer.username = strdup(username);
		OTAServer.password = strdup(password);
		OTAServer.port = port;
		OTAServer.remote_path = strdup(remote_path);
		if(!serverExist())
		{
			ret = NET_OTA_OOM;
			goto ERR;
		}
	
		return ret;
	}
	else
		ret = NET_OTA_BAD_PARAM;

ERR:
	SAFE_FREE(OTAServer.host);
	SAFE_FREE(OTAServer.username);
	SAFE_FREE(OTAServer.password);
	SAFE_FREE(OTAServer.remote_path);
	OTAServer.port = 0;

	return ret;
}

static NET_OTA_STATUS NET_OTA_DownloadFileEx(const char *remote_filename, const char *local_filename)
{
	if(!checkLocalPath()) {
		return NET_OTA_NO_STORAGE_FOUND;
	}
	NET_OTA_STATUS ret = NET_OTA_OK;
	char *local = NULL, *remote = NULL;
	asprintf(&local, "%s%s/%s", OTAServer.mount_point, LOCAL_PATH, local_filename);
	asprintf(&remote, "%s/%s", OTAServer.remote_path, remote_filename);
	if(local && remote && NET_FTP_Download(OTAServer.host, OTAServer.port, OTAServer.username, OTAServer.password, local, remote) != NET_OTA_OK) {
		printf("[OTA] Failed to download remote version!\n");
		ret = NET_OTA_DOWNLOAD_FAILURE;
	}
	SAFE_FREE(local);
	SAFE_FREE(remote);
	return ret;
}

static NET_OTA_STATUS NET_OTA_DownloadFile(const char *filename)
{
	return NET_OTA_DownloadFileEx(filename, filename);
}

static int NET_OTA_Check_Version(char *current_version, char *remote_version)
{
	if((current_version == NULL) || (remote_version == NULL)){
		return -1;
	}

    printf("[OTA] compare version. current_version:%s, remote_version:%s\n",current_version,remote_version);
	if(strcmp(current_version, remote_version) != 0){
        printf("[OTA] remote version is different\n");
        return 0;
	}
    printf("[OTA] remote version is same\n");
    return -1;

}

NET_OTA_STATUS NET_OTA_CheckUpdate(void)
{
	char current_version[MAX_VERSION_LEN];
	char remote_version[MAX_VERSION_LEN];
	if(!serverExist()) {
		printf("[OTA] Server is not set correctly!\n");
		return NET_OTA_BAD_PARAM;
	}
	if(!checkLocalPath()) {
		return NET_OTA_NO_STORAGE_FOUND;
	}

	getCurrentVersion(current_version);

	// retrieve version of bin on FTP
	if(NET_OTA_DownloadFileEx(LOCAL_VER_FILE, REMOTE_VER_FILE) == NET_OTA_OK) {
		int rtn = getBinVersion(REMOTE_VER_FILE, remote_version);
		if( rtn != 0 ){
			return NET_OTA_DOWNLOAD_FAILURE;
		}
		if(NET_OTA_Check_Version(current_version, remote_version) == -1){
			// remove REMOTE_VER_FILE
			printf("[OTA] same version. Ignore\n");
			removeLocalFile(REMOTE_VER_FILE);
			return NET_OTA_UP_TO_DATE;
		}
	}
	else {
		printf("[OTA] Failed to download remote version!\n");
		return NET_OTA_DOWNLOAD_FAILURE;
	}
	return NET_OTA_OK;
}

NET_OTA_STATUS NET_OTA_DownloadUpdate(void)
{
	if(!serverExist()) {
		return NET_OTA_BAD_PARAM;
	}

	// retrieve bin on FTP
	printf("[OTA] Prepare to download remote bin\n");
	if(NET_OTA_DownloadFile(CONFIG_BIN_FILENAME) != NET_OTA_OK) {
		printf("[OTA] Failed to download remote bin!\n");
		// remove remote version file
		removeLocalFile(REMOTE_VER_FILE);
		return NET_OTA_DOWNLOAD_FAILURE;
	}

	updateCurrentVersion();

	printf("[OTA] Complete downloading remote bin!\n");
	return NET_OTA_OK;
}

static bool isNetworkReady()
{
	bool ret = false;
	const char* iface[] =
	{
#ifdef CONFIG_SUPPORT_ETHERNET
		"eth0",
#endif
#ifdef CONFIG_SUPPORT_WIFI
		"wlan0",
#endif
	};
	int fd = socket( AF_INET, SOCK_DGRAM, 0 );
	if(fd != -1)
	{
		unsigned int i;
		for(i = 0; i < sizeof(iface)/sizeof(const char*); ++i)
		{
			struct ifreq ifr;
			memset( &ifr, 0, sizeof(ifr) );
			strcpy( ifr.ifr_name, iface[i] );
			ifr.ifr_addr.sa_family = AF_INET;

			if( ioctl(fd, SIOCGIFFLAGS, &ifr) != -1 )
			{
				int up_and_running = (ifr.ifr_flags & ( IFF_UP | IFF_RUNNING )) == ( IFF_UP | IFF_RUNNING );
				if(up_and_running)
				{
					if( ioctl(fd, SIOCGIFADDR, &ifr) != -1 )
					{
						ret = true;
						break;
					}
				}
			}
		}
		close(fd);
	}
	return ret;
}

static void* OTATask(void *arg)
{
	pthread_detach(pthread_self());

	// wait until 1) network is up and running 2) usb storage mounted
	while((!isNetworkReady() || !checkLocalPath()) && !OTAServer.exit_thread) {
		struct timeval now;
		struct timespec outtime;
		gettimeofday(&now, NULL);
		outtime.tv_sec = now.tv_sec + 10;
		outtime.tv_nsec = now.tv_usec * 1000;
		pthread_cond_timedwait(&OTAServer.cond, &OTAServer.mutex, &outtime);
	}

	if(OTAServer.exit_thread)
		pthread_exit(NULL);

	printf("[OTA] Network is ready. Check for update now.\n");	
	if(NET_OTA_CheckUpdate() == NET_OTA_OK) {
		printf("[OTA] An update is available now.\n");	
		if(OTAServer.callback)
			OTAServer.callback(NET_OTA_EVENT_NEW_UPDATE_FOUND, 1);
	}
	else
		printf("[OTA] Current version is already up-to-date.\n");	

	pthread_exit(NULL);
}

NET_OTA_STATUS NET_OTA_StartUpdateMonitor(void)
{
	OTAServer.exit_thread = false;
	pthread_mutex_init(&OTAServer.mutex, NULL);
	pthread_cond_init(&OTAServer.cond, NULL);
	pthread_create(&OTAServer.threadID, NULL, OTATask, NULL);
	return NET_OTA_OK;
}

NET_OTA_STATUS NET_OTA_StopUpdateMonitor(void)
{
	OTAServer.exit_thread = true;
	pthread_cond_signal(&OTAServer.cond);
	pthread_mutex_destroy(&OTAServer.mutex);
	pthread_cond_destroy(&OTAServer.cond);
	return NET_OTA_OK;
}

void NET_OTA_RegisterCallback(NET_OTA_Event_Callback_t func)
{
	OTAServer.callback = func;
}

