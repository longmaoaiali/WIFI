#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/time.h>
#include <runav.h>
#include "xpipe.h"
#include "threads.h"
#include "airp_player.h"
#include "t1_format.h"
#include "mid_dtv_display.h"
#include "dpswrape.h"

#define EPSILON  0.0002f

typedef struct {
	char * url;
	float start_pos;
} Airp_Play_param_t;

static AirplayCbkFunc_t al_callback = NULL;
static bool isRunavRunning = false;
static bool isVideoSupported = false;
static Airp_Player_State_t playerState = AIRP_PLAYER_STOPPED;
static thread_handle_t runav_thread = 0;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
static uint32_t lastPosition = 0;
static uint32_t lastDuration = 0;
static uint32_t seekPositionMs = 0;
static uint32_t targetDuration = 0;
static uint32_t reloadTime = 0;
static bool isSeeking = false;

static void update_position(int sec);

static void runav_event_handler(int event_id, void *arg)
{
	Airplay_Event_t event = AIRPLAY_EVENT_END;

	switch(event_id)
	{

	case RUNAV_EVENT_HEAD_OF_FILE:
		printf("[event] HOF\n");
		break;

	case RUNAV_EVENT_OOM:
		printf("[event] OOM\n");
		isRunavRunning = false;
		break;

	case RUNAV_EVENT_EOF:
		printf("[event] EOF\n");
		lastPosition = airp_player_get_duration() + 1;
		isRunavRunning = false;
		update_position(lastPosition);
		break;

	case RUNAV_EVENT_VIDEO_UNSUPPORT:
		printf("[event] video unsupport\n");
		isVideoSupported = false;
		isRunavRunning = false;
		break;

	case RUNAV_EVENT_AUDIO_UNSUPPORT:
		printf("[event] audio unsupport\n");
		break;

	case RUNAV_EVENT_INPROCESS:
		printf("[event] inprocess\n");
		event = AIRPLAY_AV_EVENT_DECODE_START;
		break;

	case RUNAV_EVENT_FINISH:
		printf("[event] init finish\n");
		break;

	case RUNAV_EVENT_UNKNOWN_FORMAT:
		printf("[event] unknown format\n");
		isVideoSupported = false;
		isRunavRunning = false;
		break;

	case RUNAV_EVENT_FILE_NOT_EXIST:
		printf("[event] file not exist\n");
		isVideoSupported = false;
		isRunavRunning = false;
		break;

	case RUNAV_EVENT_STREAM_INFO:
		printf("[event] event stream info\n");
		break;

	case RUNAV_EVENT_SEEK_COMPLETE:
		printf("[event] seek complete\n");
		isSeeking = false;
		break;

	case RUNAV_EVENT_SEEK_FAIL:
		printf("[event] seek fail\n");
		isSeeking = false;
		break;
	case RUNAV_EVENT_BUFFERING_START:
		printf("[event] BUFFERING_START\n");
		break;

	case RUNAV_EVENT_BUFFERING_END:
		printf("[event] BUFFERING_END\n");
		break;
	
	case RUNAV_EVENT_SET_PLAYLIST_RELOAD_TIME:
		printf("[event] SET_PLAYLIST_RELOAD_TIME: %d\n", *((int*)arg));
		reloadTime = (uint32_t)(*((int*)arg));
		break;
	}

	if(event != AIRPLAY_EVENT_END && al_callback != NULL)
	{
		al_callback(event, 0);
	}
}

static void update_position(int sec)
{
	// update current position
	int hh = sec / 3600;
	int mm = (sec - hh * 3600) / 60;
	int ss = sec % 60;
	char pos[10] = {0};
	snprintf(pos, sizeof(pos), "%02d:%02d:%02d", hh, mm, ss);
	printf("[airp] Update position: [%s]\n", pos);
	airdpsSetServiceTableVar(DMR_AVT_RELATIVETIMEPOSITION, pos);
}

static void update_duration()
{
	// update duration
	int sec = (int)airp_player_get_duration();
	int hh = sec / 3600;
	int mm = (sec - hh * 3600) / 60;
	int ss = sec % 60;
	char dur[10] = {0};
	snprintf(dur, sizeof(dur), "%02d:%02d:%02d", hh, mm, ss);
	printf("[airp] Update duration: [%s]\n", dur);
	airdpsSetServiceTableVar(DMR_AVT_CURRENTTRACKDURATION, dur);
}

static THREAD_RETVAL
airp_player_thread(void *arg)
{
	MID_DISP_MediaSetSource(INPUT_TYPE_MEDIA);
	Airp_Play_param_t* param = (Airp_Play_param_t*) arg;
	
	do {
		if(!param->url || (strncmp(param->url, "http", 4) != 0 && strncmp(param->url, "file://", 7) != 0)) {
			/* Some APPs, e.g. Netflix and YouTube, use non-HTTP protocols, which we do not support.
			   Try to stop and re-run server again with "Airplay_Start(AIRPLAY_SUPPORT_MIRROR)" to force APP to run in mirror mode. */
			printf("[airp] invalid URL [%s]\n", param->url);
			al_callback(AIRPLAY_AV_EVENT_NOT_HTTP, 0);
			break;
		}
		
		playerState = AIRP_PLAYER_INITIALIZING;
		reloadTime = 0;

		if(runav_init(param->url, RUNAV_AIRPLAY_STREAMING, runav_event_handler) != 0) {
			printf("[airp] runav init - FAILED\n");
			break;
		}
		else if(!isVideoSupported) {
			printf("[airp] Video not supported.\n");
			break;
		}

		playerState = AIRP_PLAYER_READY;
		printf("[airp] runav init - OK\n");
		if(isRunavRunning) {
			runav_play();
			playerState = AIRP_PLAYER_PLAYING;
		}
		else {
			printf("[airp] abort runav\n");
			break;
		}

		if(isRunavRunning && seekPositionMs != 0)
		{
			printf("[airp] Seek to position = %u ms\n", seekPositionMs);
			airp_player_set_position(seekPositionMs / 1000);
			seekPositionMs = 0;
		}
		else if(isRunavRunning && fabs(param->start_pos - 0.0f) > EPSILON) // seek to start position
		{
			printf("[airp] Seek to start position %f\n", param->start_pos);
			float duration = airp_player_get_duration();
			airp_player_set_position(duration * param->start_pos);
		}
		else if(isRunavRunning)
		{
			update_position(0);
		}

		if(isRunavRunning) {
			al_callback(AIRPLAY_AV_EVENT_INITOK, 0);
			update_duration();
			airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PLAYING");
		}
		
		uint32_t cnt = 0;
		while(isRunavRunning) {
			update_position((int)airp_player_get_position());
			++cnt;
			if(reloadTime != 0 && cnt >= reloadTime) {
				airdpsSendEvent();
				cnt = 0;
			}
			else if(reloadTime==0 && targetDuration != 0 && cnt >= targetDuration) {
				airdpsSendEvent();
				cnt = 0;
			}
			pthread_mutex_lock(&mutex);
			struct timespec to;
			struct timeval now;
			gettimeofday(&now, NULL);
			to.tv_sec = now.tv_sec + 1;
			to.tv_nsec = now.tv_usec * 1000;
			pthread_cond_timedwait(&cond, &mutex, &to);
			pthread_mutex_unlock(&mutex);
		}

	} while(0);

	if(playerState != AIRP_PLAYER_STOPPED && playerState != AIRP_PLAYER_STOPPING) {
		printf("[airp] now exiting runav\n");
		runav_exit();
		al_callback(AIRPLAY_AV_EVENT_PLAY_DONE, 0);
		airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "STOPPED");
		playerState = AIRP_PLAYER_STOPPED;
		lastPosition = 0;
		lastDuration = 0;
	}

	isRunavRunning = false;

	if(param->url) free(param->url);
	if(param) free(param);
	return 0;
}

int airp_player_play(const char * url, float start_pos)
{
	if(runav_thread != 0)
	{
		printf("[airp] runav is already running\n");
		return -2;
	}
	isRunavRunning = true;
	printf("[airp] play URL=[%s], start position = %f\n", url, start_pos);

	t1_airp_destroy();

	isVideoSupported = true;

	airdpsSetServiceTableVar(DMR_AVT_RELATIVETIMEPOSITION, "00:00:00");
	airdpsSetServiceTableVar(DMR_AVT_CURRENTTRACKDURATION, "00:00:00");

	Airp_Play_param_t* param = (Airp_Play_param_t*) malloc(sizeof(Airp_Play_param_t));
	if(param)
	{
		param->url = strdup(url);
		param->start_pos = start_pos;
		THREAD_CREATE(runav_thread, airp_player_thread, (void*) param);
		return 0;
	}
	return -1;
}

void airp_player_stop(void)
{
	printf("[airp] stop\n");
	if(isRunavRunning)
	{
		playerState = AIRP_PLAYER_STOPPING;
		isRunavRunning = false;
		pthread_mutex_lock(&mutex);
		pthread_cond_signal(&cond);
		pthread_mutex_unlock(&mutex);
		runav_exit();
		playerState = AIRP_PLAYER_STOPPED;
		lastPosition = 0;
		lastDuration = 0;
		if(al_callback != NULL)
			al_callback(AIRPLAY_AV_EVENT_PLAY_DONE, 0);
	}
	airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "STOPPED");
	
	if(runav_thread != 0) {
		printf("[airp] stop: join thread\n");
		THREAD_JOIN(runav_thread);
		runav_thread = 0;
	}
	printf("[airp] stop: END\n");
}

void airp_player_set_rate(int rate)
{
	if(!isRunavRunning)
		return;
	if(rate == 0 && playerState == AIRP_PLAYER_PLAYING) {
		printf("[airp] pause\n");
		runav_pause();
		playerState = AIRP_PLAYER_PAUSED;
		airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PAUSED_PLAYBACK");
	}
	else if(rate == 1 && playerState == AIRP_PLAYER_PAUSED) {
		printf("[airp] play\n");
		runav_play();
		playerState = AIRP_PLAYER_PLAYING;
		airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PLAYING");
	}
	else {
		printf("[airp] invalid state %d\n", playerState);
	}
}

int airp_player_toggle_pause_play(void)
{
	if(!isRunavRunning)
		return -1;
	if(playerState == AIRP_PLAYER_PLAYING) {
		printf("[airp] pause\n");
		runav_pause();
		playerState = AIRP_PLAYER_PAUSED;	
		airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PAUSED_PLAYBACK");
		return 0;
	}
	else if(playerState == AIRP_PLAYER_PAUSED) {
		printf("[airp] play\n");
		runav_play();
		playerState = AIRP_PLAYER_PLAYING;
		airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PLAYING");
		return 0;
	}
	return -1;
}

void airp_player_set_callback(AirplayCbkFunc_t func)
{
	al_callback = func;
}

uint32_t airp_player_get_duration(void)
{
	if(isRunavRunning)
	{
		media_info_t info = {0};
		runav_getinfo(&info);
		lastDuration = (uint32_t)info.duration;
	}
	return lastDuration;
}

uint32_t airp_player_get_position(void)
{
	if(isRunavRunning && !isSeeking)
	{
		unsigned int position = 0;
		if(runav_getCurrentTime(&position) == 0) {
			lastPosition = position / 1000; // convert from milliseconds to seconds
		}
	}
	return lastPosition;
}

void airp_player_set_position(uint32_t position)
{
	printf("[airp] seek to %d sec, state = %d\n", position, playerState);
	if(playerState >= AIRP_PLAYER_READY)
	{
		isSeeking = true;
		if(position < lastPosition) {
			lastPosition = position;
			update_position(position);
		}
		runav_seek(position * 1000, 1);
		while(isSeeking && isRunavRunning) {
			usleep(100000);
		}
	}
	else if(position != 0 )
	{
		isSeeking = true;
		if(position < lastPosition) {
			lastPosition = position;
			update_position(position);
		}
		seekPositionMs = (uint32_t)(position * 1000);
	}
}

void airp_player_set_m3u8_target_duration(uint32_t duration)
{
	targetDuration = duration;
}

Airp_Player_State_t airp_player_get_player_state(void)
{
	return playerState;
}


