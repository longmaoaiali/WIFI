#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <net/if.h>

#include "airplay.h"
#include "netsetting_if.h"
#include "airp_player.h"
#include "t1_format.h"
#include "dpswrape.h"
#include "runav.h"
#include "runav_link.h"
#include "threads.h"
#include "dpswrape.h"
#include "../../../../../cvte_build/include/global_CVT_DEF_MIRACAST_MODEL_NAME.h"
#include "../../../../../cvte_build/include/global_CVT_EN_MIRCAST_RESOLUTION_1080P.h"



//#define DEFAULT_NAME "RDAServer"
#define DEFAULT_NAME CVT_DEF_MIRACAST_MODEL_NAME

#define MAC_SIZE 6
#define IGNORE_QQ_URL

#define LOCAL_MASTER_M3U8     "/tmp/master.m3u8"
#define LOCAL_VIDEO_M3U8      "/tmp/video.m3u8"
#define LOCAL_AUDIO_M3U8      "/tmp/audio.m3u8"
#define LOCAL_MASTER_M3U8_URI "file:/" LOCAL_MASTER_M3U8
#define LOCAL_VIDEO_M3U8_URI  "file:/" LOCAL_VIDEO_M3U8
#define LOCAL_AUDIO_M3U8_URI  "file:/" LOCAL_AUDIO_M3U8

#define MASTER_M3U8_CONTENT "#EXTM3U\n" \
"#EXT-X-INDEPENDENT-SEGMENTS\n" \
"#EXT-X-MEDIA:URI=\"file://tmp/audio.m3u8\",TYPE=AUDIO,GROUP-ID=\"234\",DEFAULT=YES,AUTOSELECT=YES,NAME=\"Default\"\n" \
"#EXT-X-STREAM-INF:BANDWIDTH=1568726,CODECS=\"avc1.4d401f,mp4a.40.2\",AUDIO=\"234\",FRAME-RATE=30,CLOSED-CAPTIONS=NONE\n" \
"file://tmp/video.m3u8\n"

typedef enum {
	AIRP_AUDIO_TYPE_NONE = 0,
	AIRP_AUDIO_TYPE_AAC,
	AIRP_AUDIO_TYPE_ALAC,
} AirplayAudioType_e;
typedef enum {
	AIRP_PLAY_TYPE_UNKNOWN = 0,
	AIRP_PLAY_TYPE_PLAY = 1,
	AIRP_PLAY_TYPE_PLAYLIST_INSERT = 2,
} AirplayPlayType_e;

typedef enum {
	AIRP_STOP_TYPE_ALL = 0,
	AIRP_STOP_TYPE_URL = 1,
	AIRP_STOP_TYPE_PLAYLIST_REMOVE = 2,
	AIRP_STOP_TYPE_MIRROR_VIDEO = 110,
	AIRP_STOP_TYPE_MIRROR_AUDIO = 96,
} AirplayStopType_e;

typedef struct _Playlist {
	char *url;
	struct _Playlist *next;
} Playlist_t;

typedef struct {
	pthread_t initThread;
	bool initThreadValid;
	bool initThreadRunning;
	bool inited;

	int socket_fd;
	bool has_video;
	bool has_audio;
	AirplayAudioType_e audio_type;
	bool has_url;
	bool audio_m3u8_ready;
	bool video_m3u8_ready;
	uint32_t audio_m3u8_sequence;
	uint32_t video_m3u8_sequence;
	uint32_t audio_m3u8_len;
	uint32_t video_m3u8_len;
	float start_position;
	uint32_t target_duration;
	Playlist_t *playlist;

	mutex_handle_t actionMutex;

	/* These variables only edited mutex locked */
	char *coverart;
	int coverart_len;
	Airplay_Audio_MetaData_t metadata;
	mutex_handle_t metadataMutex;
#ifdef IGNORE_QQ_URL
    char* ignoreURL;
#endif

} AirplayServer_t;

static AirplayServer_t *airp = NULL;
static AirplayCbkFunc_t airp_cbk = NULL;


static int isNetworkConnected()
{
	int ret = 0;
	const char* iface[] =
	{
#ifdef CONFIG_SUPPORT_ETHERNET
		"eth0",
#endif
#ifdef CONFIG_SUPPORT_WIFI
		"wlan0",
#endif
	};
	int fd = socket( AF_INET, SOCK_DGRAM, 0 );
	if(fd != -1)
	{
		unsigned int i;
		for(i = 0; i < sizeof(iface)/sizeof(const char*); ++i)
		{
			struct ifreq ifr;
			memset(&ifr, 0, sizeof(ifr) );
			strcpy(ifr.ifr_name, iface[i] );
			ifr.ifr_addr.sa_family = AF_INET;

			if( ioctl(fd, SIOCGIFFLAGS, &ifr) != -1 )
			{
				int up_and_running = (ifr.ifr_flags & ( IFF_UP | IFF_RUNNING )) == ( IFF_UP | IFF_RUNNING );
				if(up_and_running)
				{
					if( ioctl(fd, SIOCGIFADDR, &ifr) != -1 )
					{
						printf("IP address of %s - %s\n" , iface[i] , inet_ntoa(( (struct sockaddr_in *)&ifr.ifr_addr )->sin_addr) );
						ret = 1;
						break;
					}
				}
				else
				{
					printf("%s is not up-and-runnung!\n", iface[i]);
				}
			}
		}
		close(fd);
	}
	return ret;
}


static int isMdnsdRunning()
{
	int ret = 0;
	FILE *fp = popen("ps", "r");
	if(fp) {
		char buf[1024];
		while(fgets(buf, sizeof(buf), fp) != NULL) {
			if(strstr(buf, "/sbin/mdnsd") != NULL) {
				ret = 1;
				break;
			}
		}
		pclose(fp);
	}
	return ret;
}

static bool find_mac(char *server_hw_addr)
{
	MID_NWSI_MAC_Addr_t mac_address;
	int result;
	printf("server_hw_addr before addr=%x:%x:%x:%x:%x:%x \n",server_hw_addr[0],server_hw_addr[1],server_hw_addr[2],server_hw_addr[3],server_hw_addr[4],server_hw_addr[5]);
	printf("mac_address before addr=%x:%x:%x:%x:%x:%x \n",mac_address.A,mac_address.B,mac_address.C,mac_address.D,mac_address.E,mac_address.F);
#ifdef CONFIG_SUPPORT_ETHERNET
	result = MID_NWSI_GetMAC(E_MID_NWSI_CONNECT_TYPE_ETHERNET,&mac_address);
#else
	result = MID_NWSI_GetMAC(E_MID_NWSI_CONNECT_TYPE_WIRELESS,&mac_address);
#endif
	printf("mac_address after addr=%x:%x:%x:%x:%x:%x \n",mac_address.A,mac_address.B,mac_address.C,mac_address.D,mac_address.E,mac_address.F);
	if(result==S_OK)
	{
		memset(server_hw_addr, 0, sizeof(MID_NWSI_MAC_Addr_t));
		memcpy(server_hw_addr,&mac_address,sizeof(MID_NWSI_MAC_Addr_t));
		printf("server_hw_addr after addr=%x:%x:%x:%x:%x:%x \n",server_hw_addr[0],server_hw_addr[1],server_hw_addr[2],server_hw_addr[3],server_hw_addr[4],server_hw_addr[5]);
	}
	return result;
}

static inline void readString(MetaData_String_t *outString, const unsigned char *buf, int offset, int byteLen)
{
	outString->size = byteLen;
	memcpy(outString->data, buf + offset, byteLen);
}

static inline UINT16 readUINT16BE(const unsigned char *buf, int offset)
{
	return (buf[offset] << 8) + buf[offset+1];
}

static inline UINT32 readUINT32BE(const unsigned char *buf, int offset)
{
	return (buf[offset] << 24) + (buf[offset+1] << 16) + (buf[offset+2] << 8) + buf[offset+3];
}

static void audio_set_metadata(const void *buffer, int buflen) {
	const unsigned char *p = buffer;
	char key[5] = {0};
	int i = 8;

	if(!airp) return;

	MUTEX_LOCK(airp->metadataMutex);

	memset(&airp->metadata, 0, sizeof(Airplay_Audio_MetaData_t));

	while(i < buflen) {
		memcpy(key, p+i, 4);
		uint32_t size = readUINT32BE(p, i + 4);
		uint32_t outSize = size < METADATA_STRING_LEN ? size : METADATA_STRING_LEN;
		i += 8;

		if(strncmp(key, "minm", 4) == 0)
		{
			readString(&airp->metadata.songName, p, i, outSize);
		}
		else if(strncmp(key, "asaa", 4) == 0)
		{
			readString(&airp->metadata.songAlbumArtist, p, i, outSize);
		}
		else if(strncmp(key, "asar", 4) == 0)
		{
			readString(&airp->metadata.songArtist, p, i, outSize);
		}
		else if(strncmp(key, "asal", 4) == 0)
		{
			readString(&airp->metadata.songAlbum, p, i, outSize);
		}
		else if(strncmp(key, "ascp", 4) == 0)
		{
			readString(&airp->metadata.songComposer, p, i, outSize);
		}
		else if(strncmp(key, "asgn", 4) == 0)
		{
			readString(&airp->metadata.songGenre, p, i, outSize);
		}
		else if(strncmp(key, "astc", 4) == 0)
		{
			airp->metadata.songTrackCount = readUINT16BE(p, i);
		}
		else if(strncmp(key, "astn", 4) == 0)
		{
			airp->metadata.songTrackNumber = readUINT16BE(p, i);
		}
		else if(strncmp(key, "astm", 4) == 0)
		{
			airp->metadata.totalTime = readUINT32BE(p, i);
		}
		else if(strncmp(key, "asst", 4) == 0)
		{
			airp->metadata.startTime = readUINT32BE(p, i);
		}
		else if(strncmp(key, "asyr", 4) == 0)
		{
			airp->metadata.songYear = readUINT16BE(p, i);
		}
		i += size;
	}

	MUTEX_UNLOCK(airp->metadataMutex);

	if(airp_cbk)
	{
		airp_cbk(AIRPLAY_AV_EVENT_SET_METADATA, 0);
	}
}

static void empty_playlist(void)
{
	if(!airp) return;
	Playlist_t *list = airp->playlist;
	while(list) {
		Playlist_t *next = list->next;
		if(list->url) free(list->url);
		free(list);
		list = next;
	}
	airp->playlist = NULL;
}

static void insert_playlist(const char *url)
{
	if(!url || !airp)
		return;

	Playlist_t *node = (Playlist_t*) malloc(sizeof(Playlist_t));
	if(!node) {
		printf("[airp] %s: OOM.\n", __func__);
		return;
	}
	node->url = strdup(url);
	if(!node->url) {
		printf("[airp] %s: failed to copy URL.\n", __func__);
		free(node);
		return;
	}
	node->next = NULL;

	if(!airp->playlist) {
		airp->playlist = node;
	}
	else {
		Playlist_t *p = airp->playlist;
		while(p->next)
			p = p->next;
		p->next = node;
	}
}

static char *dequeue_playlist(void)
{
	char *url = NULL;
	Playlist_t *p = airp->playlist;
	if(p) {
		airp->playlist = p->next;
		url = p->url;
		free(p);
	}
	return url;
}
static void audio_set_coverart(const void *buffer, int buflen)
{
	if(!airp) return;

	MUTEX_LOCK(airp->metadataMutex);

	if(airp->coverart)
	{
		free(airp->coverart);
		airp->coverart = NULL;
		airp->coverart_len = 0;
	}

	if(buffer && buflen)
	{
		airp->coverart = (char*) malloc(buflen);
		if(airp->coverart)
		{
			airp->coverart_len = buflen;
			memcpy(airp->coverart, buffer, buflen);
		}
	}

	MUTEX_UNLOCK(airp->metadataMutex);

	if(airp_cbk)
	{
		airp_cbk(AIRPLAY_AV_EVENT_SET_COVERART, 0);
	}
}

static int airp_write_video(unsigned char *src_buf, unsigned int size, unsigned long long pts, int frametype)
{
	if(frametype == 0)
		t1_airp_write_video_codec(src_buf, (int)size, pts);
	else if(frametype == 1)
		t1_airp_write_video_bitstream(src_buf, (int)size, pts);
	return 0;
}

static int airp_write_audio(unsigned char *src_buf, unsigned int size, unsigned long long pts, int not_used)
{
	t1_airp_write_audio(src_buf, (int)size, pts);
	return 0;
}

static int write_playlist(const char *data, int len, const char *path)
{
	FILE *fp = fopen(path, "w");
	if(!fp) {
		printf("Failed to open '%s'\n", path);
		return -1;
	}
	fwrite(data, 1, len, fp);
	fclose(fp);
	return 0;
}

static uint32_t parse_target_duration(const char *data)
{
	uint32_t dur = 0;
	if(strstr(data, "#EXT-X-ENDLIST") != NULL)
		return 0;

	const char *p = strstr(data, "#EXT-X-TARGETDURATION:");
	if(p) {
		p += strlen("#EXT-X-TARGETDURATION:");
		sscanf(p, "%u", &dur);
	}
	return dur;
}

static uint32_t parse_media_sequence(const char *data)
{
	uint32_t seq = 0;
	const char *p = strstr(data, "#EXT-X-MEDIA-SEQUENCE:");
	if(p) {
		p += strlen("#EXT-X-MEDIA-SEQUENCE:");
		sscanf(p, "%u", &seq);
	}
	return seq;
}

static void cleanup_t1_player()
{
	printf("%s: has_video = %d, has_audio = %d\n", __func__, airp->has_video, airp->has_audio);
	if(airp->has_audio || airp->has_video) {
		t1_airp_destroy();
		runav_link_has_audio(0);
		airp->has_video = airp->has_audio = false;
		airp->audio_type = AIRP_AUDIO_TYPE_NONE;
	}
}

static void cleanup_airp_player()
{
	printf("%s: has_url = %d\n", __func__, airp->has_url);
	if(airp->has_url) {
		airp_player_stop();
		airp->has_url = false;
		empty_playlist();
		airp->audio_m3u8_ready = airp->video_m3u8_ready = false;
		airp->audio_m3u8_sequence = airp->video_m3u8_sequence = 0;
		airp->audio_m3u8_len = airp->video_m3u8_len = 0;
		remove(LOCAL_MASTER_M3U8);
		remove(LOCAL_AUDIO_M3U8);
		remove(LOCAL_VIDEO_M3U8);
	}
}

static int airdpsActionHandle(int Action, int NumArg, const char *Arg, ...)
{
	fprintf(stderr, "%s: Action = %d, NumArg = %d\n", __func__, Action, NumArg);
	MUTEX_LOCK(airp->actionMutex);
	fprintf(stderr, "%s: Action = %d, acquire lock\n", __func__, Action);

	va_list ArgList;
	va_start(ArgList, Arg);
	const char *ArgName[10] = {0};
	const char *ArgValue[10] = {0};
	int Idx = 0;

	while(Idx < NumArg) {
		ArgName[Idx]  = (Idx == 0 ? Arg : va_arg(ArgList, const char *));
		ArgValue[Idx] = va_arg(ArgList, const char *);
		printf("Arg[%d] name = [%s], value = [%.*s]\n", Idx, ArgName[Idx], 100, ArgValue[Idx]);
		Idx++;
	}

	switch(Action) {
		case DMR_ACTION_AVT_PAUSE: {
			// Pause();
			if(airp->has_url) {
				airp_player_set_rate(0);
				airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PAUSED_PLAYBACK");
			}
			break;
		}
		case DMR_ACTION_AVT_PLAY: {
			// Resume();
			if(airp->has_url) {
				airp_player_set_rate(1);
				airdpsSetServiceTableVar(DMR_AVT_TRANSPORTSTATE, "PLAYING");
			}
			break;
		}
		case DMR_ACTION_AVT_SEEK: {
			uint32_t hh = 0, mm = 0, ss = 0;
			if(sscanf(ArgValue[1], "%u:%u:%u", &hh, &mm, &ss) == 3) {
				airp_player_set_position(hh * 3600 + mm * 60 + ss);
			}
			break;
		}
		case DMR_ACTION_AVT_SETAVTRANSPORTURI: {
			printf("DMR_ACTION_AVT_SETAVTRANSPORTURI: ArgValue[1] = [%s]\n", ArgValue[1]);
			//ArgValue[2]	socket_fd:AirPlay链接ID		//保存当前ID
			// if (g_socket_fd)
				// airdpsDisconnectClient(g_socket_fd); //连续投屏时，主动断开上次链接

			//if ArgValue[1]	"object.item.raopMirror":镜像
			//if ArgValue[1]	"object.item.raopalac":音乐
			//if ArgValue[1]	"object.item.airplayVideoItem":URL
				//ArgValue[0] url
				// Play(url);

			float start_position = 0.0f;
			AirplayPlayType_e url_type = AIRP_PLAY_TYPE_UNKNOWN;
			int i;
			for(i = 0; i < NumArg; ++i) {
				if(!ArgName[i]) continue;
				if(strcmp(ArgName[i], "Position") == 0) {
					if(ArgValue[i])
						start_position = atof(ArgValue[i]);
				}
				else if(strcmp(ArgName[i], "instanceid") == 0) {
					int socket_fd = atoi(ArgValue[i]);
					if(socket_fd != 0 && socket_fd != airp->socket_fd) {
						// close previous session
						if(airp->socket_fd != -1) {
							MUTEX_UNLOCK(airp->actionMutex);
							airdpsDisconnectClient(airp->socket_fd);
							MUTEX_LOCK(airp->actionMutex);
							cleanup_t1_player();
							cleanup_airp_player();
						}
						airp->socket_fd = socket_fd;
					}
				}
				else if(strcmp(ArgName[i], "Urltpye") == 0) {
					if(ArgValue[i])
						url_type = strtoul(ArgValue[i], NULL, 10);
				}
			}

			if(strstr(ArgValue[1], "object.item.raopMirror")) {
				cleanup_airp_player();
				if(airp->has_audio) // need to restart runav when switching from audio-only to A+V
					t1_airp_destroy();
				t1_airp_init();
				airp->has_video = true;
			}
			else if(strstr(ArgValue[1], "object.item.raopalac")) {
				cleanup_airp_player();
				t1_airp_init_ex(T1_AIRP_INIT_AUDIO_ONLY);
				airp->audio_type = AIRP_AUDIO_TYPE_ALAC;
				airp->has_audio = true;
				runav_link_has_audio(1);
			}
			else if(strstr(ArgValue[1], "object.item.raopaac")) {
				cleanup_airp_player();
				t1_airp_init();
				airp->has_audio = true;
				airp->audio_type = AIRP_AUDIO_TYPE_AAC;
				runav_link_has_audio(1);
			}
			else if(strstr(ArgValue[1], "object.item.airplayVideoItem")) {			
           #ifdef IGNORE_QQ_URL
				if(strncmp(ArgValue[0], "RTDATA://", 9) == 0) {
					if(airp->ignoreURL) {
						free(airp->ignoreURL);
						airp->ignoreURL = 0;
					}
					airp->ignoreURL = strdup(ArgValue[0] + strlen("RTDATA://"));
					printf("QQ URL = [%s]\n", airp->ignoreURL);
					break;
				}
           #endif
				if(strncmp(ArgValue[0], "http://", 7) != 0 && strncmp(ArgValue[0], "https://", 8) != 0) {
					printf("Unknown URL type: [%s]\n", ArgValue[0]);
					break;
				}
			
          #ifdef IGNORE_QQ_URL
				char *p = strstr(ArgValue[0], "://");
				if(p) {
					p += 3;
					if((strncmp(p, "uqmv.music.tc.qq.com", strlen("uqmv.music.tc.qq.com")) == 0)
						|| (airp->ignoreURL && strcmp(p, airp->ignoreURL) == 0)) {
						printf("Ignore QQ music URL!\n");
						break;
					}
				}
          #endif
				//if(airp->has_video || airp->has_audio) {
				if(airp->has_audio && airp->audio_type == AIRP_AUDIO_TYPE_AAC) {
					printf("Ignore URL in mirroring mode: [%s]\n", ArgValue[0]);
					break;
				}
				cleanup_t1_player();
				if(airp->has_url && url_type == AIRP_PLAY_TYPE_PLAYLIST_INSERT) {
					printf("playlist insert url [%s]\n", ArgValue[0]);
					insert_playlist(ArgValue[0]);
					break;
				}
				cleanup_airp_player();
				airp->start_position = start_position;
				airp_player_play(ArgValue[0], airp->start_position);
				airp->has_url = true;
			}
			else if(strcmp(ArgValue[1], "object.item.airplayYouTubeMasterItem") == 0) {
				cleanup_airp_player();
				airp->start_position = start_position;
				write_playlist(MASTER_M3U8_CONTENT, strlen(MASTER_M3U8_CONTENT), LOCAL_MASTER_M3U8);
			}
			else if(strcmp(ArgValue[1], "object.item.airplayYouTubeAudioItem") == 0) {
				uint32_t len = strtoul(ArgValue[3], NULL, 10);
				if(!len) break;
				uint32_t seq = parse_media_sequence(ArgValue[0]);
				if(seq != 0 && seq == airp->audio_m3u8_sequence && len == airp->audio_m3u8_len)
					break;
				airp->audio_m3u8_sequence = seq;
				airp->audio_m3u8_len = len;

				uint32_t dur = parse_target_duration(ArgValue[0]);
				if(airp->target_duration == 0 || dur < airp->target_duration)
					airp->target_duration = dur;

				printf("%s: %d: seq = %u. Lock audio.m3u8\n", __func__, __LINE__, seq);
				runav_locking_YT_m3u8_file();
				printf("%s: %d: acquire lock\n", __func__, __LINE__);
				write_playlist(ArgValue[0], len, LOCAL_AUDIO_M3U8);
				runav_unlocking_YT_m3u8_file();
				printf("%s: %d: release lock\n", __func__, __LINE__);

				if(!airp->audio_m3u8_ready) {
					airp->audio_m3u8_ready = true;
					if(airp->video_m3u8_ready) {
						cleanup_t1_player();
						airp_player_stop();
						airp_player_set_m3u8_target_duration(airp->target_duration);
						airp_player_play(LOCAL_MASTER_M3U8_URI, airp->start_position);
						airp->has_url = true;
					}
				}
			}
			else if(strcmp(ArgValue[1], "object.item.airplayYouTubeVideoItem") == 0) {
				uint32_t len = strtoul(ArgValue[3], NULL, 10);
				if(!len) break;
				uint32_t seq = parse_media_sequence(ArgValue[0]);
				if(seq != 0 && seq == airp->video_m3u8_sequence && len == airp->video_m3u8_len)
					break;
				airp->video_m3u8_sequence = seq;
				airp->video_m3u8_len = len;

				uint32_t dur = parse_target_duration(ArgValue[0]);
				if(airp->target_duration == 0 || dur < airp->target_duration)
					airp->target_duration = dur;

				printf("%s: %d: seq = %u. Lock video.m3u8\n", __func__, __LINE__, seq);
				runav_locking_YT_m3u8_file();
				printf("%s: %d: acquire lock\n", __func__, __LINE__);
				write_playlist(ArgValue[0], len, LOCAL_VIDEO_M3U8);
				runav_unlocking_YT_m3u8_file();
				printf("%s: %d: release lock\n", __func__, __LINE__);

				if(!airp->video_m3u8_ready) {
					airp->video_m3u8_ready = true;
					if(airp->audio_m3u8_ready) {
						cleanup_t1_player();
						airp_player_stop();
						airp_player_set_m3u8_target_duration(airp->target_duration);
						airp_player_play(LOCAL_MASTER_M3U8_URI, airp->start_position);
						airp->has_url = true;
					}
				}
			}

			break;
		}
		case DMR_ACTION_AVT_STOP: {
			printf("DMR_ACTION_AVT_STOP: type = [%s]\n", ArgValue[0]);
			AirplayStopType_e stop_type = atoi(ArgValue[0]);
			
			if(stop_type == AIRP_STOP_TYPE_MIRROR_VIDEO) {
				airp->has_video = false;
				if(!airp->has_audio) {
					t1_airp_destroy();
				}
				else { // disable video while keeping audio, send SCREEN_OFF event
					t1_airp_set_screenlock(true);
				}
			}
			else if(stop_type == AIRP_STOP_TYPE_MIRROR_AUDIO) {
				airp->has_audio = false;
				airp->audio_type = AIRP_AUDIO_TYPE_NONE;
				runav_link_has_audio(0);
				if(!airp->has_video) {
					t1_airp_destroy();
				}
			}
			else if(stop_type == AIRP_STOP_TYPE_URL) {
				cleanup_airp_player();
			}
			else if(stop_type == AIRP_STOP_TYPE_PLAYLIST_REMOVE) {
				char *nextURL = dequeue_playlist();
				if(nextURL) {
					printf("Play next url in playlist [%s]\n", nextURL);
					cleanup_airp_player();
					airp_player_play(nextURL, 0);
					airp->has_url = true;

					free(nextURL);
				}
				else
					cleanup_airp_player();
			}
			else if(stop_type == AIRP_STOP_TYPE_ALL) {
				cleanup_airp_player();
				cleanup_t1_player();
			}
			break;
		}
		case DMR_ACTION_RCS_SETMUTE: {
			//ArgValue[0]	"1"/"0"
				// SetMute(ArgValue[0]);
			break;
		}
		case DMR_ACTION_RCS_SETVOLUME: {
			//ArgValue[0]	"0"-"100"
				// SetVolume(ArgValue[0]);
			break;
		}
		case DMR_ACTION_AIR_PROGRESS: {		//可选
			//ArgValue[0]	"start/curr/end"
			// unsigned int position = (curr - start)/44100;	//秒
			// unsigned int duration = (end - start)/44100;	//秒
			break;
		}
		case DMR_ACTION_AIR_COVERART: {		//可选
			//ArgValue[0]	data
			//ArgValue[1]	data length
			// 保存成jpeg图片显示
			int buflen = atoi(ArgValue[1]);
			if(buflen) {
				audio_set_coverart(ArgValue[0], buflen);
			}
			break;
		}
		case DMR_ACTION_AIR_METADATA: {		//可选
			//ArgValue[0]	DMAP data
			//ArgValue[1]	data length
			// 解析DMAP数据得到歌曲名、作者、歌词显示
			int buflen = atoi(ArgValue[1]);
			if(buflen) {
				audio_set_metadata(ArgValue[0], buflen);
			}
			break;
		}
		case DMR_ACTION_AIR_FEEDBACK: {
			break;
		}
		default:
			break;
	}
	va_end(ArgList);

	fprintf(stderr, "%s: Action = %d, release lock\n", __func__, Action);
	MUTEX_UNLOCK(airp->actionMutex);

	return 0;
}


static void* AirplayInitTask(void *arg)
{
	while(airp->initThreadRunning)
	{
		if(isNetworkConnected() && isMdnsdRunning())
			break;
		sleep(1);
	}
	if(!airp->initThreadRunning) // thread is canceled
	{
		pthread_exit(NULL);
	}

	char server_hw_addr[MAC_SIZE]={0};
	char ServerName[20] = {0};
	find_mac(server_hw_addr);
	#ifdef CONFIG_FM_PROJECTOR
	snprintf(ServerName, sizeof(ServerName), "%s", DEFAULT_NAME);
	#else
	snprintf(ServerName, sizeof(ServerName), "%s-%02hhx%02hhx", DEFAULT_NAME, server_hw_addr[4], server_hw_addr[5]);
	#endif

	airdpsServerSetMirrorCallBack(airp_write_video);
	airdpsServerSetAudioCallBack(airp_write_audio);
	airdpsSetActionCallBack(airdpsActionHandle);
	#if CVT_EN_MIRCAST_RESOLUTION_1080P
	airdpsSetPixels(1920, 1080);
	#else
    airdpsSetPixels(1280, 720);
	#endif
	airdpsStart(ServerName);

	airp->inited = true;
	pthread_exit(NULL);
}

Airplay_Status_e Airplay_Start(uint32_t capability)
{
	if(airp)
	{
		printf("Airplay is already running.\n");
		return AIRPLAY_ERR_BAD_STATE;
	}

	if(capability == 0) // 'capability' is for API backward compatibility - it is not used now
	{
		return AIRPLAY_ERR_BAD_PARAM;
	}

	if(!airp)
	{
		airp = (AirplayServer_t *) calloc(1, sizeof(AirplayServer_t));
		if(!airp) return AIRPLAY_ERR_OOM;
	}

	if(!airp->initThreadValid)
	{
		airp->initThreadRunning = true;
		airp->initThreadValid = (pthread_create(&airp->initThread, NULL, AirplayInitTask, NULL) == 0);
		airp->initThreadRunning = airp->initThreadValid;
		airp->socket_fd = -1;
		airp->has_video = false;
		airp->has_audio = false;
		airp->has_url = false;
		MUTEX_CREATE(airp->metadataMutex);
		MUTEX_CREATE(airp->actionMutex);
	}
	else
	{
		printf("Airplay is being initialized.");
		return AIRPLAY_ERR_BAD_STATE;
	}

	return AIRPLAY_SUCCESS;
}

Airplay_Status_e Airplay_Stop(void)
{
	if(airp)
	{

		if(airp->initThreadValid)
		{
			airp->initThreadRunning = false;
			pthread_join(airp->initThread, NULL);
			airp->initThreadValid = false;
		}

		if(airp->inited) {
			airdpsStop();
			cleanup_t1_player();
			cleanup_airp_player();
		}

		airp->inited = false;
		if(airp->coverart)
		{
			free(airp->coverart);
			airp->coverart = NULL;
			airp->coverart_len = 0;
		}
		MUTEX_DESTROY(airp->metadataMutex);
		MUTEX_DESTROY(airp->actionMutex);

     #ifdef IGNORE_QQ_URL
		if(airp->ignoreURL) {
			free(airp->ignoreURL);
			airp->ignoreURL = NULL;
		}
     #endif

		free(airp);
		airp = NULL;
		return AIRPLAY_SUCCESS;
	}
	return AIRPLAY_ERR_BAD_STATE;
}

Airplay_Status_e Airplay_GetAudioMetadata(Airplay_Audio_MetaData_t * metadata)
{
	if(!airp || !metadata)
		return AIRPLAY_ERR_BAD_PARAM;

	MUTEX_LOCK(airp->metadataMutex);
	memcpy(metadata, &airp->metadata, sizeof(Airplay_Audio_MetaData_t));
	MUTEX_UNLOCK(airp->metadataMutex);

	return AIRPLAY_SUCCESS;
}

Airplay_Status_e Airplay_GetAudioCoverArt(Airplay_Audio_CoverArt_t * coverart)
{
	if(!airp || !airp->coverart || !airp->coverart_len)
		return AIRPLAY_ERR_NO_RESOURCE;
	if(!coverart)
		return AIRPLAY_ERR_BAD_PARAM;

	MUTEX_LOCK(airp->metadataMutex);

	coverart->data = (char*) malloc(airp->coverart_len);
	if(!coverart->data)
	{
		MUTEX_UNLOCK(airp->metadataMutex);
		return AIRPLAY_ERR_OOM;
	}
	coverart->size = airp->coverart_len;

	MUTEX_UNLOCK(airp->metadataMutex);

	return AIRPLAY_SUCCESS;
}

Airplay_Status_e Airplay_FreeAudioCoverArt(Airplay_Audio_CoverArt_t * coverart)
{
	if(!coverart)
		return AIRPLAY_ERR_BAD_PARAM;

	if(coverart->data)
		free(coverart->data);

	return AIRPLAY_SUCCESS;
}

Airplay_Status_e Airplay_Ctrl_PausePlay(void)
{
	if(airp_player_toggle_pause_play() == 0)
		return AIRPLAY_SUCCESS;
	return AIRPLAY_ERR_BAD_STATE;
}


static bool callbackDispatcher(Airplay_Event_t event, int param)
{
	switch(event) {
	default:
		break;
	}
	if(airp_cbk)
		airp_cbk(event, param);
	return true;
}

void Airplay_RegisterCBKFunc(AirplayCbkFunc_t func)
{
	t1_airp_set_callback(callbackDispatcher);
	airp_player_set_callback(callbackDispatcher);
	airp_cbk = func;
}

AirplayCbkFunc_t Airplay_GetRegisteredCBKFunc(void)
{
	return airp_cbk;
}

bool Airplay_Is_AudioOnly(void)
{
	if(airp)
	{
		if(airp->has_audio &&  !airp->has_video)
			return TRUE;
	}
	return FALSE;
}

Airp_Player_State_t Airplay_Get_PlayerState(void)
{
	return airp_player_get_player_state();
}


