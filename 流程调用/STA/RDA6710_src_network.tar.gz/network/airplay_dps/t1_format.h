#ifndef _T1_FORMAT_H
#define _T1_FORMAT_H

#include "airplay.h"

enum {
	T1_AIRP_INIT_AUDIO_ONLY = 0x1,
};

void t1_airp_init(void);

void t1_airp_init_ex(uint32_t flag);

void t1_airp_destroy(void);

int t1_airp_write_video_codec(unsigned char *src_buf, int size, uint64_t pts);

int t1_airp_write_video_bitstream(unsigned char *src_buf, int size, uint64_t pts);

int t1_airp_write_audio(unsigned char *src_buf, int size, uint64_t pts);

void t1_airp_set_volume(float);

void t1_airp_set_callback(AirplayCbkFunc_t);

AirplayCbkFunc_t t1_airp_get_callback(void);

void t1_airp_set_screenlock(bool);

#endif
