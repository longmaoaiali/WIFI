#ifndef _AIRP_PLAYER_H
#define _AIRP_PLAYER_H

#include "airplay.h"
#include <stdint.h>

int airp_player_play(const char * url, float start_pos);

void airp_player_set_rate(int rate);

int airp_player_get_rate(void);

void airp_player_stop(void);

uint32_t airp_player_get_duration(void);

uint32_t airp_player_get_position(void);

void airp_player_set_position(uint32_t position);

void airp_player_set_callback(AirplayCbkFunc_t);

void airp_player_set_m3u8_target_duration(uint32_t duration);

int airp_player_toggle_pause_play(void);
Airp_Player_State_t airp_player_get_player_state(void);

#endif
