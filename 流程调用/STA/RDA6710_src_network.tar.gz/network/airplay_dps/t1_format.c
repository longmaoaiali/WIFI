#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <runav.h>
#include "xpipe.h"
#include "threads.h"
#include "t1_format.h"
#include "airp_player.h"
#include "mid_dtv_display.h"
#include "runav_link.h"

#define MKTAG(a,b,c,d) (a | (b << 8) | (c << 16) | (d << 24))
#define T1_AIRPLAY_TAG          MKTAG('T', '1', 'F', 'M')
#define AIRP_VIDEO_TAG          MKTAG('V', 'I', 'D', 'E')
#define AIRP_AUDIO_TAG          MKTAG('A', 'U', 'D', 'I')
#define AIRP_VIDEO_INFO_TAG     MKTAG('V', 'I', 'F', 'O')
#define AIRP_AUDIO_INFO_TAG     MKTAG('A', 'I', 'F', 'O')
#define AIRP_VCODEC_TAG         MKTAG('V', 'C', 'O', 'D')
#define AIRP_ACODEC_TAG         MKTAG('A', 'C', 'O', 'D')
#define AIRP_VDATA_TAG          MKTAG('V', 'D', 'A', 'T')
#define AIRP_ADATA_TAG          MKTAG('A', 'D', 'A', 'T')
#define AIRP_CDATA_TAG          MKTAG('C', 'D', 'A', 'T')

typedef enum
{
	UNINITIALIZED,
	XPIPE_CREATED,
	RUNAV_INITIALIZING,
	RUNAV_READY,
	RUNAV_PLAYING
} RunavState;

typedef struct
{
	//video into
	unsigned int frate;
	//video codec
	unsigned int vcodec;
	//audio info
	unsigned int chn_cnt;
	unsigned int sample_rate;
	unsigned int sample_bits;
	//audio codec
	unsigned int acodec;
} t1aipr_header_info;


typedef struct {
	thread_handle_t runav_thread;
	BOOL video_unsupported;
	BOOL audio_unsupported;
	mutex_handle_t xpipe_mutex;
	RunavState state;
	bool audio_only;
	bool exitingThread;

	// codec data
	unsigned char * last_cdata;
	int last_cdata_size;
	bool screen_lock;
	mutex_handle_t cdata_mutex;
} t1_renderer_t;

static t1_renderer_t ucRunAv = {
	.cdata_mutex = PTHREAD_MUTEX_INITIALIZER,
	.xpipe_mutex = PTHREAD_MUTEX_INITIALIZER
};
static AirplayCbkFunc_t al_callback = NULL;

static void runav_event_handler(int event_id, void *arg)
{
	Airplay_Event_t event = AIRPLAY_EVENT_END;

	switch(event_id)
	{

	case RUNAV_EVENT_HEAD_OF_FILE:
		printf("[event] HOF\n");
		event = AIRPLAY_AV_EVENT_PLAY_DONE;
		break;

	case RUNAV_EVENT_OOM:
		printf("[event] OOM\n");
		break;

	case RUNAV_EVENT_EOF:
		printf("[event] EOF\n");
		t1_airp_destroy();
		//event = AIRPLAY_AV_EVENT_PLAY_DONE;
		break;

	case RUNAV_EVENT_VIDEO_UNSUPPORT:
		printf("[event] video unsupport\n");
		ucRunAv.video_unsupported = TRUE;
		break;

	case RUNAV_EVENT_AUDIO_UNSUPPORT:
		printf("[event] audio unsupport\n");
		ucRunAv.audio_unsupported = TRUE;
		break;

	case RUNAV_EVENT_INPROCESS:
		printf("[event] inprocess\n");
		event = AIRPLAY_AV_EVENT_DECODE_START;
		break;

	case RUNAV_EVENT_FINISH:
		printf("[event] init finish\n");
		ucRunAv.state = RUNAV_READY;
		event = AIRPLAY_AV_EVENT_INITOK;
		break;

	case RUNAV_EVENT_UNKNOWN_FORMAT:
		printf("[event] unknown format\n");
		break;

	case RUNAV_EVENT_FILE_NOT_EXIST:
		printf("[event] file not exist\n");
		break;

	case RUNAV_EVENT_STREAM_INFO:
		printf("[event] event stream info\n");
		break;

	case RUNAV_EVENT_BUFFERING_START:
		printf("[event] BUFFERING_START\n");
		break;

	case RUNAV_EVENT_BUFFERING_END:
		printf("[event] BUFFERING_END\n");
		break;
	}
	
	if(event != AIRPLAY_EVENT_END && al_callback != NULL)
	{
		al_callback(event, 0);
	}
}

static void airplay_runav_init(void)
{
	if(ucRunAv.state != RUNAV_INITIALIZING) {
		printf("%s: xpipe not yet created!\n", __func__);
		return;
	}

	ucRunAv.video_unsupported = FALSE;
	ucRunAv.audio_unsupported = FALSE;

	MID_DISP_MediaSetSource(INPUT_TYPE_MEDIA);
	unsigned int flag = RUNAV_AIRPLAY;
	if(ucRunAv.audio_only) flag |= RUNAV_VIDEO_DISABLE;
	if(!ucRunAv.exitingThread // make sure airplay_runav_exit() is not called prior to runav_init()
		&& runav_init("xpipe://", flag, runav_event_handler) == 0 && ucRunAv.state == RUNAV_READY) {
		if(!ucRunAv.exitingThread) {
			runav_play();
			ucRunAv.state = RUNAV_PLAYING;
		}
		else {
			printf("runav_init is aborted.\n");
		}
	}
}

static void airplay_runav_exit(void)
{
	printf("%s: state = %d\n", __func__, ucRunAv.state);
	ucRunAv.exitingThread = true;
	if(ucRunAv.state > XPIPE_CREATED) 
    {
		runav_exit();
		ucRunAv.state = XPIPE_CREATED;
		ucRunAv.video_unsupported = FALSE;
		ucRunAv.audio_unsupported = FALSE;
	}
}


static void t1_airp_put_tag(unsigned char *buf, unsigned int tag)
{
	buf[0]=tag&0xff;
	buf[1]=(tag>>8)&0xff;
	buf[2]=(tag>>16)&0xff;
	buf[3]=(tag>>24)&0xff;
	//buf+=4;
}

static void t1_airp_put_pts(unsigned char *buf, uint64_t pts)
{
	buf[7]=pts&0xff;
	buf[6]=(pts>>8)&0xff;
	buf[5]=(pts>>16)&0xff;
	buf[4]=(pts>>24)&0xff;
	buf[3]=(pts>>32)&0xff;
	buf[2]=(pts>>40)&0xff;
	buf[1]=(pts>>48)&0xff;
	buf[0]=(pts>>56)&0xff;
	//buf+=8;
}

static void t1_airp_put_size(unsigned char *buf, unsigned int tag_size)
{
	unsigned int *size = (unsigned int*) buf;
	unsigned int be_size=0;
	be_size = (tag_size&0xff)<<24|((tag_size>>8)&0xff)<<16|((tag_size>>16)&0xff)<<8|((tag_size>>24)&0xff);
	*size = be_size;
	//buf+=4;
}

static int t1_airp_write_header(unsigned char *buf, t1aipr_header_info *header_info)
{
	int header_size = 0;
	t1_airp_put_tag(buf, T1_AIRPLAY_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x4C);
	buf+=4;
	t1_airp_put_tag(buf, AIRP_VIDEO_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x18);
	buf+=4;

	t1_airp_put_tag(buf, AIRP_VIDEO_INFO_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x4);
	buf+=4;
	t1_airp_put_size(buf, 0x0);//stream_id
	buf+=4;

	t1_airp_put_tag(buf, AIRP_VCODEC_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x4);
	buf+=4;
	t1_airp_put_tag(buf, header_info->vcodec);
	buf+=4;

	t1_airp_put_tag(buf, AIRP_AUDIO_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x24);
	buf+=4;

	t1_airp_put_tag(buf, AIRP_AUDIO_INFO_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x10);
	buf+=4;
	t1_airp_put_size(buf, 0x1);//stream_id
	buf+=4;
	t1_airp_put_size(buf, header_info->sample_rate);//sample_rate
	buf+=4;
	t1_airp_put_size(buf, header_info->chn_cnt);
	buf+=4;
	t1_airp_put_size(buf, header_info->sample_bits);
	buf+=4;

	t1_airp_put_tag(buf, AIRP_ACODEC_TAG);
	buf+=4;
	t1_airp_put_size(buf, 0x4);
	buf+=4;
	t1_airp_put_tag(buf, header_info->acodec);
	buf+=4;
	header_size = 0x4C+8;
	return header_size;
}

static int xpipe_write_all(unsigned char *src_buf, int size)
{
	if(ucRunAv.state == UNINITIALIZED) {
		//printf("%s: xpipe not yet created\n", __func__);
		return 0;
	}

	int written = 0, remain = size;
	while(remain != 0 && ucRunAv.state >= XPIPE_CREATED) {
		written = xpipe_write(src_buf, remain);
		remain -= written;
		src_buf += written;
		if(remain != 0) {
			printf("xpipe: %d written, %d left\n", written, remain);
			usleep(10);
		}
	}
	
	if(remain != 0)
		printf("%s: abort with %d bytes left.\n", __func__, remain);

	return 0;
}

static void airplay_write_header(void)
{
	unsigned char buf[100] = {0};
	int header_size;
	t1aipr_header_info header_info;
	header_info.frate = 30;
	header_info.vcodec = MKTAG('H', '2', '6', '4');
	header_info.chn_cnt = 2;
	header_info.sample_rate = 44100;
	header_info.sample_bits = 16;
	header_info.acodec = MKTAG('P', 'C', 'M', '.');
	header_size = t1_airp_write_header(buf, &header_info);

	MUTEX_LOCK(ucRunAv.xpipe_mutex);
	
	xpipe_write_all(buf, header_size);
	
	MUTEX_UNLOCK(ucRunAv.xpipe_mutex);
}

static void toggle_screen_onoff(void)
{
	ucRunAv.screen_lock = !ucRunAv.screen_lock;
	if(ucRunAv.screen_lock && al_callback) {
	runav_link_screen_on(0);
		al_callback(AIRPLAY_AV_EVENT_SCREEN_OFF, 0);
	}
	else if(!ucRunAv.screen_lock && al_callback) {
        runav_link_screen_on(1);
		al_callback(AIRPLAY_AV_EVENT_SCREEN_ON, 0);
	}
}

void t1_airp_init(void)
{
	t1_airp_init_ex(0);
}

void t1_airp_init_ex(uint32_t flag)
{
	if(ucRunAv.state != UNINITIALIZED) {
		printf("%s: is already running\n", __func__);
		return;
	}

	airp_player_stop();

	if(xpipe_create(0x180000,0) == NULL) {
		printf("%s: failed to create xpipe\n", __func__);
		return;
	}
	ucRunAv.state = XPIPE_CREATED;
	airplay_write_header();

	ucRunAv.audio_only = ((flag & T1_AIRP_INIT_AUDIO_ONLY) != 0);

	// reset cdata counting
	MUTEX_LOCK(ucRunAv.cdata_mutex);
	ucRunAv.last_cdata = NULL;
	ucRunAv.last_cdata_size = 0;
	ucRunAv.screen_lock = false;
	MUTEX_UNLOCK(ucRunAv.cdata_mutex);

	ucRunAv.state = RUNAV_INITIALIZING;
	ucRunAv.exitingThread = false;
	THREAD_CREATE(ucRunAv.runav_thread,(void *)airplay_runav_init, NULL);

}

void t1_airp_destroy(void)
{
	if(ucRunAv.state == UNINITIALIZED) {
		printf("%s: is not running\n", __func__);
		return;
	}
	airplay_runav_exit();
	THREAD_JOIN(ucRunAv.runav_thread);
	xpipe_close();
	ucRunAv.state = UNINITIALIZED;

	// clear cdata counting
	MUTEX_LOCK(ucRunAv.cdata_mutex);
	if(ucRunAv.last_cdata) {
		free(ucRunAv.last_cdata);
		ucRunAv.last_cdata = NULL;
	}
	ucRunAv.last_cdata_size = 0;
	ucRunAv.screen_lock = false;
	MUTEX_UNLOCK(ucRunAv.cdata_mutex);

	if(al_callback)
		al_callback(AIRPLAY_AV_EVENT_PLAY_DONE, 0);
}

int t1_airp_write_video_bitstream(unsigned char *src_buf, int size, uint64_t pts)
{
	unsigned char buf[8] = {0};

	if(ucRunAv.screen_lock) {
		printf("Unlock screen after receiving video bitstream\n");
		toggle_screen_onoff();
	}

	MUTEX_LOCK(ucRunAv.xpipe_mutex);

	/* write TAG */
	t1_airp_put_tag(buf, AIRP_VDATA_TAG);
	t1_airp_put_size(buf + 4, size + 8);
	xpipe_write_all(buf, 8);

	/* write PTS */
	t1_airp_put_pts(buf, pts);
	xpipe_write_all(buf, 8);

	/* write video data */
	xpipe_write_all(src_buf, size);

	MUTEX_UNLOCK(ucRunAv.xpipe_mutex);
	return 0;
}

int t1_airp_write_video_codec(unsigned char *src_buf, int size, uint64_t pts)
{
	unsigned char buf[8] = {0};
	
	if(ucRunAv.state == UNINITIALIZED) {
		return 0;
	}

	MUTEX_LOCK(ucRunAv.xpipe_mutex);

	/* write TAG */
	t1_airp_put_tag(buf, AIRP_CDATA_TAG);
	t1_airp_put_size(buf + 4, size + 8);
	xpipe_write_all(buf, 8);

	/* write PTS */
	t1_airp_put_pts(buf, pts);
	xpipe_write_all(buf, 8);

	/* write codec data */
	xpipe_write_all(src_buf, size);

	MUTEX_UNLOCK(ucRunAv.xpipe_mutex);

	MUTEX_LOCK(ucRunAv.cdata_mutex);

	if(size == ucRunAv.last_cdata_size && ucRunAv.last_cdata != NULL && memcmp(src_buf, ucRunAv.last_cdata, size) == 0) {
		/* received the same codec data */
		printf("Same SPS/PPS. Screen lock = %d\n", ucRunAv.screen_lock);
		if(!ucRunAv.screen_lock)
			toggle_screen_onoff();
	}
	else {
		/* Codec data changed */
		printf("Different SPS/PPS. Screen lock = %d\n", ucRunAv.screen_lock);
		/* save current codec data for further usage */
		ucRunAv.last_cdata = (unsigned char*) realloc(ucRunAv.last_cdata, size);
		if(ucRunAv.last_cdata) {
			ucRunAv.last_cdata_size = size;
			memcpy(ucRunAv.last_cdata, src_buf, size);
		}
	}

	MUTEX_UNLOCK(ucRunAv.cdata_mutex);

   	return 0;
}

int t1_airp_write_audio(unsigned char *src_buf, int size, uint64_t pts)
{
	unsigned char buf[8] = {0};

	MUTEX_LOCK(ucRunAv.xpipe_mutex);

	/* write TAG */
	t1_airp_put_tag(buf, AIRP_ADATA_TAG);
	t1_airp_put_size(buf + 4, size + 8);
	xpipe_write_all(buf, 8);

	/* write PTS */
	t1_airp_put_pts(buf, pts);
	xpipe_write_all(buf, 8);

	/* write audio data */
	xpipe_write_all(src_buf, size);
	
	MUTEX_UNLOCK(ucRunAv.xpipe_mutex);

	return 0;
}

void t1_airp_set_volume(float volume)
{
	int vol = (volume + 30) * 100 / 30;
	vol = vol < 0 ? 0 : vol;
	if(al_callback)
		al_callback(AIRPLAY_AV_EVENT_SET_VOLUME, vol);
}

void t1_airp_set_callback(AirplayCbkFunc_t func)
{
	al_callback = func;
}

AirplayCbkFunc_t t1_airp_get_callback(void)
{
	return al_callback;
}

void t1_airp_set_screenlock(bool is_lock)
{
	ucRunAv.screen_lock = is_lock;
	if(ucRunAv.screen_lock && al_callback) {
		runav_link_screen_on(0);
		al_callback(AIRPLAY_AV_EVENT_SCREEN_OFF, 0);
	}
	else if(!ucRunAv.screen_lock && al_callback) {
		runav_link_screen_on(1);
		al_callback(AIRPLAY_AV_EVENT_SCREEN_ON, 0);
	}
}

