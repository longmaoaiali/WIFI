#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/file.h> 
#include <sys/ioctl.h>
#include <sys/time.h>
#include <unistd.h>
//#include <sistypes.h>
//#include "net_player_obj.h"
//#include <sisap/umftypes.h>
//#include "medialib_internal.h"
//#define __MEDIA_MOVIE_CTRL_C__

//#include "medialib_controller.h"
#include "netctrl_video_flow_ctrl.h"
#include "types.h"
#include "mid_sub_type.h"
/****************************************************/
/* Add for Notice UMF to shutdown automatically with long no-operations. */
//#include "sc_media_utils.h"
//#include "uap_umf_interface.h"
/*
void MediaCtrl_NoticeUMFMediaStatus(BOOL bIsPlay)
{
	NetCtrlHandle	*pNetCtrlHandle;
	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	int value=0;
	if(bIsPlay)
	{
		if(pNetCtrlHandle->nMediaMode == MEDIA_MUSIC)
		{
			value = MULTIMEDIA_MUSIC_PLAYING;
		}else
		{
			value = MULTIMEDIA_MOVIE_PLAYING;
		}
	}else
	{
		value = MULTIMEDIA_NOT_PLAYING;
	}
	noticeUMF_MultiMediaStatus(value);
}
*/
/****************************************************/

//Net_Player_CustomInfo_t* pstCustom;
sDataSource     Net_currentData;

unsigned char g_bNetFlowDebugON = 1;


typedef int (*NoticeCallBack)(int) ; //notiefunc call back value ��FUN callbackfunc; 
static NoticeCallBack pCallbackFunc = NULL;
static	NetCtrlHandle	g_NetCtrlHandle = {0};
#ifdef MEDIA_ENABLE_FF_FB_x32	// wyLiao@20121102: support 32X
static 	int nFastSpeed[6]={1,2,4,8,16,32};
#else
static 	int nFastSpeed[5]={1,2,4,8,16};
#endif

static BOOL b_MediaCtrlInit=FALSE;
static BOOL b_RunavInit=FALSE;
static BOOL (*gPE_Hook_PostMsg)(AL_NET_PLAYER_Event_t) = NULL;
static AL_NET_PLAYER_t gPlay_State = AL_NET_PLAYER_SUCCESS;


void NetCtrl_NET_Player_PE_Event_Process(UINT32 event_id)
{
	switch(event_id)
	{
		case NET_PLAYER_AV_EVENT_DECODE_START:
			FLOW_DBG("NET_PLAYER_AV_EVENT_DECODE_START\n");
			if(gPE_Hook_PostMsg)
				gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_DECODE_START);
			break;

		case NET_PLAYER_AV_EVENT_INITOK:
			FLOW_DBG("NET_PLAYER_AV_EVENT_INITOK\n");
			if(gPE_Hook_PostMsg)
				gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_INITOK);	
			break;
			
  		case NET_PLAYER_AV_EVENT_PLAY_DONE:
			FLOW_DBG("NET_PLAYER_AV_EVENT_PLAY_DONE\n");
			if(gPE_Hook_PostMsg)
				gPE_Hook_PostMsg(NET_PLAYER_AV_EVENT_PLAY_DONE);	
			break;
			
		default:
			FLOW_DBG("Unknown event 0x%X\n", event_id);
			break;
	}
}

void NetCtrl_NET_Player_PE_Register_MsgRouteway(BOOL (*SendMsg_Func)(AL_NET_PLAYER_Event_t))
{
    gPE_Hook_PostMsg = SendMsg_Func;
}

void NetCtrl_NET_Player_RegisterMsgRouteway(BOOL (*SendMsg_Func)(AL_NET_PLAYER_Event_t))
{
    NetCtrl_NET_Player_PE_Register_MsgRouteway(SendMsg_Func);
}

AL_NET_PLAYER_t NetCtrl_NET_Get_Play_State(void)
{
	return gPlay_State;
}


void NetCtrl_IsDebugON()
{
	FILE   *fp = NULL;

	fp = fopen("/tmp/flow.debug.on", "r");
	if(fp != NULL)
	{
		g_bNetFlowDebugON = 1;
		fclose(fp);
	}
	else
		g_bNetFlowDebugON = 0;
}


void* NetCtrl_GetNetCtrlHandle()
{
	return &g_NetCtrlHandle;
}

void NetCtrl_UpdateStreamInfo(void *Arg)
{
	if(Arg)
	{
		short 	i, j;
		BOOL	bFind;
		AvStreamInfo	*pAvInfo = NULL;
		//SubInfoList	*pSubInfo = NULL;
		runav_stream_info_t *pStreamInfo = (runav_stream_info_t *)Arg;
		NetCtrlHandle	*pNetCtrlHandle;


		pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
		

		FLOW_DBG("count=%d, vstream_index=%d, astream_index=%d, sstream_index=%d\n", 
			pStreamInfo->nb_streams, pStreamInfo->track_video, pStreamInfo->track_audio, pStreamInfo->track_subtitle);
		FLOW_DBG("current_prog_id=%d\n", pStreamInfo->prog_id);

		pNetCtrlHandle->pRunavStreamInfo = pStreamInfo;

printf("NetCtrl_UpdateStreamInfo: step1\n");
		// Step1: Find program id.
		pNetCtrlHandle->nTotalProgram = 0;
		pNetCtrlHandle->nCurrentProId = pStreamInfo->prog_id;
		//pNetCtrlHandle->nSubtitleCount = ((SubInfoList*)pStreamInfo->subtitle_info_list)->total_sub_count;
		FLOW_DBG("current, pro_id=%d, SubtileCount=%d  \n", pStreamInfo->prog_id, pNetCtrlHandle->nSubtitleCount);
		for(i=0;i<pStreamInfo->nb_streams;i++)
		{
			FLOW_DBG("Total (%d) -- prog_id=%d, id=%d, index=%d, type=%d, lang=%s  \n", 
				i,
				pStreamInfo->streams[i].prog_id,
				pStreamInfo->streams[i].id,
				pStreamInfo->streams[i].index,
				pStreamInfo->streams[i].type,
				pStreamInfo->streams[i].lang);
			
			if (pStreamInfo->streams[i].type == RUNAV_STREAM_TYPE_VIDEO)
			{
				pAvInfo = &pNetCtrlHandle->AvStreamInfo[pNetCtrlHandle->nTotalProgram];
				
				pAvInfo->nProId = pStreamInfo->streams[i].prog_id;
				pAvInfo->nType = RUNAV_STREAM_TYPE_VIDEO;

				//pSubInfo = pStreamInfo->subtitle_info_list;
				//pAvInfo->nSubtitleCount = pSubInfo->total_sub_count;
				
				
				pNetCtrlHandle->nTotalProgram++;
			}
		}

		if(pNetCtrlHandle->nTotalProgram == 0)	// No Video Program
		{
			pNetCtrlHandle->bVideoNotSupport = 1;
			bFind = FALSE;
			for(i=0;i<pStreamInfo->nb_streams;i++)
			{
				if (pStreamInfo->streams[i].type == RUNAV_STREAM_TYPE_AUDIO)
				{
					for(j=0;j<pNetCtrlHandle->nTotalProgram;j++)
					{
						if(pStreamInfo->streams[j].prog_id == pNetCtrlHandle->AvStreamInfo[j].nProId)
							bFind = TRUE;
					}

					if(pNetCtrlHandle->nTotalProgram == 0 || !bFind )
					{
						pNetCtrlHandle->AvStreamInfo[pNetCtrlHandle->nTotalProgram].nProId = pStreamInfo->prog_id;
						pNetCtrlHandle->AvStreamInfo[pNetCtrlHandle->nTotalProgram].nType = RUNAV_STREAM_TYPE_AUDIO;
						pNetCtrlHandle->nTotalProgram++;
					}
				}
			}

			//if(bFind == FALSE)
			//	pNetCtrlHandle->bAudioNotSupport = 1;
		}

		//memset(&AvStreamInfo[pStreamInfo->nb_streams], 
		//			0, 
		//			sizeof(AvStreamInfo)*(MAX_PROGRAM_COUNT - pStreamInfo->nb_streams) );
		for(i=0;i<pNetCtrlHandle->nTotalProgram;i++)
		{
			FLOW_DBG("pro_id[%d] -- prog_id=%d, type=%d  \n",
				i, 
				pNetCtrlHandle->AvStreamInfo[i].nProId,
				pNetCtrlHandle->AvStreamInfo[i].nType);

			pNetCtrlHandle->AvStreamInfo[i].nAudioCount = 0;
		}
			


		// Step2: Use program id of step1 to find audio.
		
		for(i=0;i<pNetCtrlHandle->nTotalProgram;i++)
		{
			pAvInfo = &pNetCtrlHandle->AvStreamInfo[i];
			for(j=0;j<pStreamInfo->nb_streams;j++)
			{
				if(pAvInfo->nProId == pStreamInfo->streams[j].prog_id
					&& pStreamInfo->streams[j].type == RUNAV_STREAM_TYPE_AUDIO)
				{
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nIndex = pStreamInfo->streams[j].index;
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nId = pStreamInfo->streams[j].id;
					pAvInfo->AudioInfo[pAvInfo->nAudioCount].nTrack = pStreamInfo->streams[j].track;
					strcpy(pAvInfo->AudioInfo[pAvInfo->nAudioCount].strLang, pStreamInfo->streams[j].lang);

					FLOW_DBG("audio[%d] -- index=%d, id=%d, tarck=%d, lang=%s   \n",
						pAvInfo->nAudioCount,
						pAvInfo->AudioInfo[pAvInfo->nAudioCount].nIndex,
						pAvInfo->AudioInfo[pAvInfo->nAudioCount].nId,
						pAvInfo->AudioInfo[pAvInfo->nAudioCount].nTrack,
						pAvInfo->AudioInfo[pAvInfo->nAudioCount].strLang);
					
					pAvInfo->nAudioCount++;
				}
			}
		}
		

		if(pNetCtrlHandle->nTotalProgram && pAvInfo->nAudioCount == 0)
			pNetCtrlHandle->bAudioNotSupport = 1;
	}


}


void NetCtrl_EventHandler(int nEventID, void *arg)
{
	NetCtrlHandle	*pNetCtrlHandle;
	AL_NET_PLAYER_Event_t Event = NET_PLAYER_EVENT_END;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	
	
	switch(nEventID)
	{
		case RUNAV_EVENT_EOF:
			FLOW_DBG("RUNAV_EVENT_EOF, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			Event = NET_PLAYER_AV_EVENT_PLAY_DONE;
			break;

		case RUNAV_EVENT_VIDEO_UNSUPPORT:
			FLOW_DBG("RUNAV_EVENT_VIDEO_UNSUPPORT, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			pNetCtrlHandle->bVideoNotSupport = 1;
			break;

		case RUNAV_EVENT_AUDIO_UNSUPPORT:
			FLOW_DBG("RUNAV_EVENT_AUDIO_UNSUPPORT, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			pNetCtrlHandle->bAudioNotSupport = 1;
			break;

		case RUNAV_EVENT_INPROCESS:	
			FLOW_DBG("RUNAV_EVENT_INPROCESS, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			Event = NET_PLAYER_AV_EVENT_DECODE_START;
			break;

		case RUNAV_EVENT_FINISH:	
			FLOW_DBG("RUNAV_EVENT_FINISH, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			b_RunavInit = TRUE;
			Event = NET_PLAYER_AV_EVENT_INITOK;
			gPlay_State = AL_NET_PLAYER_SUCCESS;
			if(pNetCtrlHandle->nMediaStatus == MEDIA_INIT)
			{
				NetCtrl_Play();
			}
			else if(pNetCtrlHandle->nMediaStatus == MEDIA_UNSUPPORT || pNetCtrlHandle->nMediaStatus == MEDIA_ERROR)
			{
				gPlay_State = AL_NET_PLAYER_ERR_FAILURE;
			/*
				NetCtrl_Stop();
				usleep(100);
				NetCtrl_Init();
				NetCtrl_SetDataSource(&Net_currentData, 0, 0);
				*/
			}
			else
			{
				FLOW_DBG("RUNAV_EVENT_FINISH, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			}
			break;

		case RUNAV_EVENT_HEAD_OF_FILE:
			FLOW_DBG("RUNAV_EVENT_HEAD_OF_FILE, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			Event = NET_PLAYER_AV_EVENT_PLAY_DONE;
			break;

		case RUNAV_EVENT_AUDIO_SUPPORT:
			FLOW_DBG("RUNAV_EVENT_AUDIO_SUPPORT, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;			

		case RUNAV_EVENT_UNKNOWN_FORMAT:
			FLOW_DBG("RUNAV_EVENT_UNKNOWN_FORMAT, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			//pNetCtrlHandle->bVideoNotSupport = 1;
			pNetCtrlHandle->nMediaStatus = MEDIA_UNSUPPORT;
			gPlay_State = AL_NET_PLAYER_ERR_FAILURE;
			break;

			
		case RUNAV_EVENT_NEXT_PROG:
			FLOW_DBG("RUNAV_EVENT_NEXT_PROG, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
		case RUNAV_EVENT_STREAM_INFO:
			if(nEventID == RUNAV_EVENT_STREAM_INFO)
				FLOW_DBG("RUNAV_EVENT_STREAM_INFO, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);

			//NetCtrl_UpdateStreamInfo(arg);
		break;			

		case RUNAV_EVENT_FILE_NOT_EXIST:	
			FLOW_DBG("RUNAV_EVENT_FILE_NOT_EXIST, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			pNetCtrlHandle->nMediaStatus = MEDIA_ERROR;
			break;
			
		case RUNAV_EVENT_OOM:
			FLOW_DBG("RUNAV_EVENT_OOM, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;

		case RUNAV_EVENT_SEEK_COMPLETE:
			FLOW_DBG("RUNAV_EVENT_SEEK_COMPLETE, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;
			

		case RUNAV_EVENT_BUFFERING_START:
			FLOW_DBG("RUNAV_EVENT_BUFFERING_START, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;

		case RUNAV_EVENT_BUFFERING_END:
			FLOW_DBG("RUNAV_EVENT_BUFFERING_END, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;

		default:
			FLOW_DBG("Unknown Event, MediaStatus=%d \n", pNetCtrlHandle->nMediaStatus);
			break;

	}

	pNetCtrlHandle->nEvent = nEventID;
	NetCtrl_NET_Player_PE_Event_Process(Event);
	FLOW_DBG("runav event=%d  \n", nEventID);
#if 0
	pNetCtrlHandle->nEventBuffer[pNetCtrlHandle->nEnqIdx] = nEventID;
	FLOW_DBG("Event=%d,  nEnqIdx=%d   +++++++++++\n", nEventID, pNetCtrlHandle->nEnqIdx);
	pNetCtrlHandle->nEnqIdx++;
	if(pNetCtrlHandle->nEnqIdx == MAX_BUFFER_COUNT)
		pNetCtrlHandle->nEnqIdx = 0;
#endif
/*	
	pthread_mutex_lock(&pNetCtrlHandle->MediaEvent_Mutex);
	pthread_cond_signal(&pNetCtrlHandle->CondEvent_Thread);
	pthread_mutex_unlock(&pNetCtrlHandle->MediaEvent_Mutex);
*/	

}


void NetCtrl_SetNotificationFunc(void *pData)
{
	if(pData)
		pCallbackFunc = pData;
}

void NetCtrl_SetMediaMode(int nMode)
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	pNetCtrlHandle->nMediaMode = nMode;
}

int NetCtrl_GetMediaStatus()
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bMutexThread == 0)
		return -1;

	return pNetCtrlHandle->nMediaStatus;
}

unsigned char NetCtrl_IsPlay()
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	return pNetCtrlHandle->bPlay;
}

void NetCtrl_VideoAudioSupport(unsigned char *bVideoNotSupport, unsigned char *bAudioNotSupport)
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	*bVideoNotSupport = pNetCtrlHandle->bVideoNotSupport;
	*bAudioNotSupport = pNetCtrlHandle->bAudioNotSupport;

	FLOW_DBG("bVideoNotSupport=%d, bAudioNotSupport=%d  \n",
		pNetCtrlHandle->bVideoNotSupport, pNetCtrlHandle->bAudioNotSupport);
	
}

void* NetCtrl_EventThread(void *pArg)
{
	NetCtrlHandle	*pNetCtrlHandle = pArg;
	//int				nEventId, nPreviousEvent;
	int				nEventId;
	long		nCurrentSeconds, nTotalSeconds;
	long		nAbsSeconds;
	unsigned char		nSpeed = 0, bDoSeek;


	nCurrentSeconds =  nAbsSeconds = nTotalSeconds = 0;
	//nPreviousEvent = 0;
	while(pNetCtrlHandle->bMutexThread)
	{

		if(pNetCtrlHandle->bMutexThread)
		{
			nEventId = pNetCtrlHandle->nEventBuffer[pNetCtrlHandle->nDeqIdx];
			while( nEventId != -1 )
			{
				if(pCallbackFunc)
				{
					FLOW_DBG("Event=%d,  nDeqIdx=%d   ----------\n", nEventId, pNetCtrlHandle->nDeqIdx);
					pNetCtrlHandle->nEventBuffer[pNetCtrlHandle->nDeqIdx] = -1;
					(*pCallbackFunc)(nEventId);

					pNetCtrlHandle->nDeqIdx++;
					if(pNetCtrlHandle->nDeqIdx == MAX_BUFFER_COUNT)
						pNetCtrlHandle->nDeqIdx = 0;

					nEventId = pNetCtrlHandle->nEventBuffer[pNetCtrlHandle->nDeqIdx];
				}
			}
		}

		if(pNetCtrlHandle->bPlay && pNetCtrlHandle->nMediaMode == MEDIA_MUSIC)
		{
			//if(pNetCtrlHandle->nMediaStatus == MEDIA_FF || pNetCtrlHandle->nMediaStatus == MEDIA_FR)
			if(pNetCtrlHandle->nSpeed_FF || pNetCtrlHandle->nSpeed_FR)
			{
				nCurrentSeconds = NetCtrl_GetCurrentTime()/1000;
				nTotalSeconds = NetCtrl_GetTotalTime();
				bDoSeek = 0;

/*
				if(nAbsSeconds == 0 ||
					( nAbsSeconds <= nCurrentSeconds && pNetCtrlHandle->nMediaStatus == MEDIA_FF) ||
					(nAbsSeconds >= nCurrentSeconds && pNetCtrlHandle->nMediaStatus == MEDIA_FR) )
					bDoSeek = 1;
*/

				if(nAbsSeconds == 0 ||
					( nAbsSeconds <= nCurrentSeconds && pNetCtrlHandle->nSpeed_FF) ||
					(nAbsSeconds >= nCurrentSeconds && pNetCtrlHandle->nSpeed_FR) )
					bDoSeek = 1;

				if(pNetCtrlHandle->nSpeed_FF && bDoSeek)
				{
					nSpeed = nFastSpeed[pNetCtrlHandle->nSpeed_FF];
					nAbsSeconds = nCurrentSeconds + nSpeed;
					if(nAbsSeconds >= nTotalSeconds)
						pNetCtrlHandle->nSpeed_FF = 0;

				}
				else if(pNetCtrlHandle->nSpeed_FR && bDoSeek)
				{
					nSpeed = nFastSpeed[pNetCtrlHandle->nSpeed_FR];
					if( (nCurrentSeconds - nSpeed) < 0)
					{
						pNetCtrlHandle->nSpeed_FR = 0;
						nAbsSeconds = 0;
					}
					else
						nAbsSeconds = nCurrentSeconds - nSpeed;
				}

					FLOW_DBG("nAbsSeconds=%ld , %ld,  %ld, FF=%d, FR=%d, %d --\n", nAbsSeconds, nCurrentSeconds, nTotalSeconds,
						pNetCtrlHandle->nSpeed_FF, pNetCtrlHandle->nSpeed_FR, nSpeed);

				if(bDoSeek)
				{
					NetCtrl_SeekTime(nAbsSeconds*1000);

					if((nAbsSeconds == 0 && pNetCtrlHandle->nSpeed_FR == 0))
					{	
						usleep(200000);
						NetCtrl_Play();
					}
				}
				

				usleep(800000);
				

			}
			else
			{
				nCurrentSeconds =  nAbsSeconds = nTotalSeconds = 0;
			}

		}


		usleep(1000);

	}

	pthread_exit(0);
}


unsigned char NetCtrl_InitMutex()
{
	NetCtrlHandle	*pNetCtrlHandle;
	//int 				nRes, i;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	if(pNetCtrlHandle->bMutexThread == 0)
	{
		if (pthread_mutex_init(&pNetCtrlHandle->MediaCmd_Mutex, NULL) != 0)
		{
			FLOW_ERR("Initialize MediaCmd_Mutex Fail !!!\n");
			return 0;
		}

		if (pthread_mutex_init(&pNetCtrlHandle->MediaSubtitle_Mutex, NULL) != 0)
		{
			pthread_mutex_destroy(&pNetCtrlHandle->MediaCmd_Mutex);
			
			FLOW_ERR("Initialize MediaSubtitle_Mutex Fail !!!\n");
			return 0;
		}

		if (pthread_mutex_init(&pNetCtrlHandle->MediaEvent_Mutex, NULL) != 0)
		{
			pthread_mutex_destroy(&pNetCtrlHandle->MediaCmd_Mutex);
			pthread_mutex_destroy(&pNetCtrlHandle->MediaSubtitle_Mutex);
			
			FLOW_ERR("Initialize MediaEvent_Mutex Fail !!!\n");
			return 0;
		}
	/*	
		if (pthread_cond_init(&pNetCtrlHandle->CondEvent_Thread, NULL) != 0)
		{
			pthread_mutex_destroy(&pNetCtrlHandle->MediaCmd_Mutex);
			pthread_mutex_destroy(&pNetCtrlHandle->MediaSubtitle_Mutex);
			pthread_mutex_destroy(&pNetCtrlHandle->MediaEvent_Mutex);
			
			FLOW_ERR("Initialize CondEvent_Thread Fail !!!\n");
			return 0;
		}
	*/
#if 0
		pNetCtrlHandle->nEnqIdx = pNetCtrlHandle->nDeqIdx = 0;
		for(i=0;i<12;i++)
			pNetCtrlHandle->nEventBuffer[i] = -1;
#endif
		pNetCtrlHandle->bMutexThread = 1;
//YC mark
#if 0
		nRes = pthread_create(&pNetCtrlHandle->MediaEvent_Thread, 
						NULL, 
						NetCtrl_EventThread, 
						pNetCtrlHandle);

		if(nRes !=0)
		{
			pthread_mutex_destroy(&pNetCtrlHandle->MediaCmd_Mutex);
			pthread_mutex_destroy(&pNetCtrlHandle->MediaSubtitle_Mutex);
			pthread_mutex_destroy(&pNetCtrlHandle->MediaEvent_Mutex);
			pthread_cond_destroy(&pNetCtrlHandle->CondEvent_Thread);

			
			FLOW_ERR("Media Event Thread Fail  !!! \n");
			return 0;
		}
#endif
		
	}

	return 1;

}


void NetCtrl_DestroyMutex()
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	if(pNetCtrlHandle->bMutexThread == 1)
	{
		pNetCtrlHandle->nEvent = 0;
		pNetCtrlHandle->bMutexThread = 0;
/*
		pthread_mutex_lock(&pNetCtrlHandle->MediaEvent_Mutex);
		pthread_cond_signal(&pNetCtrlHandle->CondEvent_Thread);
		pthread_mutex_unlock(&pNetCtrlHandle->MediaEvent_Mutex);		
		
		pthread_join(pNetCtrlHandle->MediaEvent_Thread, NULL);
*/
	printf("[NetCtrl_DestroyMutex] step1\n");	
		if(pthread_mutex_destroy(&pNetCtrlHandle->MediaCmd_Mutex) != 0)
			FLOW_ERR("Destroy MediaCmd_Mutex Fail  \n");
	printf("[NetCtrl_DestroyMutex] step2\n");
		if(pthread_mutex_destroy(&pNetCtrlHandle->MediaSubtitle_Mutex) != 0)
			FLOW_ERR("Destroy MediaSubtitle_Mutex Fail  \n");
	printf("[NetCtrl_DestroyMutex] step3\n");
		if(pthread_mutex_destroy(&pNetCtrlHandle->MediaEvent_Mutex) != 0)
			FLOW_ERR("Destroy MediaEvent_Mutex Fail  \n");
/*
		if(pthread_cond_destroy(&pNetCtrlHandle->CondEvent_Thread) != 0)
			FLOW_ERR("Destroy CondEvent_Thread Fail  \n");
*/
	printf("[NetCtrl_DestroyMutex] step5\n");
		
	}
}

int NetCtrl_Init()
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet = 1;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	printf("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	//NetCtrl_InitMutex();

	if(pNetCtrlHandle->nMediaStatus != MEDIA_IDLE)
	{
		FLOW_DBG("Media Status != MEDIA_IDLE  \n");
		return -1;
	}

	if(pNetCtrlHandle->bMutexThread == 0)
		return -1;

	
	pNetCtrlHandle->nSpeed_FF = pNetCtrlHandle->nSpeed_FR = 0;
	pNetCtrlHandle->nCurrentProId = 0;
	pNetCtrlHandle->bVideoNotSupport = pNetCtrlHandle->bAudioNotSupport = 0;
	pNetCtrlHandle->nTotalTime = 0;
	pNetCtrlHandle->nRunavOpt = 0;
	memset(&pNetCtrlHandle->MediaFileInfo, 0, sizeof(media_info_t));
	//pNetCtrlHandle->nMediaStatus = MEDIA_INIT;
	//pNetCtrlHandle->nMediaMode = MEDIA_MOVIE;
	nRet = 1;

	return nRet;
	
}

int  NetCtrl_Initialize()
{
	int nRet = 1;
	printf("[NetCtrl_Initialize] in\n");
	NetCtrlHandle *pNetCtrlHandle;
      pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	

	pNetCtrlHandle->nMediaStatus = MEDIA_IDLE;
	NetCtrl_InitMutex();
//	pstCustom = (Net_Player_CustomInfo_t*)pstCusInfo;
	NetCtrl_Init();
	b_MediaCtrlInit = TRUE;
	b_RunavInit = FALSE;
	return nRet;
}
int NetCtrl_Finalize()
{
	int                             nRet = 1;
	if(b_MediaCtrlInit)
	{
		printf("NetCtrl_Finalize in \n");
		NetCtrl_Stop();
		printf("YC: final stop complete\n");
		NetCtrl_DestroyMutex();
		printf("NetCtrl_Finalize out \n");
		b_MediaCtrlInit = FALSE;
	}
	if (Net_currentData.pFullPath)
	{
		free(Net_currentData.pFullPath);
		Net_currentData.pFullPath = NULL;
	}
	return nRet;
}
void NetCtrl_Exit()
{
	NetCtrlHandle	*pNetCtrlHandle;


	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);
	if(pNetCtrlHandle->nMediaStatus == MEDIA_STOP)
	{
/*
		if(pNetCtrlHandle->bSubtitleOn)
		{
			FLOW_DBG("NetCtrl_SetSubtitleOff    \n");
			NetCtrl_SetSubtitleOff();
		}
*/
		if(b_RunavInit)
		{
			printf("YC: runav_exit in\n");
			runav_exit();
			b_RunavInit = FALSE;
			printf("YC: runav_exit out\n");
		}

		pNetCtrlHandle->nMediaStatus = MEDIA_IDLE;
		pNetCtrlHandle->bPlay = FALSE;
//		MediaCtrl_NoticeUMFMediaStatus(FALSE);
		FLOW_DBG("EXIT -------------------------------------------------------\n");
	}

}
static pthread_t gRunav_task;
static void _Player_Runav_Init_Task(void* Param)
{
	NetCtrlHandle *pNetCtrlHandle;
    pthread_detach(gRunav_task);
	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
    printf("runav init [%s] start\n", pNetCtrlHandle->strFilePath);
	runav_init(pNetCtrlHandle->strFilePath,  pNetCtrlHandle->nRunavOpt, NetCtrl_EventHandler);
	//b_RunavInit = TRUE;
    printf("runav init [%s] end\n", pNetCtrlHandle->strFilePath);
    pthread_exit(NULL);
}


int NetCtrl_SetDataSource(sDataSource *pData, unsigned long nLowTime, unsigned long nHighTime)
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet = 1;
	UINT64 	n64Pos;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);
	if(pData->src == 0 && pData->pFullPath && pNetCtrlHandle->nMediaStatus == MEDIA_IDLE)
	{

		//pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);
		
		strcpy(pNetCtrlHandle->strFilePath, pData->pFullPath);
		printf("[NetCtrl_SetDataSource] Url = %s\n", pNetCtrlHandle->strFilePath);
		if(nLowTime || nHighTime)
		{
			n64Pos = ((UINT64)nHighTime << 32) | nLowTime;
			nRet = runav_init_fpos(pNetCtrlHandle->strFilePath, pNetCtrlHandle->nRunavOpt, NetCtrl_EventHandler,  n64Pos);
		}
		else
		{
			//pNetCtrlHandle->nRunavOpt  |= (RUNAV_RECORD | RUNAV_AUDIO_DISABLE);
			//nRet = runav_init(pNetCtrlHandle->strFilePath, pNetCtrlHandle->nRunavOpt, NetCtrl_EventHandler);
			pthread_attr_t AVAttr;
			pthread_attr_init(&AVAttr);
			pthread_attr_setstacksize(&AVAttr, 1*1024*1024);
			nRet = pthread_create(&gRunav_task, &AVAttr, (void *)_Player_Runav_Init_Task, NULL);
			pthread_attr_destroy(&AVAttr);
		}

		//pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);
		
		//if(nRet != -1)
		{
			//media_info_t		FilmInfo;

			pNetCtrlHandle->nMediaStatus = MEDIA_INIT;
/*
			if( NetCtrl_GetFilmInfo(&FilmInfo) != -1)
			{
				pNetCtrlHandle->nTotalTime = FilmInfo.duration;

				// This music file duration time less than 1 second
				if(pNetCtrlHandle->nTotalTime == 0)
				{
					FLOW_DBG("This music file duration time less than 1 second  !!!!!\n");
					pNetCtrlHandle->nTotalTime  = 1;
				}
			}
*/
		}
	}


	FLOW_DBG("nRet=%d, src=%d, Path=%s  \n", nRet, pData->src, pData->pFullPath);

	return nRet;
}


int NetCtrl_SetMediaInfo(char *pszFileName)
{
	printf("NetCtrl_SetMediaInfo in \n");
	//NetCtrlHandle *pNetCtrlHandle;
        int                             nRet = 1;

	//pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
printf("go there = = 1?\n");
//	Net_Player_MediaInfo *MediaInfo = (Net_Player_MediaInfo*)_MediaInfo;

	//sDataSource     Net_currentData;
	Net_currentData.src = 0;
	Net_currentData.index = 0;
printf("go there = = 3?\n");
	char *pUrl;

	pUrl = malloc(strlen(pszFileName)+1);
	memset(pUrl, '\0', strlen(pszFileName)+1);
	memcpy(pUrl, pszFileName, strlen(pszFileName));

	Net_currentData.pFullPath = pUrl;
printf("go there = = 4?\n");
	printf("[NetCtrl_SetMediaInfo] Url = %s\n", Net_currentData.pFullPath);
//	if(MediaInfo->eAPPB_mode == NET_PLAYER_APPB_A)
//		NetCtrl_SetMediaMode(MEDIA_MUSIC);
//	else if(MediaInfo->eAPPB_mode == NET_PLAYER_APPB_V)
	NetCtrl_SetMediaMode(MEDIA_MOVIE);
	NetCtrl_SetDataSource(&Net_currentData, 0, 0);

	return nRet;

}

int NetCtrl_GetFilmInfo(void *pFilmInfo)
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet = -1;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT)
	{
		runav_getinfo(&pNetCtrlHandle->MediaFileInfo);
		memcpy(pFilmInfo, &pNetCtrlHandle->MediaFileInfo, sizeof(media_info_t));

		FLOW_DBG("Duration=%lld  \n", pNetCtrlHandle->MediaFileInfo.duration);
		nRet = 1;
	}

	return nRet;	
}


void NetCtrl_Play()
{
	printf("NetCtrl_Play in \n");
	NetCtrlHandle	*pNetCtrlHandle;
	int				nCurrentTime;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d, nMediaMode = %d \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay, pNetCtrlHandle->nMediaMode);

	if(pNetCtrlHandle->nMediaStatus < MEDIA_INIT)
		return;
#if 0
	if(pNetCtrlHandle->bVideoNotSupport && pNetCtrlHandle->nMediaMode != MEDIA_MUSIC)
	{
		FLOW_DBG("Video Not Support,  %d, %d \n", 
			pNetCtrlHandle->bVideoNotSupport, pNetCtrlHandle->bAudioNotSupport);

		NetCtrl_Stop();

		return;
	}
	if(pNetCtrlHandle->bAudioNotSupport && pNetCtrlHandle->nMediaMode == MEDIA_MUSIC)
	{
		FLOW_DBG("Audio Not Support, %d \n", pNetCtrlHandle->bAudioNotSupport);
		NetCtrl_Stop();
		return;
	}
#endif	
	if(pNetCtrlHandle->nMediaStatus == MEDIA_PLAY || pNetCtrlHandle->nMediaStatus == MEDIA_STOP)
		return;

	if(pNetCtrlHandle->bPlay == TRUE && pNetCtrlHandle->nMediaStatus == MEDIA_FF)
	{
		nCurrentTime = NetCtrl_GetCurrentTime();
		if((pNetCtrlHandle->nTotalTime - (nCurrentTime/1000)) <= (2 + nFastSpeed[pNetCtrlHandle->nSpeed_FF]))
		{
			printf("%s: Special Case1 \n", __FUNCTION__);
			return;
		}
	}

	pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);
	if(pNetCtrlHandle->nMediaStatus == MEDIA_FF ||pNetCtrlHandle->nMediaStatus == MEDIA_FR)
	{
		pNetCtrlHandle->nSpeed_FF = pNetCtrlHandle->nSpeed_FR = 0;
	}

	if(pNetCtrlHandle->bPlay == FALSE)
		FLOW_DBG("PLAY +++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");


	runav_play();
	//runav_set_play();
	pNetCtrlHandle->nMediaStatus = MEDIA_PLAY;
	pNetCtrlHandle->bPlay = TRUE;
	//MediaCtrl_NoticeUMFMediaStatus(TRUE);
	
	pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);
	
}


void NetCtrl_Pause()
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d  \n", pNetCtrlHandle->nMediaStatus);

	if(pNetCtrlHandle->bPlay == FALSE)
		return;

	if(pNetCtrlHandle->nMediaStatus == MEDIA_PAUSE)
		return;	

	pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);
	if(pNetCtrlHandle->nMediaStatus == MEDIA_FF ||pNetCtrlHandle->nMediaStatus == MEDIA_FR)
	{
		pNetCtrlHandle->nSpeed_FF = pNetCtrlHandle->nSpeed_FR = 0;
		//return;
	}

	pNetCtrlHandle->nMediaStatus = MEDIA_PAUSE;
	runav_pause();
	pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);

}


void NetCtrl_Stop()
{
	NetCtrlHandle	*pNetCtrlHandle;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", 
		pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->nMediaStatus == MEDIA_STOP)
		return;	

	
	if(pNetCtrlHandle->nMediaStatus >= MEDIA_IDLE)	//pNetCtrlHandle->bPlay
	{
		pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);

		pNetCtrlHandle->nMediaStatus = MEDIA_STOP;
		pNetCtrlHandle->bPlay = FALSE;
		
		NetCtrl_Exit();
//YC add
		pNetCtrlHandle->nSpeed_FF = pNetCtrlHandle->nSpeed_FR = 0;
        	pNetCtrlHandle->nCurrentProId = 0;
        	pNetCtrlHandle->bVideoNotSupport = pNetCtrlHandle->bAudioNotSupport = 0;
        	pNetCtrlHandle->nTotalTime = 0;
        	pNetCtrlHandle->nRunavOpt = 0;
        	memset(&pNetCtrlHandle->MediaFileInfo, 0, sizeof(media_info_t));
//~YC add
		pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);
	}

	
}



int NetCtrl_FastForward()
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet = 0;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bPlay)
	{
		//pNetCtrlHandle->nMediaStatus = MEDIA_FF;
		switch(pNetCtrlHandle->nMediaStatus)
		{
			case MEDIA_PLAY:
			case MEDIA_FF:
			case MEDIA_PAUSE:
			case MEDIA_FR:	
			{
				if(pNetCtrlHandle->nMediaStatus == MEDIA_FR)
					pNetCtrlHandle->nSpeed_FR = 0;

				if(pNetCtrlHandle->nMediaMode == MEDIA_MUSIC &&
					pNetCtrlHandle->nSpeed_FF == 0)
					NetCtrl_Pause();

				
				if(pNetCtrlHandle->nSpeed_FF == 0)
					pNetCtrlHandle->nSpeed_FF = 1;
				else
					pNetCtrlHandle->nSpeed_FF++;

				if(pNetCtrlHandle->nSpeed_FF == MAX_FF_FR_SPEED)
				{
					pNetCtrlHandle->nSpeed_FF = 0;

					//if(pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
						NetCtrl_Play();
				}
				else
				{
					pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);

					if(pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
						nRet = runav_fast_forward(pNetCtrlHandle->nSpeed_FF);

					if(nRet == 0)
						pNetCtrlHandle->nMediaStatus = MEDIA_FF;
					
					pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);
				}
			}
			break;
		}

		
	}

	FLOW_DBG("nRet=%d, FF=%d, FR=%d  \n", 
		nRet, pNetCtrlHandle->nSpeed_FF, pNetCtrlHandle->nSpeed_FR);
	return pNetCtrlHandle->nSpeed_FF;
}


int NetCtrl_FastRewind()
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet = 0;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bPlay)
	{
		
		//pNetCtrlHandle->nMediaStatus = MEDIA_FF;
		switch(pNetCtrlHandle->nMediaStatus)
		{
			case MEDIA_PLAY:
			case MEDIA_FF:
			case MEDIA_PAUSE:
			case MEDIA_FR:	
			{
				if(pNetCtrlHandle->nMediaStatus == MEDIA_FF)
					pNetCtrlHandle->nSpeed_FF = 0;


				if(pNetCtrlHandle->nMediaMode == MEDIA_MUSIC &&
					pNetCtrlHandle->nSpeed_FR == 0)
					NetCtrl_Pause();


				if(pNetCtrlHandle->nSpeed_FR == 0)
					pNetCtrlHandle->nSpeed_FR = 1;
				else
					pNetCtrlHandle->nSpeed_FR++;

				if(pNetCtrlHandle->nSpeed_FR == MAX_FF_FR_SPEED)
				{
					pNetCtrlHandle->nSpeed_FR = 0;

					if(pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
						NetCtrl_Play();
				}
				else
				{
					pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);

					if(pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
					{
						nRet = runav_fast_backward(pNetCtrlHandle->nSpeed_FR);
					}

					if(nRet == 0)
						pNetCtrlHandle->nMediaStatus = MEDIA_FR;					
					
					pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);
				}
			}
			break;
		}
		
	}

	FLOW_DBG("nRet=%d, FF=%d, FR=%d  \n", 
		nRet, pNetCtrlHandle->nSpeed_FF, pNetCtrlHandle->nSpeed_FR);
	return pNetCtrlHandle->nSpeed_FR;
}
#if 0
void MediaCtrl_Goto()
{
}

void MediaCtrl_Next()
{
	NetCtrlHandle *pNetCtrlHandle;
        int                             nRet = 0;

        pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
        FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

        if(pNetCtrlHandle->bPlay)
	{

		pthread_t pTaskId;
		pthread_create(&pTaskId, NULL, _MediaCtrl_Next, NULL);
	}
}

static void * _MediaCtrl_Next()
{
	Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfAVCallback;

        Net_Player_MediaInfo mediaInfo;
        mediaInfo.eMode = NET_PLAYER_IF_AV;
        if (pfCbListner(NET_PLAYER_CBK_GET_NEXT_URL, Net_currentData.index, (UINT32)&mediaInfo) == 0)
        {
		NetCtrl_Stop();
		NetCtrl_Init();
                printf("next url = [%s]\n", mediaInfo.pUrl);
                NetCtrl_SetMediaInfo(&mediaInfo);
		printf("YC: xxxxxxxxxxxxxxxxxxxx MediaInfo->eAPPB_mode = %d\n", mediaInfo.eAPPB_mode);
                NetCtrl_Play();
                pfCbListner(NET_PLAYER_CBK_SHOW_NEXT, mediaInfo.Index, 0);
        }

	pthread_detach(pthread_self());
}

void MediaCtrl_Prev()
{
	NetCtrlHandle *pNetCtrlHandle;
        int                             nRet = 0;

        pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();	
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);
	
	if(pNetCtrlHandle->bPlay)
        {

                pthread_t pTaskId;
                pthread_create(&pTaskId, NULL, _MediaCtrl_Prev, NULL);
        }
}

static void * _MediaCtrl_Prev()
{
        Net_Player_MWCallback pfCbListner = pstCustom->stAVInfo.pfAVCallback;

        Net_Player_MediaInfo mediaInfo;
        mediaInfo.eMode = NET_PLAYER_IF_AV;

	if (pfCbListner(NET_PLAYER_CBK_GET_PRE_URL, Net_currentData.index, (UINT32)&mediaInfo) == 0)
        {
                NetCtrl_Stop();
                NetCtrl_Init();
                printf("prev url = [%s]\n", mediaInfo.pUrl);
		NetCtrl_SetMediaInfo(&mediaInfo);
		NetCtrl_Play();
                pfCbListner(NET_PLAYER_CBK_SHOW_PREV, mediaInfo.Index, 0);
        }

	pthread_detach(pthread_self());
}
#endif
#if 0
int NetCtrl_GetSubtitleCount()
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					nRet;
	runav_stream_info_t 	*pStreamInfo;
	SubInfoList			*pInfoList;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	nRet = 0;
	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT)
	{
		FLOW_DBG("nMediaStatus=%d, bPlay=%d, nCount=%d  \n", 
			pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay, pNetCtrlHandle->nSubtitleCount);
		nRet = pNetCtrlHandle->nSubtitleCount;
	}

	return nRet;
}


void	NetCtrl_SetSubtitleOff()
{
	NetCtrlHandle	*pNetCtrlHandle;
	int				nRet;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	if(pNetCtrlHandle->bSubtitleOn)
	{
		pthread_mutex_lock(&pNetCtrlHandle->MediaSubtitle_Mutex);
		nRet = runav_subtitle_off();
		pNetCtrlHandle->bSubtitleOn = FALSE;
		pthread_mutex_unlock(&pNetCtrlHandle->MediaSubtitle_Mutex);
	}
}


void NetCtrl_SetSubtitleIndex(int nIndex, int nType)
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					nRet;
	runav_stream_info_t 	*pStreamInfo;
	SubInfoList			*pInfoList;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d, nIndex=%d  \n", 
		pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay, nIndex);

	if(pNetCtrlHandle->nSubtitleCount == 0 ||
		pNetCtrlHandle->nSubtitleCount <= nIndex)
		return;

	pStreamInfo = pNetCtrlHandle->pRunavStreamInfo;
	if(pStreamInfo)
	{
		pInfoList = pStreamInfo->subtitle_info_list;

		if(pInfoList)
		{
			FLOW_DBG("Count=%d, index=%d  \n",
				pInfoList->total_sub_count, nIndex);
			if(pInfoList->sub_info_entry)
			{
				FLOW_DBG("pInfoList->sub_info_entry[nIndex].id=%d \n", pInfoList->sub_info_entry[nIndex].id);
			
				pthread_mutex_lock(&pNetCtrlHandle->MediaSubtitle_Mutex);
				if (SetEncode(nType))
				{
					FLOW_DBG("SetEncode(%d) success.\n", nType);
				}	
				
				nRet = runav_subtitle_on(pInfoList->sub_info_entry[nIndex].id);
				if(pNetCtrlHandle->bSubtitleOn == FALSE)
					pNetCtrlHandle->bSubtitleOn = TRUE;

				pthread_mutex_unlock(&pNetCtrlHandle->MediaSubtitle_Mutex);
			}
		}
	}
}
#endif
int NetCtrl_GetAudioCount()
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					i, j, nCount;
	AvStreamInfo			*pAvInfo = NULL;
	runav_stream_info_t	*pCurrentInfo;


	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	nCount = 0;
	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT && pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
	{
		pCurrentInfo = pNetCtrlHandle->pRunavStreamInfo;
		FLOW_DBG("(Current) prog_id=%d, video=%d, audio=%d, subtitle=%d  \n",
			pCurrentInfo->prog_id,
			pCurrentInfo->track_video,
			pCurrentInfo->track_audio,
			pCurrentInfo->track_subtitle);
		
		for(i=0;i<pNetCtrlHandle->nTotalProgram;i++)
		{
			pAvInfo = &pNetCtrlHandle->AvStreamInfo[i];
			FLOW_DBG("nTotalProgram=%d, nProId=%d, nType=%d, nAudioCout=%d  \n", 
				pNetCtrlHandle->nTotalProgram,
				pAvInfo->nProId,
				pAvInfo->nType,
				pAvInfo->nAudioCount);
			if(pAvInfo->nProId == pCurrentInfo->prog_id)
			{
				for(j=0;j<pAvInfo->nAudioCount;j++)
				{
					FLOW_DBG("j=%d, index=%d, nId=%d, track=%d, strLang=%s  \n",
						j,
						pAvInfo->AudioInfo[j].nIndex,
						pAvInfo->AudioInfo[j].nId,
						pAvInfo->AudioInfo[j].nTrack,
						pAvInfo->AudioInfo[j].strLang);
				}
				nCount = pAvInfo->nAudioCount;
			}
		}
	}

	return nCount;	
}

int NetCtrl_GetCurrentAudioIndex(char *pLang)
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					i, j, nSelected;
	AvStreamInfo			*pAvInfo = NULL;
	runav_stream_info_t	*pCurrentInfo;


	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	nSelected = -1;
	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT  && pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
	{
		pCurrentInfo = pNetCtrlHandle->pRunavStreamInfo;
		FLOW_DBG("(Current) nTotalProgram=%d, prog_id=%d, video=%d, audio=%d, subtitle=%d  \n",
			pNetCtrlHandle->nTotalProgram,
			pCurrentInfo->prog_id,
			pCurrentInfo->track_video,
			pCurrentInfo->track_audio,
			pCurrentInfo->track_subtitle);
		
		for(i=0;i<pNetCtrlHandle->nTotalProgram;i++)
		{
			pAvInfo = &pNetCtrlHandle->AvStreamInfo[i];
			FLOW_DBG("nProId=%d, nType=%d, nAudioCout=%d  \n", 
				pAvInfo->nProId,
				pAvInfo->nType,
				pAvInfo->nAudioCount);
			if(pAvInfo->nProId == pCurrentInfo->prog_id)
			{
				for(j=0;j<pAvInfo->nAudioCount;j++)
				{
					FLOW_DBG("j=%d, index=%d, nId=%d, track=%d, strLang=%s  \n",
						j,
						pAvInfo->AudioInfo[j].nIndex,
						pAvInfo->AudioInfo[j].nId,
						pAvInfo->AudioInfo[j].nTrack,
						pAvInfo->AudioInfo[j].strLang);

					if(pCurrentInfo->track_audio == pAvInfo->AudioInfo[j].nTrack)
					{
						printf("nSelected=%d,  Lang=%s \n", j, pAvInfo->AudioInfo[j].strLang);
						nSelected = j;
						strcpy(pLang, pAvInfo->AudioInfo[j].strLang);
						break;
					}
				}
			}
		}
	}

	return nSelected;	
}

void NetCtrl_SetAudioVideoFlag(BOOL bEnableAudio, BOOL bEnableVideo)
{
	NetCtrlHandle		*pNetCtrlHandle;
	unsigned long			nFlag;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d, nRunavOpt=%lx  \n", 
		pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay, pNetCtrlHandle->nRunavOpt);

	nFlag = 0;
	if(bEnableAudio == FALSE)
		nFlag |= RUNAV_AUDIO_DISABLE;

	if(bEnableVideo == FALSE)
		nFlag |= RUNAV_VIDEO_DISABLE;

	pNetCtrlHandle->nRunavOpt &= ~(RUNAV_AUDIO_DISABLE | RUNAV_VIDEO_DISABLE);
	pNetCtrlHandle->nRunavOpt |= nFlag;

}

#if 0
int MediaCtrl_SetAudioIndex(int nIndex, char *pLang)
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					i, j;//, nRet;
	AvStreamInfo			*pAvInfo = NULL;
	runav_stream_info_t	*pCurrentInfo;


	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	//nRet = 1;
	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT  && pNetCtrlHandle->nMediaMode == MEDIA_MOVIE)
	{
		pCurrentInfo = pNetCtrlHandle->pRunavStreamInfo;
		FLOW_DBG("(Current) nTotalProgram=%d, prog_id=%d, video=%d, audio=%d, subtitle=%d  \n",
			pNetCtrlHandle->nTotalProgram,
			pCurrentInfo->prog_id,
			pCurrentInfo->track_video,
			pCurrentInfo->track_audio,
			pCurrentInfo->track_subtitle);
		
		for(i=0;i<pNetCtrlHandle->nTotalProgram;i++)
		{
			pAvInfo = &pNetCtrlHandle->AvStreamInfo[i];
			FLOW_DBG("nProId=%d, nType=%d, nAudioCout=%d  \n", 
				pAvInfo->nProId,
				pAvInfo->nType,
				pAvInfo->nAudioCount);
			if(pAvInfo->nProId == pCurrentInfo->prog_id)
			{
/*			
				for(j=0;j<pAvInfo->nAudioCount;j++)
				{
					FLOW_DBG("j=%d, index=%d, nId=%d, strLang=%s   (arg idx=%d) \n",
						j,
						pAvInfo->AudioInfo[j].nIndex,
						pAvInfo->AudioInfo[j].nId,
						pAvInfo->AudioInfo[j].strLang,
						nIndex);
				}
*/				

				if( runav_stream_setidx(RUNAV_STREAM_TYPE_AUDIO, pAvInfo->AudioInfo[nIndex].nIndex) != 0 )
				{
					FLOW_ERR("Set Audio Stream Fail !!!\n");
					//nRet = -1;
				}
				else
				{
					FLOW_DBG("index=%d, nId=%d, track=%d, strLang=%s   (arg idx=%d)",
						pAvInfo->AudioInfo[nIndex].nIndex,
						pAvInfo->AudioInfo[nIndex].nId,
						pAvInfo->AudioInfo[nIndex].nTrack,
						pAvInfo->AudioInfo[nIndex].strLang,
						nIndex);
					strcpy(pLang, pAvInfo->AudioInfo[nIndex].strLang);
				}
			}
		}
	}



}

void MediaCtrl_ChannelUpDown(int nUpDown)
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					nRet;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d, nRunavOpt=%lx  \n", 
		pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay, pNetCtrlHandle->nRunavOpt);

	if(pNetCtrlHandle->bPlay == FALSE)
		return;

// Offset = 1, Next Channel
// Offset = -1, Previous Channel
// return 0 (Succsee),  return -1 (Fail)

	pthread_mutex_lock(&pNetCtrlHandle->MediaCmd_Mutex);

	nRet = runav_next_prog(nUpDown);

	pthread_mutex_unlock(&pNetCtrlHandle->MediaCmd_Mutex);

}
#endif
unsigned long NetCtrl_GetCurrentTime()
{
	NetCtrlHandle		*pNetCtrlHandle;
	unsigned int			nCurrentTime = 0;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	//FLOW_DBG("nMediaStatus=%d, bPlay=%d \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bPlay == FALSE)
		return 0;

	runav_getCurrentTime(&nCurrentTime);

	return (unsigned long)nCurrentTime;
}

long long NetCtrl_GetTotalTime()
{
	NetCtrlHandle		*pNetCtrlHandle;
	long long				nTotalTime = 0;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();

	if(pNetCtrlHandle->nMediaStatus >= MEDIA_INIT)
	{
		return pNetCtrlHandle->nTotalTime;
	}	

	return nTotalTime;
}

int NetCtrl_SeekTime(unsigned long nAbsSeconds)	// milliSecond
{
	NetCtrlHandle		*pNetCtrlHandle;
	int					nRet;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bPlay == FALSE)
		return -1;

	// return -1, if any error
	nRet = runav_seek(nAbsSeconds, RUNAV_SEEK_SET);

	return nRet;
}

void NetCtrl_GetPosition(unsigned long *nLow, unsigned long *nHigh)
{
	NetCtrlHandle		*pNetCtrlHandle;
	UINT64				n64Pos = 0;

	pNetCtrlHandle = NetCtrl_GetNetCtrlHandle();
	FLOW_DBG("nMediaStatus=%d, bPlay=%d  \n", pNetCtrlHandle->nMediaStatus, pNetCtrlHandle->bPlay);

	if(pNetCtrlHandle->bPlay == FALSE)
	{
		*nLow = *nHigh = 0;
		return;
	}	

	// return -1, if any error
	n64Pos = runav_get_fpos();

	*nLow = n64Pos & 0xffffffff;
	*nHigh = (n64Pos >> 32) & 0xffffffff;
}
#if 0
int MediaCtrl_Set(Net_Player_Set_e eSet, UINT32 dParam)
{
        int dRtnValue = 1;

        switch(eSet)
        {
                case NET_PLAYER_SET_AUDIOSTREAM:
                        //NET_AVPlayer_ChangeAudioStream(dParam);
                        break;

                case NET_PLAYER_SET_AUDIOCHANNEL:
                                             //NET_AVPlayer_ChangeAudioChannel(dParam);
                        break;

                case NET_PLAYER_SET_SUBPICONOFF:
                                                //NET_AVPlayer_SetCurrentSupicOnOff(dParam);
                	break;

                case NET_PLAYER_SET_SUBPICCHANGE:
                                            //NET_AVPlayer_ChangeSupicStream(dParam);
                	break;

        	case NET_PLAYER_SET_WMKLOCKRULE:
                      //AVP_IF_SetWMKLockRule();
                	break;

                case NET_PLAYER_SET_WMKUNLOCKRULE:
                      //AVP_IF_SetWMKUnLockRule();
                	break;

                default:
                        //net_avplayer_error();
                        break;
        }

        return dRtnValue;
}

int MediaCtrl_Get(Net_Player_Get_e eGet, UINT32 *dParam)
{
        int dRtnValue = 1;
	printf("MediaCtrl_Get in\n");
        switch(eGet)
        {
                case NET_PLAYER_GET_ELAPSEDTIME:
			*dParam = NetCtrl_GetCurrentTime()/1000;
                        //NET_AVPlayer_GetElapsedTime((void*)dParam);
                        break;
                case NET_PLAYER_GET_PLAYBACKINFO:
                {
			*dParam = NetCtrl_GetMediaStatus();
			printf("NET_PLAYER_GET_PLAYBACKINFO: dParam = %d\n", *dParam);
/*
                        AVPPlayBackInfo_t stInfo;
                        memset(&stInfo, 0, sizeof(AVPPlayBackInfo_t));
                        dRtnValue = AVP_IF_GetPlayBackInfo(&stInfo);
                        memcpy((void*)dParam, &stInfo, sizeof(AVPPlayBackInfo_t));
*/
                }
                break;
                case NET_PLAYER_GET_CURRENTAUDIOSTREAMNUM:
                        //NET_AVPlayer_GetCurrentAudioStream((void*)dParam);
                        break;
                case NET_PLAYER_GET_TOTALAUDIOSTREAMCOUNT:
                        //NET_AVPlayer_GetTotalAudioStreamCount((void*)dParam);
                        break;
                case NET_PLAYER_GET_CURRENTAUDIOCHANNELNUM:
                        //NET_AVPlayer_GetCurrentAudioChannel((void*)dParam);
                        break;
                case NET_PLAYER_GET_TOTALAUDIOCHANNELCOUNT:
                        //NET_AVPlayer_GetTotalAudioChannelCount((void*)dParam);
                        break;
                case NET_PLAYER_GET_PlaySpeed:
                        //NET_AVPlayer_GetSpeed((UINT32 *)dParam);
                        break;
                case NET_PLAYER_GET_AUDIOSTREAMATTRIBUTE:
                {
/*
                        Net_Player_AudStrmAttribute_t* pAudioAttr = (Net_Player_AudStrmAttribute_t*)dParam;
                        if (pAudioAttr != NULL)
                                NET_AVPlayer_GetAudioStreamAttribute(pAudioAttr->dAudStrmIdx, pAudioAttr->pstAudStrmAttribute);
*/
                }
                break;
                case NET_PLAYER_GET_CURRENTPOSITION://add by rui.l 0411
                        //NET_AVPlayer_GetElapsedPosition((UINT64 *)dParam);
                        break;
                case NET_PLAYER_GET_CURRENTTRACKSIZE://add by rui.l 0411
                        //NET_AVPlayer_GetFileTrackSize((UINT64 *)dParam);
                        break;

                case NET_PLAYER_GET_TOTALSUBPICCOUNT:
                                                //NET_AVPlayer_GetTotalSupicStreamCount((UINT32 *)dParam);
                        break;

                case NET_PLAYER_GET_CURSUBPICONOFF:
                                                //NET_AVPlayer_GetCurrentSupicOnOff((UINT32 *)dParam);
                	break;

                case NET_PLAYER_GET_CURSUBPICSTREAM:
                                                //NET_AVPlayer_GetCurrentSupicStreamNum((UINT32 *)dParam);
                	break;

                default:
                        //net_avplayer_error();
                	break;
        }

        return dRtnValue;
}

const Net_Player_Obj_t  stObjAVPlayer =
{
	NET_PLAYER_M_AV,

	NetCtrl_Initialize,
	NetCtrl_Finalize,
	NetCtrl_SetMediaInfo,
	NetCtrl_Play,
	NetCtrl_Stop,
	NetCtrl_Pause,
	NetCtrl_FastForward,
	NetCtrl_FastRewind,
	MediaCtrl_Goto,
	MediaCtrl_Next,
	MediaCtrl_Prev,
	MediaCtrl_Set,
	MediaCtrl_Get				
};
#endif
/*
iMedia_Controller gMovieController =
{
	.pFunc_SetNotificationCBFunc = NetCtrl_SetNotificationFunc,
	.pFunc_SetMediaMode = NetCtrl_SetMediaMode,
        .pFunc_QueryStatus = NetCtrl_GetMediaStatus,
        .pFunc_Init = NetCtrl_Init,
        .pFunc_Exit = NetCtrl_Exit,
        .pFunc_SetDataSource = NetCtrl_SetDataSource,
        .pFunc_GetFilmInfo = NetCtrl_GetFilmInfo,
        .pFunc_Play = NetCtrl_Play,
        .pFunc_Pause = NetCtrl_Pause,
        .pFunc_Stop = NetCtrl_Stop,
        .pFunc_FastForward = NetCtrl_FastForward,
        .pFunc_FastRewind = NetCtrl_FastRewind, 
        .pFunc_SetSubtitleOff = NetCtrl_SetSubtitleOff,
        .pFunc_SetSubtitleIndex = NetCtrl_SetSubtitleIndex,
        .pFunc_SetAudioVideoFlag = NetCtrl_SetAudioVideoFlag,
        .pFunc_SetAudioIndex = MediaCtrl_SetAudioIndex,
        .pFunc_ChannelUpDown = MediaCtrl_ChannelUpDown,
        .pFunc_GetCurrentTime = NetCtrl_GetCurrentTime,
        .pFunc_SeekTime = NetCtrl_SeekTime,
        .pFunc_GetPosition = NetCtrl_GetPosition,

	.pFunc_SetRotate = NULL;
	.pFunc_SetZoom = NULL;
	.pFunc_SetPan = NULL;	
	
};
*/

