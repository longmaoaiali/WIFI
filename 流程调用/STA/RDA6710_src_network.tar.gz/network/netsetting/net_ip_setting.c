#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <netinet/in.h>
#include <linux/route.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netsetting/netsetting_if.h>
#include "net_ip_setting.h"
#include "net_llctrl.h"




BOOL MID_NWSI_IsValidConnectType(E_MID_NWSI_CONNECT_TYPE type)
{

    if(type >= E_MID_NWSI_CONNECT_TYPE_ETHERNET && type<= E_MID_NWSI_CONNECT_TYPE_WIRELESS)
        return TRUE;
    
    return FALSE;
}

static INT8 * _net_getIFName(E_MID_NWSI_CONNECT_TYPE type)
{
        if(type == E_MID_NWSI_CONNECT_TYPE_ETHERNET)
            return "eth0";
        else if(type == E_MID_NWSI_CONNECT_TYPE_WIRELESS)
            return "wlan0";
        else 
            return NULL;
}

static int net_TransIPFormat(INT8 IPstr[16], MID_NWSI_IPv4_Addr_t* IP) 
{
    UINT8 i=0,tmp = 0;
    INT8 *pos;
    INT8 *dot = ".";
    BOOL valid = TRUE;
    INT8 tmpIPstr[16], *IPtoken;
    INT32 IPint = -1;
    INT8 *pIP;
    MID_NWSI_IPv4_Addr_t* IPset;

    DEBF("===>[%s]\n",__FUNCTION__);

    memset(IP, 0, sizeof(MID_NWSI_IPv4_Addr_t));
    IPset = (MID_NWSI_IPv4_Addr_t*)malloc(sizeof(MID_NWSI_IPv4_Addr_t));
    strcpy(tmpIPstr,IPstr); // strsep will seperate the original string
    pIP = tmpIPstr;

    for(i=0;i<3;i++) // ip example: 192.168.150.1
    {
        pos = strstr(&IPstr[tmp],dot);

        if(pos == NULL)
        {
            DEBF("IP illeagal.\n");
            valid = FALSE;
            free(IPset);
            return E_FAIL;
        }
        else
        {
            IPtoken = strsep(&pIP,dot);

            IPint = atoi(IPtoken);

            if(IPint <0 || IPint >255 || !(strcmp(IPtoken,"")))
            {
                DEBF("[NET] IP value illeagl.\n");
                valid = FALSE;
                free(IPset);
                return E_FAIL;
            }
            else
            {

                tmp = (pos-IPstr)+1;
                DEBF(" === [%s ,%d] ===\n",__FUNCTION__,__LINE__);
                switch(i)
                {
                    case 0:
                        IPset->A = IPint;
                        break;
                    case 1:
                        IPset->B = IPint;
                        break;
                    case 2:
                        IPset->C = IPint;
                        break;
                    default:
                        break;
                }

            }

        }

    }

    if(valid)
    {
        IPtoken = strsep(&pIP,dot);
        IPint = atoi(IPtoken);
        if(IPint <0 || IPint >255 || !(strcmp(IPtoken,"")))
        {
            DEBF("[NET] IP value illeagl.\n");
            valid = FALSE;
            free(IPset);
            return E_FAIL;
        }
        else
        {
            IPset->D = IPint;
            memcpy(IP , IPset, sizeof(MID_NWSI_IPv4_Addr_t));
            DEBF(" IP parse success !! \n");
        }
    }
    free(IPset);
    DEBF("[%s]<===\n",__FUNCTION__);    
    return S_OK;

}

INT32 MID_NWSI_GetIFIndex(E_MID_NWSI_CONNECT_TYPE type)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct ifreq ifr;
    INT32 retval;

    DEBF("===%s===\n", __FUNCTION__);

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;

    ifname = _net_getIFName(type);
    if((sockfd = socket(AF_INET, SOCK_DGRAM,0)) < 0)
    {
        perror("Socket fail");
        return E_FAIL;
    }

    memset(&ifr, 0, sizeof(ifr));
    strcpy(ifr.ifr_name, ifname);
    retval = ioctl(sockfd, SIOCGIFINDEX, &ifr);    
    if(retval < 0) {        
        perror("@@ SIOCGIFINDEX");
        DEBF("@@ Can't find network interface!\n");
        close(sockfd);        
        return E_FAIL;  
    }     
    close(sockfd);

    return ifr.ifr_ifindex;
}

INT32 MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE type, BOOL bUp)
{
    INT8 *ifname;
  INT32 sockfd;
  struct ifreq ifr;


    DEBF("[set_if_up]type =%d, bUp =%d\n", type, bUp);
    if(! MID_NWSI_IsValidConnectType(type))
        return E_FAIL;

    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) <0) {
        perror("Socket fail");
        return E_FAIL;
    }
    
    memset(&ifr, 0, sizeof(struct ifreq));
    ifname =_net_getIFName(type);
    strcpy(ifr.ifr_name, ifname);
    
    /*get current status*/
    if(ioctl(sockfd, SIOCGIFFLAGS, &ifr) != 0)
    {
        perror("ioctl- get flags fail");   
        close(sockfd);
        return E_FAIL; 
    }

    if(bUp)
    {
        ifr.ifr_flags |= (IFF_UP | IFF_RUNNING);
    }
    else
    {
        ifr.ifr_flags &= ~(IFF_UP | IFF_RUNNING);
    }

    if(ioctl(sockfd, SIOCSIFFLAGS, &ifr) != 0)
    {
        perror("ioctl- set flags fail");    
        close(sockfd);
        return E_FAIL; 
    }
    
    close(sockfd);
    return S_OK;
}

//IP
INT32 MID_NWSI_SetIP(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t addr)
{
    INT8 *ifname = NULL;
    INT32 sockfd ;
    struct ifreq ifr;
    struct sockaddr_in saddr;
    INT8 ip_buf[16];

    if(! MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
    
    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) <0) {
        perror("Socket fail");
        return E_FAIL;
    }
    
    memset(&ifr, 0, sizeof(struct ifreq));
    memset(&saddr, 0, sizeof(struct sockaddr_in));
    memset(ip_buf,0, sizeof(ip_buf));

    ifname = _net_getIFName(type);
    sprintf(ip_buf, "%d.%d.%d.%d", addr.A, addr.B, addr.C, addr.D);
        
    DEBF("[set_ip] ipbuf =%s\n", ip_buf);

        strcpy(ifr.ifr_name, ifname);

    saddr.sin_family = AF_INET;
    if(inet_aton(ip_buf, &saddr.sin_addr) == 0)
    {
            DEBF("[set_ip]- @@ ip inet_aton conversion fail !\n");
    }

    memcpy(&ifr.ifr_addr, &saddr, sizeof(struct sockaddr_in));
    if(ioctl(sockfd, SIOCSIFADDR, &ifr) < 0)
    {
        close(sockfd);
        perror("@@ SIOCSIFADDR");
        return E_FAIL;
    }
    
    close(sockfd);

    return S_OK;
}

INT32 MID_NWSI_GetIP(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t *paddr)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct ifreq ifr;
    struct sockaddr_in saddr;

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
    
    if(!paddr)
        return E_FAIL;

    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) <0) {
        perror("Socket fail");
        return E_FAIL;
    }

    memset(&ifr,0, sizeof(struct ifreq));
    memset(&saddr, 0, sizeof(struct sockaddr_in));

    ifname = _net_getIFName(type);
    strcpy(ifr.ifr_name, ifname);
    saddr.sin_family = AF_INET;
    memcpy(&ifr.ifr_addr, &saddr, sizeof(struct sockaddr_in));

    if(ioctl(sockfd, SIOCGIFADDR, &ifr) <0) 
    {
            close(sockfd); 
            perror("@@ SIOCGIFADDR");
        return E_FAIL;
    }
    
    close(sockfd);
    memcpy(paddr, &(ifr.ifr_addr.sa_data[2]), 4);

    DEBF("[get_ip] IP=%d.%d.%d.%d\n",paddr->A, paddr->B, paddr->C, paddr->D);
    
    return S_OK;
}
//Netmask
INT32 MID_NWSI_SetNetmask(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t addr)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct ifreq ifr;
    struct sockaddr_in saddr;
    INT8 mask_buf[16];

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
    
    
    if( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
    {
        perror("Socket fail");
        return E_FAIL;
    }

    memset(&ifr, 0, sizeof(struct ifreq));
    memset(&saddr, 0, sizeof(struct sockaddr_in));
    memset(mask_buf, 0, sizeof(mask_buf));

    ifname = _net_getIFName(type);
    
    sprintf(mask_buf,"%d.%d.%d.%d", addr.A, addr.B, addr.C, addr.D);
    DEBF("[get_ip] mask_buf =%s\n", mask_buf);
    strcpy(ifr.ifr_name, ifname);
    saddr.sin_family = AF_INET;
    
    if(inet_aton(mask_buf, &saddr.sin_addr) == 0)
    {
        DEBF("[get_ip] @@ netmask inet_aton conversion fail!\n");
    }

    memcpy(&ifr.ifr_netmask, &saddr, sizeof(struct sockaddr_in));

    if(ioctl(sockfd, SIOCSIFNETMASK, &ifr) <0) {
        close(sockfd);
        perror("@@ SIOCSIFNETMASK");
        return E_FAIL;
    }

    close(sockfd);

    return S_OK;
}

INT32 MID_NWSI_GetNetmask(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t *paddr)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct ifreq ifr;
    struct sockaddr_in saddr;

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
   
    if(!paddr)
        return E_FAIL;
    
    if( (sockfd = socket(AF_INET, SOCK_DGRAM,0)) <0)
    {
        perror("Socket fail");
        return E_FAIL;
    }

    memset((void *)&ifr, 0, sizeof(struct ifreq));
    memset((void *)&saddr, 0, sizeof(struct sockaddr_in));

    ifname = _net_getIFName(type);
    strcpy(ifr.ifr_name, ifname);
    saddr.sin_family = AF_INET;
    memcpy(&ifr.ifr_addr, &saddr, sizeof(struct sockaddr_in));


    if(ioctl(sockfd, SIOCGIFNETMASK, &ifr) < 0)
    {
        close(sockfd); 
        perror("@@ SIOCGIFNETMASK");
        return E_FAIL;
    }

    close(sockfd);
    memcpy(paddr, &ifr.ifr_netmask.sa_data[2],4);

    DEBF("[get_netmask] netmask=%d.%d.%d.%d\n", paddr->A, paddr->B, paddr->C, paddr->D);
    
    return S_OK;
}

//Gateway
INT32 MID_NWSI_SetGateway(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t addr)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct rtentry rt;
    struct sockaddr_in saddr;
    INT8 gateway_buf[16];

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
    
    
    if( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) <0)
    {
        perror("Socket fail");
        return E_FAIL;
    }

    memset(&rt, 0, sizeof(struct rtentry));
    memset(&saddr, 0, sizeof(struct sockaddr_in));
    memset(gateway_buf, 0, sizeof(gateway_buf));

    ifname = _net_getIFName(type);
 
    sprintf(gateway_buf, "%d.%d.%d.%d", addr.A, addr.B, addr.C, addr.D);
    saddr.sin_family = AF_INET;

    /*set destination addr*/
    inet_aton("0.0.0.0", &saddr.sin_addr);   
    memcpy(&rt.rt_dst, &saddr, sizeof(struct sockaddr_in));  
    /*set gateway addr*/
    if(inet_aton(gateway_buf, &saddr.sin_addr) == 0)
    {
        DEBF("[set_gateway]@@ gateway inet_aton conversion fail!\n");
    }   
    memcpy(&rt.rt_gateway, &saddr, sizeof(struct sockaddr_in));
    /*set genmask addr*/
    inet_aton("0.0.0.0", &saddr.sin_addr);
    memcpy(&rt.rt_genmask, &saddr, sizeof(struct sockaddr_in));

    rt.rt_dev = ifname;
    //rt.rt_flags = RTF_GATEWAY | RTF_DEFAULT;
    rt.rt_flags = RTF_GATEWAY;
    if(ioctl(sockfd, SIOCADDRT, &rt) <0)
    {
        close(sockfd);
        if(strstr(strerror(errno),"File exists") == NULL)
        {
            DEBF("[set_gateway]@@ ioctl SIOCADDRT failed : %s!\n",strerror(errno));
            return E_FAIL;
        }
        else
        {
            DEBF("[set_gateway] Set gateway OK!\n");
            return S_OK; 
        }  
    }
    close(sockfd);

    return S_OK;
}

INT32 MID_NWSI_GetGateway(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_IPv4_Addr_t *paddr)
{

    INT8 tmp[100],iface[10],desAddr[10],gateAddr[10];
    INT8 tmpStr[3];
    FILE *fp;
    MID_NWSI_IPv4_Addr_t *pGateway;
    UINT8 i = 0;
    BOOLEAN valid = FALSE;



    fp= fopen("/proc/net/route","r");
    if(fp)
    {
        fgets(tmp, 100, fp); // Skip title
        pGateway = (MID_NWSI_IPv4_Addr_t *)malloc(sizeof(MID_NWSI_IPv4_Addr_t));
        
        if(pGateway)
        {
        	memset(pGateway, 0, sizeof(MID_NWSI_IPv4_Addr_t));	
        }
        
        while(fgets(tmp, 100, fp) != '\0')
        {
            memset(iface, 0 ,10);
            memset(desAddr, 0 ,10);
            memset(gateAddr, 0 ,10);
            if((sscanf(tmp, "%9s %9s %9s",iface, desAddr, gateAddr) == 3) && 
                    (strcmp( desAddr, "00000000" ) == 0) && (strcmp( gateAddr, "00000000" ) != 0))
            {
                for( i =0; i<4; i++) // mask example : FE01A8C0 (192.168.1.254)
                {
                    memset(tmpStr, 0, sizeof(tmpStr));
                    memcpy(tmpStr,&gateAddr[i*2] , 2);

                    if(strcmp(tmpStr,"")==0)
                    {
                        DEBF("Get mask address invalid!!\n");
                        free(pGateway);
						fclose(fp);
                        return E_FAIL;
                    }
                    else
                    {
                        switch(i)
                        {
                            case 0:
                                pGateway->D= (UINT8)strtol(tmpStr, NULL, 16);
                                break;
                            case 1:
                                pGateway->C = (UINT8)strtol(tmpStr, NULL, 16);
                                break;
                            case 2:
                                pGateway->B = (UINT8)strtol(tmpStr, NULL, 16);
                                break;
                            case 3:
                                pGateway->A = (UINT8)strtol(tmpStr, NULL, 16);
                                valid = TRUE;
                                break;
                            default:
                                DEBF(" === [Wrong gateway address.] ===\n");
                                break;
                        }
                    }
                }
            }

            else
            {   
                //printf("%s",tmp);
                continue;
            }

        }

        if(valid)
        {
            DEBF("Catch gateway address SUCCESS!!\n");
            memcpy(paddr, pGateway, sizeof(MID_NWSI_IPv4_Addr_t));
        }
        else
        {
            DEBF("Catch gateway address FAIL!!\n");
            fclose(fp);
            free(pGateway);
            return E_FAIL;
        }

		fclose(fp);
	}
    else // !fp
    {
        DEBF(" Open /proc/net/route fail !!\n");
        return E_FAIL;
    }
    free(pGateway);

    return S_OK;
}

//DNS
INT32 MID_NWSI_SetDNS(MID_NWSI_IPv4_Addr_t dns1, MID_NWSI_IPv4_Addr_t dns2)
{
    FILE *fp = NULL;
    INT8 dns1_buf[64];
    INT8 dns2_buf[64];

    
    DEBF("===== %s ====== \n", __FUNCTION__);
    
    fp = fopen("/etc/resolv.conf","w+");
    if(fp)
    {
        sprintf(dns1_buf, "%d.%d.%d.%d", dns1.A, dns1.B, dns1.C, dns1.D);
        sprintf(dns2_buf, "%d.%d.%d.%d", dns2.A, dns2.B, dns2.C, dns2.D);    
        DEBF("dns1=%s, dns2=%s\n", dns1_buf, dns2_buf);
        fprintf(fp, "%s %s \n", "nameserver", dns1_buf);
        fprintf(fp, "%s %s \n", "nameserver", dns2_buf);
        fsync(fileno(fp));
        fclose(fp);
    }
    else
    {
        DEBF( "@@ Set DNS fail!\n");
        return E_FAIL;
    }
  
    return S_OK;

}

INT32 MID_NWSI_GetDNS(MID_NWSI_IPv4_Addr_t *pdns1, MID_NWSI_IPv4_Addr_t *pdns2)
{

    FILE *fp = NULL;
    INT8 tmp[100],tmpStr1[20],tmpStr2[20];
    INT8 tmpIP[16];
    INT32  numDNS = 0;
    MID_NWSI_IPv4_Addr_t dns1, dns2;
    MID_NWSI_IPv4_Addr_t addr;
    fp = fopen("/etc/resolv.conf", "r");

    if(!pdns1 || !pdns2)
    {	
    	fclose(fp);
    	return E_FAIL;
    }
    memset(&dns1, 0, sizeof(MID_NWSI_IPv4_Addr_t));
    memset(&dns2, 0, sizeof(MID_NWSI_IPv4_Addr_t));

    memset(pdns1, 0, sizeof(MID_NWSI_IPv4_Addr_t));
    memset(pdns2, 0, sizeof(MID_NWSI_IPv4_Addr_t));
    if(fp)
    {
        fgets(tmp, 100, fp);

        do {
            sscanf(tmp, "%19s %19s", tmpStr1, tmpStr2);
            if(strcmp(tmpStr1, "nameserver") == 0)
            {
                strncpy(tmpIP, tmpStr2, 16);
                if(net_TransIPFormat(tmpIP, &addr) == S_OK)
                {
                    numDNS++;
                    if(numDNS == 1)
                    {
                        memcpy(&dns1, &addr, sizeof(MID_NWSI_IPv4_Addr_t));
                        memcpy(pdns1, &addr, sizeof(MID_NWSI_IPv4_Addr_t));
                    }
                    else if(numDNS == 2)
                    {   
                        memcpy(&dns2, &addr, sizeof(MID_NWSI_IPv4_Addr_t));
                        memcpy(pdns2, &addr, sizeof(MID_NWSI_IPv4_Addr_t));
                        break;//skip loop
                    }
                }
            }

        }while(fgets(tmp, 100 ,fp) != NULL);
    }
    else
    {
        DEBF("[get_dns]open /etc/resolv.conf fail !!\n");
        return E_FAIL;
    }
    fclose(fp);

    DEBF("[get_dns]dns1 = %d.%d.%d.%d\n", dns1.A, dns1.B, dns1.C, dns1.D);
    DEBF("[get_dns]dns2 = %d.%d.%d.%d\n", dns2.A, dns2.B, dns2.C, dns2.D);

    return S_OK;
}

//MTU
INT32 MID_NWSI_GetMTU(E_MID_NWSI_CONNECT_TYPE type)
{

    struct ifreq ifr;
    INT32 sockfd; 
    INT8 *ifname = NULL;
    INT32 mtu = 0;

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;

    ifname = _net_getIFName(type);

    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
        return 0;
    }

    ifr.ifr_addr.sa_family = AF_INET;
    strcpy(ifr.ifr_name, ifname);
    if (ioctl(sockfd, SIOCGIFMTU, (caddr_t)&ifr) < 0)
    {   
        close(sockfd);
        fprintf(stderr,"get mtu failed\n");
        return 0;
    }

    DEBF("MTU of %s is %d.\n", ifname, ifr.ifr_mtu);
    close(sockfd);
    
    mtu = ifr.ifr_mtu;
    return mtu;
}

//MAC
INT32 MID_NWSI_GetMAC(E_MID_NWSI_CONNECT_TYPE type, MID_NWSI_MAC_Addr_t *pmac)
{
    INT8 *ifname = NULL;
    INT32 sockfd;
    struct ifreq ifr;

    DEBF("===%s===\n", __FUNCTION__);

    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;

    if(!pmac)
    {
        DEBF("@@ Not allocate memory for MAC address buffer!\n");
        return E_FAIL;
    }
    

    ifname = _net_getIFName(type);
    memset(pmac, 0, sizeof(MID_NWSI_MAC_Addr_t));

    if((sockfd = socket(AF_INET, SOCK_DGRAM,0)) < 0)
    {
        perror("Socket fail");
        return E_FAIL;
    }

    memset(&ifr, 0, sizeof(ifr));

    strcpy(ifr.ifr_name, ifname);

    if(ioctl(sockfd, SIOCGIFHWADDR, &ifr) < 0)
    {
        close(sockfd);
        perror("@@ SIOCGIFADDR");
        return E_FAIL;
    }

    close(sockfd);

    memcpy(pmac, &(ifr.ifr_hwaddr.sa_data[0]), 6);

    DEBF("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x\n",
            pmac->A,
            pmac->B,
            pmac->C,
            pmac->D,
            pmac->E,
            pmac->F);

    return S_OK;

}

UINT8 MID_NWSI_GetIFFlag(E_MID_NWSI_CONNECT_TYPE type)
{
    UINT8 ifflag= E_MID_NWSI_IF_OFF;
    INT32 sockfd = 0;
    INT8 *ifname = NULL;
    struct ifreq ifr;

    if(!MID_NWSI_IsValidConnectType(type))
        return ifflag;
    
    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) <0)
    {
        fprintf(stderr,"socket create failed\n");    
        return ifflag; // link status error     
    }

    ifname = _net_getIFName(type);

    memset((void *)&ifr, 0, sizeof(struct ifreq));
    strcpy(ifr.ifr_name, ifname);
    if(ioctl(sockfd, SIOCGIFFLAGS, &ifr) <0)
    {
        close(sockfd);
        return ifflag;
    }

    if(ifr.ifr_flags & IFF_RUNNING)
    {
        ifflag |= E_MID_NWSI_IF_RUNNING; 
    }

    if(ifr.ifr_flags & IFF_UP)
    {
        ifflag |= E_MID_NWSI_IF_UP;     
    }

    if(sockfd)
        close(sockfd);

    return ifflag;
}


