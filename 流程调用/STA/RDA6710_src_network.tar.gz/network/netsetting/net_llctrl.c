#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "types.h"
#include <netsetting/netsetting_if.h>
#include "net_llctrl.h"
#include "net_ip_setting.h"

//----------- double link list function
UINT8 _MID_NWSI_isHeadNode_(MID_NWSI_APNode_t *node)
{
    return (node !=NULL) && (node->prev == NULL) && (node->next != NULL);
}

UINT8 _MID_NWSI_isInternalNode_(MID_NWSI_APNode_t *node)
{
    return (node != NULL) && (node->prev!=NULL) && (node->next != NULL);
}

UINT8 _MID_NWSI_isTailNode_(MID_NWSI_APNode_t *node)
{

    return (node != NULL) && (node->prev!=NULL) && (node->next == NULL);
}

UINT8 MID_NWSI_Init_List(MID_NWSI_APList_t *list)
{
    list->head.prev = NULL;
    list->head.next = &list->tail;
    list->tail.prev = &list->head;
    list->tail.next = 0;
    list->apNum = 0;

    return 1;
}

UINT8 _MID_NWSI_isEmpty_(MID_NWSI_APList_t *list)
{
    return (list != NULL) && (list->head.next == &list->tail);    
}

MID_NWSI_APNode_t *_MID_NWSI_First_Node_(MID_NWSI_APList_t *list)
{
    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    return list->head.next;
}

MID_NWSI_APNode_t *_MID_NWSI_Last_Node_(MID_NWSI_APList_t *list)
{
    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    return list->tail.prev;
}

void _MID_NWSI_Append_List_(MID_NWSI_APNode_t *before, MID_NWSI_APNode_t *node)
{
    if(before->next != NULL)
        before->next->prev = node;

    node->prev = before;
    node->next = before->next;
    before->next = node;
}

void _MID_NWSI_Insert_Front_(MID_NWSI_APList_t *list, MID_NWSI_APNode_t *node)
{
    _MID_NWSI_Append_List_(&list->head, node);
}

void _MID_NWSI_Insert_Rear_(MID_NWSI_APList_t *list, MID_NWSI_APNode_t *node)
{
    _MID_NWSI_Append_List_(list->tail.prev, node);
}

void _MID_NWSI_Remove_Node_(MID_NWSI_APNode_t *node)
{
    if(_MID_NWSI_isInternalNode_(node)){
        node->prev->next = node->next;
        node->next->prev = node->prev;
        node->next = NULL;
        node->prev = NULL;
    }

}

MID_NWSI_APNode_t *_MID_NWSI_Remove_FirstNode_(MID_NWSI_APList_t *list)
{
    MID_NWSI_APNode_t *node = _MID_NWSI_First_Node_(list);

    if(node != NULL)
    {
        _MID_NWSI_Remove_Node_(node);
        //list->apNum --;
    }
    return node;
}

MID_NWSI_APNode_t *_MID_NWSI_Remove_LastNode_(MID_NWSI_APList_t *list)
{
    MID_NWSI_APNode_t *node = _MID_NWSI_Last_Node_(list);
    if(node != NULL)
    {
        _MID_NWSI_Remove_Node_(node);
    }

    return node;
}   

MID_NWSI_APNode_t *MID_NWSI_GetListFirstAPData(MID_NWSI_APList_t *list)
{
    if(!list)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    return (list->head.next != NULL)?list->head.next  : NULL ;
}

MID_NWSI_APNode_t *MID_NWSI_GetListLastAPdata(MID_NWSI_APList_t *list)
{
    if(!list)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    return (list->tail.prev != NULL)?list->tail.prev  :  NULL ;
}

MID_NWSI_APNode_t *MID_NWSI_GetListNextAPNode(MID_NWSI_APList_t *list, MID_NWSI_APNode_t *before)
{
    MID_NWSI_APNode_t *ptmpNode = NULL;
    if(!list)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    if(!before)
        return list->head.next;


    ptmpNode = before->next;

    return (ptmpNode != &list->tail) ? ptmpNode : NULL;

}

MID_NWSI_APNode_t *MID_NWSI_GetListPrevAPNode(MID_NWSI_APList_t *list, MID_NWSI_APNode_t *next)
{
    MID_NWSI_APNode_t *ptmpNode = NULL;

    if(!list)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    if(!next) //return last node
        return list->tail.prev;

    ptmpNode = next->prev;

    return (ptmpNode != &list->head) ? ptmpNode : NULL;

}

void MID_NWSI_RemoveAPfromListByName(MID_NWSI_APList_t *list, INT8 *pName)
{
    MID_NWSI_APNode_t *ptmpNode ;

    if(!list || !pName)
        return ;

    ptmpNode = MID_NWSI_FindAPInListByName(list, pName);
    
    if(ptmpNode)
    {
        _MID_NWSI_Remove_Node_(ptmpNode);
        if(ptmpNode->data)
            free(ptmpNode->data);
        free(ptmpNode); 
        list->apNum--;
    }
}

void MID_NWSI_RemoveAPNodefromList(MID_NWSI_APList_t *list, MID_NWSI_APNode_t *pNode)
{

    if(!list || !pNode)
        return ;

    if(pNode)
    {
        _MID_NWSI_Remove_Node_(pNode);
        if(pNode->data)
            free(pNode->data);
        free(pNode); 
        list->apNum--;
    }
}

void MID_NWSI_DisplayList(MID_NWSI_APList_t *list)
{
    MID_NWSI_APNode_t *ptmpNode;
    DEBF(" ====> %s\n",__FUNCTION__);
    DEBF("head - %p, prev = %p, next = %p, data = %p \n",&list->head, list->head.prev, list->head.next, list->head.data);
    ptmpNode = list->head.next;
    while(ptmpNode != &list->tail)
    {
        DEBF("inte - %p, prev =%p, next = %p, data = %p\n", ptmpNode, ptmpNode->prev, ptmpNode->next, ptmpNode->data);
        DEBF("      data - name =%s, channl = %d, quality = %d, encryption = 0x%08x, mac =[%02x:%02x:%02x:%02x:%02x:%02x], st=0x%08x \n",
                ptmpNode->data->APName, ptmpNode->data->APChannel, ptmpNode->data->APQuality, ptmpNode->data->APEncryption, 
                ptmpNode->data->APMAC.A, ptmpNode->data->APMAC.B,ptmpNode->data->APMAC.C, ptmpNode->data->APMAC.D, ptmpNode->data->APMAC.E, ptmpNode->data->APMAC.F, ptmpNode->state);
        ptmpNode = ptmpNode->next;
    }
    DEBF("tail - %p, prev = %p, next = %p,data = %p\n",&list->tail, list->tail.prev, list->tail.next, list->tail.data);
     DEBF("<==== %s\n",__FUNCTION__);

}

INT32 MID_NWSI_AddAPDataToList(MID_NWSI_APList_t *list, MID_NWSI_APData_t *data)
{
    MID_NWSI_APNode_t *apNode = NULL;
    MID_NWSI_APData_t *pData = NULL;
    if(!list || !data)
        return E_FAIL;
#if 0
    printf("list = %p\n", list);
    printf("-----print data start -----\n");
    printf("APName = %s\n",data->APName);
    printf("APChannel = %d\n",data->APChannel);
    printf("APQuality = %d\n",data->APQuality);
    printf("APEncryption = %#x\n",data->APEncryption);
    printf("APMAC = [0x%02x:0x%02x:0x%02x:0x%02x:0x%02x:0x%02x] \n",
            data->APMAC.A, data->APMAC.B, data->APMAC.C,data->APMAC.D, data->APMAC.E, data->APMAC.F);

    printf("-----print data end -----\n");

#endif
    apNode = (MID_NWSI_APNode_t *)malloc(sizeof(MID_NWSI_APNode_t));
    pData = (MID_NWSI_APData_t *)malloc(sizeof(MID_NWSI_APData_t));
    if(!apNode || !pData )
    {
        if(apNode)
            free(apNode);
        if(pData)
            free(pData);
        return E_FAIL;
    } 

    memcpy(pData, data, sizeof(MID_NWSI_APData_t));
    apNode->prev = apNode->next = NULL;
    apNode->state = E_MID_NWSI_AP_STATE_NEW;
    apNode->data= pData;
    _MID_NWSI_Insert_Rear_(list, apNode);
    list->apNum ++;
    //MID_NWSI_DisplayList(list);
    return S_OK;
}

INT32 MID_NWSI_DestroyList(MID_NWSI_APList_t *list)
{

    MID_NWSI_APNode_t *ptmpNode = NULL;

    if(!list)
        return E_FAIL;

    while((ptmpNode = _MID_NWSI_Remove_FirstNode_(list))!= NULL)
    {
        if(ptmpNode->data)
            free(ptmpNode->data);
        free(ptmpNode);
        //MID_NWSI_DisplayList(list);
        list->apNum --;
    }

    return S_OK;
}

INT32 MID_NWSI_ResetALLAPStateInList(MID_NWSI_APList_t *list)
{
    MID_NWSI_APNode_t *ptmpNode = NULL;

    if(!list)
        return E_FAIL;

    if(_MID_NWSI_isEmpty_(list))
        return S_OK;

    ptmpNode = list->head.next;

    while(ptmpNode != &list->tail)
    {
        ptmpNode->state = E_MID_NWSI_AP_STATE_NOT_EXIST;
        ptmpNode = ptmpNode->next;
    }

    return S_OK;
}

INT32 MID_NWSI_UpdateAPNodeData(MID_NWSI_APNode_t *pAPNode, MID_NWSI_APData_t *pApdata)
{
    if(!pAPNode)
        return E_FAIL;


    pAPNode->state = E_MID_NWSI_AP_STATE_OLD;

    if(pApdata)
        memcpy(pAPNode->data, pApdata, sizeof(MID_NWSI_APData_t));

    return S_OK;
}

MID_NWSI_APNode_t *MID_NWSI_FindAPInListByName(MID_NWSI_APList_t *list, INT8 *pName)
{
    MID_NWSI_APNode_t *ptmpNode = NULL, *pMatchNode = NULL;


    if(!list)
        return NULL;
    if(!pName)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    ptmpNode = list->head.next;

    while(ptmpNode != &list->tail)
    {

        if(strcmp(ptmpNode->data->APName, pName) == 0)
        {
            pMatchNode = ptmpNode;
            break;
        }
        ptmpNode = ptmpNode->next;
    }


    return pMatchNode;
}

MID_NWSI_APNode_t *MID_NWSI_FindAPInListByBSSID(MID_NWSI_APList_t *list, MID_NWSI_MAC_Addr_t *pMac)
{
    MID_NWSI_APNode_t *ptmpNode = NULL, *pMatchNode = NULL;


    if(!list)
        return NULL;
    if(!pMac)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    ptmpNode = list->head.next;

    while(ptmpNode != &list->tail)
    {

        if(!memcmp(&ptmpNode->data->APMAC, pMac, sizeof(MID_NWSI_MAC_Addr_t)))
        {
            pMatchNode = ptmpNode;
            break;
        }
        ptmpNode = ptmpNode->next;
    }


    return pMatchNode;
}

MID_NWSI_APNode_t *MID_NWSI_FindAPInListBySSID(MID_NWSI_APList_t *list, INT8* ssid, INT8 quality, UINT8 *bUpdate)
{
    MID_NWSI_APNode_t *ptmpNode = NULL, *pMatchNode = NULL;
	if(!bUpdate)
        return NULL;
    if(!list)
        return NULL;
    if(!ssid)
        return NULL;

    if(_MID_NWSI_isEmpty_(list))
        return NULL;

    ptmpNode = list->head.next;

    while(ptmpNode != &list->tail)
    {
        if( strlen(ssid)==strlen(ptmpNode->data->APName) &&
			!memcmp(&ptmpNode->data->APName, ssid, strlen(ssid)))
        {
			pMatchNode = ptmpNode;
			if(ptmpNode->data->APQuality >= quality)
				*bUpdate = TRUE;
			else
				*bUpdate = FALSE;
			break;
		}
        ptmpNode = ptmpNode->next;
    }


    return pMatchNode;
}
//----------------
