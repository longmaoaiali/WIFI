#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/fcntl.h>
#include <gsl/gl_timer.h>
#include <gsl/gl_mutex.h>
#include <gsl/gl_sema.h>
#include <gsl/gl_task.h>
#include "netsetting_if.h"
#include "net_ip_setting.h"
#include "net_llctrl.h"
#include "mid_partition_list.h"
#include <dirent.h> // DIR need

#define CONFIG_WIRELSEE 1

typedef struct _ap_pwd_data_{
    INT8 name[33];
    UINT8 entype;
    INT32 keylen;
    INT8 *pkey;
}AP_Pwd_Data;

typedef enum {
    e_IPMODE_NONE,
    e_IPMODE_AUTO,
    e_IPMODE_STATIC,
}e_IPMODE;

#define SUPPORT_WIFILIST_FILTER_BY_APNAME

#define FTP_AUTO_PLAY "AutoPlay"
#define FTP_VIDEO_FILE 	"ftp_ouput.ts"
#define FTP_VERSION_FILE "ftp_version.txt"
#define USB_VERSION_FILE "usb_version.txt"
#define MAX_FTP_BUF_SIZE 2048
#define INTERNAL_FTP_DISK_NAME_LEN (15)
#ifdef CONFIG_SUPPORT_PARTITIONNUM_MAX
#define MAX_FTP_PARTITION_NUM (20)
#else
#define MAX_FTP_PARTITION_NUM (8)
#endif
static char FTPFilePath[MAX_FTP_BUF_SIZE];

static BOOL st_bInited = FALSE;
static BOOL st_isThreadRun = FALSE;
static E_MID_NWSI_CONNECT_TYPE gConnectMode = E_MID_NWSI_CONNECT_TYPE_END;
static BOOL stbConnectMode_enable = FALSE;
static INT8 gIPMode = e_IPMODE_NONE;
static MID_NWSI_PPPOE_Account_Data_t gAccountData = {.account={0}, .pwd={0}};
static BOOL bPPPOEConnectStatus = FALSE;
static MID_NWSI_APList_t gAPlist = {.head = {0}, .tail = {0}, .apNum = 0};

static GL_Mutex_t stAPListMutex;
static GL_Mutex_t stWLANConnectMutex;
static GL_Mutex_t stwpacmdMutex;
static INT32 stWPAPid = 0;
static INT8 stWLANNetworkID =  -1; 
static E_MID_NWSI_WLAN_CONNECT_STATE stWLANConnectSt;
static BOOL stScanAPStart = FALSE;
GL_Task_t checkconnectHandle = 0;
GL_Task_t APScanHandle = 0;
GL_Semaphore_t APScanSema = 0;
GL_Semaphore_t check_dev_enable_sema = 0;
static UINT8 gifstatus = 0;
AP_Pwd_Data gConnectAPData;
MID_NWSI_CallBack gpfSettingCB = NULL;

static BOOL bUSBVersionFileExist = FALSE;


void _MID_NWSI_WPA_Enable_(void);
static void wpacmd(INT8 *cmd)
{
    if(!cmd)
        return ;

    DEBF("%s -stWPAPid = %d ,cmd = %s\n",__FUNCTION__, stWPAPid,cmd);
    GL_MutexLock(stwpacmdMutex);    
    system(cmd);
    GL_MutexUnlock(stwpacmdMutex);
}


static INT32 umfsleep(time_t  sec, long nsec)
{
    struct timespec req;
    struct timespec rem;
    int retval;

    req.tv_sec = sec;
    req.tv_nsec = nsec;
    
    while(1)
    {
        retval = nanosleep(&req, &rem);
        if (retval == 0)
        {
            //Completed the entire sleep time; all done
            return 0;
        }
        else if (retval == -1 && errno == EINTR)
        {
            //Interrupted by a signal. Try again
            req = rem;
        }
        else
        {
            return -1;
        }
    }
}

INT32 _MID_NWSI_Check_File_Exist_(INT8 *fname)
{
    struct stat fstat;

    if(lstat(fname, &fstat) == -1)
        return 0;

    if (S_ISREG(fstat.st_mode))
        return 1;

    return 0;
}

UINT32 _MID_NWSI_Find_Id_(INT8 *path)
{
    INT8 DTVblock[8] = {0};
    INT8 tmp[8] = {0};
    FILE *fp;
    UINT32 pid = 0;

    fp = fopen(path, "r");
    if(fp == NULL)
    {
        DEBF("fp == NULL.\n");
        pid = 0;
    }
    else
    {
        DEBF("Find pid start.\n");
        fgets(tmp,8,fp);
        sscanf(&tmp[0], "%7s", DTVblock);
        pid = (UINT32)atoi(DTVblock);
        fclose(fp);
    }

    return pid;
}

INT32 MID_NWSI_SetPPPoEAccount(MID_NWSI_PPPOE_Account_Data_t data)
{
    memset(&gAccountData, 0, sizeof(MID_NWSI_PPPOE_Account_Data_t));
    memcpy(&gAccountData, &data, sizeof(MID_NWSI_PPPOE_Account_Data_t));
    return 1;
}

INT32 MID_NWSI_ConnectPPPoE(BOOL bConnect)
{
    INT32 pppd_pid = 0;
    FILE *fp = NULL;
    INT8 tmpbuf[128] = {0};

    if(bConnect)
    {
        //set account and password
        fp = fopen("/etc/ppp/pap-secrets", "w+");

        if(fp)
        {
            fprintf(fp, "%s * %s * \n", gAccountData.account, gAccountData.pwd);
            fclose(fp);

            if(_MID_NWSI_Check_File_Exist_("/var/pppd.pid"))
                system("rm /var/pppd.pid");

            if(MID_NWSI_GetIFIndex(E_MID_NWSI_CONNECT_TYPE_ETHERNET) <0) 
            {
                return E_FAIL;
            }
            sprintf(tmpbuf, "/usr/bin/pppd file /etc/pppoe/options pty '/usr/bin/pppoe - Ieth0' user %s -p /var/pppd.pid", gAccountData.account);
            system(tmpbuf);
            bPPPOEConnectStatus = TRUE;
        }
        else 
        {
                DEBF("@@ Can't open /etc/ppp/pap-secrets!\n");
                bPPPOEConnectStatus = FALSE;
                return E_FAIL;
        }
    }
    else
    {
        pppd_pid = _MID_NWSI_Find_Id_("/var/pppd.pid");

        if(pppd_pid >0)
        {
            kill(pppd_pid, SIGKILL);
            if(_MID_NWSI_Check_File_Exist_("/var/pppd.pid"))
                system("rm /var/pppd.pid");

        }

        if(_MID_NWSI_Check_File_Exist_("/var/pppd.pid"))
            system("rm /var/pppd.pid");

        bPPPOEConnectStatus = TRUE;
    }

    return S_OK;
}


INT32 MID_NWSI_StopDHCP(void)
{
    UINT32 dhcp_pid;
    
    
    dhcp_pid = _MID_NWSI_Find_Id_("/var/udhcpc_pid");

    if(dhcp_pid)
    {
        kill(dhcp_pid,SIGKILL);
        if(_MID_NWSI_Check_File_Exist_("/var/udhcpc_pid"))
            system("rm /var/udhcpc_pid");
    }

    return S_OK;
}

INT32 MID_NWSI_SetDHCP(E_MID_NWSI_CONNECT_TYPE type)
{
    if(!MID_NWSI_IsValidConnectType(type))
        return E_FAIL;
    
    MID_NWSI_StopDHCP();

    if(E_MID_NWSI_CONNECT_TYPE_ETHERNET == type)
    {
        DEBF("%s,%d - Do: udhcpc -A 10 -t 10 -T 2 -i eth0 -p /var/udhcpc_pid &\n",__FUNCTION__, __LINE__);
        system("udhcpc -A 10 -t 10 -T 2 -i eth0 -p /var/udhcpc_pid &");
    }
    else if(E_MID_NWSI_CONNECT_TYPE_WIRELESS == type)
    {
        DEBF("%s,%d - Do: udhcpc -i wlan0 -p /var/udhcpc_pid &\n",__FUNCTION__, __LINE__);
        system("udhcpc -i wlan0 -p /var/udhcpc_pid &");
    }

    gIPMode = e_IPMODE_AUTO;

    return 1;
}

//-------wireless
//----------------
INT8 _MID_NWSI_Parse_String_Quality_(INT8 *pStr, INT32 *value1, INT32 *value2)
{
    INT32 ret = 0;
    INT32 tmp1, tmp2; 
    if(!pStr || !value1 || !value2)
        return FALSE;

    ret = sscanf(pStr, "%d/%d",&tmp1, &tmp2);

    if(ret!= 2)
    {
        return FALSE;
    }
    *value1= tmp1;
    *value2 = tmp2;

    return TRUE;
}

INT8 _MID_NWSI_Parse_String_Flag_(INT8 *pStr, UINT8 *enValue)
{
    UINT8 encryption = E_MID_NWSI_ENCRYPTIONTYPE_OFF;
    INT8 ch = '[';
    INT8 *ploc = NULL;

    if(!pStr)
        return FALSE;

    if(!enValue)
        return FALSE;

    ploc = strchr(pStr, ch);
    while(ploc != NULL)
    {
        if(strncmp(ploc + 1, "WPA2", 4) == 0)
        {
            encryption |= E_MID_NWSI_ENCRYPTIONTYPE_WPA2;
        }
        else if(strncmp(ploc + 1, "WPA", 3) == 0)
        {    
            encryption |= E_MID_NWSI_ENCRYPTIONTYPE_WPA;
        }
        else if(strncmp(ploc + 1, "WEP", 3) == 0)
        {
            encryption |= E_MID_NWSI_ENCRYPTIONTYPE_WEP;
        }
        else if(strncmp(ploc + 1, "ESS", 3) == 0)
        {    
            encryption |= E_MID_NWSI_ENCRYPTIONTYPE_OFF;
        }

        ploc = strchr(ploc+1, ch);
    }

    *enValue = encryption;
    return TRUE;
}

INT8 _MID_NWSI_Parse_String_MAC_(INT8 *pStr, MID_NWSI_MAC_Addr_t *pMac)
{
    // char string[] = "00:02:44:33:dd:ff";
    //MID_NWSI_MAC_Addr_t mac = {0};
    INT32 ret = 0;
    INT8 tStr[3] = {0};
    INT8 strLen = 0;
    INT8 idx = 0;
    UINT8 bFormatOK = TRUE;
    INT8 ch = '0';
    INT32 a,b,c,d,e,f ;


    if(!pStr)
        return FALSE;

    if(!pMac)
        return FALSE;
    memset(tStr, 0, sizeof(tStr));
    //check the string is bssid string
    strLen = strlen(pStr);

    if(strLen < 17) //leng : xx:xx:xx:xx:xx:xx
        return FALSE;
	
	 if(strLen >= 17) //leng : xx:xx:xx:xx:xx:xx
	 	strLen = 17;

    for(idx=0; idx<strLen; idx++)
    {
        ch = *(pStr + idx); //for build code error, since ch = pStr[idx] will happen build code error.
        
        if((idx+1)%3 == 0) //the pStr[idx] should be ':'
        {
            if( ch != ':')
                bFormatOK = FALSE; 
        }
        else //should be in the ranage "a-z A-Z 0-9"
        {
            if(!((ch >= '0' && ch <= '9') ||
                 (ch >= 'a' && ch <= 'f') || 
                 (ch >= 'A' && ch <= 'F'))
              )
                bFormatOK = FALSE;
        }

        if(!bFormatOK)
        {
            return FALSE;
        }   

    }
    //check end
    //printf("strLen =%d, bFormatOK =%d\n", strLen, bFormatOK);
#if 1
    //printf("%s - pstr =%s\n", __FUNCTION__, pStr);
    //ret = sscanf(pStr, "%02x:%02x:%02x:%02x:%02x:%02x", (INT8 *)&(pMac->A), (INT8 *)&(pMac->B), (INT8 *)&(pMac->C),(INT8 *)&(pMac->D), (INT8 *)&(pMac->E), (INT8 *)&(pMac->F));

    ret = sscanf(pStr, "%02x:%02x:%02x:%02x:%02x:%02x", &a, &b, &c, &d, &e, &f);
    //printf("ret  =%d\n", ret);

    pMac->A = (UINT8)a;
    pMac->B = (UINT8)b;
    pMac->C = (UINT8)c;
    pMac->D = (UINT8)d;
    pMac->E = (UINT8)e;
    pMac->F = (UINT8)f;
    if(ret != 6)
    {//format error
        //memset(&mac, 0, sizeof(MID_NWSI_MAC_Addr_t));
        return FALSE;
    }
#endif  
    //printf("%02x-%02x-%02x-%02x-%02x-%02x\n", a, b, c, d, e, f);
    //printf("%02x-%02x-%02x-%02x-%02x-%02x\n", pMac->A, pMac->B, pMac->C, pMac->D, pMac->E, pMac->F);

    return TRUE;
}

void _MID_NWSI_WLAN_ScanAP_Start_(void)
{
    GL_INT32 ret = 0;

    DEBF(" ====> %s\n",__FUNCTION__);
    GL_MutexLock(stAPListMutex);
    MID_NWSI_DestroyList(&gAPlist);    
    GL_MutexUnlock(stAPListMutex);

    if(!stScanAPStart)
    {    
        stScanAPStart = TRUE;

        if(APScanSema)
        {
            do {
                ret  = GL_SemaphoreGive(APScanSema);
            }while(ret != GL_SUCCESS);

        }
    }
    DEBF(" <==== %s\n",__FUNCTION__);
}

void _MID_NWSI_WLAN_ScanAP_Stop_(void)
{
    GL_INT32 ret = 0;

   DEBF(" ====> %s\n",__FUNCTION__);

    if(stScanAPStart)//for prevent deadlocked, since the init flow will take this sema
    {
        stScanAPStart = FALSE;

        if(APScanSema)
        {    
            do {
                ret  = GL_SemaphoreTake(APScanSema, GL_INFINITE_WAIT);
            }while(ret != GL_SUCCESS);
        }
    }
   DEBF("<==== %s\n",__FUNCTION__);
}

void _MID_NWSI_WLAN_Check_Connect_Status_Routine_(void *param)
{
    BOOL bexist = FALSE;
    UINT8 ifflag = 0;
    
    while(st_isThreadRun)
    {

        GL_SemaphoreTake(check_dev_enable_sema, GL_INFINITE_WAIT);
        ifflag = E_MID_NWSI_IF_OFF;

        if(gConnectMode == E_MID_NWSI_CONNECT_TYPE_WIRELESS)
        {
            bexist = MID_NWSI_WLAN_IsDevExistence();    
        }
        else
        {
           bexist = TRUE;
        }

        if(bexist) //device existence.
        {
            ifflag = MID_NWSI_GetIFFlag(gConnectMode);
        }
        else
        {
            ifflag = E_MID_NWSI_IF_OFF;
        }

        
        //check if is up??
        if(bexist && !(ifflag & E_MID_NWSI_IF_UP))//try enable device
        {
            DEBF("[check_connect]iff not up, try enable device\n");
            //try enable device
            MID_NWSI_SetIFUp(gConnectMode, TRUE);
        }

        if(bexist && (gConnectMode == E_MID_NWSI_CONNECT_TYPE_WIRELESS) && stbConnectMode_enable && !stWPAPid)
        { //try enable wpa
            DEBF("[check_connect] try enable wpa\n");
            _MID_NWSI_WPA_Enable_();
        }

        if(gifstatus != ifflag)
        {
            if(gpfSettingCB)
            {
                if(ifflag & E_MID_NWSI_IF_UP)
                    gpfSettingCB(E_MID_NWSI_REPORT_WLAN_DEVICE_ENABLED, NULL);
                else
                    gpfSettingCB(E_MID_NWSI_REPORT_WLAN_DEVICE_DISABLED, NULL);
            }
        }

        gifstatus = ifflag;
        
        GL_SemaphoreGive(check_dev_enable_sema);

        GL_TaskSleep(500);
    }

    if(check_dev_enable_sema)
        GL_SemaphoreGive(check_dev_enable_sema);

}

#if 1
void MID_NWSI_WLAN_ScanAP()
{
    GL_INT32 glret = 0;
    BOOL bAPListUpdate = FALSE;

	do {
		glret  = GL_SemaphoreTake(APScanSema, GL_INFINITE_WAIT);
	}while( glret != GL_SUCCESS);

	if((gifstatus & E_MID_NWSI_IF_UP) && stWPAPid) //interface must up
	{
		MID_NWSI_ScanWifiAP(&bAPListUpdate);
		if(bAPListUpdate && gpfSettingCB)
			gpfSettingCB(E_MID_NWSI_REPORT_WLAN_AP_ListUpdate, NULL);

	}
	else
	{
		DEBF("interface is down / no wpa, skip scan\n");
	}
	GL_SemaphoreGive(APScanSema);
}
#else
void _MID_NWSI_WLAN_ScanAP_Routine_(void *param)
{
    GL_INT32 glret = 0;
    BOOL bAPListUpdate = FALSE;
    INT32 count = 0;

    while(st_isThreadRun)
    {
        do {
            glret  = GL_SemaphoreTake(APScanSema, GL_INFINITE_WAIT);
        }while( glret != GL_SUCCESS);

        if((gifstatus & E_MID_NWSI_IF_UP) && stWPAPid) //interface must up
        {
            MID_NWSI_ScanWifiAP(&bAPListUpdate);
            if(bAPListUpdate && gpfSettingCB)
                gpfSettingCB(E_MID_NWSI_REPORT_WLAN_AP_ListUpdate, NULL);

        }
        else
        {
            DEBF("interface is down / no wpa, skip scan\n");
        }
        GL_SemaphoreGive(APScanSema);
        count = 0;
        do {
            GL_TaskSleep(1000 /*1s*/);
        }while(st_isThreadRun && (count++ < 100)); 
		//XXX tune sleeptime from 1s to 10s since it will block file read in rtp_read, causing rtp_read timeout and video data lost
    }

}
#endif

BOOL MID_NWSI_P2P_ScanAP(E_MID_NWSI_INTERFACE Interface)
{
	BOOL bAPListUpdate = FALSE;

	if((MID_NWSI_GetIFFlag(E_MID_NWSI_CONNECT_TYPE_WIRELESS) & E_MID_NWSI_IF_UP) && _MID_NWSI_Find_Id_("/etc/wpa_p2p_pidfile")) //interface must up
	{
		MID_NWSI_ScanP2PAP(&bAPListUpdate, Interface);
	}
	else
	{
		DEBF("interface is down / no wpa, skip scan\n");
	}
	return bAPListUpdate;
}

unsigned char MID_Wifi_ssid_convert_decimal(char ssid) 
{
	unsigned char ssid_char = 0; 
	if (ssid >= '0' && ssid <='9') 
	{  
		ssid_char = ssid - '0'; 
	} 
	else if (ssid >= 'a' && ssid <='f')
	{  
		ssid_char = ssid - 'a' + 10; 
	} 
	else if (ssid >= 'A' && ssid <='F') 
	{  
		ssid_char = ssid - 'A' + 10; 
	} 
	else 
	{  
		ssid_char = 0; 
	} 
	return ssid_char;
}

void MID_Wifi_ssid_StringToUtf8(unsigned char *ssid, char *bssid, UINT32 size) 
{ 
	int ssid_char; 
	UINT32 i=0, j=0;
	bool bcheck; 
	DEBF(" %s size = %d \n", __FUNCTION__, size);  
	for (i=0; i < size; i++) 
	{  
		if (bssid[i] == '\0' || j >= 64)   
		{   
			DEBF("%s  end j = %d \n", __FUNCTION__, j);    
			break;  
		}  
		bcheck = ((bssid[i] == '\\' && bssid[i+1] == 'x') || (bssid[i] == '\\' && bssid[i+1] == 'X'));  
		if (bcheck && (bssid[i+2] >= '0' && bssid[i+2] <='f')   && (bssid[i+3] >= '0' && bssid[i+3] <='f'))  		
		{   
			ssid_char = (MID_Wifi_ssid_convert_decimal(bssid[i+2]) << 4) + MID_Wifi_ssid_convert_decimal(bssid[i+3]);   
			if (ssid_char <= 255)   
			{     
				ssid[j] = ssid_char;    
			}   
			else   
			{    
				ssid[j] = 0;    
			}   
			i += 3;    
			j++;  
		}  
		else   
		{   
			ssid[j] = bssid[i];   
			j++;  
		}   
	} 
	//printf(" %s ssid:%s \n",__FUNCTION__,ssid);
	ssid[j] = '\0';
}

INT32 MID_NWSI_ScanWifiAP(BOOL *pbAPUpdate)
{
    FILE *fp = NULL;
    BOOL bFormatOK = FALSE;
    MID_NWSI_APData_t tmpAPdata;
    INT8 *scan_file = "/var/AccessPoint";
    INT8 tmpbuf[250];
    INT8 cpbuf[250];
#ifndef CONFIG_KERNEL_VERSION_3_0_8
    INT32 quality1 = 0, quality2 = 0;
#endif
    INT32  j = 0;
    UINT8 column = 0;
    INT32 retval = S_OK;
    MID_NWSI_APNode_t *ptmpNode = NULL, *pPrevNode = NULL;
    INT8 *pToken = NULL;
    INT8 *tmpRet = NULL;
    BOOL bHasNew = FALSE, bNotFind = FALSE;
    UINT32 offset,posEnd = 0;

    if(pbAPUpdate)
        *pbAPUpdate = FALSE;
#ifdef CONFIG_KERNEL_VERSION_3_0_8
	wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 scan"); //Scan AP
#else
    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant scan"); //Scan AP
#endif

    umfsleep(2, 0);
#ifdef CONFIG_KERNEL_VERSION_3_0_8
	wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 scan_results > /var/AccessPoint");  //Scan result
#else
    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant scan_results > /var/AccessPoint");  //Scan result
#endif

    umfsleep(1, 0);
    fp = fopen(scan_file, "r");
    if(fp)
    {
        fgets(tmpbuf, 250, fp); //The first line is label name.
        tmpRet = fgets(tmpbuf, 250, fp);
    
        for(j=0; (stScanAPStart == TRUE) && ((tmpRet == NULL) && j<10) ; j++) // retry get access point
        {
            if(fp)
                fclose(fp);
            fp = NULL;

            if(!(gifstatus & E_MID_NWSI_IF_UP))
            {//if is down, stop scan.
                DEBF("IF is down, skip scan !!\n");
                return S_OK;   
            }
            umfsleep(1 , 0);    

            /*if(j > 1)
                DEBF("Read file AccessPoint retry %d time.\n",j);*/
#ifdef CONFIG_KERNEL_VERSION_3_0_8          
            wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 scan_results > /var/AccessPoint");
#else
            wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant scan_results > /var/AccessPoint");
#endif

            umfsleep(0, 500000000);

            fp = fopen(scan_file, "r");
            if(fp)
            {
                fgets(tmpbuf, 250, fp); //The first line is label name.
                tmpRet = fgets(tmpbuf, 250, fp);
            }
            else
            {
                DEBF("File \"AccessPoint\" open fail !!\n");
                return E_FAIL;
            }
        }

        if(stScanAPStart == FALSE)
        {
            DEBF("-----skip scan ---\n");
            return S_OK;
        }

        memset(&tmpAPdata, 0, sizeof(MID_NWSI_APData_t));

        GL_MutexLock(stAPListMutex);

        MID_NWSI_ResetALLAPStateInList(&gAPlist);
        while(tmpRet != NULL)
        {   
            //start parse file, reset statstatee flag first, for identify is find new AP.

            column = 0;
            bFormatOK = FALSE;
            posEnd = (UINT32)tmpRet + (UINT32)strlen(tmpRet) -1;

            //copystring, since the strtok will change the tmpRet's content
            memcpy(cpbuf, tmpRet, sizeof(cpbuf));

            pToken = strtok(tmpRet, " \t");

            while(pToken != NULL)
            {
                switch(column++)
                {    
                    case 0: //bssid
                        //start parseing , set bFormatOK = TRUE, as default
                        bFormatOK = TRUE;
                        bFormatOK  &= _MID_NWSI_Parse_String_MAC_(pToken, &tmpAPdata.APMAC);
                        break;
                    case 1: //channel
                        tmpAPdata.APChannel = atoi(pToken);
                        break;
                    case 2: //signal level
                        tmpAPdata.APQuality = atoi(pToken);
                        break;
#ifdef CONFIG_KERNEL_VERSION_3_0_8
					case 3: //flags
                        bFormatOK &= _MID_NWSI_Parse_String_Flag_(pToken, &tmpAPdata.APEncryption);
                        break;
					case 4: //ssid
                        offset = (UINT32)pToken - (UINT32)tmpRet;
						#if 1
						MID_Wifi_ssid_StringToUtf8((unsigned char *)tmpAPdata.APName, (char *)(cpbuf + offset), posEnd - (UINT32)pToken);
						#else
						if(((UINT32)posEnd - (UINT32)pToken) > 64)
						{
                        	strncpy(tmpAPdata.APName, cpbuf + offset, 64);
						}
						else
						{
                        	strncpy(tmpAPdata.APName, cpbuf + offset, (UINT32)posEnd - (UINT32)pToken);
						}
						#endif
                        break;
#else
                    case 3: //quality
                        bFormatOK  &= _MID_NWSI_Parse_String_Quality_(pToken, &quality1, &quality2);
                        break;
                    case 4: //flags
                        bFormatOK &= _MID_NWSI_Parse_String_Flag_(pToken, &tmpAPdata.APEncryption);
                        break;
                    case 5: //ssid
                        offset = (UINT32)pToken - (UINT32)tmpRet;
						#if 1
						MID_Wifi_ssid_StringToUtf8((unsigned char *)tmpAPdata.APName, (char *)(cpbuf + offset), posEnd - (UINT32)pToken);
						#else
						if(((UINT32)posEnd - (UINT32)pToken) > 64)
						{
                        	strncpy(tmpAPdata.APName, cpbuf + offset, 64);
						}
						else
						{
                        	strncpy(tmpAPdata.APName, cpbuf + offset, (UINT32)posEnd - (UINT32)pToken);
						}
						#endif
                        break;			
#endif
                    default:
                        //DEBF("[%d] - pToken = %s,skip\n",column, pToken );
                        break;
                }

                  if(bFormatOK)//if parser error, stop this loop parse.
                  {
                      pToken = strtok(NULL, " \t");
                  }
                  else
                  {		
                      pToken = NULL;
                  }
            }
                  
            if(bFormatOK)
            {
#ifndef SUPPORT_WIFILIST_FILTER_BY_APNAME
                //check ap is exist??
                ptmpNode = MID_NWSI_FindAPInListByBSSID(&gAPlist,&tmpAPdata.APMAC);
#else
				//check ap ssid is same
				UINT8 bupdate= FALSE;
                ptmpNode = MID_NWSI_FindAPInListBySSID(&gAPlist,(INT8 *)&tmpAPdata.APName,tmpAPdata.APQuality,&bupdate);
#endif				
                if(!ptmpNode)
                {
                    MID_NWSI_AddAPDataToList(&gAPlist, &tmpAPdata);
                    bHasNew = TRUE;
                }
                else
                {
#ifdef SUPPORT_WIFILIST_FILTER_BY_APNAME
                	if(bupdate)
#endif				
                	{
                    	MID_NWSI_UpdateAPNodeData(ptmpNode, &tmpAPdata);    
					}
                }
            }
            memset(&tmpAPdata, 0, sizeof(MID_NWSI_APData_t));
            tmpRet = fgets(tmpbuf, 250, fp);
        }


        ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, NULL);
        while(ptmpNode != NULL)
        {
            if(ptmpNode->state == E_MID_NWSI_AP_STATE_NOT_EXIST) 
            {
                bNotFind = TRUE;
                break;
            }
            ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, ptmpNode);
        }

        if(bNotFind)
        {
            ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, NULL);

            while(ptmpNode != NULL)
            {
                pPrevNode = ptmpNode;
                ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, ptmpNode);

                if(pPrevNode->state == E_MID_NWSI_AP_STATE_NOT_EXIST)
                {
                    MID_NWSI_RemoveAPNodefromList(&gAPlist, pPrevNode);
                }
            }
        }

        if(bHasNew || bNotFind)
        {
            if(pbAPUpdate)
                *pbAPUpdate = TRUE;
        }

    }
    else
    {
        DEBF("File \"AccessPoint\" open fail !!\n");

        retval = E_FAIL;
    }


    if(fp)
        fclose(fp);

    GL_MutexUnlock(stAPListMutex);
    return retval;
}
INT32 MID_NWSI_ScanP2PAP(BOOL *pbAPUpdate, E_MID_NWSI_INTERFACE Interface)
{
    FILE *fp = NULL;
    BOOL bFormatOK = FALSE;
    MID_NWSI_APData_t tmpAPdata;
    INT8 *scan_file = "/var/AccessPoint";
    INT8 tmpbuf[250];
    INT8 cpbuf[250];
#ifndef CONFIG_KERNEL_VERSION_3_0_8
    INT32 quality1 = 0, quality2 = 0;
#endif
    UINT8 column = 0;
    INT32 retval = S_OK;
    MID_NWSI_APNode_t *ptmpNode = NULL, *pPrevNode = NULL;
    INT8 *pToken = NULL;
    INT8 *tmpRet = NULL;
    BOOL bHasNew = FALSE, bNotFind = FALSE;
    UINT32 offset,posEnd = 0;

    if(!st_bInited)
        MID_NWSI_Init_List(&gAPlist);
	
    GL_MutexLock(stAPListMutex);
    MID_NWSI_DestroyList(&gAPlist);    
    GL_MutexUnlock(stAPListMutex);


    if(pbAPUpdate)
        *pbAPUpdate = FALSE;
	
    if(Interface == E_MID_NWSI_INTERFACE_WLAN1)
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan1 scan"); //Scan AP
    else if(Interface == E_MID_NWSI_INTERFACE_P2P0)
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -ip2p0 scan"); //Scan AP
    else
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -ip2p0 scan"); //Scan AP

    umfsleep(0, 300000000);

    if(Interface == E_MID_NWSI_INTERFACE_WLAN1)
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan1 scan_results > /var/AccessPoint");  //Scan result
    else if(Interface == E_MID_NWSI_INTERFACE_P2P0)
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -ip2p0 scan_results > /var/AccessPoint");  //Scan result
    else
        wpacmd("wpa_cli -p/var/run/wpa_supplicant -ip2p0 scan_results > /var/AccessPoint");  //Scan result

    umfsleep(0, 300000000);
    fp = fopen(scan_file, "r");
    if(fp)
    {
        fgets(tmpbuf, 250, fp); //The first line is label name.
        tmpRet = fgets(tmpbuf, 250, fp);
        memset(&tmpAPdata, 0, sizeof(MID_NWSI_APData_t));

        GL_MutexLock(stAPListMutex);
        MID_NWSI_ResetALLAPStateInList(&gAPlist);
        while(tmpRet != NULL)
        {   
            //start parse file, reset statstatee flag first, for identify is find new AP.
            column = 0;
            bFormatOK = FALSE;
            posEnd = (UINT32)tmpRet + (UINT32)strlen(tmpRet) -1;

            //copystring, since the strtok will change the tmpRet's content
            memcpy(cpbuf, tmpRet, sizeof(cpbuf));

            pToken = strtok(tmpRet, " \t");

            while(pToken != NULL)
            {
                switch(column++)
                {    
                    case 0: //bssid
                        //start parseing , set bFormatOK = TRUE, as default
                        bFormatOK = TRUE;
                        bFormatOK  &= _MID_NWSI_Parse_String_MAC_(pToken, &tmpAPdata.APMAC);
                        break;
                    case 2: //signal level
                        tmpAPdata.APQuality = atoi(pToken);
                        break;
#ifndef CONFIG_KERNEL_VERSION_3_0_8
                    case 3: //quality
                        bFormatOK  &= _MID_NWSI_Parse_String_Quality_(pToken, &quality1, &quality2);
                        break;
#endif
                    case 4: //ssid
                        offset = (UINT32)pToken - (UINT32)tmpRet;
                        MID_Wifi_ssid_StringToUtf8((unsigned char *)tmpAPdata.APName, (char *)(cpbuf + offset), posEnd - (UINT32)pToken);
                        break;
                    default:
                        //DEBF("[%d] - pToken = %s,skip\n",column, pToken );
                        break;
                }

                if(bFormatOK)//if parser error, stop this loop parse.
                    { 
                      pToken = strtok(NULL, " \t");
                	}
			       else
					{
					   pToken = NULL;
			    	}
            }

            if(bFormatOK)
            {
#ifndef SUPPORT_WIFILIST_FILTER_BY_APNAME
                //check ap is exist??
                ptmpNode = MID_NWSI_FindAPInListByBSSID(&gAPlist,&tmpAPdata.APMAC);
#else
				//check ap ssid is same
				UINT8 bupdate= FALSE;
                ptmpNode = MID_NWSI_FindAPInListBySSID(&gAPlist,(INT8 *)&tmpAPdata.APName,tmpAPdata.APQuality,&bupdate);
#endif				
                if(!ptmpNode)
                {
                    MID_NWSI_AddAPDataToList(&gAPlist, &tmpAPdata);
                    bHasNew = TRUE;
                }
                else
                {
#ifdef SUPPORT_WIFILIST_FILTER_BY_APNAME
                	if(bupdate)
#endif				
                	{
                    	MID_NWSI_UpdateAPNodeData(ptmpNode, &tmpAPdata);    
					}
                }
            }
            memset(&tmpAPdata, 0, sizeof(MID_NWSI_APData_t));
            tmpRet = fgets(tmpbuf, 250, fp);
        }


        ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, NULL);
        while(ptmpNode != NULL)
        {
            if(ptmpNode->state == E_MID_NWSI_AP_STATE_NOT_EXIST) 
            {
                bNotFind = TRUE;
                break;
            }
            ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, ptmpNode);
        }

        if(bNotFind)
        {
            ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, NULL);

            while(ptmpNode != NULL)
            {
                pPrevNode = ptmpNode;
                ptmpNode = MID_NWSI_GetListNextAPNode(&gAPlist, ptmpNode);

                if(pPrevNode->state == E_MID_NWSI_AP_STATE_NOT_EXIST)
                {
                    MID_NWSI_RemoveAPNodefromList(&gAPlist, pPrevNode);
                }
            }
        }

        if(bHasNew || bNotFind)
        {
            if(pbAPUpdate)
                *pbAPUpdate = TRUE;
        }

    }
    else
    {
        DEBF("File \"AccessPoint\" open fail !!\n");

        retval = E_FAIL;
    }


    if(fp)
        fclose(fp);

    GL_MutexUnlock(stAPListMutex);
    return retval;
}

void MID_Net_WLAN_RemoveAllNetID(void)
{
#ifdef CONFIG_KERNEL_VERSION_3_0_8    
    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 remove_network all");

    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 save_config");

    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 list_networks > /var/networkList");
#else
    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant remove_network all");

    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant save_config");

    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant list_networks > /var/networkList");
#endif

    stWLANNetworkID = -1;
}

INT32 MID_NWSI_WLAN_WiFiEnable(UINT8 bEnable)
{
    INT8 *PidFilePath = "/etc/wpa_pidfile";
    INT32 pid = 0;
    INT32 retval = S_OK;

     DEBF("====> %s\n",__FUNCTION__);
    if(bEnable)
    {

        MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE_WIRELESS, TRUE);
        umfsleep(0, 800000000);
        printf("mknod -m 644 /dev/random c 1 8\n");
        system("mknod -m 644 /dev/random c 1 8");
        printf("mknod -m 600 /dev/rfkill c 10 63\n");
        system("mknod -m 600 /dev/rfkill c 10 63");
        pid = _MID_NWSI_Find_Id_(PidFilePath);
    
        if(!pid) 
        {
#ifdef CONFIG_KERNEL_VERSION_3_0_8
#ifdef CONFIG_SUPPORT_MIRACAST_DLNA_INONE
		system("./tmp/wpa_supplicant_run.sh");
#else
            system("wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -P /etc/wpa_pidfile -d -B");
#endif
#else
            system("wpa_supplicant_8 -Dwext -iwlan0 -c/etc/wpa_supplicant.conf -P /etc/wpa_pidfile -d -B");
#endif
           // umfsleep(0, 500000000);
            MID_Net_WLAN_RemoveAllNetID();
            pid = _MID_NWSI_Find_Id_(PidFilePath);
        

            if(!pid)
            {
                retval = E_FAIL;
            }
        }
        stWPAPid = pid;
    }
    else
    {
        MID_Net_WLAN_RemoveAllNetID();
        //MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE_WIRELESS, FALSE);
        pid = _MID_NWSI_Find_Id_(PidFilePath);
        
        if(pid > 0)
        {
                kill(pid, SIGKILL);
                umfsleep(0, 150000000);
        }

        if(_MID_NWSI_Check_File_Exist_(PidFilePath))
            system("rm /etc/wpa_pidfile");

        stWPAPid = 0;
    }

     DEBF("<==== %s\n",__FUNCTION__);
    return retval;
}

INT32 MID_NWSI_WLAN_Disconnect(void)
{
    FILE *fp = NULL;
    INT8 *list_file = "/var/networkList";
    INT32 retval = S_OK;
    MID_Net_WLAN_RemoveAllNetID();
    
    fp = fopen(list_file, "r");
    if(fp)
    {
        fclose(fp);    
        if(_MID_NWSI_Check_File_Exist_("/var/APIndex"))
            system("rm /var/APIndex");
        if(_MID_NWSI_Check_File_Exist_("/var/wifiStatus"))
            system("rm /var/wifiStatus");
        if(_MID_NWSI_Check_File_Exist_("/var/networkList"))
            system("rm /var/networkList");
    }
    else
    {
        retval = E_FAIL;    
    } 

    stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_OFF; 
    return retval;
}


BOOL MID_NWSI_WLAN_IsDevExistence(void)
{
    BOOL ret = FALSE;
    INT8 tmpbuf[200];
    INT8 *ptr = NULL;
    FILE *fp = NULL;

    fp = fopen("/proc/net/wireless", "r");

    if(fp != NULL)
    {
        fgets(tmpbuf, sizeof(tmpbuf), fp);
        fgets(tmpbuf, sizeof(tmpbuf), fp);

        memset(tmpbuf, 0, sizeof(tmpbuf));

        while(fgets(tmpbuf, sizeof(tmpbuf), fp))
        {
             /* Skip empty or almost empty lines. It seems that in some cases fgets return a line with only a newline. */
            if(tmpbuf[0] == '\0' || tmpbuf[1] == '\0')
                break;

            ptr = tmpbuf;
            while(strncmp(ptr, " ", 1) == 0) //skip 'whitespace'
                ptr++;
            
            /*try find string - wlan0*/
            if(strlen(ptr) > strlen("wlan0"))
            {
               if(strncmp(ptr, "wlan0", strlen("wlan0")) == 0)  
                   ret = TRUE;
            }
            
        }
    }

    if(fp)
        fclose(fp);
    return ret ;
}


//Example message:
/*************************
Selected interface 'wlan0'
bssid=d8:5d:4c:f4:86:54
ssid=TP-d85d4cf48654
id=0
mode=station
pairwise_cipher=NONE
group_cipher=NONE
key_mgmt=NONE
wpa_state=COMPLETED
address=00:03:7f:0f:a5:e1
**************************/
INT32 _MID_NWSI_CheckWifiConnection_(INT8 index)//compare bssid
{
    INT8 *status_file = "/var/wifiStatus";
    FILE *fp = NULL;
    INT8 tmpbuf[64] = {0};
    INT8 *pos =NULL;
    INT8 *netID = NULL;
    UINT8 matchstatus = 0;//0: nothing, 1: match bssid, 2: wpa_state=COMPLETE 
    //INT8 *tmpBSSID = NULL;
    //MID_NWSI_MAC_Addr_t tmpMAC ;
    INT32 retval = E_FAIL;
#if 0
    if(!pMac)
        return 0;
#endif
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 status > /var/wifiStatus");
#else
    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant status > /var/wifiStatus");
#endif

    umfsleep(0,200000000);

    fp = fopen(status_file, "r");
   
    if(!fp)
        return E_FAIL;

    fgets(tmpbuf,64,fp); // skip AP interface.

    //if(fp)
    {
        while((fgets(tmpbuf,64,fp) != NULL) )
        {
           #if 0 
            if(((pos = strstr(tmpbuf, "bssid")) - tmpbuf) == 0) // bssid
            {
                if(tmpbuf[5] == '=')
                {   
                    tmpBSSID= tmpbuf;
                    strsep(&tmpBSSID, "="); //bssid=d8:5d:4c:f4:86:54 ----> seprate connection bssid token
                    _MID_NWSI_Parse_String_MAC_(tmpBSSID, &tmpMAC);

                    if(!memcmp(pMac, &tmpMAC, sizeof(MID_NWSI_MAC_Addr_t)))
                    {
                        matchstatus |= 0x1;
                    }
                    else 
                    {
                        break;
                    }
                }
            }
           #endif 
            if(((pos = strstr(tmpbuf, "id")) - tmpbuf) == 0) // check id
            {
                if(tmpbuf[3]>='0' && tmpbuf[3]<='9')
                {   
                    //strcpy(tmpStr, tmpbuf);
                    netID = tmpbuf;
                    strsep(&netID, "="); //id=netID ----> seprate connection id token

                    if((atoi(netID)) == index)
                    {
                        matchstatus |= 0x1; // id exist
                    }

                }
            }
            else if( ((pos = strstr(tmpbuf, "wpa_state")) - tmpbuf) == 0 ) // wpa_state
            { // DISCONNECTED / SCANNING / ASSOCIATING / ASSOCIATED / COMPLETED / CONNECTING / 
                // INACTIVE / INTERFACE_DISABLED / 4WAY_HANDSHAKE / GROUP_HANDSHAKE
                if(((pos = strstr(tmpbuf, "COMPLETED")) - tmpbuf) == 10) // COMPLETED
                {
                    printf("%s, %d - pos =%s\n", __FUNCTION__,__LINE__ ,pos);
                    matchstatus |= 0x2;
                }
            }
        }
        fclose(fp);
    }

    if(matchstatus == 0x3)//bssid mathed & state=complete
        retval = S_OK;
    
    return retval;
}

UINT8 MID_NWSI_WLAN_GetAPState(void)
{
    return stWLANConnectSt;
}

INT32 MID_NWSI_WLAN_ConnectSelectedAP(MID_NWSI_APData_t *pAPData, UINT8 keylen, INT8 *pKey)
{
    FILE *fp = NULL;
    INT8 *index_file = "/var/APIndex";
    INT8 cmd[100] ={0};
    INT8 ch = '0';
    INT8 tmpbuf[64] ={0};
    INT32 dhcp_pid = 0;
    INT32 net_idx = -1;
    INT32 tmpStatus;
    UINT8 try = 0 ;
    MID_NWSI_IPv4_Addr_t ip;

    if( !pAPData || strcmp(pAPData->APName, "") == 0) //not design ssid or plug out
    {
        stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_OFF;
        return S_OK;
    }

    stWLANConnectSt = E_MID_NWSI_WLAN_SCAN_STATE_SCANNING;
    switch(pAPData->APEncryption)
    {
        case E_MID_NWSI_ENCRYPTIONTYPE_OFF:
            //do nothing
            break;
        case E_MID_NWSI_ENCRYPTIONTYPE_WPA:
        case E_MID_NWSI_ENCRYPTIONTYPE_WPA2:
        case (E_MID_NWSI_ENCRYPTIONTYPE_WPA | E_MID_NWSI_ENCRYPTIONTYPE_WPA2):
            if(!pKey || strcmp(pKey,"") ==0)
        {
            stWLANConnectSt = E_MID_NWSI_WLAN_SCAN_STATE_EXCEPTION;
        }
            break;
        default:
            stWLANConnectSt = E_MID_NWSI_WLAN_SCAN_STATE_EXCEPTION;
            break;

    }

    dhcp_pid = _MID_NWSI_Find_Id_("/var/udhcpc_pid");    

    if(dhcp_pid)
    {
        kill(dhcp_pid, SIGKILL);    
        if(_MID_NWSI_Check_File_Exist_("/var/udhcp_pid"))
            system("rm /var/udhcp_pid");
    }

    memset(&ip, 0, sizeof(MID_NWSI_IPv4_Addr_t));
    MID_NWSI_SetIP(E_MID_NWSI_CONNECT_TYPE_WIRELESS, ip);

    MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE_ETHERNET, FALSE);

    if(stWLANNetworkID != -1)
    {
        if(MID_NWSI_WLAN_Disconnect() != S_OK)
        {
            stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION;
            return E_FAIL;
        }
    }

    memset(cmd, 0, sizeof(cmd));
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 add_network > %s",index_file);
#else
    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant add_network > %s",index_file);
#endif
    wpacmd(cmd);

    umfsleep(0 , 50000000);
    fp = fopen(index_file, "r");
    if(fp)
    {
        fgets(tmpbuf, sizeof(tmpbuf), fp);// skip interface name.
        fgets(tmpbuf, sizeof(tmpbuf), fp);// catch add AP index
        net_idx = atoi(tmpbuf);

        printf("%s,%d - net_idx = %d\n",__FUNCTION__, __LINE__,net_idx );
        fclose(fp);
    }

    if(net_idx <0)
    {
        stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION;
        return E_FAIL;
    }

    GL_MutexLock(stWLANConnectMutex);
    
    switch(pAPData->APEncryption)
    {
        case E_MID_NWSI_ENCRYPTIONTYPE_OFF:
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
            wpacmd(cmd);

            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d key_mgmt NONE", net_idx);
            wpacmd(cmd);

            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 select_network %d", net_idx); // connect
            wpacmd(cmd);

            umfsleep(2 , 0);

            memset(cmd, 0, sizeof(cmd));
            system("wpa_cli -p/var/run/wpa_supplicant -iwlan0 save_config");
#else
            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
            wpacmd(cmd);

            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d key_mgmt NONE", net_idx);
            wpacmd(cmd);

            memset(cmd, 0, sizeof(cmd));
            sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant select_network %d", net_idx); // connect
            wpacmd(cmd);

            umfsleep(2 , 0);

            memset(cmd, 0, sizeof(cmd));
            system("wpa_cli_8 -p/var/run/wpa_supplicant save_config");
#endif
            umfsleep(1 , 0);
            stWLANNetworkID = net_idx;

            break;
        case E_MID_NWSI_ENCRYPTIONTYPE_WEP:
                           
                ch = *pKey;
                //WEP64, WEP128 keylen should be 5/10/13/26, and key is combined by 0~9, a~z, A~Z 
                if((keylen == 5 || keylen == 10 || keylen == 13 || keylen ==26) && 
                   ((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'b') || (ch >= 'A' && ch <= 'Z'))
                  )
                {
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d key_mgmt NONE", net_idx);
                    wpacmd(cmd);

                    if(keylen ==10  || keylen ==26 )
                        sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d wep_key0 '%s'", net_idx, pKey );
                    else
                        sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d wep_key0 '\"%s\"'", net_idx, pKey );
   
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d wep_tx_keyidx 0",net_idx);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 select_network %d",net_idx); // connect
                    wpacmd(cmd);
                    umfsleep(2, 0);
                    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 save_config");
#else
                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d key_mgmt NONE", net_idx);
                    wpacmd(cmd);

                    if(keylen ==10  || keylen ==26 )
                        sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d wep_key0 '%s'", net_idx, pKey );
                    else
                        sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d wep_key0 '\"%s\"'", net_idx, pKey );
   
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d wep_tx_keyidx 0",net_idx);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant select_network %d",net_idx); // connect
                    wpacmd(cmd);
                    umfsleep(2, 0);
                    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant save_config");
#endif
                    umfsleep(1 , 0);
                    stWLANNetworkID = net_idx;
                    printf("%s - stWLANNetworkID = %d\n",__FUNCTION__, stWLANNetworkID);
                }
                else
                {
                    stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION;
                }
            break;
        case E_MID_NWSI_ENCRYPTIONTYPE_WPA:
        case E_MID_NWSI_ENCRYPTIONTYPE_WPA2:
        case (E_MID_NWSI_ENCRYPTIONTYPE_WPA | E_MID_NWSI_ENCRYPTIONTYPE_WPA2):
                if(keylen >= 8 && keylen <= 63) 
                {
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 set_network %d psk '\"%s\"'", net_idx, pKey);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli -p/var/run/wpa_supplicant -iwlan0 select_network %d", net_idx); // connect
                    wpacmd(cmd);
                    
                    umfsleep(0 , 50000000);
                    wpacmd("wpa_cli -p/var/run/wpa_supplicant -iwlan0 save_config");
#else
                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d ssid '\"%s\"'", net_idx, pAPData->APName);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant set_network %d psk '\"%s\"'", net_idx, pKey);
                    wpacmd(cmd);

                    memset(cmd, 0, sizeof(cmd));
                    sprintf(cmd, "wpa_cli_8 -p/var/run/wpa_supplicant select_network %d", net_idx); // connect
                    wpacmd(cmd);
                    
                    umfsleep(2 , 0);
                    wpacmd("wpa_cli_8 -p/var/run/wpa_supplicant save_config");
#endif
                    umfsleep(0 , 20000000);
                    stWLANNetworkID = net_idx;
                }
                else
                {
                    stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION;
                }
                break;
        default:
                    stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION;
            break;

    }

    if(stWLANConnectSt == E_MID_NWSI_WLAN_CONNECT_STATE_EXCEPTION)
    {
        GL_MutexUnlock(stWLANConnectMutex);
        return E_FAIL;
    }
    
    while(( tmpStatus = _MID_NWSI_CheckWifiConnection_(net_idx) )!= S_OK && try <20)
    {
        umfsleep(0, 200000000);
        try++;
    }

    
    if(tmpStatus != S_OK)
        stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_OFF;
    else
        stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_ON;

    GL_MutexUnlock(stWLANConnectMutex);
    return S_OK;

}


MID_NWSI_WLANINFO_t *MID_NWSI_WLAN_GetAPList(void) //for application to get ap list
{
    MID_NWSI_WLANINFO_t *pinfo = NULL;
    MID_NWSI_APData_t *pDataList = NULL;
    MID_NWSI_APNode_t *pNode = NULL;
    INT32 idx = 0;

    GL_MutexLock(stAPListMutex);
   
    if(gAPlist.apNum != 0)
    {
        pinfo = (MID_NWSI_WLANINFO_t *)malloc(sizeof(MID_NWSI_WLANINFO_t));
        if(pinfo)
        {
            memset(pinfo, 0, sizeof(MID_NWSI_WLANINFO_t));
            
            pinfo->APTotalNum = gAPlist.apNum;
            pDataList = (MID_NWSI_APData_t *)malloc(gAPlist.apNum  * sizeof(MID_NWSI_APData_t));
            if(pDataList)
            {
                pinfo->apdatalist = pDataList;
                memset(pDataList, 0, gAPlist.apNum * sizeof(MID_NWSI_APData_t));
                pNode = MID_NWSI_GetListNextAPNode(&gAPlist, NULL);
                while(pNode)
                {
                    memcpy(pDataList+idx, pNode->data, sizeof(MID_NWSI_APData_t));
                    pNode = MID_NWSI_GetListNextAPNode(&gAPlist, pNode);
                    idx++;
                }

            }
        }
    }

    GL_MutexUnlock(stAPListMutex);
 
#if 0    
    printf("%s,%d - show ap list start \n", __FUNCTION__, __LINE__);
    for(idx=0; idx < pinfo->APTotalNum; idx++)
    {
        printf("data - name =%s, channl = %d, quality = %d, encryption = 0x%08x, mac =[%02x:%02x:%02x:%02x:%02x:%02x]\n",
                pinfo->apdatalist[idx].APName,    pinfo->apdatalist[idx].APChannel, 
                pinfo->apdatalist[idx].APQuality, pinfo->apdatalist[idx].APEncryption, 
                pinfo->apdatalist[idx].APMAC.A,   pinfo->apdatalist[idx].APMAC.B,
                pinfo->apdatalist[idx].APMAC.C,   pinfo->apdatalist[idx].APMAC.D, 
                pinfo->apdatalist[idx].APMAC.E,   pinfo->apdatalist[idx].APMAC.F);
    }
   
    printf("%s,%d - show ap list end\n",__FUNCTION__, __LINE__);

#endif
    return pinfo;
}

void _MID_NWSI_WPA_Enable_(void)
{
  INT8 *wpapidfilepath = "/etc/wpa_pidfile";
  INT32 pid = 0;  
   
    //skip enable wpa, if mode is disable
    if(stbConnectMode_enable == FALSE)
        return ;

    pid = _MID_NWSI_Find_Id_(wpapidfilepath);
    if(!pid)
    {
#ifdef CONFIG_KERNEL_VERSION_3_0_8 
       system("wpa_supplicant -Dnl80211 -iwlan0 -c/etc/wpa_supplicant.conf -P /etc/wpa_pidfile -d -B");
#else
       system("wpa_supplicant_8 -Dwext -iwlan0 -c/etc/wpa_supplicant.conf -P /etc/wpa_pidfile -d -B");
#endif
       umfsleep(0, 50000000);
       pid = _MID_NWSI_Find_Id_(wpapidfilepath);
    }
    stWPAPid = pid;
}

void MID_NWSI_DisableConnectMode(void)
{

    GL_INT32 ret = 0;
    if(E_MID_NWSI_CONNECT_TYPE_ETHERNET ==  gConnectMode)
    {
        if(e_IPMODE_AUTO == gIPMode)    
            MID_NWSI_StopDHCP();

        MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE_ETHERNET, FALSE);
    }
    else if(E_MID_NWSI_CONNECT_TYPE_WIRELESS == gConnectMode)
    {
        _MID_NWSI_WLAN_ScanAP_Stop_(); 
        if(e_IPMODE_AUTO == gIPMode)
            MID_NWSI_StopDHCP();

        if(check_dev_enable_sema)
        {
            do {
                ret =  GL_SemaphoreTake(check_dev_enable_sema, GL_INFINITE_WAIT);
            }while(ret == GL_FAILURE);
        }
        
        MID_NWSI_WLAN_WiFiEnable(FALSE);
    }

    stbConnectMode_enable = FALSE;
}

void MID_NWSI_EnableConnectMode(void)
{
    
    if(E_MID_NWSI_CONNECT_TYPE_ETHERNET == gConnectMode)
    {
        MID_NWSI_SetIFUp(E_MID_NWSI_CONNECT_TYPE_ETHERNET, TRUE);
    }
    else if(E_MID_NWSI_CONNECT_TYPE_WIRELESS == gConnectMode)
    {
        MID_NWSI_WLAN_WiFiEnable(TRUE);
        GL_SemaphoreGive(check_dev_enable_sema);
        _MID_NWSI_WLAN_ScanAP_Start_();

    }
    stbConnectMode_enable = TRUE;

}

void MID_NWSI_SetConnectMode(E_MID_NWSI_CONNECT_TYPE type)
{
    gConnectMode = type;
}

INT32 MID_NWSI_GetConnectMode(void)
{
    return gConnectMode;
}

BOOL MID_NWSI_IFStatus(void)
{
	if(gifstatus==E_MID_NWSI_IF_RUNNING)
	{
		return TRUE;
	}
	 return FALSE;
}

INT32 MID_NWSI_Init(void)
{

    GL_Status_t dReturnValue;
    if(st_bInited)
        return S_OK;
    
    MID_NWSI_Init_List(&gAPlist);
    stWLANConnectSt = E_MID_NWSI_WLAN_CONNECT_STATE_OFF;
    
    st_isThreadRun = TRUE;
    gConnectMode = E_MID_NWSI_CONNECT_TYPE_END;
    stScanAPStart = FALSE;

    dReturnValue = GL_MutexCreate("wpacmd_mutex", &stwpacmdMutex);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("create wpa cmd mutex failed\n");    
        goto _exit_fail_;
    }


    dReturnValue = GL_SemaphoreCreate("mid_net_scan_sema", 1, 1, &APScanSema);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("create scan ap sema failed\n");    
        goto _exit_fail_;
    }
    GL_SemaphoreTake(APScanSema, GL_INFINITE_WAIT);

#if 0
    dReturnValue = GL_TaskCreate("mid_net_scan_ap", _MID_NWSI_WLAN_ScanAP_Routine_, NULL, 3, 4096, FALSE, &APScanHandle);
    if(dReturnValue != GL_SUCCESS)
    {
        printf("create scan ap thread failed\n");    
        goto _exit_fail_;
    }
#endif

    dReturnValue = GL_MutexCreate("wlan_apscan_mutex", &stAPListMutex);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("create  aplist mutex failed\n");    
        goto _exit_fail_;
    }

    dReturnValue  = GL_MutexCreate("wlan_connect_mutex", &stWLANConnectMutex);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("create scan ap mutex failed\n");    
        goto _exit_fail_;
    }

    //check connect thread status 
    dReturnValue = GL_SemaphoreCreate("mid_net_check_dev_enable_sema", 1, 1, &check_dev_enable_sema);
    if(dReturnValue != GL_SUCCESS)
    {
        printf("create check dev enable sema failed\n");    
        goto _exit_fail_;
    }

    GL_SemaphoreTake(check_dev_enable_sema, GL_INFINITE_WAIT);
    dReturnValue = GL_TaskCreate("mid_net_check_connect_status", _MID_NWSI_WLAN_Check_Connect_Status_Routine_, NULL, 3, 4096, FALSE, &checkconnectHandle);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("create mid_net_check_connect_statu task failed\n");    
        goto _exit_fail_;
    }

    dReturnValue = GL_TaskActivate(checkconnectHandle);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("active check_connect_status failed\n");    
        goto _exit_fail_;   
    }
 
#if 0 
    dReturnValue = GL_TaskActivate(APScanHandle);
    if(dReturnValue != GL_SUCCESS)
    {
        DEBF("active scan ap thread failed\n");    
        goto _exit_fail_;
    }
#endif
    st_bInited = TRUE;
    return S_OK;

_exit_fail_:
    if(stwpacmdMutex)
        GL_MutexDelete(stwpacmdMutex);
    if(APScanSema)
        GL_SemaphoreDelete(APScanSema);
    if(stAPListMutex)
        GL_MutexDelete(stAPListMutex);
    if(APScanHandle)
        GL_TaskDestroyOne(APScanHandle);
    if(stWLANConnectMutex)
        GL_MutexDelete(stWLANConnectMutex);
    if(check_dev_enable_sema)
        GL_SemaphoreDelete(check_dev_enable_sema);
    if(checkconnectHandle)
        GL_TaskDestroyOne(checkconnectHandle);
    stwpacmdMutex = stAPListMutex =  stWLANConnectMutex = 0;
    APScanSema = check_dev_enable_sema = 0;
    APScanHandle = checkconnectHandle = 0;
    st_isThreadRun = stScanAPStart = FALSE;
    return E_FAIL;
}


void MID_NWSI_Destory(void)
{
    st_isThreadRun = FALSE;
    MID_NWSI_DisableConnectMode();    

    GL_MutexLock(stAPListMutex);
    MID_NWSI_DestroyList(&gAPlist);
    GL_MutexUnlock(stAPListMutex);

    if(stwpacmdMutex)
        GL_MutexDelete(stwpacmdMutex);
    if(APScanSema)
        GL_SemaphoreDelete(APScanSema);
    if(stAPListMutex)
        GL_MutexDelete(stAPListMutex);
    if(APScanHandle)
        GL_TaskDestroyOne(APScanHandle);
    if(stWLANConnectMutex)
        GL_MutexDelete(stWLANConnectMutex);
    if(check_dev_enable_sema)
        GL_SemaphoreDelete(check_dev_enable_sema);
    if(checkconnectHandle)
        GL_TaskDestroyOne(checkconnectHandle);
    stwpacmdMutex = stAPListMutex =  stWLANConnectMutex = 0;
    APScanSema = check_dev_enable_sema = 0;
    APScanHandle = checkconnectHandle = 0;
    gConnectMode = E_MID_NWSI_CONNECT_TYPE_END;
    st_bInited = FALSE;
}

void MID_NWSI_RegisterCB(MID_NWSI_CallBack pfCB)
{
    gpfSettingCB = pfCB;
}

void MID_NWSI_UnRegisterCB(void)
{
    gpfSettingCB = NULL;
}

static UINT16 FileSystem_Lib_FTP_GetTotalSupportedPartitionNumber(void)
{
	int MountedCount = MID_PartitionList_GetMountedCount();
	if (MountedCount > MAX_FTP_PARTITION_NUM)
	{
		DEBF("Partition Num = %d is more than %d\n", MountedCount, MAX_FTP_PARTITION_NUM);
		MountedCount = MAX_FTP_PARTITION_NUM;
	}
    return MountedCount;
}

static BOOL FileSystem_Lib_FTP_IsFolderExist(char* const Folder_Path)
{
    if (Folder_Path == NULL)
    {
        DEBF("Folder_Path = NULL\n");
        return FALSE;
    }
    DIR* dir;
    dir = opendir(Folder_Path);
    if (dir == NULL)
    {
        DEBF("Folder Path = %s is not exist!\n", Folder_Path);
        return FALSE;
    }
    if (closedir(dir) != 0)
    {
        DEBF("call closedir fail\n");
        return FALSE;
    }
	dir = NULL;
    return TRUE;
}

static BOOLEAN MID_FTP_AutoPlay_FilePath_SetFlag(void)
{
    UINT16 TotalPartition = FileSystem_Lib_FTP_GetTotalSupportedPartitionNumber();
    UINT16 i = 0;
    char Name[INTERNAL_FTP_DISK_NAME_LEN + 1];

    for (i = 0; i < TotalPartition; i++)
    {
        MID_PartitionList_GetMountName(i, Name);
        memset(FTPFilePath, 0, MAX_FTP_BUF_SIZE);
        snprintf(FTPFilePath, MAX_FTP_BUF_SIZE, "%s/%s", Name, FTP_AUTO_PLAY);
        printf("[%s:%d] FilePath = %s \n", __FUNCTION__, __LINE__, FTPFilePath);
        if (FileSystem_Lib_FTP_IsFolderExist(FTPFilePath))
        {
            DEBF("[%s:%d]i = [%d] folder exist \n", __FUNCTION__, __LINE__, i);
            return TRUE;
        }
    }
    //mainapp_printf("[%s:%d]: bAutoPlay = %d \n", __FUNCTION__, __LINE__, bAutoPlay);
    return FALSE;
}

BOOL MID_FTP_Ver_Check(void)
{
	BOOL Ret = FALSE;
	char vername[1024];
	FILE *fptr=NULL;
	char line[100];
	int USBFileVer = 0;
	int FTPFileVer = 0;
	/*read usb file version start*/
	printf("\e[33m\n[<====read usb file version start!!!!!]file: %s fun: %s line: %d \e[0m\n", __FILE__, __FUNCTION__, __LINE__);

	if(!MID_FTP_AutoPlay_FilePath_SetFlag())
	{
		printf("\e[33m\n[can't find AutoPlay folder!!!!!]file: %s fun: %s line: %d \e[0m\n", __FILE__, __FUNCTION__, __LINE__);
		return FALSE;
	}
	sprintf(vername, "%s/%s", FTPFilePath, USB_VERSION_FILE);
	fptr = fopen(vername, "rb");
	if(fptr == NULL)
	{
		printf("line:%d open fail \n",__LINE__);
		bUSBVersionFileExist = FALSE;
		goto GET_FTP_FILE;
	}
	bUSBVersionFileExist = TRUE;
	memset(line, 0, 10);
	fgets(line, 10, fptr);
	fclose(fptr);
	USBFileVer = atoi (line);
	printf("\e[33m\n[<====read usb file version end!!!!!]file: %s fun: %s line: %d FileVer:%d \e[0m\n", __FILE__, __FUNCTION__, __LINE__, USBFileVer);
	/*read usb file version end*/

GET_FTP_FILE:	
	/*read ftp file version start*/
	if(MID_FTP_Get(E_MID_NWSI_FTPFILETYPE_FILE_VERSION))
	{
		printf("\e[33m\n[<====read ftp file version start!!!!!]file: %s fun: %s line: %d \e[0m\n", __FILE__, __FUNCTION__, __LINE__);
		if(bUSBVersionFileExist == FALSE)
			sprintf(vername, "%s/%s", FTPFilePath, USB_VERSION_FILE);
		else
			sprintf(vername, "%s/%s", FTPFilePath, FTP_VERSION_FILE);
		fptr = fopen(vername, "rb");
		if(fptr == NULL)
		{
			printf("line:%d open fail \n",__LINE__);
			return FALSE;
		}
		memset(line, 0, 10);
		fgets(line, 10, fptr);
		fclose(fptr);
		FTPFileVer = atoi (line);
		printf("\e[33m\n[<====read ftp file version end!!!!!]file: %s fun: %s line: %d FileVer:%d \e[0m\n", __FILE__, __FUNCTION__, __LINE__, FTPFileVer);
	}
	if(FTPFileVer > USBFileVer)
	{
		Ret = TRUE;
	}
	else
	{
		Ret = FALSE;
	}
	return Ret;
}

BOOL MID_FTP_Get(E_MID_NWSI_FTPFILETYPE FILE_TYPE)
{
	INT8 szCmd[256];
	char filename[1024];
	int DestinationFd = -1;
	BOOL Ret = TRUE;

	if(FILE_TYPE == E_MID_NWSI_FTPFILETYPE_VIDEO_FILE)		
		sprintf(filename, "%s/%s", FTPFilePath, FTP_VIDEO_FILE);
	else
		sprintf(filename, "%s/%s", FTPFilePath, FTP_VERSION_FILE);
	
	DestinationFd = open(filename, O_WRONLY |O_CREAT|O_TRUNC);
	
	if(DestinationFd < 0)
	{
		printf("\e[33m\n[*****Open fail!!!!!]file: %s fun: %s line: %d open fail:%s \e[0m\n", __FILE__, __FUNCTION__, __LINE__, strerror(errno));
		return FALSE;
	}
	if(FILE_TYPE == E_MID_NWSI_FTPFILETYPE_VIDEO_FILE)
		sprintf(szCmd, "ftpget -u ftpuser -p ORZqoo123 172.27.130.172 %s/%s /AutoPlay/024_626MHz.TS\n", FTPFilePath, FTP_VIDEO_FILE);
	else
	{
		if(bUSBVersionFileExist)
			sprintf(szCmd, "ftpget -u ftpuser -p ORZqoo123 172.27.130.172 %s/%s /AutoPlay/version.txt\n", FTPFilePath, FTP_VERSION_FILE);
		else
			sprintf(szCmd, "ftpget -u ftpuser -p ORZqoo123 172.27.130.172 %s/%s /AutoPlay/version.txt\n", FTPFilePath, USB_VERSION_FILE);
	}
	system(szCmd);
	close(DestinationFd);
	DestinationFd = 0;
	if(FILE_TYPE == E_MID_NWSI_FTPFILETYPE_VIDEO_FILE)
	{
		if(bUSBVersionFileExist)
		{
			sprintf(szCmd, "mv %s/%s %s/%s\n", FTPFilePath, FTP_VERSION_FILE, FTPFilePath, USB_VERSION_FILE);
			system(szCmd);
		}
	}
	return Ret;
}

void MID_NWSI_SetWPAPid(INT32 pid)
{
	stWPAPid = pid;
}

INT32 MID_NWSI_GetWPAPid(void)
{
	return stWPAPid;
}

